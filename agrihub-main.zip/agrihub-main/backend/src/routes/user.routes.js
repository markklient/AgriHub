import { Router } from 'express';
import { optionalAuth, requireAuth } from '../middleware/auth.js';
import {
  applyForRole,
  cancelPhoneChange,
  cancelLaborBooking,
  cancelServiceBooking,
  cancelMarketplaceOrder,
  createMarketplaceListingUploadUrl,
  createMarketplaceRefundUploadUrl,
  createMarketplaceReviewUploadUrl,
  createRentalListingUploadUrl,
  confirmMarketplaceOrderReceived,
  createLaborBooking,
  createProfileAvatarUploadUrl,
  createVerificationUploadUrl,
  downloadMarketplaceWaybill,
  getCurrentUser,
  getDashboardData,
  getLaborData,
  getMarketplaceData,
  getServicesData,
  getWalletSummary,
  markLaborBookingCompleted,
  markLaborBookingOnTheWay,
  markServiceBookingCompleted,
  markServiceBookingPickedUp,
  requestWalletCashOut,
  requestEmailChange,
  submitMarketplaceOrderReview,
  requestPhoneChange,
  requestMarketplaceOrderRefund,
  submitLaborBookingReview,
  updateMarketplaceOrderStatus,
  upsertRentalListing,
  upsertMarketplaceListing,
  upsertLaborOffer,
  updateCurrentUser,
  verifyEmailChange,
  verifyPhoneChange,
} from '../controllers/user.controller.js';
import {
  createLaborPaymentCheckout,
  createMarketplacePaymentCheckout,
  createServicePaymentCheckout,
  getLaborPaymentStatus,
  getMarketplacePaymentStatus,
  getServicePaymentStatus,
} from '../controllers/payment.controller.js';

const router = Router();

router.get('/me', requireAuth, getCurrentUser);
router.put('/me', requireAuth, updateCurrentUser);
router.get('/wallet', requireAuth, getWalletSummary);
router.post('/wallet/cashout', requireAuth, requestWalletCashOut);
router.post('/me/email-change/request', requireAuth, requestEmailChange);
router.post('/me/email-change/verify', requireAuth, verifyEmailChange);
router.post('/me/phone-change/request', requireAuth, requestPhoneChange);
router.post('/me/phone-change/verify', requireAuth, verifyPhoneChange);
router.post('/me/phone-change/cancel', requireAuth, cancelPhoneChange);
router.post('/profile/avatar/upload-url', requireAuth, createProfileAvatarUploadUrl);
router.post('/marketplace/upload-url', requireAuth, createMarketplaceListingUploadUrl);
router.post('/marketplace/review-upload-url', requireAuth, createMarketplaceReviewUploadUrl);
router.post('/marketplace/refund-upload-url', requireAuth, createMarketplaceRefundUploadUrl);
router.post('/services/upload-url', requireAuth, createRentalListingUploadUrl);
router.put('/marketplace/listing', requireAuth, upsertMarketplaceListing);
router.put('/services/listing', requireAuth, upsertRentalListing);
router.patch('/marketplace/orders/:orderId/status', requireAuth, updateMarketplaceOrderStatus);
router.get('/marketplace/orders/:orderId/waybill', requireAuth, downloadMarketplaceWaybill);
router.patch('/marketplace/orders/:orderId/cancel', requireAuth, cancelMarketplaceOrder);
router.patch('/marketplace/orders/:orderId/receive', requireAuth, confirmMarketplaceOrderReceived);
router.post('/marketplace/orders/:orderId/refund-request', requireAuth, requestMarketplaceOrderRefund);
router.post('/marketplace/orders/:orderId/review', requireAuth, submitMarketplaceOrderReview);
router.post('/verification/upload-url', requireAuth, createVerificationUploadUrl);
router.post('/roles/apply', requireAuth, applyForRole);
router.post('/labor/book', requireAuth, createLaborBooking);
router.post('/labor/payment/checkout', requireAuth, createLaborPaymentCheckout);
router.get('/labor/payment/:reference', requireAuth, getLaborPaymentStatus);
router.post('/marketplace/payment/checkout', requireAuth, createMarketplacePaymentCheckout);
router.get('/marketplace/payment/:reference', requireAuth, getMarketplacePaymentStatus);
router.post('/services/payment/checkout', requireAuth, createServicePaymentCheckout);
router.get('/services/payment/:reference', requireAuth, getServicePaymentStatus);
router.patch('/labor/book/:bookingId/cancel', requireAuth, cancelLaborBooking);
router.patch('/labor/book/:bookingId/complete', requireAuth, markLaborBookingCompleted);
router.patch('/labor/book/:bookingId/on-the-way', requireAuth, markLaborBookingOnTheWay);
router.post('/labor/book/:bookingId/review', requireAuth, submitLaborBookingReview);
router.patch('/services/book/:bookingRef/pickup', requireAuth, markServiceBookingPickedUp);
router.patch('/services/book/:bookingRef/cancel', requireAuth, cancelServiceBooking);
router.patch('/services/book/:bookingRef/complete', requireAuth, markServiceBookingCompleted);
router.put('/labor/offer', requireAuth, upsertLaborOffer);
router.get('/dashboard', requireAuth, getDashboardData);
router.get('/marketplace', optionalAuth, getMarketplaceData);
router.get('/labor', optionalAuth, getLaborData);
router.get('/services', optionalAuth, getServicesData);

export { router };
