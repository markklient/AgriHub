import { Router } from 'express';
import { getPlannerHealth, optimizeMarketplaceRoute } from '../controllers/planner.controller.js';

const router = Router();

router.get('/health', getPlannerHealth);
router.post('/logistics/marketplace-route', optimizeMarketplaceRoute);

export { router };
