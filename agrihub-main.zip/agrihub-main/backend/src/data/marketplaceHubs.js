import { MarketplaceHub } from '../models/MarketplaceHub.js';

function trimValue(value = '') {
  return String(value || '').trim();
}

function normalizeCoordinatePair(coordinates = {}) {
  const lat = Number(coordinates?.lat);
  const lng = Number(coordinates?.lng);

  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    return {
      lat: null,
      lng: null,
    };
  }

  return { lat, lng };
}

function hasCoordinates(coordinates = {}) {
  const normalized = normalizeCoordinatePair(coordinates);
  return normalized.lat !== null && normalized.lng !== null;
}

function normalizeAreaToken(value = '') {
  return String(value || '')
    .toLowerCase()
    .replace(/\bphilippines\b/g, '')
    .replace(/\bprovince\b/g, '')
    .replace(/\bcity\b/g, '')
    .replace(/\bmunicipality\b/g, '')
    .replace(/[0-9]/g, ' ')
    .replace(/[^a-z\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractAreaTokens(address = '') {
  return String(address || '')
    .split(',')
    .map((part) => normalizeAreaToken(part))
    .filter(Boolean);
}

function calculateCoordinateDistanceKm(first = {}, second = {}) {
  if (!hasCoordinates(first) || !hasCoordinates(second)) {
    return Number.POSITIVE_INFINITY;
  }

  const earthRadiusKm = 6371;
  const deltaLat = ((Number(second.lat) - Number(first.lat)) * Math.PI) / 180;
  const deltaLng = ((Number(second.lng) - Number(first.lng)) * Math.PI) / 180;
  const firstLatRadians = (Number(first.lat) * Math.PI) / 180;
  const secondLatRadians = (Number(second.lat) * Math.PI) / 180;
  const a =
    Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(firstLatRadians) *
      Math.cos(secondLatRadians) *
      Math.sin(deltaLng / 2) *
      Math.sin(deltaLng / 2);

  return earthRadiusKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function findNearestGeometryIndex(routeGeometry = [], coordinates = {}) {
  if (!Array.isArray(routeGeometry) || routeGeometry.length === 0 || !hasCoordinates(coordinates)) {
    return -1;
  }

  return routeGeometry.reduce((bestIndex, point, index) => {
    const currentDistance = calculateCoordinateDistanceKm(point, coordinates);
    const bestDistance = calculateCoordinateDistanceKm(routeGeometry[bestIndex], coordinates);
    return currentDistance < bestDistance ? index : bestIndex;
  }, 0);
}

function normalizeHubDocument(hub = {}) {
  return {
    id: trimValue(hub?.code) || trimValue(hub?._id),
    provider: trimValue(hub?.provider),
    type: trimValue(hub?.type) === 'delivery' ? 'delivery' : 'sorting',
    name: trimValue(hub?.name) || trimValue(hub?.code) || 'Marketplace hub',
    address: trimValue(hub?.address),
    coordinates: normalizeCoordinatePair(hub?.coordinates || {}),
    serviceAreas: Array.isArray(hub?.serviceAreas)
      ? hub.serviceAreas.map((area) => normalizeAreaToken(area)).filter(Boolean)
      : [],
  };
}

export async function listMarketplaceHubs() {
  const hubs = await MarketplaceHub.find({ active: true }).lean();
  return hubs.map(normalizeHubDocument).filter((hub) => hasCoordinates(hub.coordinates));
}

export async function findMarketplaceRouteHubs({
  sellerAddress = '',
  buyerAddress = '',
  sellerCoordinates = {},
  buyerCoordinates = {},
  routeGeometry = [],
} = {}) {
  const maxVisibleHubRouteDistanceKm = 0.35;
  const buyerAreaTokens = new Set(extractAreaTokens(buyerAddress));
  const sellerAreaTokens = new Set(extractAreaTokens(sellerAddress));
  const hubs = await listMarketplaceHubs();
  const normalizedSellerCoordinates = normalizeCoordinatePair(sellerCoordinates);
  const normalizedBuyerCoordinates = normalizeCoordinatePair(buyerCoordinates);
  const sortingHubCandidates = hubs
    .filter((hub) => hub.type === 'sorting')
    .map((hub) => {
      const nearestGeometryIndex = findNearestGeometryIndex(routeGeometry, hub.coordinates);
      const nearestPoint = nearestGeometryIndex >= 0 ? routeGeometry[nearestGeometryIndex] : null;
      const routeDistanceKm = nearestPoint
        ? calculateCoordinateDistanceKm(nearestPoint, hub.coordinates)
        : Number.POSITIVE_INFINITY;
      const sellerDistanceKm = hasCoordinates(normalizedSellerCoordinates)
        ? calculateCoordinateDistanceKm(normalizedSellerCoordinates, hub.coordinates)
        : Number.POSITIVE_INFINITY;
      const servicesBuyerArea = hub.serviceAreas.some((area) => buyerAreaTokens.has(area));
      const servicesSellerArea = hub.serviceAreas.some((area) => sellerAreaTokens.has(area));
      const matchesArea = hub.serviceAreas.length === 0 || servicesBuyerArea || servicesSellerArea;

      if (!matchesArea) {
        return null;
      }

      return {
        ...hub,
        nearestGeometryIndex,
        routeDistanceKm,
        sellerDistanceKm,
      };
    })
    .filter(Boolean);

  const matchedRouteSortingHubs = sortingHubCandidates
    .filter((hub) => hub.routeDistanceKm <= maxVisibleHubRouteDistanceKm);
  const matchedDeliveryHubs = hubs
    .filter((hub) => hub.type === 'delivery')
    .map((hub) => {
      const buyerDistanceKm = hasCoordinates(normalizedBuyerCoordinates)
        ? calculateCoordinateDistanceKm(normalizedBuyerCoordinates, hub.coordinates)
        : Number.POSITIVE_INFINITY;
      const nearestGeometryIndex = findNearestGeometryIndex(routeGeometry, hub.coordinates);
      const nearestPoint = nearestGeometryIndex >= 0 ? routeGeometry[nearestGeometryIndex] : null;
      const routeDistanceKm = nearestPoint
        ? calculateCoordinateDistanceKm(nearestPoint, hub.coordinates)
        : Number.POSITIVE_INFINITY;
      const servicesBuyerArea = hub.serviceAreas.some((area) => buyerAreaTokens.has(area));
      const areaBoost = servicesBuyerArea ? 0 : 1000;

      return {
        ...hub,
        buyerDistanceKm,
        routeDistanceKm,
        areaBoost,
      };
    })
    .filter((hub) => hub.routeDistanceKm <= maxVisibleHubRouteDistanceKm)
    .sort((left, right) => {
      if (left.areaBoost !== right.areaBoost) {
        return left.areaBoost - right.areaBoost;
      }

      return left.buyerDistanceKm - right.buyerDistanceKm;
    });

  const sortingHubs = [...matchedRouteSortingHubs];

  const orderedSortingHubs = sortingHubs.sort((left, right) => {
    if (left.nearestGeometryIndex !== right.nearestGeometryIndex) {
      return left.nearestGeometryIndex - right.nearestGeometryIndex;
    }

    return left.routeDistanceKm - right.routeDistanceKm;
  });

  return {
    sortingHubs: orderedSortingHubs,
    deliveryHub: matchedDeliveryHubs[0] || null,
  };
}
