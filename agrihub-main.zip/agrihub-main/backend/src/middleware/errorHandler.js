export function notFoundHandler(req, res) {
  res.status(404).json({
    message: 'The requested action is not available right now.',
  });
}

export function errorHandler(error, _req, res, _next) {
  console.error(error);

  const status = Number(error?.status || error?.statusCode || 0);
  const isJsonParseError = error?.type === 'entity.parse.failed';

  res.status(isJsonParseError ? 400 : status >= 400 ? status : 500).json({
    message: isJsonParseError ? 'Malformed JSON request body.' : error.message || 'Internal server error.',
  });
}
