import fs from 'fs/promises';
import path from 'path';
import mongoose from 'mongoose';
import { MarketplaceHub } from '../models/MarketplaceHub.js';

function slugify(value = '') {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .trim();
}

function normalizeHubRecord(record = {}) {
  const provider = String(record.provider || '').trim().toLowerCase();
  const lat = Number(record?.coordinates?.lat ?? record?.lat);
  const lng = Number(record?.coordinates?.lng ?? record?.lng);
  const fallbackCode = `${slugify(record.name || 'hub')}-${String(lat).replace(/[^0-9]/g, '').slice(0, 8)}-${String(lng).replace(/[^0-9]/g, '').slice(0, 8)}`;
  const code = String(record.code || record.id || fallbackCode).trim();
  const name = String(record.name || '').trim();
  const type = String(record.type || '').trim().toLowerCase() === 'delivery' ? 'delivery' : 'sorting';
  const address = String(record.address || '').trim();
  const province = String(record.province || '').trim();
  const city = String(record.city || '').trim();
  const barangay = String(record.barangay || '').trim();
  const serviceAreas = Array.isArray(record.serviceAreas)
    ? record.serviceAreas.map((value) => String(value || '').trim()).filter(Boolean)
    : [];

  if (!provider || !code || !name || !Number.isFinite(lat) || !Number.isFinite(lng)) {
    return null;
  }

  return {
    provider,
    code,
    name,
    type,
    address,
    province,
    city,
    barangay,
    serviceAreas,
    coordinates: { lat, lng },
    metadata: typeof record.metadata === 'object' && record.metadata ? record.metadata : {},
    active: record.active !== false,
  };
}

async function main() {
  const mongoUri = process.env.MONGODB_URI;

  if (!mongoUri) {
    throw new Error('MONGODB_URI is missing. Add it to your environment variables or .env file.');
  }

  const inputPath = process.argv[2]
    ? path.resolve(process.argv[2])
    : path.resolve(process.cwd(), 'src', 'data', 'marketplace-hubs.seed.json');
  const raw = await fs.readFile(inputPath, 'utf8');
  const parsed = JSON.parse(raw);
  const records = Array.isArray(parsed) ? parsed : [];
  const normalizedRecords = records.map(normalizeHubRecord).filter(Boolean);

  await mongoose.connect(mongoUri);

  for (const record of normalizedRecords) {
    await MarketplaceHub.findOneAndUpdate(
      { provider: record.provider, code: record.code },
      { $set: record },
      { upsert: true, new: true },
    );
  }

  console.log(JSON.stringify({
    imported: normalizedRecords.length,
    source: inputPath,
  }, null, 2));

  await mongoose.disconnect();
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
