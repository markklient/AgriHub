import mongoose from 'mongoose';

const marketplaceReviewSchema = new mongoose.Schema(
  {
    id: {
      type: String,
      default: '',
      trim: true,
    },
    author: {
      type: String,
      default: '',
      trim: true,
    },
    authorUserId: {
      type: String,
      default: '',
      trim: true,
    },
    rating: {
      type: Number,
      default: 0,
    },
    comment: {
      type: String,
      default: '',
      trim: true,
    },
    imagePaths: {
      type: [String],
      default: [],
    },
    imageUrls: {
      type: [String],
      default: [],
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: false },
);

const marketplaceVarietySchema = new mongoose.Schema(
  {
    id: {
      type: String,
      default: '',
      trim: true,
    },
    label: {
      type: String,
      default: '',
      trim: true,
    },
    price: {
      type: Number,
      default: 0,
    },
    stock: {
      type: Number,
      default: 0,
    },
  },
  { _id: false },
);

const marketplaceListingSchema = new mongoose.Schema(
  {
    listingId: String,
    name: String,
    category: String,
    description: String,
    brand: String,
    variety: String,
    condition: String,
    harvestDate: String,
    location: String,
    price: Number,
    unit: String,
    stock: Number,
    minimumOrder: Number,
    varieties: {
      type: [marketplaceVarietySchema],
      default: [],
    },
    image: String,
    imagePaths: {
      type: [String],
      default: [],
    },
    reviews: {
      type: [marketplaceReviewSchema],
      default: [],
    },
    rating: Number,
    status: {
      type: String,
      default: 'active',
    },
    views: {
      type: Number,
      default: 0,
    },
    orders: {
      type: Number,
      default: 0,
    },
  },
  { _id: false },
);

const marketplaceOrderSchema = new mongoose.Schema(
  {
    orderId: {
      type: String,
      default: '',
      trim: true,
    },
    paymentReference: {
      type: String,
      default: '',
      trim: true,
    },
    listingId: {
      type: String,
      default: '',
      trim: true,
    },
    sellerUserId: {
      type: String,
      default: '',
      trim: true,
    },
    buyerUserId: {
      type: String,
      default: '',
      trim: true,
    },
    sellerName: {
      type: String,
      default: '',
      trim: true,
    },
    sellerEmail: {
      type: String,
      default: '',
      trim: true,
      lowercase: true,
    },
    sellerPhone: {
      type: String,
      default: '',
      trim: true,
    },
    sellerAddress: {
      type: String,
      default: '',
      trim: true,
    },
    sellerCoordinates: {
      lat: {
        type: Number,
        default: null,
      },
      lng: {
        type: Number,
        default: null,
      },
    },
    buyerName: {
      type: String,
      default: '',
      trim: true,
    },
    buyerPhone: {
      type: String,
      default: '',
      trim: true,
    },
    buyerAddress: {
      type: String,
      default: '',
      trim: true,
    },
    buyerCoordinates: {
      lat: {
        type: Number,
        default: null,
      },
      lng: {
        type: Number,
        default: null,
      },
    },
    itemName: {
      type: String,
      default: '',
      trim: true,
    },
    category: {
      type: String,
      default: '',
      trim: true,
    },
    unit: {
      type: String,
      default: '',
      trim: true,
    },
    quantity: {
      type: Number,
      default: 0,
    },
    price: {
      type: Number,
      default: 0,
    },
    subtotal: {
      type: Number,
      default: 0,
    },
    tax: {
      type: Number,
      default: 0,
    },
    shipping: {
      type: Number,
      default: 0,
    },
    totalPaid: {
      type: Number,
      default: 0,
    },
    paymentMethod: {
      type: String,
      default: '',
      trim: true,
    },
    location: {
      type: String,
      default: '',
      trim: true,
    },
    imagePath: {
      type: String,
      default: '',
      trim: true,
    },
    selectedVarietyId: {
      type: String,
      default: '',
      trim: true,
    },
    selectedVarietyLabel: {
      type: String,
      default: '',
      trim: true,
    },
    status: {
      type: String,
      enum: ['paid', 'preparing', 'ready_for_pickup', 'in_transit', 'received', 'completed', 'cancelled', 'return_refund'],
      default: 'paid',
    },
    reviewed: {
      type: Boolean,
      default: false,
    },
    reviewRating: {
      type: Number,
      default: 0,
    },
    reviewComment: {
      type: String,
      default: '',
      trim: true,
    },
    reviewImagePaths: {
      type: [String],
      default: [],
    },
    reviewImageUrls: {
      type: [String],
      default: [],
    },
    sellerPayoutStatus: {
      type: String,
      enum: ['pending', 'released'],
      default: 'pending',
    },
    sellerPayoutAmount: {
      type: Number,
      default: 0,
    },
    sellerPayoutReleasedAt: {
      type: Date,
      default: null,
    },
    sellerPayoutTransactionId: {
      type: String,
      default: '',
      trim: true,
    },
    paidAt: {
      type: Date,
      default: null,
    },
    preparingAt: {
      type: Date,
      default: null,
    },
    readyForPickupAt: {
      type: Date,
      default: null,
    },
    inTransitAt: {
      type: Date,
      default: null,
    },
    receivedAt: {
      type: Date,
      default: null,
    },
    completedAt: {
      type: Date,
      default: null,
    },
    cancelledAt: {
      type: Date,
      default: null,
    },
    cancellationReason: {
      type: String,
      default: '',
      trim: true,
    },
    cancelledBy: {
      type: String,
      default: '',
      trim: true,
    },
    refundRequest: {
      status: {
        type: String,
        enum: ['none', 'pending', 'approved', 'rejected'],
        default: 'none',
      },
      reason: {
        type: String,
        default: '',
        trim: true,
      },
      imagePaths: {
        type: [String],
        default: [],
      },
      imageUrls: {
        type: [String],
        default: [],
      },
      requestedAt: {
        type: Date,
        default: null,
      },
      reviewedAt: {
        type: Date,
        default: null,
      },
      reviewedByUserId: {
        type: String,
        default: '',
        trim: true,
      },
      reviewedByName: {
        type: String,
        default: '',
        trim: true,
      },
      adminDecisionReason: {
        type: String,
        default: '',
        trim: true,
      },
      refundedAt: {
        type: Date,
        default: null,
      },
    },
    waybill: {
      generatedAt: {
        type: Date,
        default: null,
      },
      generatedBy: {
        type: String,
        default: '',
        trim: true,
      },
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
    logistics: {
      trackingNumber: {
        type: String,
        default: '',
        trim: true,
      },
      providerMeta: {
        eta: {
          type: String,
          default: '',
          trim: true,
        },
        geometry: {
          type: String,
          default: '',
          trim: true,
        },
        optimization: {
          type: String,
          default: '',
          trim: true,
        },
      },
      simulationEnabled: {
        type: Boolean,
        default: false,
      },
      simulationLockedReason: {
        type: String,
        default: '',
        trim: true,
      },
      currentStopIndex: {
        type: Number,
        default: 0,
      },
      progressPercent: {
        type: Number,
        default: 0,
      },
      currentLocation: {
        lat: {
          type: Number,
          default: null,
        },
        lng: {
          type: Number,
          default: null,
        },
      },
      distanceKm: {
        type: Number,
        default: 0,
      },
      durationMinutes: {
        type: Number,
        default: 0,
      },
      lastUpdatedAt: {
        type: Date,
        default: null,
      },
      estimatedArrivalAt: {
        type: Date,
        default: null,
      },
      routeGeometry: {
        type: [
          new mongoose.Schema(
            {
              lat: {
                type: Number,
                default: null,
              },
              lng: {
                type: Number,
                default: null,
              },
            },
            { _id: false },
          ),
        ],
        default: [],
      },
      routeStops: {
        type: [
          new mongoose.Schema(
            {
              id: {
                type: String,
                default: '',
                trim: true,
              },
              type: {
                type: String,
                default: '',
                trim: true,
              },
              label: {
                type: String,
                default: '',
                trim: true,
              },
              address: {
                type: String,
                default: '',
                trim: true,
              },
              coordinates: {
                lat: {
                  type: Number,
                  default: null,
                },
                lng: {
                  type: Number,
                  default: null,
                },
              },
              estimatedAt: {
                type: Date,
                default: null,
              },
              arrivedAt: {
                type: Date,
                default: null,
              },
              departedAt: {
                type: Date,
                default: null,
              },
            },
            { _id: false },
          ),
        ],
        default: [],
      },
    },
  },
  { _id: false },
);

const laborReviewSchema = new mongoose.Schema(
  {
    id: {
      type: String,
      default: '',
      trim: true,
    },
    author: {
      type: String,
      default: '',
      trim: true,
    },
    authorUserId: {
      type: String,
      default: '',
      trim: true,
    },
    rating: {
      type: Number,
      default: 0,
    },
    comment: {
      type: String,
      default: '',
      trim: true,
    },
    bookingId: {
      type: String,
      default: '',
      trim: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: false },
);

const laborBookingSchema = new mongoose.Schema(
  {
    bookingId: String,
    worker: String,
    workerId: String,
    workerEmail: String,
    workerPhone: String,
    type: String,
    date: String,
    time: String,
    duration: String,
    location: String,
    rate: Number,
    status: String,
    cost: Number,
    rating: Number,
    reviewComment: {
      type: String,
      default: '',
      trim: true,
    },
    reviewedAt: {
      type: Date,
      default: null,
    },
    bookedByUserId: String,
    bookedByName: String,
    bookedByEmail: String,
    bookedByPhone: String,
    travelTracking: {
      isOnTheWay: {
        type: Boolean,
        default: false,
      },
      startedAt: {
        type: Date,
        default: null,
      },
      updatedAt: {
        type: Date,
        default: null,
      },
      currentLocation: {
        lat: {
          type: Number,
          default: null,
        },
        lng: {
          type: Number,
          default: null,
        },
      },
    },
    completionConfirmation: {
      clientConfirmedAt: {
        type: Date,
        default: null,
      },
      workerConfirmedAt: {
        type: Date,
        default: null,
      },
    },
    completedAt: {
      type: Date,
      default: null,
    },
    cancelledAt: {
      type: Date,
      default: null,
    },
    cancellationReason: {
      type: String,
      default: '',
    },
    cancelledBy: {
      type: String,
      default: '',
    },
  },
  { _id: false },
);

const laborOfferSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      default: '',
    },
    description: {
      type: String,
      default: '',
    },
    workerType: {
      type: String,
      default: '',
    },
    rate: {
      type: Number,
      default: 0,
    },
    availability: {
      type: String,
      default: 'Available',
    },
    skills: {
      type: [String],
      default: [],
    },
    distance: {
      type: String,
      default: '',
    },
    serviceArea: {
      type: String,
      default: '',
    },
    workingHoursStart: {
      type: String,
      default: '',
    },
    workingHoursEnd: {
      type: String,
      default: '',
    },
    isPublished: {
      type: Boolean,
      default: false,
    },
    reviews: {
      type: [laborReviewSchema],
      default: [],
    },
    reviewCount: {
      type: Number,
      default: 0,
    },
    rating: {
      type: Number,
      default: 0,
    },
  },
  { _id: false },
);

const serviceItemSchema = new mongoose.Schema(
  {
    listingId: {
      type: String,
      default: '',
      trim: true,
    },
    name: {
      type: String,
      default: '',
      trim: true,
    },
    category: {
      type: String,
      default: 'equipment-rental',
      trim: true,
    },
    description: {
      type: String,
      default: '',
      trim: true,
    },
    condition: {
      type: String,
      default: '',
      trim: true,
    },
    identifier: {
      type: String,
      default: '',
      trim: true,
    },
    location: {
      type: String,
      default: '',
      trim: true,
    },
    rate: {
      type: Number,
      default: 0,
    },
    unit: {
      type: String,
      default: 'day',
      trim: true,
    },
    minimumOrder: {
      type: Number,
      default: 1,
    },
    quantity: {
      type: Number,
      default: 1,
    },
    available: {
      type: Boolean,
      default: true,
    },
    ownerRole: {
      type: String,
      default: '',
      trim: true,
    },
    status: {
      type: String,
      default: 'active',
      trim: true,
    },
    image: {
      type: String,
      default: '',
      trim: true,
    },
    imagePaths: {
      type: [String],
      default: [],
    },
  },
  { _id: false },
);

const serviceBookingSchema = new mongoose.Schema(
  {
    service: String,
    provider: String,
    providerUserId: {
      type: String,
      default: '',
      trim: true,
    },
    customer: {
      type: String,
      default: '',
      trim: true,
    },
    customerUserId: {
      type: String,
      default: '',
      trim: true,
    },
    listingId: {
      type: String,
      default: '',
      trim: true,
    },
    date: String,
    time: String,
    duration: String,
    location: String,
    status: String,
    description: String,
    rate: String,
    contact: String,
    bookingRef: String,
    pickupConfirmation: {
      customerConfirmedAt: {
        type: Date,
        default: null,
      },
      providerConfirmedAt: {
        type: Date,
        default: null,
      },
    },
    completionConfirmation: {
      customerConfirmedAt: {
        type: Date,
        default: null,
      },
      providerConfirmedAt: {
        type: Date,
        default: null,
      },
    },
    completedAt: {
      type: Date,
      default: null,
    },
    cancelledAt: {
      type: Date,
      default: null,
    },
    cancellationReason: {
      type: String,
      default: '',
      trim: true,
    },
    cancelledBy: {
      type: String,
      default: '',
      trim: true,
    },
  },
  { _id: false },
);

const operationTaskSchema = new mongoose.Schema(
  {
    id: String,
    label: String,
    icon: String,
    completed: Boolean,
  },
  { _id: false },
);

const operationSchema = new mongoose.Schema(
  {
    title: String,
    field: String,
    crop: String,
    startDate: String,
    completedDate: String,
    duration: String,
    progress: Number,
    workers: Number,
    equipment: String,
    priority: String,
    notes: String,
    estimatedDuration: String,
    status: String,
    tasks: {
      type: [operationTaskSchema],
      default: [],
    },
  },
  { _id: false },
);

const roleVerificationSchema = new mongoose.Schema(
  {
    status: {
      type: String,
      enum: ['unverified', 'pending', 'verified'],
      default: 'unverified',
    },
    submittedAt: {
      type: Date,
      default: null,
    },
    verifiedAt: {
      type: Date,
      default: null,
    },
    rejectedAt: {
      type: Date,
      default: null,
    },
    reviewReason: {
      type: String,
      default: '',
      trim: true,
    },
    documents: {
      type: [
        new mongoose.Schema(
          {
            type: {
              type: String,
              required: true,
            },
            bucket: {
              type: String,
              required: true,
            },
            path: {
              type: String,
              required: true,
            },
            originalName: {
              type: String,
              required: true,
            },
            uploadedAt: {
              type: Date,
              default: Date.now,
            },
          },
          { _id: false },
        ),
      ],
      default: [],
    },
    details: {
      idType: {
        type: String,
        default: '',
      },
      idNumber: {
        type: String,
        default: '',
      },
      farmProofType: {
        type: String,
        default: '',
      },
      profileAddress: {
        type: String,
        default: '',
      },
      addressConfirmed: {
        type: Boolean,
        default: false,
      },
      selfieConfirmed: {
        type: Boolean,
        default: false,
      },
      riskAccepted: {
        type: Boolean,
        default: false,
      },
      consentAccepted: {
        type: Boolean,
        default: false,
      },
      experience: {
        type: String,
        default: '',
      },
      description: {
        type: String,
        default: '',
      },
      laborProofType: {
        type: String,
        default: '',
      },
      skills: {
        type: [String],
        default: [],
      },
    },
  },
  { _id: false },
);

const activityLogSchema = new mongoose.Schema(
  {
    description: {
      type: String,
      required: true,
      trim: true,
    },
    status: {
      type: String,
      enum: ['completed', 'confirmed', 'pending', 'cancelled'],
      default: 'confirmed',
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: false },
);

const passwordResetSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      default: '',
    },
    expiresAt: {
      type: Date,
      default: null,
    },
    verifiedAt: {
      type: Date,
      default: null,
    },
    requestedAt: {
      type: Date,
      default: null,
    },
  },
  { _id: false },
);

const emailVerificationSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      default: '',
    },
    expiresAt: {
      type: Date,
      default: null,
    },
    requestedAt: {
      type: Date,
      default: null,
    },
    verifiedAt: {
      type: Date,
      default: null,
    },
    pendingEmail: {
      type: String,
      default: '',
      lowercase: true,
      trim: true,
    },
  },
  { _id: false },
);

const phoneVerificationSchema = new mongoose.Schema(
  {
    status: {
      type: String,
      enum: ['unverified', 'verified'],
      default: 'unverified',
    },
    source: {
      type: String,
      default: 'email',
      trim: true,
    },
    code: {
      type: String,
      default: '',
    },
    expiresAt: {
      type: Date,
      default: null,
    },
    requestedAt: {
      type: Date,
      default: null,
    },
    verifiedAt: {
      type: Date,
      default: null,
    },
    pendingPhone: {
      type: String,
      default: '',
      trim: true,
    },
  },
  { _id: false },
);

const paymentMethodSchema = new mongoose.Schema(
  {
    accountName: {
      type: String,
      default: '',
      trim: true,
    },
    mobileNumber: {
      type: String,
      default: '',
      trim: true,
    },
    cardholderName: {
      type: String,
      default: '',
      trim: true,
    },
    brand: {
      type: String,
      default: '',
      trim: true,
    },
    last4: {
      type: String,
      default: '',
      trim: true,
    },
  },
  { _id: false },
);

const walletTransactionSchema = new mongoose.Schema(
  {
    id: {
      type: String,
      required: true,
      trim: true,
    },
    type: {
      type: String,
      enum: ['credit', 'cashout', 'payment'],
      required: true,
    },
    amount: {
      type: Number,
      default: 0,
    },
    status: {
      type: String,
      enum: ['completed', 'pending', 'failed'],
      default: 'completed',
    },
    method: {
      type: String,
      default: '',
      trim: true,
    },
    description: {
      type: String,
      default: '',
      trim: true,
    },
    reference: {
      type: String,
      default: '',
      trim: true,
    },
    destinationLabel: {
      type: String,
      default: '',
      trim: true,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: false },
);

const walletSchema = new mongoose.Schema(
  {
    balance: {
      type: Number,
      default: 0,
    },
    totalEarned: {
      type: Number,
      default: 0,
    },
    totalWithdrawn: {
      type: Number,
      default: 0,
    },
    transactions: {
      type: [walletTransactionSchema],
      default: [],
    },
  },
  { _id: false },
);

const penaltySchema = new mongoose.Schema(
  {
    status: {
      type: String,
      enum: ['good', 'warned', 'restricted', 'suspended'],
      default: 'good',
    },
    reason: {
      type: String,
      default: '',
      trim: true,
    },
    notes: {
      type: String,
      default: '',
      trim: true,
    },
    penalizedAt: {
      type: Date,
      default: null,
    },
    expiresAt: {
      type: Date,
      default: null,
    },
    penalizedBy: {
      type: String,
      default: '',
      trim: true,
    },
  },
  { _id: false },
);

const penaltyHistorySchema = new mongoose.Schema(
  {
    status: {
      type: String,
      enum: ['good', 'warned', 'restricted', 'suspended'],
      required: true,
    },
    reason: {
      type: String,
      default: '',
      trim: true,
    },
    notes: {
      type: String,
      default: '',
      trim: true,
    },
    penalizedAt: {
      type: Date,
      default: Date.now,
    },
    expiresAt: {
      type: Date,
      default: null,
    },
    penalizedBy: {
      type: String,
      default: '',
      trim: true,
    },
  },
  { _id: false },
);

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    phone: {
      type: String,
      trim: true,
      default: '',
    },
    passwordHash: {
      type: String,
      default: null,
    },
    googleId: {
      type: String,
      default: undefined,
    },
    emailVerified: {
      type: Boolean,
      default: false,
    },
    role: {
      type: String,
      enum: ['user', 'admin'],
      default: 'user',
    },
    roles: {
      type: [String],
      enum: ['buyer', 'seller', 'laborer', 'service', 'operations', 'admin'],
      default: ['buyer'],
    },
    accountType: {
      type: String,
      enum: ['customer', 'vendor', 'laborer', 'service', 'operations', 'admin'],
      default: 'customer',
    },
    accountStatus: {
      type: String,
      enum: ['active', 'disabled'],
      default: 'active',
    },
    disabledAt: {
      type: Date,
      default: null,
    },
    disabledReason: {
      type: String,
      default: '',
      trim: true,
    },
    pendingDisableAt: {
      type: Date,
      default: null,
    },
    pendingDisableReason: {
      type: String,
      default: '',
      trim: true,
    },
    pendingDeleteAt: {
      type: Date,
      default: null,
    },
    pendingDeleteReason: {
      type: String,
      default: '',
      trim: true,
    },
    verification: {
      seller: {
        type: roleVerificationSchema,
        default: () => ({}),
      },
      laborer: {
        type: roleVerificationSchema,
        default: () => ({}),
      },
    },
    activityLog: {
      type: [activityLogSchema],
      default: [],
    },
    passwordReset: {
      type: passwordResetSchema,
      default: () => ({}),
    },
    emailVerification: {
      type: emailVerificationSchema,
      default: () => ({}),
    },
    phoneVerification: {
      type: phoneVerificationSchema,
      default: () => ({}),
    },
    paymentMethods: {
      gcash: {
        type: paymentMethodSchema,
        default: () => ({}),
      },
      paymaya: {
        type: paymentMethodSchema,
        default: () => ({}),
      },
      card: {
        type: paymentMethodSchema,
        default: () => ({}),
      },
    },
    wallet: {
      type: walletSchema,
      default: () => ({}),
    },
    penalty: {
      type: penaltySchema,
      default: () => ({}),
    },
    penaltyHistory: {
      type: [penaltyHistorySchema],
      default: [],
    },
    profile: {
      firstName: {
        type: String,
        default: '',
      },
      middleName: {
        type: String,
        default: '',
      },
      lastName: {
        type: String,
        default: '',
      },
      age: {
        type: String,
        default: '',
      },
      gender: {
        type: String,
        default: '',
      },
      dateOfBirth: {
        type: String,
        default: '',
      },
      civilStatus: {
        type: String,
        default: '',
      },
      nationality: {
        type: String,
        default: '',
      },
      emergencyContactName: {
        type: String,
        default: '',
      },
      emergencyContactPhone: {
        type: String,
        default: '',
      },
      address: {
        type: String,
        default: '',
      },
      streetAddress: {
        type: String,
        default: '',
      },
      city: {
        type: String,
        default: '',
      },
      state: {
        type: String,
        default: '',
      },
      postalCode: {
        type: String,
        default: '',
      },
      country: {
        type: String,
        default: '',
      },
      farmName: {
        type: String,
        default: '',
      },
      location: {
        type: String,
        default: '',
      },
      coordinates: {
        lat: {
          type: Number,
          default: null,
        },
        lng: {
          type: Number,
          default: null,
        },
      },
      farmSize: {
        type: String,
        default: '',
      },
      experience: {
        type: String,
        default: '',
      },
      specialization: {
        type: String,
        default: '',
      },
      avatarPath: {
        type: String,
        default: '',
      },
      avatarUrl: {
        type: String,
        default: '',
      },
    },
    marketplaceListings: {
      type: [marketplaceListingSchema],
      default: [],
    },
    marketplaceOrders: {
      purchases: {
        type: [marketplaceOrderSchema],
        default: [],
      },
      sales: {
        type: [marketplaceOrderSchema],
        default: [],
      },
    },
    laborBookings: {
      activeBookings: {
        type: [laborBookingSchema],
        default: [],
      },
      bookingHistory: {
        type: [laborBookingSchema],
        default: [],
      },
    },
    laborProfile: {
      title: {
        type: String,
        default: '',
      },
      description: {
        type: String,
        default: '',
      },
      workerType: {
        type: String,
        default: '',
      },
      rate: {
        type: Number,
        default: 0,
      },
      availability: {
        type: String,
        default: 'Available',
      },
      skills: {
        type: [String],
        default: [],
      },
      distance: {
        type: String,
        default: '',
      },
      serviceArea: {
        type: String,
        default: '',
      },
      rating: {
        type: Number,
        default: 0,
      },
      isPublished: {
        type: Boolean,
        default: false,
      },
      listings: {
        type: [laborOfferSchema],
        default: [],
      },
      activeBookings: {
        type: [laborBookingSchema],
        default: [],
      },
      bookingHistory: {
        type: [laborBookingSchema],
        default: [],
      },
    },
    serviceProfile: {
      category: {
        type: String,
        default: '',
      },
      services: {
        type: [serviceItemSchema],
        default: [],
      },
      bookings: {
        type: [serviceBookingSchema],
        default: [],
      },
      incomingBookings: {
        type: [serviceBookingSchema],
        default: [],
      },
    },
    operationsProfile: {
      fields: {
        type: [
          new mongoose.Schema(
            {
              id: String,
              name: String,
              area: Number,
              crop: String,
              status: String,
            },
            { _id: false },
          ),
        ],
        default: [],
      },
      activeOperations: {
        type: [operationSchema],
        default: [],
      },
      plannedOperations: {
        type: [operationSchema],
        default: [],
      },
      completedOperations: {
        type: [operationSchema],
        default: [],
      },
    },
  },
  {
    timestamps: true,
  },
);

userSchema.index(
  { googleId: 1 },
  {
    unique: true,
    partialFilterExpression: {
      googleId: {
        $type: 'string',
      },
    },
  },
);

export const User = mongoose.model('User', userSchema);
