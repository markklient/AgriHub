import mongoose from 'mongoose';

const platformSettingSchema = new mongoose.Schema(
  {
    key: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    value: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
    },
    updatedBy: {
      type: String,
      default: '',
      trim: true,
    },
  },
  {
    timestamps: true,
  },
);

export const PlatformSetting = mongoose.model('PlatformSetting', platformSettingSchema);

export const WALLET_CASHOUT_REAL_ENABLED_KEY = 'wallet_cashout_real_enabled';

export async function getWalletCashOutRealEnabled() {
  const setting = await PlatformSetting.findOne({ key: WALLET_CASHOUT_REAL_ENABLED_KEY });
  return Boolean(setting?.value);
}

export async function setWalletCashOutRealEnabled(enabled, updatedBy = '') {
  const setting = await PlatformSetting.findOneAndUpdate(
    { key: WALLET_CASHOUT_REAL_ENABLED_KEY },
    {
      $set: {
        value: Boolean(enabled),
        updatedBy: String(updatedBy || '').trim(),
      },
    },
    {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    },
  );

  return Boolean(setting?.value);
}
