import mongoose from 'mongoose';

const marketplaceHubSchema = new mongoose.Schema(
  {
    provider: {
      type: String,
      default: '',
      trim: true,
      lowercase: true,
    },
    code: {
      type: String,
      default: '',
      trim: true,
    },
    name: {
      type: String,
      default: '',
      trim: true,
    },
    type: {
      type: String,
      enum: ['sorting', 'delivery'],
      default: 'sorting',
    },
    address: {
      type: String,
      default: '',
      trim: true,
    },
    province: {
      type: String,
      default: '',
      trim: true,
    },
    city: {
      type: String,
      default: '',
      trim: true,
    },
    barangay: {
      type: String,
      default: '',
      trim: true,
    },
    serviceAreas: {
      type: [String],
      default: [],
    },
    coordinates: {
      lat: {
        type: Number,
        default: null,
      },
      lng: {
        type: Number,
        default: null,
      },
    },
    metadata: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },
    active: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
    collection: 'marketplace_hubs',
  },
);

marketplaceHubSchema.index({ provider: 1, code: 1 }, { unique: true, sparse: true });
marketplaceHubSchema.index({ provider: 1, type: 1, city: 1, province: 1 });
marketplaceHubSchema.index({ active: 1 });

export const MarketplaceHub = mongoose.models.MarketplaceHub
  || mongoose.model('MarketplaceHub', marketplaceHubSchema);

