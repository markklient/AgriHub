import mongoose from 'mongoose';

const pendingRegistrationSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },
    name: {
      type: String,
      default: '',
      trim: true,
    },
    phone: {
      type: String,
      default: '',
      trim: true,
    },
    passwordHash: {
      type: String,
      required: true,
      minlength: 6,
    },
    role: {
      type: String,
      default: 'user',
      trim: true,
    },
    roles: {
      type: [String],
      default: ['buyer'],
    },
    accountType: {
      type: String,
      default: 'customer',
      trim: true,
    },
    profile: {
      firstName: {
        type: String,
        default: '',
        trim: true,
      },
      middleName: {
        type: String,
        default: '',
        trim: true,
      },
      lastName: {
        type: String,
        default: '',
        trim: true,
      },
    },
    emailVerification: {
      code: {
        type: String,
        default: '',
        trim: true,
      },
      expiresAt: {
        type: Date,
        default: null,
      },
      requestedAt: {
        type: Date,
        default: null,
      },
    },
  },
  {
    timestamps: true,
  },
);

export const PendingRegistration = mongoose.model('PendingRegistration', pendingRegistrationSchema);
