import mongoose from 'mongoose';

const servicePaymentSchema = new mongoose.Schema(
  {
    reference: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    status: {
      type: String,
      enum: [
        'pending_checkout',
        'awaiting_payment',
        'paid',
        'booking_created',
        'expired',
        'failed',
        'ready_for_release',
        'released',
        'refunded',
      ],
      default: 'pending_checkout',
    },
    paymentMethod: {
      type: String,
      default: '',
    },
    paymentProvider: {
      type: String,
      default: 'xendit',
    },
    buyerUserId: {
      type: String,
      default: '',
      index: true,
    },
    buyerName: {
      type: String,
      default: '',
    },
    buyerEmail: {
      type: String,
      default: '',
    },
    buyerPhone: {
      type: String,
      default: '',
    },
    providerUserId: {
      type: String,
      default: '',
      index: true,
    },
    providerName: {
      type: String,
      default: '',
    },
    providerEmail: {
      type: String,
      default: '',
    },
    providerPhone: {
      type: String,
      default: '',
    },
    listingId: {
      type: String,
      default: '',
      index: true,
    },
    itemName: {
      type: String,
      default: '',
    },
    itemUnit: {
      type: String,
      default: '',
    },
    bookingDate: {
      type: String,
      default: '',
    },
    bookingTime: {
      type: String,
      default: '',
    },
    bookingDuration: {
      type: String,
      default: '',
    },
    bookingLocation: {
      type: String,
      default: '',
    },
    bookingNotes: {
      type: String,
      default: '',
    },
    bookingRef: {
      type: String,
      default: '',
      index: true,
    },
    rate: {
      type: Number,
      default: 0,
    },
    subtotal: {
      type: Number,
      default: 0,
    },
    tax: {
      type: Number,
      default: 0,
    },
    total: {
      type: Number,
      default: 0,
    },
    checkoutUrl: {
      type: String,
      default: '',
    },
    xenditInvoiceId: {
      type: String,
      default: '',
      index: true,
    },
    xenditInvoiceStatus: {
      type: String,
      default: '',
    },
    xenditWebhookPayload: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
    },
    paidAt: {
      type: Date,
      default: null,
    },
    bookingCreatedAt: {
      type: Date,
      default: null,
    },
    releasedAt: {
      type: Date,
      default: null,
    },
    releaseStatus: {
      type: String,
      enum: ['not_ready', 'ready', 'pending', 'released', 'failed'],
      default: 'not_ready',
    },
    releaseFailureReason: {
      type: String,
      default: '',
    },
    refundStatus: {
      type: String,
      enum: ['not_requested', 'refunded'],
      default: 'not_requested',
    },
    refundedAt: {
      type: Date,
      default: null,
    },
    metadata: {
      type: mongoose.Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
  },
);

export const ServicePayment = mongoose.model('ServicePayment', servicePaymentSchema);
