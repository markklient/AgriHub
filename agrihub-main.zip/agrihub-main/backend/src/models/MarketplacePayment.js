import mongoose from 'mongoose';

const marketplacePaymentItemSchema = new mongoose.Schema(
  {
    id: {
      type: String,
      default: '',
      trim: true,
    },
    name: {
      type: String,
      default: '',
      trim: true,
    },
    category: {
      type: String,
      default: '',
      trim: true,
    },
    seller: {
      type: String,
      default: '',
      trim: true,
    },
    sellerUserId: {
      type: String,
      default: '',
      trim: true,
    },
    listingId: {
      type: String,
      default: '',
      trim: true,
    },
    selectedVarietyId: {
      type: String,
      default: '',
      trim: true,
    },
    quantity: {
      type: Number,
      default: 0,
    },
    unit: {
      type: String,
      default: '',
      trim: true,
    },
    price: {
      type: Number,
      default: 0,
    },
    total: {
      type: Number,
      default: 0,
    },
  },
  { _id: false },
);

const marketplacePaymentSchema = new mongoose.Schema(
  {
    reference: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    status: {
      type: String,
      enum: ['pending_checkout', 'awaiting_payment', 'paid', 'expired', 'failed'],
      default: 'pending_checkout',
    },
    paymentMethod: {
      type: String,
      default: '',
      trim: true,
    },
    paymentProvider: {
      type: String,
      default: 'xendit',
      trim: true,
    },
    buyerUserId: {
      type: String,
      required: true,
      trim: true,
    },
    buyerName: {
      type: String,
      default: '',
      trim: true,
    },
    buyerEmail: {
      type: String,
      default: '',
      trim: true,
      lowercase: true,
    },
    buyerPhone: {
      type: String,
      default: '',
      trim: true,
    },
    items: {
      type: [marketplacePaymentItemSchema],
      default: [],
    },
    subtotal: {
      type: Number,
      default: 0,
    },
    tax: {
      type: Number,
      default: 0,
    },
    shipping: {
      type: Number,
      default: 0,
    },
    total: {
      type: Number,
      default: 0,
    },
    checkoutUrl: {
      type: String,
      default: '',
      trim: true,
    },
    xenditInvoiceId: {
      type: String,
      default: '',
      trim: true,
    },
    xenditInvoiceStatus: {
      type: String,
      default: '',
      trim: true,
    },
    xenditWebhookPayload: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
    },
    paidAt: {
      type: Date,
      default: null,
    },
    fulfillmentStatus: {
      type: String,
      enum: ['pending', 'completed', 'failed'],
      default: 'pending',
    },
    fulfilledAt: {
      type: Date,
      default: null,
    },
    releasedAt: {
      type: Date,
      default: null,
    },
    releasedOrderIds: {
      type: [String],
      default: [],
    },
    fulfillmentFailureReason: {
      type: String,
      default: '',
      trim: true,
    },
  },
  {
    timestamps: true,
  },
);

export const MarketplacePayment = mongoose.model('MarketplacePayment', marketplacePaymentSchema);
