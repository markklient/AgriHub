import './config/env.js';
import app from './app.js';
import { connectToDatabase } from './config/db.js';
import { seedDemoData } from './config/seedDemoData.js';

const port = Number(process.env.PORT) || 5000;

async function startServer() {
  console.log('Starting backend server...');
  console.log(`Runtime port: ${port}`);
  console.log(`MongoDB URI configured: ${Boolean(process.env.MONGODB_URI)}`);
  console.log(`JWT secret configured: ${Boolean(process.env.JWT_SECRET)}`);
  console.log(`Primary client URL configured: ${Boolean(process.env.CLIENT_URL)}`);

  console.log('Connecting to MongoDB...');
  await connectToDatabase();

  console.log('MongoDB connection established. Seeding demo data cleanup...');
  await seedDemoData();

  console.log('Startup preparation complete. Launching HTTP server...');

  app.listen(port, () => {
    console.log(`Backend listening on http://localhost:${port}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start backend:', error?.stack || error?.message || error);
  process.exit(1);
});
