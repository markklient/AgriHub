function toNumber(value) {
  if (value === null || value === undefined || value === '') {
    return null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function parsePlannerBody(body) {
  if (!body) {
    return {};
  }

  if (typeof body === 'object' && !Array.isArray(body)) {
    return body;
  }

  if (typeof body !== 'string') {
    throw new Error('Planner payload must be a JSON object.');
  }

  const trimmedBody = body.trim();

  if (!trimmedBody) {
    return {};
  }

  try {
    const parsed = JSON.parse(trimmedBody);

    if (typeof parsed === 'string') {
      return JSON.parse(parsed);
    }

    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    const error = new Error('Malformed planner JSON payload.');
    error.status = 400;
    throw error;
  }
}

function normalizeCoordinates(input = {}) {
  const lat = toNumber(input?.lat);
  const lng = toNumber(input?.lng);

  if (lat === null || lng === null) {
    return { lat: null, lng: null };
  }

  return { lat, lng };
}

function hasCoordinates(input = {}) {
  return toNumber(input?.lat) !== null && toNumber(input?.lng) !== null;
}

function toRadians(value) {
  return (value * Math.PI) / 180;
}

function calculateDistanceKm(from = {}, to = {}) {
  if (!hasCoordinates(from) || !hasCoordinates(to)) {
    return Number.POSITIVE_INFINITY;
  }

  const earthRadiusKm = 6371;
  const dLat = toRadians(Number(to.lat) - Number(from.lat));
  const dLng = toRadians(Number(to.lng) - Number(from.lng));
  const fromLat = toRadians(Number(from.lat));
  const toLat = toRadians(Number(to.lat));

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2)
    + Math.cos(fromLat) * Math.cos(toLat) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return earthRadiusKm * c;
}

function cloneStop(stop = {}) {
  return {
    ...stop,
    coordinates: normalizeCoordinates(stop?.coordinates),
  };
}

function optimizeIntermediateStops(stops = []) {
  if (stops.length <= 2) {
    return stops.map(cloneStop);
  }

  const clonedStops = stops.map(cloneStop);
  const pickup = clonedStops[0];
  const destination = clonedStops[clonedStops.length - 1];
  const pending = clonedStops.slice(1, -1);
  const ordered = [pickup];
  let currentCoordinates = pickup?.coordinates;

  while (pending.length > 0) {
    let selectedIndex = 0;
    let selectedDistance = Number.POSITIVE_INFINITY;

    pending.forEach((candidate, index) => {
      const distance = calculateDistanceKm(currentCoordinates, candidate?.coordinates);
      if (distance < selectedDistance) {
        selectedDistance = distance;
        selectedIndex = index;
      }
    });

    const [selected] = pending.splice(selectedIndex, 1);
    ordered.push(selected);

    if (hasCoordinates(selected?.coordinates)) {
      currentCoordinates = selected.coordinates;
    }
  }

  ordered.push(destination);
  return ordered;
}

function buildLegSummaries(stops = []) {
  const legs = [];

  for (let index = 0; index < stops.length - 1; index += 1) {
    const from = stops[index];
    const to = stops[index + 1];
    const distanceKm = calculateDistanceKm(from?.coordinates, to?.coordinates);

    legs.push({
      fromStopId: from?.id || `stop_${index}`,
      toStopId: to?.id || `stop_${index + 1}`,
      distanceKm: Number.isFinite(distanceKm) ? Number(distanceKm.toFixed(2)) : null,
    });
  }

  return legs;
}

function getPlannerHealth(_req, res) {
  res.json({
    status: 'ok',
    service: 'agrihub-dev-planner',
    mode: 'development',
  });
}

function optimizeMarketplaceRoute(req, res) {
  const payload = parsePlannerBody(req.body);
  const submittedStops = Array.isArray(payload?.stops) ? payload.stops : [];

  if (submittedStops.length < 2) {
    return res.status(400).json({
      message: 'At least two stops are required.',
    });
  }

  const optimizedStops = optimizeIntermediateStops(submittedStops);

  return res.json({
    provider: 'agrihub-dev-planner',
    mode: 'nearest-neighbor',
    stops: optimizedStops,
    legs: buildLegSummaries(optimizedStops),
    context: payload?.context || {},
  });
}

export {
  getPlannerHealth,
  optimizeMarketplaceRoute,
};
