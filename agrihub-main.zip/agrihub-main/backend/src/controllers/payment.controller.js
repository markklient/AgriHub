import { LaborPayment } from '../models/LaborPayment.js';
import { MarketplacePayment } from '../models/MarketplacePayment.js';
import { ServicePayment } from '../models/ServicePayment.js';
import { User } from '../models/User.js';
import { appendActivity } from '../utils/activityLog.js';
import {
  buildMarketplaceLogisticsSnapshot,
  getMarketplaceAddressSnapshot,
  getMarketplaceCoordinateSnapshot,
} from '../utils/marketplaceLogistics.js';
import { canManageCommercialFeatures, roleQuery } from '../utils/roles.js';
import {
  createXenditInvoice,
  getXenditInvoice,
  mapLaborPaymentMethodToXendit,
  verifyXenditCallbackToken,
} from '../utils/xendit.js';

function normalizeClockTime(value) {
  const normalized = String(value || '').trim();
  return /^\d{2}:\d{2}$/.test(normalized) ? normalized : '';
}

function convertClockTimeToMinutes(value) {
  const normalized = normalizeClockTime(value);

  if (!normalized) {
    return null;
  }

  const [hours, minutes] = normalized.split(':').map(Number);
  return Number.isFinite(hours) && Number.isFinite(minutes) ? hours * 60 + minutes : null;
}

function formatWorkingHoursRange(start, end) {
  const normalizedStart = normalizeClockTime(start);
  const normalizedEnd = normalizeClockTime(end);

  if (!normalizedStart || !normalizedEnd) {
    return '';
  }

  const [startHours, startMinutes] = normalizedStart.split(':').map(Number);
  const [endHours, endMinutes] = normalizedEnd.split(':').map(Number);
  const formatOptions = { hour: 'numeric', minute: '2-digit' };

  return `${new Date(2000, 0, 1, startHours, startMinutes).toLocaleTimeString('en-US', formatOptions)} - ${new Date(
    2000,
    0,
    1,
    endHours,
    endMinutes,
  ).toLocaleTimeString('en-US', formatOptions)}`;
}

function getDurationHours(value) {
  const match = String(value || '').trim().match(/^(\d+)\s*hour/i);

  if (!match) {
    return null;
  }

  const parsed = Number(match[1]);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function getDurationQuantity(value, unit) {
  const normalizedUnit = String(unit || '').trim().toLowerCase();
  const pattern =
    normalizedUnit === 'day'
      ? /^(\d+)\s*day/i
      : normalizedUnit === 'week'
        ? /^(\d+)\s*week/i
        : normalizedUnit === 'trip'
          ? /^(\d+)\s*trip/i
          : /^(\d+)\s*hour/i;
  const match = String(value || '').trim().match(pattern);

  if (!match) {
    return null;
  }

  const parsed = Number(match[1]);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function hasLaborBookingTimeConflict(bookings = [], date, requestedStartMinutes, requestedDurationHours) {
  const normalizedDate = String(date || '').trim();
  const requestedEndMinutes = requestedStartMinutes + requestedDurationHours * 60;

  return bookings.some((booking) => {
    if (!booking) {
      return false;
    }

    if (String(booking.date || '').trim() !== normalizedDate) {
      return false;
    }

    if (String(booking.status || '').trim().toLowerCase() === 'cancelled') {
      return false;
    }

    const existingStartMinutes = convertClockTimeToMinutes(booking.time);
    const existingDurationHours = getDurationHours(booking.duration);

    if (existingStartMinutes === null || existingDurationHours === null) {
      return false;
    }

    const existingEndMinutes = existingStartMinutes + existingDurationHours * 60;
    return requestedStartMinutes <= existingEndMinutes && existingStartMinutes <= requestedEndMinutes;
  });
}

function buildLaborPaymentReference() {
  return `LPAY-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function buildServicePaymentReference() {
  return `SPAY-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function buildMarketplacePaymentReference() {
  return `MPAY-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function buildMarketplaceOrderId() {
  return `MORD-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function buildLaborBookingId() {
  return `LB-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function buildServiceBookingReference() {
  return `RBOOK-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function createTravelTrackingSnapshot() {
  return {
    isOnTheWay: false,
    startedAt: null,
    updatedAt: null,
    currentLocation: {
      lat: null,
      lng: null,
    },
  };
}

function ensureWalletState(user) {
  if (!user.wallet) {
    user.wallet = {
      balance: 0,
      totalEarned: 0,
      totalWithdrawn: 0,
      transactions: [],
    };
  }

  user.wallet.balance = Number(user.wallet.balance || 0);
  user.wallet.totalEarned = Number(user.wallet.totalEarned || 0);
  user.wallet.totalWithdrawn = Number(user.wallet.totalWithdrawn || 0);

  if (!Array.isArray(user.wallet.transactions)) {
    user.wallet.transactions = [];
  }

  return user.wallet;
}

function buildWalletTransactionId(prefix = 'WAL') {
  return `${prefix}-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function addWalletTransaction(user, transaction) {
  const wallet = ensureWalletState(user);
  wallet.transactions = [
    {
      id: transaction.id || buildWalletTransactionId(),
      type: transaction.type,
      amount: Number(transaction.amount || 0),
      status: transaction.status || 'completed',
      method: transaction.method || '',
      description: transaction.description || '',
      reference: transaction.reference || '',
      destinationLabel: transaction.destinationLabel || '',
      createdAt: transaction.createdAt || new Date(),
    },
    ...wallet.transactions,
  ].slice(0, 100);
}

function ensureMarketplaceOrdersState(user) {
  if (!user.marketplaceOrders) {
    user.marketplaceOrders = {
      purchases: [],
      sales: [],
    };
  }

  if (!Array.isArray(user.marketplaceOrders.purchases)) {
    user.marketplaceOrders.purchases = [];
  }

  if (!Array.isArray(user.marketplaceOrders.sales)) {
    user.marketplaceOrders.sales = [];
  }

  return user.marketplaceOrders;
}

function debitWalletForPayment(user, amount, transaction = {}) {
  const numericAmount = Number(amount || 0);

  if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
    throw new Error('Enter a valid wallet payment amount.');
  }

  const wallet = ensureWalletState(user);

  if (wallet.balance < numericAmount) {
    throw new Error('Insufficient wallet balance for this payment.');
  }

  wallet.balance -= numericAmount;
  addWalletTransaction(user, {
    ...transaction,
    type: 'payment',
    amount: numericAmount,
    status: transaction.status || 'completed',
  });
}

function getLaborListings(user) {
  const listings = Array.isArray(user?.laborProfile?.listings) ? user.laborProfile.listings : [];

  if (listings.length > 0) {
    return listings.filter((listing) => String(listing?.workerType || '').trim());
  }

  if (String(user?.laborProfile?.workerType || '').trim()) {
    return [user.laborProfile];
  }

  return [];
}

function getServiceListings(user) {
  return Array.isArray(user?.serviceProfile?.services) ? user.serviceProfile.services : [];
}

function laborOfferIsComplete(user, offer) {
  return Boolean(
    String(offer?.description || '').trim() &&
      String(offer?.workerType || '').trim() &&
      Number(offer?.rate || 0) > 0 &&
      String(offer?.availability || '').trim() &&
      Array.isArray(offer?.skills) &&
      offer.skills.length > 0 &&
      String(offer?.workingHoursStart || '').trim() &&
      String(offer?.workingHoursEnd || '').trim() &&
      String(user?.profile?.experience || '').trim() &&
      String(user?.profile?.location || '').trim() &&
      String(user?.phone || '').trim(),
  );
}

function mapInvoiceStatusToLaborPaymentStatus(status) {
  const normalized = String(status || '').trim().toUpperCase();

  if (normalized === 'PAID' || normalized === 'SETTLED') {
    return 'paid';
  }

  if (normalized === 'EXPIRED') {
    return 'expired';
  }

  if (normalized === 'FAILED' || normalized === 'VOIDED') {
    return 'failed';
  }

  return 'awaiting_payment';
}

function buildMarketplaceReceipt(payment) {
  return {
    id: payment.reference,
    type: 'purchase',
    date: payment.createdAt ? new Date(payment.createdAt).toLocaleDateString('en-CA') : '',
    time: payment.createdAt ? new Date(payment.createdAt).toLocaleTimeString('en-US') : '',
    items: (Array.isArray(payment.items) ? payment.items : []).map((item) => ({
      name: item.name,
      quantity: Number(item.quantity || 0),
      unit: item.unit,
      price: Number(item.price || 0),
      total: Number(item.total || 0),
    })),
    subtotal: Number(payment.subtotal || 0),
    tax: Number(payment.tax || 0),
    shipping: Number(payment.shipping || 0),
    total: Number(payment.total || 0),
    paymentMethod:
      payment.paymentMethod === 'GCASH'
        ? 'GCash'
        : payment.paymentMethod === 'PAYMAYA'
          ? 'Maya'
          : 'Credit or Debit Card',
    seller: 'Multiple Sellers',
    buyer: payment.buyerName || 'Authenticated User',
  };
}

async function validateMarketplacePaymentItems(items = []) {
  const normalizedItems = [];

  for (const item of items) {
    const sellerUserId = String(item?.sellerUserId || '').trim();
    const listingId = String(item?.listingId || '').trim();
    const selectedVarietyId = String(item?.selectedVarietyId || '').trim();
    const quantity = Number(item?.quantity || 0);
    const price = Number(item?.price || 0);

    if (!sellerUserId || !listingId || !quantity || quantity <= 0 || !price || price <= 0) {
      throw new Error('Each cart item must include a valid seller, listing, quantity, and price.');
    }

    const seller = await User.findById(sellerUserId);

    if (!seller || !Array.isArray(seller.marketplaceListings)) {
      throw new Error('One of the marketplace listings could no longer be found.');
    }

    const listingIndex = seller.marketplaceListings.findIndex(
      (listing) => String(listing?.listingId || '').trim() === listingId,
    );

    if (listingIndex < 0) {
      throw new Error('One of the marketplace listings could no longer be found.');
    }

    const listing = seller.marketplaceListings[listingIndex];
    const listingVarieties = Array.isArray(listing?.varieties) ? listing.varieties : [];
    const selectedVariety = selectedVarietyId
      ? listingVarieties.find((variety) => String(variety?.id || '').trim() === selectedVarietyId)
      : null;

    if (selectedVarietyId && !selectedVariety) {
      throw new Error(`The selected variety for ${String(item?.name || 'this listing').trim() || 'this listing'} is no longer available.`);
    }

    const availableStock = selectedVariety
      ? Number(selectedVariety.stock || 0)
      : Number(listing?.stock || 0);

    if (availableStock < quantity) {
      throw new Error(`Only ${availableStock} ${String(item?.unit || 'item').trim() || 'item'} remain for ${String(item?.name || 'this listing').trim() || 'this listing'}.`);
    }

    normalizedItems.push({
      id: String(item?.id || '').trim(),
      name: String(item?.name || '').trim(),
      category: String(item?.category || '').trim(),
      seller: String(item?.seller || '').trim(),
      sellerUserId,
      listingId,
      selectedVarietyId,
      quantity,
      unit: String(item?.unit || '').trim(),
      price,
      total: quantity * price,
    });
  }

  return normalizedItems;
}

async function fulfillMarketplacePayment(payment) {
  if (!payment || payment.fulfillmentStatus === 'completed') {
    return payment;
  }

  const items = Array.isArray(payment.items) ? payment.items : [];

  if (items.length === 0) {
    payment.fulfillmentStatus = 'failed';
    payment.fulfillmentFailureReason = 'No marketplace items were found on this payment.';
    await payment.save();
    return payment;
  }

  const touchedSellers = new Map();
  const buyerUser = await User.findById(payment.buyerUserId);

  if (!buyerUser) {
    payment.fulfillmentStatus = 'failed';
    payment.fulfillmentFailureReason = 'The buyer account could not be found while creating marketplace orders.';
    await payment.save();
    return payment;
  }

  ensureMarketplaceOrdersState(buyerUser);

  for (const item of items) {
    const sellerUserId = String(item?.sellerUserId || '').trim();
    const listingId = String(item?.listingId || '').trim();
    const selectedVarietyId = String(item?.selectedVarietyId || '').trim();
    const quantity = Number(item?.quantity || 0);

    if (!sellerUserId || !listingId || !Number.isFinite(quantity) || quantity <= 0) {
      payment.fulfillmentStatus = 'failed';
      payment.fulfillmentFailureReason = 'Marketplace payment is missing listing references for stock fulfillment.';
      await payment.save();
      return payment;
    }

    let sellerUser = touchedSellers.get(sellerUserId);

    if (!sellerUser) {
      sellerUser = await User.findById(sellerUserId);
      if (!sellerUser) {
        payment.fulfillmentStatus = 'failed';
        payment.fulfillmentFailureReason = 'One of the seller accounts could not be found while applying marketplace stock.';
        await payment.save();
        return payment;
      }

      touchedSellers.set(sellerUserId, sellerUser);
    }

    if (!Array.isArray(sellerUser.marketplaceListings)) {
      payment.fulfillmentStatus = 'failed';
      payment.fulfillmentFailureReason = 'A seller marketplace listing collection could not be loaded.';
      await payment.save();
      return payment;
    }

    const listingIndex = sellerUser.marketplaceListings.findIndex(
      (listing) => String(listing?.listingId || '').trim() === listingId,
    );

    if (listingIndex < 0) {
      payment.fulfillmentStatus = 'failed';
      payment.fulfillmentFailureReason = 'One of the marketplace listings could no longer be found during stock update.';
      await payment.save();
      return payment;
    }

    const listingSnapshot = sellerUser.marketplaceListings[listingIndex].toObject?.()
      ? sellerUser.marketplaceListings[listingIndex].toObject()
      : sellerUser.marketplaceListings[listingIndex];
    const nextListing = {
      ...listingSnapshot,
      varieties: Array.isArray(listingSnapshot?.varieties)
        ? listingSnapshot.varieties.map((variety) => ({
            ...(variety.toObject?.() || variety),
          }))
        : [],
    };

    if (selectedVarietyId) {
      const varietyIndex = nextListing.varieties.findIndex(
        (variety) => String(variety?.id || '').trim() === selectedVarietyId,
      );

      if (varietyIndex < 0) {
        payment.fulfillmentStatus = 'failed';
        payment.fulfillmentFailureReason = 'A selected variety could no longer be found during stock update.';
        await payment.save();
        return payment;
      }

      const currentVarietyStock = Number(nextListing.varieties[varietyIndex]?.stock || 0);

      if (currentVarietyStock < quantity) {
        payment.fulfillmentStatus = 'failed';
        payment.fulfillmentFailureReason = 'A marketplace variety no longer has enough stock for this paid order.';
        await payment.save();
        return payment;
      }

      nextListing.varieties[varietyIndex].stock = currentVarietyStock - quantity;
    } else {
      const currentListingStock = Number(nextListing.stock || 0);

      if (currentListingStock < quantity) {
        payment.fulfillmentStatus = 'failed';
        payment.fulfillmentFailureReason = 'A marketplace listing no longer has enough stock for this paid order.';
        await payment.save();
        return payment;
      }

      nextListing.stock = currentListingStock - quantity;
    }

    nextListing.stock = Array.isArray(nextListing.varieties) && nextListing.varieties.length > 0
      ? nextListing.varieties.reduce((sum, variety) => sum + Number(variety?.stock || 0), 0)
      : Number(nextListing.stock || 0);
    nextListing.orders = Number(nextListing.orders || 0) + quantity;
    nextListing.status = nextListing.stock > 0 ? 'active' : 'sold out';

    sellerUser.marketplaceListings[listingIndex] = nextListing;

    ensureMarketplaceOrdersState(sellerUser);

    const orderId = buildMarketplaceOrderId();
    const paidAt = payment.paidAt || new Date();
    const sellerAddress = getMarketplaceAddressSnapshot(sellerUser, nextListing.location || '');
    const buyerAddress = getMarketplaceAddressSnapshot(buyerUser, '');
    const sellerCoordinates = getMarketplaceCoordinateSnapshot(sellerUser);
    const buyerCoordinates = getMarketplaceCoordinateSnapshot(buyerUser);
    const baseOrder = {
      orderId,
      paymentReference: payment.reference,
      listingId,
      sellerUserId,
      buyerUserId: String(payment.buyerUserId || '').trim(),
      sellerName: String(item?.seller || sellerUser.profile?.farmName || sellerUser.name || '').trim(),
      sellerEmail: String(sellerUser.email || '').trim().toLowerCase(),
      sellerPhone: String(sellerUser.phone || '').trim(),
      sellerAddress,
      sellerCoordinates,
      buyerName: String(payment.buyerName || '').trim(),
      buyerPhone: String(buyerUser.phone || payment.buyerPhone || '').trim(),
      buyerAddress,
      buyerCoordinates,
      itemName: String(item?.name || '').trim(),
      category: String(item?.category || '').trim(),
      unit: String(item?.unit || '').trim(),
      quantity,
      price: Number(item?.price || 0),
      subtotal: Number(item?.total || 0),
      tax: 0,
      shipping: 0,
      totalPaid: Number(item?.total || 0),
      paymentMethod: String(payment.paymentMethod || '').trim(),
      location: String(nextListing.location || '').trim(),
      imagePath: String(nextListing.image || nextListing.imagePaths?.[0] || '').trim(),
      selectedVarietyId,
      selectedVarietyLabel: selectedVarietyId
        ? String(
            nextListing.varieties.find((variety) => String(variety?.id || '').trim() === selectedVarietyId)?.label || '',
          ).trim()
        : '',
      status: 'paid',
      reviewed: false,
      reviewRating: 0,
      reviewComment: '',
      sellerPayoutStatus: 'pending',
      sellerPayoutAmount: Number(item?.total || 0),
      sellerPayoutReleasedAt: null,
      sellerPayoutTransactionId: '',
      paidAt,
      preparingAt: null,
      readyForPickupAt: null,
      inTransitAt: null,
      receivedAt: null,
      completedAt: null,
      cancelledAt: null,
      cancellationReason: '',
      cancelledBy: '',
      createdAt: payment.createdAt || paidAt,
      logistics: await buildMarketplaceLogisticsSnapshot({
        orderId,
        status: 'paid',
        createdAt: payment.createdAt || paidAt,
        sellerAddress,
        buyerAddress,
        sellerCoordinates,
        buyerCoordinates,
      }),
    };

    buyerUser.marketplaceOrders.purchases = [baseOrder, ...buyerUser.marketplaceOrders.purchases];
    sellerUser.marketplaceOrders.sales = [baseOrder, ...sellerUser.marketplaceOrders.sales];
  }

  appendActivity(buyerUser, {
    description: `Placed marketplace order ${payment.reference}`,
    status: 'completed',
  });

  Array.from(touchedSellers.values()).forEach((seller) => {
    appendActivity(seller, {
      description: `Received marketplace order ${payment.reference}`,
      status: 'confirmed',
    });
  });

  await Promise.all([buyerUser.save(), ...Array.from(touchedSellers.values()).map((seller) => seller.save())]);

  payment.fulfillmentStatus = 'completed';
  payment.fulfilledAt = payment.fulfilledAt || new Date();
  payment.fulfillmentFailureReason = '';
  await payment.save();

  return payment;
}

async function activatePaidLaborBooking(payment) {
  if (payment.bookingId) {
    return payment;
  }

  const [buyer, worker] = await Promise.all([
    User.findById(payment.buyerUserId),
    User.findOne({
      _id: payment.workerUserId,
      ...roleQuery('laborer'),
    }),
  ]);

  if (!buyer || !worker) {
    payment.status = 'release_failed';
    payment.releaseFailureReason = 'Buyer or laborer could not be found while activating the paid booking.';
    await payment.save();
    return payment;
  }

  const selectedListing = getLaborListings(worker).find(
    (listing) => String(listing?.workerType || '').trim() === String(payment.workerType || '').trim(),
  );

  if (
    !selectedListing ||
    !canManageCommercialFeatures(worker) ||
    !selectedListing.isPublished ||
    !laborOfferIsComplete(worker, selectedListing)
  ) {
    payment.status = 'release_failed';
    payment.releaseFailureReason = 'The labor listing is no longer available for activation.';
    await payment.save();
    return payment;
  }

  const requestedTimeMinutes = convertClockTimeToMinutes(payment.bookingTime);
  const durationHoursValue = getDurationHours(payment.bookingDuration);
  const workerActiveBookings = Array.isArray(worker?.laborProfile?.activeBookings)
    ? worker.laborProfile.activeBookings
    : [];

  if (
    requestedTimeMinutes === null ||
    durationHoursValue === null ||
    hasLaborBookingTimeConflict(workerActiveBookings, payment.bookingDate, requestedTimeMinutes, durationHoursValue)
  ) {
    payment.status = 'release_failed';
    payment.releaseFailureReason = 'The laborer became unavailable for the paid booking time.';
    await payment.save();
    return payment;
  }

  const bookingId = buildLaborBookingId();

  const buyerBooking = {
    bookingId,
    worker: worker.name,
    workerId: worker._id.toString(),
    workerEmail: String(worker.email || '').trim().toLowerCase(),
    workerPhone: String(worker.phone || '').trim(),
    type: payment.workerType,
    date: payment.bookingDate,
    time: payment.bookingTime,
    duration: payment.bookingDuration,
    location: payment.bookingLocation,
    rate: payment.rate,
    status: 'confirmed',
    cost: payment.subtotal,
    bookedByUserId: buyer._id.toString(),
    bookedByName: String(buyer.name || '').trim() || 'Authenticated User',
    bookedByEmail: String(buyer.email || '').trim().toLowerCase(),
    bookedByPhone: String(buyer.phone || '').trim(),
    travelTracking: createTravelTrackingSnapshot(),
  };

  const workerBooking = {
    ...buyerBooking,
    worker: String(buyer.name || '').trim() || 'Authenticated User',
  };

  if (!buyer.laborBookings) {
    buyer.laborBookings = {
      activeBookings: [],
      bookingHistory: [],
    };
  }

  buyer.laborBookings.activeBookings = [
    ...(Array.isArray(buyer.laborBookings.activeBookings) ? buyer.laborBookings.activeBookings : []),
    buyerBooking,
  ];

  worker.laborProfile.activeBookings = [
    ...(Array.isArray(worker.laborProfile?.activeBookings) ? worker.laborProfile.activeBookings : []),
    workerBooking,
  ];

  appendActivity(buyer, {
    description: `Paid labor booking created for ${worker.name} on ${payment.bookingDate}`,
    status: 'confirmed',
  });

  payment.bookingId = bookingId;
  payment.status = 'booking_created';
  payment.bookingCreatedAt = new Date();
  payment.releaseStatus = 'not_ready';

  await Promise.all([buyer.save(), worker.save(), payment.save()]);

  return payment;
}

async function activatePaidServiceBooking(payment) {
  if (payment.bookingRef) {
    return payment;
  }

  const [buyer, provider] = await Promise.all([
    User.findById(payment.buyerUserId),
    User.findById(payment.providerUserId),
  ]);

  if (!buyer || !provider) {
    payment.status = 'failed';
    await payment.save();
    return payment;
  }

  if (!buyer.serviceProfile) {
    buyer.serviceProfile = {
      category: 'Equipment Rentals',
      services: [],
      bookings: [],
      incomingBookings: [],
    };
  }

  if (!Array.isArray(buyer.serviceProfile.bookings)) {
    buyer.serviceProfile.bookings = [];
  }

  if (!provider.serviceProfile || !Array.isArray(provider.serviceProfile.services)) {
    payment.status = 'failed';
    await payment.save();
    return payment;
  }

  if (!Array.isArray(provider.serviceProfile.incomingBookings)) {
    provider.serviceProfile.incomingBookings = [];
  }

  const listingIndex = provider.serviceProfile.services.findIndex(
    (listing) => String(listing?.listingId || '').trim() === String(payment.listingId || '').trim(),
  );

  if (listingIndex < 0) {
    payment.status = 'failed';
    await payment.save();
    return payment;
  }

  const listingSnapshot = provider.serviceProfile.services[listingIndex].toObject?.()
    ? provider.serviceProfile.services[listingIndex].toObject()
    : provider.serviceProfile.services[listingIndex];
  const availableUnits = Number(listingSnapshot?.quantity || 0);

  if (
    !canManageCommercialFeatures(provider)
    || String(listingSnapshot?.status || '').trim() !== 'active'
    || !Boolean(listingSnapshot?.available)
    || availableUnits < 1
  ) {
    payment.status = 'failed';
    await payment.save();
    return payment;
  }

  const nextQuantity = availableUnits - 1;
  provider.serviceProfile.services[listingIndex] = {
    ...listingSnapshot,
    quantity: nextQuantity,
    available: nextQuantity > 0,
    status: nextQuantity > 0 ? 'active' : 'unavailable',
  };

  const bookingRef = buildServiceBookingReference();
  const bookingEntry = {
    service: String(payment.itemName || '').trim(),
    provider: String(provider.name || payment.providerName || '').trim(),
    providerUserId: provider._id.toString(),
    customer: String(buyer.name || payment.buyerName || '').trim(),
    customerUserId: buyer._id.toString(),
    listingId: String(payment.listingId || '').trim(),
    date: String(payment.bookingDate || '').trim(),
    time: String(payment.bookingTime || '').trim(),
    duration: String(payment.bookingDuration || '').trim(),
    location: String(payment.bookingLocation || '').trim(),
    status: 'confirmed',
    description: String(payment.bookingNotes || listingSnapshot?.description || '').trim(),
    rate: `${Number(payment.rate || 0)}`,
    contact: String(provider.phone || payment.providerPhone || '').trim(),
    bookingRef,
    pickupConfirmation: {
      customerConfirmedAt: null,
      providerConfirmedAt: null,
    },
  };
  const incomingBookingEntry = {
    ...bookingEntry,
    contact: String(buyer.phone || payment.buyerPhone || '').trim(),
  };

  buyer.serviceProfile.bookings = [bookingEntry, ...buyer.serviceProfile.bookings];
  provider.serviceProfile.incomingBookings = [incomingBookingEntry, ...provider.serviceProfile.incomingBookings];

  appendActivity(buyer, {
    description: `Booked rental ${bookingEntry.service} for ${bookingEntry.date}`,
    status: 'confirmed',
  });
  appendActivity(provider, {
    description: `Rental booking received for ${bookingEntry.service} on ${bookingEntry.date}`,
    status: 'confirmed',
  });

  payment.bookingRef = bookingRef;
  payment.status = 'booking_created';
  payment.bookingCreatedAt = new Date();
  payment.releaseStatus = 'not_ready';
  payment.releaseFailureReason = '';

  await Promise.all([buyer.save(), provider.save(), payment.save()]);

  return payment;
}

async function refreshLaborPaymentFromXendit(payment) {
  if (!payment || payment.bookingId || !payment.xenditInvoiceId) {
    return payment;
  }

  const invoice = await getXenditInvoice(payment.xenditInvoiceId);
  const nextStatus = mapInvoiceStatusToLaborPaymentStatus(invoice?.status);

  payment.xenditInvoiceStatus = String(invoice?.status || payment.xenditInvoiceStatus || '').trim();

  if (nextStatus === 'paid') {
    payment.status = 'paid';
    payment.paidAt = payment.paidAt || new Date();
    await payment.save();
    return activatePaidLaborBooking(payment);
  }

  if (nextStatus && nextStatus !== payment.status) {
    payment.status = nextStatus;
    await payment.save();
  }

  return payment;
}

async function refreshMarketplacePaymentFromXendit(payment) {
  if (!payment || !payment.xenditInvoiceId) {
    return payment;
  }

  const invoice = await getXenditInvoice(payment.xenditInvoiceId);
  const nextStatus = mapInvoiceStatusToLaborPaymentStatus(invoice?.status);

  payment.xenditInvoiceStatus = String(invoice?.status || payment.xenditInvoiceStatus || '').trim();

  if (nextStatus === 'paid') {
    payment.status = 'paid';
    payment.paidAt = payment.paidAt || new Date();
    await payment.save();
    await fulfillMarketplacePayment(payment);
    return payment;
  }

  if (nextStatus && nextStatus !== payment.status) {
    payment.status = nextStatus;
    await payment.save();
  }

  return payment;
}

async function refreshServicePaymentFromXendit(payment) {
  if (!payment || payment.bookingRef || !payment.xenditInvoiceId) {
    return payment;
  }

  const invoice = await getXenditInvoice(payment.xenditInvoiceId);
  const nextStatus = mapInvoiceStatusToLaborPaymentStatus(invoice?.status);

  payment.xenditInvoiceStatus = String(invoice?.status || payment.xenditInvoiceStatus || '').trim();

  if (nextStatus === 'paid') {
    payment.status = 'paid';
    payment.paidAt = payment.paidAt || new Date();
    await payment.save();
    return activatePaidServiceBooking(payment);
  }

  if (nextStatus && nextStatus !== payment.status) {
    payment.status = nextStatus;
    await payment.save();
  }

  return payment;
}

export async function createLaborPaymentCheckout(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    if (
      req.user.phoneVerification?.status !== 'verified' ||
      !String(req.user.phone || '').trim()
    ) {
      return res.status(400).json({
        message: 'Verify your phone number before paying for a labor booking.',
      });
    }

    const workerId = String(req.body?.workerId || '').trim();
    const workerType = String(req.body?.workerType || '').trim();
    const date = String(req.body?.date || '').trim();
    const time = String(req.body?.time || '').trim();
    const duration = String(req.body?.duration || '').trim();
    const location = String(req.body?.location || '').trim();
    const paymentMethod = String(req.body?.paymentMethod || '').trim().toLowerCase();

    if (!workerId || !workerType || !date || !time || !duration || !location || !paymentMethod) {
      return res.status(400).json({
        message: 'Worker, labor type, date, time, duration, location, and payment method are required.',
      });
    }

    if (String(req.user._id || '') === workerId) {
      return res.status(403).json({
        message: 'You cannot book your own labor listing.',
      });
    }

    const worker = await User.findOne({
      _id: workerId,
      ...roleQuery('laborer'),
    });

    const selectedListing = getLaborListings(worker).find(
      (listing) => String(listing?.workerType || '').trim() === workerType,
    );

    if (
      !worker ||
      !selectedListing ||
      !canManageCommercialFeatures(worker) ||
      !selectedListing.isPublished ||
      !laborOfferIsComplete(worker, selectedListing)
    ) {
      return res.status(404).json({
        message: 'Selected worker is not available for booking.',
      });
    }

    const requestedTimeMinutes = convertClockTimeToMinutes(time);
    const workingHoursStartMinutes = convertClockTimeToMinutes(selectedListing.workingHoursStart);
    const workingHoursEndMinutes = convertClockTimeToMinutes(selectedListing.workingHoursEnd);
    const durationHoursValue = getDurationHours(duration);

    if (
      requestedTimeMinutes === null ||
      workingHoursStartMinutes === null ||
      workingHoursEndMinutes === null ||
      durationHoursValue === null
    ) {
      return res.status(400).json({
        message: 'Enter a valid labor booking time and duration.',
      });
    }

    if (requestedTimeMinutes < workingHoursStartMinutes || requestedTimeMinutes > workingHoursEndMinutes) {
      return res.status(400).json({
        message: `Bookings for this laborer are only available from ${formatWorkingHoursRange(selectedListing.workingHoursStart, selectedListing.workingHoursEnd)}.`,
      });
    }

    if (requestedTimeMinutes + durationHoursValue * 60 > workingHoursEndMinutes) {
      return res.status(400).json({
        message: `This booking extends past the laborer's working hours of ${formatWorkingHoursRange(selectedListing.workingHoursStart, selectedListing.workingHoursEnd)}.`,
      });
    }

    const workerActiveBookings = Array.isArray(worker?.laborProfile?.activeBookings)
      ? worker.laborProfile.activeBookings
      : [];

    if (hasLaborBookingTimeConflict(workerActiveBookings, date, requestedTimeMinutes, durationHoursValue)) {
      return res.status(409).json({
        message: 'This worker is already booked for part of that time range on the selected date.',
      });
    }

    const numericRate = Number(selectedListing.rate || 0);
    const subtotal = numericRate * durationHoursValue;
    const tax = subtotal * 0.08;
    const total = subtotal + tax;
    const reference = buildLaborPaymentReference();
    const useWalletPayment = paymentMethod === 'wallet';
    const paymentMethodCode = useWalletPayment ? 'WALLET' : mapLaborPaymentMethodToXendit(paymentMethod);
    const clientUrl = String(process.env.CLIENT_URL || 'http://localhost:5173').trim();

    const payment = await LaborPayment.create({
      reference,
      status: useWalletPayment ? 'paid' : 'pending_checkout',
      paymentMethod: paymentMethodCode,
      paymentProvider: useWalletPayment ? 'wallet' : 'xendit',
      buyerUserId: req.user._id.toString(),
      buyerName: String(req.user.name || '').trim(),
      buyerEmail: String(req.user.email || '').trim().toLowerCase(),
      buyerPhone: String(req.user.phone || '').trim(),
      workerUserId: worker._id.toString(),
      workerName: String(worker.name || '').trim(),
      workerEmail: String(worker.email || '').trim().toLowerCase(),
      workerPhone: String(worker.phone || '').trim(),
      workerType,
      bookingDate: date,
      bookingTime: time,
      bookingDuration: duration,
      bookingLocation: location,
      rate: numericRate,
      subtotal,
      tax,
      total,
      metadata: {
        listingRate: numericRate,
        workingHoursStart: selectedListing.workingHoursStart,
        workingHoursEnd: selectedListing.workingHoursEnd,
      },
    });

    if (useWalletPayment) {
      debitWalletForPayment(req.user, total, {
        id: buildWalletTransactionId('PAY'),
        method: 'wallet',
        reference,
        description: `Paid labor booking for ${worker.name}`,
        createdAt: new Date(),
      });
      appendActivity(req.user, {
        description: `Paid labor booking for ${worker.name} using wallet`,
        status: 'completed',
      });
      payment.paidAt = new Date();
      await Promise.all([req.user.save(), payment.save()]);
      await activatePaidLaborBooking(payment);

      return res.status(201).json({
        message: 'Labor payment completed using wallet balance.',
        payment: {
          reference: payment.reference,
          status: payment.status,
          total: payment.total,
          subtotal: payment.subtotal,
          tax: payment.tax,
          paymentMethod: payment.paymentMethod,
        },
        checkoutUrl: '',
      });
    }

    const invoice = await createXenditInvoice({
      external_id: reference,
      amount: total,
      payer_email: payment.buyerEmail,
      description: `AgriHub labor booking for ${payment.workerName} (${payment.workerType}) on ${date} at ${time}. Subtotal: PHP ${subtotal.toFixed(2)}, Tax: PHP ${tax.toFixed(2)}, Total: PHP ${total.toFixed(2)}`,
      currency: 'PHP',
      success_redirect_url: `${clientUrl}/app?tab=labor&laborPaymentRef=${encodeURIComponent(reference)}&laborPaymentState=success`,
      failure_redirect_url: `${clientUrl}/app?tab=labor&laborPaymentRef=${encodeURIComponent(reference)}&laborPaymentState=failure`,
      payment_methods: [paymentMethodCode],
      customer: {
        given_names: payment.buyerName || 'AgriHub Customer',
        email: payment.buyerEmail,
        mobile_number: payment.buyerPhone,
      },
      items: [
        {
          name: `${payment.workerType} labor booking`,
          quantity: durationHoursValue,
          price: numericRate,
          category: 'labor',
        },
        {
          name: 'Tax (8%)',
          quantity: 1,
          price: tax,
          category: 'fee',
        },
      ],
      metadata: {
        agrihub_reference: reference,
        worker_id: payment.workerUserId,
        buyer_id: payment.buyerUserId,
      },
    });

    payment.status = 'awaiting_payment';
    payment.checkoutUrl = String(invoice?.invoice_url || '').trim();
    payment.xenditInvoiceId = String(invoice?.id || '').trim();
    payment.xenditInvoiceStatus = String(invoice?.status || '').trim();
    await payment.save();

    return res.status(201).json({
      message: 'Labor payment checkout created.',
      payment: {
        reference: payment.reference,
        status: payment.status,
        releaseStatus: payment.releaseStatus,
        releasedAt: payment.releasedAt,
        total: payment.total,
        subtotal: payment.subtotal,
        tax: payment.tax,
        paymentMethod: payment.paymentMethod,
      },
      checkoutUrl: payment.checkoutUrl,
    });
  } catch (error) {
    next(error);
  }
}

export async function createMarketplacePaymentCheckout(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    const items = Array.isArray(req.body?.items) ? req.body.items : [];
    const paymentMethod = String(req.body?.paymentMethod || '').trim().toLowerCase();

    if (!items.length || !paymentMethod) {
      return res.status(400).json({
        message: 'Cart items and a payment method are required.',
      });
    }

    const normalizedItems = await validateMarketplacePaymentItems(items);

    if (!normalizedItems.length) {
      return res.status(400).json({
        message: 'Add valid cart items before starting checkout.',
      });
    }

    const subtotal = normalizedItems.reduce((sum, item) => sum + item.total, 0);
    const tax = subtotal * 0.08;
    const shipping = 15;
    const total = subtotal + tax + shipping;
    const reference = buildMarketplacePaymentReference();
    const useWalletPayment = paymentMethod === 'wallet';
    const paymentMethodCode = useWalletPayment ? 'WALLET' : mapLaborPaymentMethodToXendit(paymentMethod);
    const clientUrl = String(process.env.CLIENT_URL || 'http://localhost:5173').trim();

    const payment = await MarketplacePayment.create({
      reference,
      status: useWalletPayment ? 'paid' : 'pending_checkout',
      paymentMethod: paymentMethodCode,
      paymentProvider: useWalletPayment ? 'wallet' : 'xendit',
      buyerUserId: req.user._id.toString(),
      buyerName: String(req.user.name || '').trim(),
      buyerEmail: String(req.user.email || '').trim().toLowerCase(),
      buyerPhone: String(req.user.phone || '').trim(),
      items: normalizedItems,
      subtotal,
      tax,
      shipping,
      total,
    });

    if (useWalletPayment) {
      debitWalletForPayment(req.user, total, {
        id: buildWalletTransactionId('PAY'),
        method: 'wallet',
        reference,
        description: 'Paid marketplace checkout using wallet',
        createdAt: new Date(),
      });
      appendActivity(req.user, {
        description: `Paid marketplace order ${reference} using wallet`,
        status: 'completed',
      });
      payment.paidAt = new Date();
      await Promise.all([req.user.save(), payment.save()]);
      await fulfillMarketplacePayment(payment);

      return res.status(201).json({
        message: 'Marketplace payment completed using wallet balance.',
        payment: {
          reference: payment.reference,
          status: payment.status,
          total: payment.total,
          subtotal: payment.subtotal,
          tax: payment.tax,
          shipping: payment.shipping,
          paymentMethod: payment.paymentMethod,
        },
        checkoutUrl: '',
      });
    }

    const invoice = await createXenditInvoice({
      external_id: reference,
      amount: total,
      payer_email: payment.buyerEmail,
      description: `AgriHub marketplace checkout with ${normalizedItems.length} item(s). Subtotal: PHP ${subtotal.toFixed(2)}, Tax: PHP ${tax.toFixed(2)}, Shipping: PHP ${shipping.toFixed(2)}, Total: PHP ${total.toFixed(2)}`,
      currency: 'PHP',
      success_redirect_url: `${clientUrl}/app?tab=marketplace&marketplacePaymentRef=${encodeURIComponent(reference)}&marketplacePaymentState=success`,
      failure_redirect_url: `${clientUrl}/app?tab=marketplace&marketplacePaymentRef=${encodeURIComponent(reference)}&marketplacePaymentState=failure`,
      payment_methods: [paymentMethodCode],
      customer: {
        given_names: payment.buyerName || 'AgriHub Customer',
        email: payment.buyerEmail,
        mobile_number: payment.buyerPhone,
      },
      items: [
        ...normalizedItems.map((item) => ({
          name: item.name,
          quantity: item.quantity,
          price: item.price,
          category: item.category || 'marketplace',
        })),
        {
          name: 'Tax (8%)',
          quantity: 1,
          price: tax,
          category: 'fee',
        },
        {
          name: 'Shipping',
          quantity: 1,
          price: shipping,
          category: 'fee',
        },
      ],
      metadata: {
        agrihub_reference: reference,
        buyer_id: payment.buyerUserId,
        checkout_type: 'marketplace',
      },
    });

    payment.status = 'awaiting_payment';
    payment.checkoutUrl = String(invoice?.invoice_url || '').trim();
    payment.xenditInvoiceId = String(invoice?.id || '').trim();
    payment.xenditInvoiceStatus = String(invoice?.status || '').trim();
    await payment.save();

    return res.status(201).json({
      message: 'Marketplace payment checkout created.',
      payment: {
        reference: payment.reference,
        status: payment.status,
        total: payment.total,
        subtotal: payment.subtotal,
        tax: payment.tax,
        shipping: payment.shipping,
        paymentMethod: payment.paymentMethod,
      },
      checkoutUrl: payment.checkoutUrl,
    });
  } catch (error) {
    next(error);
  }
}

export async function createServicePaymentCheckout(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    if (
      req.user.phoneVerification?.status !== 'verified' ||
      !String(req.user.phone || '').trim()
    ) {
      return res.status(400).json({
        message: 'Verify your phone number before paying for a rental booking.',
      });
    }

    const providerUserId = String(req.body?.providerUserId || '').trim();
    const listingId = String(req.body?.listingId || '').trim();
    const date = String(req.body?.date || '').trim();
    const time = String(req.body?.time || '').trim();
    const duration = String(req.body?.duration || '').trim();
    const notes = String(req.body?.notes || '').trim();
    const paymentMethod = String(req.body?.paymentMethod || '').trim().toLowerCase();

    if (!providerUserId || !listingId || !date || !time || !duration || !paymentMethod) {
      return res.status(400).json({
        message: 'Provider, rental listing, date, time, duration, and payment method are required.',
      });
    }

    if (String(req.user._id || '') === providerUserId) {
      return res.status(403).json({
        message: 'You cannot book your own rental listing.',
      });
    }

    const provider = await User.findById(providerUserId);

    if (!provider || !canManageCommercialFeatures(provider)) {
      return res.status(404).json({
        message: 'Selected rental provider is not available for booking.',
      });
    }

    const listing = getServiceListings(provider).find(
      (entry) => String(entry?.listingId || '').trim() === listingId,
    );

    if (
      !listing ||
      String(listing?.status || '').trim() !== 'active' ||
      !Boolean(listing?.available) ||
      Number(listing?.quantity || 0) < 1
    ) {
      return res.status(404).json({
        message: 'Selected equipment rental is not available for booking.',
      });
    }

    const requestedTimeMinutes = convertClockTimeToMinutes(time);
    const normalizedUnit = String(listing.unit || 'hour').trim().toLowerCase();
    const durationQuantity = getDurationQuantity(duration, normalizedUnit);
    if (
      requestedTimeMinutes === null ||
      durationQuantity === null
    ) {
      return res.status(400).json({
        message: 'Enter a valid rental booking time and duration.',
      });
    }

    const numericRate = Number(listing.rate || 0);
    const subtotal = numericRate * durationQuantity;
    const tax = subtotal * 0.08;
    const total = subtotal + tax;
    const reference = buildServicePaymentReference();
    const useWalletPayment = paymentMethod === 'wallet';
    const paymentMethodCode = useWalletPayment ? 'WALLET' : mapLaborPaymentMethodToXendit(paymentMethod);
    const clientUrl = String(process.env.CLIENT_URL || 'http://localhost:5173').trim();

    const payment = await ServicePayment.create({
      reference,
      status: useWalletPayment ? 'paid' : 'pending_checkout',
      paymentMethod: paymentMethodCode,
      paymentProvider: useWalletPayment ? 'wallet' : 'xendit',
      buyerUserId: req.user._id.toString(),
      buyerName: String(req.user.name || '').trim(),
      buyerEmail: String(req.user.email || '').trim().toLowerCase(),
      buyerPhone: String(req.user.phone || '').trim(),
      providerUserId: provider._id.toString(),
      providerName: String(provider.name || '').trim(),
      providerEmail: String(provider.email || '').trim().toLowerCase(),
      providerPhone: String(provider.phone || '').trim(),
      listingId,
      itemName: String(listing.name || '').trim(),
      itemUnit: String(listing.unit || 'day').trim(),
      bookingDate: date,
      bookingTime: time,
      bookingDuration: duration,
      bookingLocation: String(listing.location || '').trim(),
      bookingNotes: notes,
      rate: numericRate,
      subtotal,
      tax,
      total,
      metadata: {
        ownerRole: String(listing.ownerRole || '').trim(),
        identifier: String(listing.identifier || '').trim(),
      },
    });

    if (useWalletPayment) {
      debitWalletForPayment(req.user, total, {
        id: buildWalletTransactionId('PAY'),
        method: 'wallet',
        reference,
        description: `Paid rental booking for ${payment.itemName}`,
        createdAt: new Date(),
      });
      appendActivity(req.user, {
        description: `Paid rental booking for ${payment.itemName} using wallet`,
        status: 'completed',
      });
      payment.paidAt = new Date();
      await Promise.all([req.user.save(), payment.save()]);
      await activatePaidServiceBooking(payment);

      return res.status(201).json({
        message: 'Rental payment completed using wallet balance.',
        payment: {
          reference: payment.reference,
          status: payment.status,
          total: payment.total,
          subtotal: payment.subtotal,
          tax: payment.tax,
          paymentMethod: payment.paymentMethod,
        },
        checkoutUrl: '',
      });
    }

    const invoice = await createXenditInvoice({
      external_id: reference,
      amount: total,
      payer_email: payment.buyerEmail,
      description: `AgriHub rental booking for ${payment.itemName} on ${date} at ${time}. Subtotal: PHP ${subtotal.toFixed(2)}, Tax: PHP ${tax.toFixed(2)}, Total: PHP ${total.toFixed(2)}`,
      currency: 'PHP',
      success_redirect_url: `${clientUrl}/app?tab=services&servicePaymentRef=${encodeURIComponent(reference)}&servicePaymentState=success`,
      failure_redirect_url: `${clientUrl}/app?tab=services&servicePaymentRef=${encodeURIComponent(reference)}&servicePaymentState=failure`,
      payment_methods: [paymentMethodCode],
      customer: {
        given_names: payment.buyerName || 'AgriHub Customer',
        email: payment.buyerEmail,
        mobile_number: payment.buyerPhone,
      },
      items: [
        {
          name: `${payment.itemName} rental`,
          quantity: durationQuantity,
          price: numericRate,
          category: 'equipment-rental',
        },
        {
          name: 'Tax (8%)',
          quantity: 1,
          price: tax,
          category: 'fee',
        },
      ],
      metadata: {
        agrihub_reference: reference,
        buyer_id: payment.buyerUserId,
        checkout_type: 'service',
      },
    });

    payment.status = 'awaiting_payment';
    payment.checkoutUrl = String(invoice?.invoice_url || '').trim();
    payment.xenditInvoiceId = String(invoice?.id || '').trim();
    payment.xenditInvoiceStatus = String(invoice?.status || '').trim();
    await payment.save();

    return res.status(201).json({
      message: 'Rental payment checkout created.',
      payment: {
        reference: payment.reference,
        status: payment.status,
        total: payment.total,
        subtotal: payment.subtotal,
        tax: payment.tax,
        paymentMethod: payment.paymentMethod,
      },
      checkoutUrl: payment.checkoutUrl,
    });
  } catch (error) {
    next(error);
  }
}

export async function getLaborPaymentStatus(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    const reference = String(req.params?.reference || '').trim();

    if (!reference) {
      return res.status(400).json({
        message: 'A payment reference is required.',
      });
    }

    const payment = await LaborPayment.findOne({
      reference,
      buyerUserId: req.user._id.toString(),
    });

    if (!payment) {
      return res.status(404).json({
        message: 'That labor payment could not be found on this account.',
      });
    }

    if (!payment.bookingId && payment.xenditInvoiceId) {
      try {
        await refreshLaborPaymentFromXendit(payment);
      } catch (refreshError) {
        console.warn('Unable to refresh labor payment from Xendit:', refreshError?.message || refreshError);
      }
    }

    return res.json({
      payment: {
        reference: payment.reference,
        status: payment.status,
        paymentMethod: payment.paymentMethod,
        total: payment.total,
        checkoutUrl: payment.checkoutUrl,
        bookingId: payment.bookingId,
        bookingDate: payment.bookingDate,
        bookingTime: payment.bookingTime,
        workerName: payment.workerName,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getServicePaymentStatus(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    const reference = String(req.params?.reference || '').trim();

    if (!reference) {
      return res.status(400).json({
        message: 'A payment reference is required.',
      });
    }

    const payment = await ServicePayment.findOne({
      reference,
      buyerUserId: req.user._id.toString(),
    });

    if (!payment) {
      return res.status(404).json({
        message: 'That rental payment could not be found on this account.',
      });
    }

    if (!payment.bookingRef && payment.xenditInvoiceId) {
      try {
        await refreshServicePaymentFromXendit(payment);
      } catch (refreshError) {
        console.warn('Unable to refresh rental payment from Xendit:', refreshError?.message || refreshError);
      }
    }

    return res.json({
      payment: {
        reference: payment.reference,
        status: payment.status,
        total: payment.total,
        subtotal: payment.subtotal,
        tax: payment.tax,
        paymentMethod: payment.paymentMethod,
        bookingRef: payment.bookingRef,
        checkoutUrl: payment.checkoutUrl,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getMarketplacePaymentStatus(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    const reference = String(req.params?.reference || '').trim();

    if (!reference) {
      return res.status(400).json({
        message: 'A payment reference is required.',
      });
    }

    const payment = await MarketplacePayment.findOne({
      reference,
      buyerUserId: req.user._id.toString(),
    });

    if (!payment) {
      return res.status(404).json({
        message: 'That marketplace payment could not be found on this account.',
      });
    }

    if (payment.xenditInvoiceId) {
      try {
        await refreshMarketplacePaymentFromXendit(payment);
      } catch (refreshError) {
        console.warn('Unable to refresh marketplace payment from Xendit:', refreshError?.message || refreshError);
      }
    }

    return res.json({
      payment: {
        reference: payment.reference,
        status: payment.status,
        paymentMethod: payment.paymentMethod,
        total: payment.total,
        checkoutUrl: payment.checkoutUrl,
      },
      receipt: buildMarketplaceReceipt(payment),
    });
  } catch (error) {
    next(error);
  }
}

export async function handleXenditWebhook(req, res, next) {
  try {
    if (!verifyXenditCallbackToken(req.headers['x-callback-token'])) {
      return res.status(401).json({
        message: 'Invalid Xendit callback token.',
      });
    }

    const reference = String(req.body?.external_id || '').trim();

    if (!reference) {
      return res.status(400).json({
        message: 'Missing payment reference.',
      });
    }

    const nextStatus = mapInvoiceStatusToLaborPaymentStatus(req.body?.status);

    if (reference.startsWith('MPAY-')) {
      const payment = await MarketplacePayment.findOne({ reference });

      if (!payment) {
        return res.status(404).json({
          message: 'Marketplace payment record not found.',
        });
      }

      payment.xenditInvoiceId = String(req.body?.id || payment.xenditInvoiceId || '').trim();
      payment.xenditInvoiceStatus = String(req.body?.status || '').trim();
      payment.xenditWebhookPayload = req.body;
      payment.status = nextStatus;

      if (nextStatus === 'paid') {
        payment.paidAt = payment.paidAt || new Date();
        await payment.save();
        await fulfillMarketplacePayment(payment);
      } else {
        await payment.save();
      }
      return res.json({
        received: true,
      });
    }

    if (reference.startsWith('SPAY-')) {
      const payment = await ServicePayment.findOne({ reference });

      if (!payment) {
        return res.status(404).json({
          message: 'Rental payment record not found.',
        });
      }

      payment.xenditInvoiceId = String(req.body?.id || payment.xenditInvoiceId || '').trim();
      payment.xenditInvoiceStatus = String(req.body?.status || '').trim();
      payment.xenditWebhookPayload = req.body;
      payment.status = nextStatus;

      if (nextStatus === 'paid') {
        payment.paidAt = payment.paidAt || new Date();
        await payment.save();
        await activatePaidServiceBooking(payment);
      } else {
        await payment.save();
      }

      return res.json({
        received: true,
      });
    }

    const payment = await LaborPayment.findOne({ reference });

    if (!payment) {
      return res.status(404).json({
        message: 'Labor payment record not found.',
      });
    }

    payment.xenditInvoiceId = String(req.body?.id || payment.xenditInvoiceId || '').trim();
    payment.xenditInvoiceStatus = String(req.body?.status || '').trim();
    payment.xenditWebhookPayload = req.body;
    payment.status = nextStatus;

    if (nextStatus === 'paid') {
      payment.paidAt = payment.paidAt || new Date();
      await payment.save();
      await activatePaidLaborBooking(payment);
    } else {
      await payment.save();
    }

    return res.json({
      received: true,
    });
  } catch (error) {
    next(error);
  }
}
