import { User } from '../models/User.js';
import { getWalletCashOutRealEnabled } from '../models/PlatformSetting.js';
import { LaborPayment } from '../models/LaborPayment.js';
import { MarketplacePayment } from '../models/MarketplacePayment.js';
import { ServicePayment } from '../models/ServicePayment.js';
import { appendActivity, getUserActivities } from '../utils/activityLog.js';
import {
  sendEmailChangeVerificationCode,
  sendPhoneVerificationCodeEmail,
} from '../utils/mailer.js';
import {
  canManageCommercialFeatures,
  ensurePrivilegedAccess,
  getPenaltyState,
  getUserRoles,
  getVerificationState,
  hasRole,
  isSuperAdmin,
  roleQuery,
} from '../utils/roles.js';
import {
  createMarketplaceListingSignedUrl,
  createMarketplaceListingSignedUrls,
  createMarketplaceListingUploadTarget,
  createMarketplaceRefundSignedUrls,
  createMarketplaceRefundUploadTarget,
  createMarketplaceReviewSignedUrls,
  createMarketplaceReviewUploadTarget,
  createProfileAvatarUploadTarget,
  createProfileAvatarSignedUrl,
  createRentalListingSignedUrls,
  createRentalListingUploadTarget,
  createVerificationUploadTarget,
  deleteVerificationDocuments,
  extractProfileAvatarPath,
} from '../utils/verificationStorage.js';
import {
  buildMarketplaceLogisticsView,
  ensureMarketplaceLogisticsSnapshot,
  getMarketplaceAddressSnapshot,
  getMarketplaceCoordinateSnapshot,
} from '../utils/marketplaceLogistics.js';
import {
  buildMarketplaceWaybillProfileAddress,
  canGenerateMarketplaceWaybill,
  generateMarketplaceWaybillPdf,
} from '../utils/marketplaceWaybill.js';
import {
  createXenditPayout,
  getSupportedWalletCashOutBanks,
  isSupportedWalletCashOutBank,
  mapWalletCashOutMethodToXenditChannel,
} from '../utils/xendit.js';

async function sanitizeProfile(profile) {
  const plainProfile = profile?.toObject?.() || profile || {};
  const avatarPath = plainProfile.avatarPath || extractProfileAvatarPath(plainProfile.avatarUrl || '');

  if (!avatarPath) {
    return plainProfile;
  }

  try {
    const { url } = await createProfileAvatarSignedUrl(avatarPath);
    return {
      ...plainProfile,
      avatarPath,
      avatarUrl: url,
    };
  } catch {
    return plainProfile;
  }
}

function buildPhoneVerificationState(user) {
  return {
    status: user?.phoneVerification?.status === 'verified' ? 'verified' : 'unverified',
    source: user?.phoneVerification?.source || 'email',
    verifiedAt: user?.phoneVerification?.verifiedAt || null,
    requestedAt: user?.phoneVerification?.requestedAt || null,
  };
}

function buildWalletSummary(user) {
  const wallet = user?.wallet || {};
  const transactions = Array.isArray(wallet?.transactions) ? wallet.transactions : [];

  return {
    balance: Number(wallet?.balance || 0),
    totalEarned: Number(wallet?.totalEarned || 0),
    totalWithdrawn: Number(wallet?.totalWithdrawn || 0),
    transactions: transactions
      .map((transaction) => ({
        id: String(transaction?.id || '').trim(),
        type: String(transaction?.type || '').trim(),
        amount: Number(transaction?.amount || 0),
        status: String(transaction?.status || 'completed').trim(),
        method: String(transaction?.method || '').trim(),
        description: String(transaction?.description || '').trim(),
        reference: String(transaction?.reference || '').trim(),
        destinationLabel: String(transaction?.destinationLabel || '').trim(),
        createdAt: transaction?.createdAt || null,
      }))
      .filter((transaction) => transaction.id)
      .sort((left, right) => new Date(right.createdAt || 0).getTime() - new Date(left.createdAt || 0).getTime()),
  };
}

function ensureWalletState(user) {
  if (!user.wallet) {
    user.wallet = {
      balance: 0,
      totalEarned: 0,
      totalWithdrawn: 0,
      transactions: [],
    };
  }

  user.wallet.balance = Number(user.wallet.balance || 0);
  user.wallet.totalEarned = Number(user.wallet.totalEarned || 0);
  user.wallet.totalWithdrawn = Number(user.wallet.totalWithdrawn || 0);

  if (!Array.isArray(user.wallet.transactions)) {
    user.wallet.transactions = [];
  }

  return user.wallet;
}

function buildWalletTransactionId(prefix = 'WAL') {
  return `${prefix}-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function addWalletTransaction(user, transaction) {
  const wallet = ensureWalletState(user);
  wallet.transactions = [
    {
      id: transaction.id || buildWalletTransactionId(),
      type: transaction.type,
      amount: Number(transaction.amount || 0),
      status: transaction.status || 'completed',
      method: transaction.method || '',
      description: transaction.description || '',
      reference: transaction.reference || '',
      destinationLabel: transaction.destinationLabel || '',
      createdAt: transaction.createdAt || new Date(),
    },
    ...wallet.transactions,
  ].slice(0, 100);
}

function creditWallet(user, amount, transaction = {}) {
  const numericAmount = Number(amount || 0);

  if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
    return;
  }

  const wallet = ensureWalletState(user);
  wallet.balance += numericAmount;
  wallet.totalEarned += numericAmount;
  addWalletTransaction(user, {
    ...transaction,
    type: 'credit',
    amount: numericAmount,
    status: transaction.status || 'completed',
  });
}

function buildMarketplaceSellerPayoutTransactionId(orderId) {
  return `MKTREL-${String(orderId || '').trim() || Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

async function releaseMarketplaceSellerPayout({
  sellerUser,
  saleIndex,
  saleOrder,
  buyerUser = null,
  purchaseIndex = -1,
  purchaseOrder = null,
}) {
  const normalizedSaleOrder = saleOrder?.toObject?.() ? saleOrder.toObject() : saleOrder;

  if (!sellerUser || !normalizedSaleOrder) {
    return {
      released: false,
      alreadyReleased: false,
    };
  }

  if (String(normalizedSaleOrder?.sellerPayoutStatus || 'pending').trim() === 'released') {
    return {
      released: false,
      alreadyReleased: true,
    };
  }

  const payoutAmount = Number(
    normalizedSaleOrder?.sellerPayoutAmount || normalizedSaleOrder?.totalPaid || 0,
  );

  if (!Number.isFinite(payoutAmount) || payoutAmount <= 0) {
    return {
      released: false,
      alreadyReleased: false,
    };
  }

  const releasedAt = new Date();
  const transactionId =
    String(normalizedSaleOrder?.sellerPayoutTransactionId || '').trim()
    || buildMarketplaceSellerPayoutTransactionId(normalizedSaleOrder?.orderId);

  creditWallet(sellerUser, payoutAmount, {
    id: transactionId,
    method: 'marketplace_release',
    reference: String(normalizedSaleOrder?.paymentReference || normalizedSaleOrder?.orderId || '').trim(),
    description: `Marketplace payout released for order ${String(normalizedSaleOrder?.orderId || '').trim()}`,
    destinationLabel: '',
    status: 'completed',
    createdAt: releasedAt,
  });

  sellerUser.marketplaceOrders.sales[saleIndex] = {
    ...normalizedSaleOrder,
    sellerPayoutStatus: 'released',
    sellerPayoutAmount: payoutAmount,
    sellerPayoutReleasedAt: releasedAt,
    sellerPayoutTransactionId: transactionId,
  };

  if (buyerUser && purchaseIndex >= 0 && purchaseOrder) {
    const normalizedPurchaseOrder = purchaseOrder?.toObject?.() ? purchaseOrder.toObject() : purchaseOrder;
    buyerUser.marketplaceOrders.purchases[purchaseIndex] = {
      ...normalizedPurchaseOrder,
      sellerPayoutStatus: 'released',
      sellerPayoutAmount: payoutAmount,
      sellerPayoutReleasedAt: releasedAt,
      sellerPayoutTransactionId: transactionId,
    };
  }

  const paymentReference = String(normalizedSaleOrder?.paymentReference || '').trim();

  if (paymentReference) {
    await MarketplacePayment.findOneAndUpdate(
      { reference: paymentReference },
      {
        $set: {
          releasedAt,
        },
        $addToSet: {
          releasedOrderIds: String(normalizedSaleOrder?.orderId || '').trim(),
        },
      },
    );
  }

  appendActivity(sellerUser, {
    description: `Marketplace payout released for order ${String(normalizedSaleOrder?.orderId || '').trim()}`,
    status: 'completed',
    createdAt: releasedAt,
  });

  return {
    released: true,
    alreadyReleased: false,
  };
}

async function reconcileMarketplaceSellerPayouts(user) {
  if (!user || !hasRole(user, 'seller')) {
    return false;
  }

  ensureMarketplaceOrdersState(user);
  const sales = Array.isArray(user?.marketplaceOrders?.sales) ? user.marketplaceOrders.sales : [];
  const releasableEntries = sales
    .map((order, index) => ({
      index,
      order: order?.toObject?.() ? order.toObject() : order,
    }))
    .filter(({ order }) =>
      ['received', 'completed'].includes(String(order?.status || '').trim())
      && String(order?.sellerPayoutStatus || 'pending').trim() !== 'released',
    );

  if (releasableEntries.length === 0) {
    return false;
  }

  let changed = false;

  for (const entry of releasableEntries) {
    const buyerUserId = String(entry.order?.buyerUserId || '').trim();
    const buyerUser = buyerUserId ? await User.findById(buyerUserId) : null;
    let purchaseIndex = -1;
    let purchaseOrder = null;

    if (buyerUser) {
      ensureMarketplaceOrdersState(buyerUser);
      purchaseIndex = buyerUser.marketplaceOrders.purchases.findIndex(
        (order) => String(order?.orderId || '').trim() === String(entry.order?.orderId || '').trim(),
      );
      purchaseOrder = purchaseIndex >= 0 ? buyerUser.marketplaceOrders.purchases[purchaseIndex] : null;
    }

    const releaseResult = await releaseMarketplaceSellerPayout({
      sellerUser: user,
      saleIndex: entry.index,
      saleOrder: entry.order,
      buyerUser,
      purchaseIndex,
      purchaseOrder,
    });

    if (releaseResult.released) {
      changed = true;
      if (buyerUser && purchaseIndex >= 0) {
        await buyerUser.save();
      }
    }
  }

  if (changed) {
    await user.save();
  }

  return changed;
}

async function findRelatedLaborPaymentForBooking(booking = {}) {
  const bookingId = String(booking?.bookingId || '').trim();

  if (bookingId) {
    const paymentByBookingId = await LaborPayment.findOne({ bookingId });

    if (paymentByBookingId) {
      return paymentByBookingId;
    }
  }

  const workerUserId = String(booking?.workerId || '').trim();
  const buyerUserId = String(booking?.bookedByUserId || '').trim();
  const workerType = String(booking?.type || '').trim();
  const bookingDate = String(booking?.date || '').trim();
  const bookingTime = String(booking?.time || '').trim();

  if (!workerUserId || !buyerUserId || !workerType || !bookingDate || !bookingTime) {
    return null;
  }

  return LaborPayment.findOne({
    workerUserId,
    buyerUserId,
    workerType,
    bookingDate,
    bookingTime,
    status: {
      $in: ['paid', 'booking_created', 'ready_for_release', 'release_pending', 'released'],
    },
  }).sort({ createdAt: -1 });
}

async function findRelatedServicePaymentForBooking(booking = {}) {
  const bookingRef = String(booking?.bookingRef || '').trim();

  if (bookingRef) {
    const paymentByBookingRef = await ServicePayment.findOne({ bookingRef });

    if (paymentByBookingRef) {
      return paymentByBookingRef;
    }
  }

  const providerUserId = String(booking?.providerUserId || '').trim();
  const buyerUserId = String(booking?.customerUserId || '').trim();
  const listingId = String(booking?.listingId || '').trim();
  const bookingDate = String(booking?.date || '').trim();
  const bookingTime = String(booking?.time || '').trim();

  if (!providerUserId || !buyerUserId || !listingId || !bookingDate || !bookingTime) {
    return null;
  }

  return ServicePayment.findOne({
    providerUserId,
    buyerUserId,
    listingId,
    bookingDate,
    bookingTime,
    status: {
      $in: ['paid', 'booking_created', 'ready_for_release', 'released'],
    },
  }).sort({ createdAt: -1 });
}

function buildCancellationActorLabel(isBuyerCancelling) {
  return isBuyerCancelling ? 'client' : 'laborer';
}

function buildLaborReviewId() {
  return `LRV-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function debitWalletForCashOut(user, amount, transaction = {}) {
  const numericAmount = Number(amount || 0);

  if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
    throw new Error('Enter a valid cash-out amount.');
  }

  const wallet = ensureWalletState(user);

  if (wallet.balance < numericAmount) {
    throw new Error('Insufficient wallet balance for this cash out.');
  }

  wallet.balance -= numericAmount;
  wallet.totalWithdrawn += numericAmount;
  addWalletTransaction(user, {
    ...transaction,
    type: 'cashout',
    amount: numericAmount,
    status: transaction.status || 'completed',
  });
}

function normalizeCashOutDestination(payload = {}) {
  const method = String(payload?.method || '').trim().toLowerCase();
  const accountName = String(payload?.accountName || '').trim();
  const mobileNumber = normalizePhilippinePhone(payload?.mobileNumber || '');
  const bankCode = String(payload?.bankCode || '').trim().toUpperCase();
  const bankName = String(payload?.bankName || '').trim();
  const accountNumber = String(payload?.accountNumber || '').trim();
  const cardholderName = String(payload?.cardholderName || '').trim();
  const cardBrand = String(payload?.cardBrand || '').trim();
  const cardLast4 = String(payload?.cardLast4 || '').replace(/\D/g, '').slice(-4);

  return {
    method,
    accountName,
    mobileNumber,
    bankCode,
    bankName,
    accountNumber,
    cardholderName,
    cardBrand,
    cardLast4,
  };
}

function buildCashOutDestinationLabel(destination) {
  if (destination.method === 'gcash' || destination.method === 'paymaya') {
    return [destination.accountName, destination.mobileNumber].filter(Boolean).join(' - ');
  }

  if (destination.method === 'card') {
    const masked = destination.cardLast4 ? `**** ${destination.cardLast4}` : '';
    return [destination.cardBrand, masked, destination.cardholderName].filter(Boolean).join(' - ');
  }

  if (destination.method === 'bank') {
    return [destination.bankName || destination.bankCode, destination.accountNumber, destination.accountName]
      .filter(Boolean)
      .join(' - ');
  }

  return '';
}

function normalizeXenditPayoutStatus(status) {
  const normalized = String(status || '').trim().toUpperCase();

  if (['SUCCEEDED', 'SUCCESSFUL', 'COMPLETED', 'PAID', 'SETTLED'].includes(normalized)) {
    return 'completed';
  }

  if (['FAILED', 'CANCELLED', 'REJECTED', 'EXPIRED'].includes(normalized)) {
    return 'failed';
  }

  return 'pending';
}

function buildCashOutMethodLabel(method) {
  if (method === 'gcash') {
    return 'GCash';
  }

  if (method === 'paymaya') {
    return 'PayMaya';
  }

  if (method === 'bank') {
    return 'bank account';
  }

  return 'wallet';
}

async function createWalletCashOutPayout({
  reference,
  amount,
  destination,
  destinationLabel,
  user,
}) {
  const channelCode =
    destination.method === 'bank'
      ? destination.bankCode
      : mapWalletCashOutMethodToXenditChannel(destination.method);
  const realCashOutEnabled = await getWalletCashOutRealEnabled();

  if (!realCashOutEnabled) {
    return {
      id: `test-payout-${reference}`,
      status: 'COMPLETED',
      isTestMode: true,
    };
  }

  return createXenditPayout({
    reference_id: reference,
    channel_code: channelCode,
    currency: 'PHP',
    amount,
    description: `AgriHub wallet cash out to ${buildCashOutMethodLabel(destination.method)}`,
    channel_properties: {
      account_holder_name: destination.accountName,
      account_number: destination.method === 'bank' ? destination.accountNumber : destination.mobileNumber,
      mobile_number: destination.method === 'bank' ? undefined : destination.mobileNumber,
    },
    metadata: {
      agrihubUserId: String(user?._id || '').trim(),
      destinationMethod: destination.method,
      destinationLabel,
    },
  });
}

async function sanitizeUser(user) {
  return {
    id: user._id.toString(),
    name: user.name,
    email: user.email,
    phone: user.phone,
    role: user.role,
    accountType: user.accountType,
    roles: getUserRoles(user),
    isAdmin: hasRole(user, 'admin'),
    isSuperAdmin: isSuperAdmin(user),
    verification: getVerificationState(user),
    verificationMeta: {
      seller: {
        reviewReason: user.verification?.seller?.reviewReason || '',
        rejectedAt: user.verification?.seller?.rejectedAt || null,
      },
      laborer: {
        reviewReason: user.verification?.laborer?.reviewReason || '',
        rejectedAt: user.verification?.laborer?.rejectedAt || null,
      },
    },
    emailChangePending: user?.emailVerification?.pendingEmail
      ? {
          email: user.emailVerification.pendingEmail,
          requestedAt: user.emailVerification?.requestedAt || null,
        }
      : null,
    phoneChangePending: user?.phoneVerification?.pendingPhone
      ? {
          phone: user.phoneVerification.pendingPhone,
          requestedAt: user?.phoneVerification?.requestedAt || null,
        }
      : null,
    phoneVerification: buildPhoneVerificationState(user),
    wallet: buildWalletSummary(user),
    penalty: getPenaltyState(user),
    canManageCommercialFeatures: canManageCommercialFeatures(user),
    profile: await sanitizeProfile(user.profile),
  };
}

function buildEmailVerificationCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function buildVerificationWindow() {
  const now = new Date();
  return {
    now,
    expiresAt: new Date(now.getTime() + 15 * 60 * 1000),
  };
}

function isEmailVerificationCodeValid(user, code) {
  return (
    user?.emailVerification?.code &&
    user.emailVerification.code === code &&
    user.emailVerification.expiresAt &&
    new Date(user.emailVerification.expiresAt).getTime() > Date.now()
  );
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function normalizeExperienceYears(value) {
  const digits = String(value || '').replace(/\D/g, '');
  return digits;
}

function formatExperienceYears(value) {
  const normalized = normalizeExperienceYears(value);
  return normalized ? `${normalized} years` : '';
}

function formatPhpCurrency(value) {
  const parsed = Number(value || 0);

  return new Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency: 'PHP',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number.isFinite(parsed) ? parsed : 0);
}

function formatPhpRate(value, unit = 'hour') {
  return `${formatPhpCurrency(value)}/${unit === 'hour' ? 'hr' : unit}`;
}

function buildMarketplaceListingId() {
  return `ML-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function buildMarketplaceVarietyId() {
  return `MLV-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function buildRentalListingId() {
  return `RTL-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function normalizeMarketplaceListingPayload(payload = {}) {
  const normalizedImagePaths = Array.isArray(payload?.imagePaths)
    ? payload.imagePaths
        .map((path) => String(path || '').trim())
        .filter(Boolean)
    : [];
  const normalizedVarieties = Array.isArray(payload?.varieties)
    ? payload.varieties
        .map((variety, index) => ({
          id: String(variety?.id || `MVR-${index + 1}`).trim(),
          label: String(variety?.label || '').trim(),
          price: Number(variety?.price || 0),
          stock: Number(variety?.stock || 0),
        }))
        .filter((variety) => variety.label && Number.isFinite(variety.price) && variety.price > 0 && Number.isFinite(variety.stock) && variety.stock > 0)
    : [];
  const normalizedReviews = Array.isArray(payload?.reviews)
    ? payload.reviews
        .map((review, index) => ({
          id: String(review?.id || `MPR-${index + 1}`).trim(),
          author: String(review?.author || '').trim(),
          authorUserId: String(review?.authorUserId || '').trim(),
          rating: Number(review?.rating || 0),
          comment: String(review?.comment || '').trim(),
          imagePaths: Array.isArray(review?.imagePaths)
            ? review.imagePaths.map((path) => String(path || '').trim()).filter(Boolean)
            : [],
          imageUrls: Array.isArray(review?.imageUrls)
            ? review.imageUrls.map((url) => String(url || '').trim()).filter(Boolean)
            : [],
          createdAt: review?.createdAt || null,
        }))
        .filter((review) => Number.isFinite(review.rating) && review.rating > 0)
    : [];
  const fallbackVarietyLabel = String(payload?.variety || '').trim();
  const fallbackPrice = Number(payload?.price || 0);
  const fallbackStock = Number(payload?.stock || 0);
  const effectiveVarieties = normalizedVarieties.length > 0
    ? normalizedVarieties
    : fallbackVarietyLabel && Number.isFinite(fallbackPrice) && fallbackPrice > 0 && Number.isFinite(fallbackStock) && fallbackStock > 0
      ? [{
          id: buildMarketplaceVarietyId(),
          label: fallbackVarietyLabel,
          price: fallbackPrice,
          stock: fallbackStock,
        }]
      : [];
  const aggregatedStock = effectiveVarieties.length > 0
    ? effectiveVarieties.reduce((sum, variety) => sum + Number(variety.stock || 0), 0)
    : fallbackStock;
  const lowestPrice = effectiveVarieties.length > 0
    ? effectiveVarieties.reduce((lowest, variety) => Math.min(lowest, Number(variety.price || 0)), Number(effectiveVarieties[0]?.price || 0))
    : fallbackPrice;

  return {
    listingId: String(payload?.listingId || '').trim(),
    name: String(payload?.name || '').trim(),
    category: String(payload?.category || '').trim().toLowerCase(),
    description: String(payload?.description || '').trim(),
    brand: String(payload?.brand || '').trim(),
    variety: String(payload?.variety || '').trim(),
    condition: String(payload?.condition || '').trim(),
    harvestDate: String(payload?.harvestDate || '').trim(),
    location: String(payload?.location || '').trim(),
    price: Number.isFinite(lowestPrice) ? lowestPrice : 0,
    unit: String(payload?.unit || '').trim(),
    stock: Number.isFinite(aggregatedStock) ? aggregatedStock : 0,
    minimumOrder: Number(payload?.minimumOrder || 0),
    varieties: effectiveVarieties,
    image: normalizedImagePaths[0] || String(payload?.image || '').trim(),
    imagePaths: normalizedImagePaths,
    reviews: normalizedReviews,
    rating: Number(payload?.rating || 0),
    reviewCount: Number(payload?.reviewCount || normalizedReviews.length || 0),
    status: String(payload?.status || '').trim() || 'active',
    views: Number(payload?.views || 0),
    orders: Number(payload?.orders || 0),
  };
}

function normalizeRentalListingPayload(payload = {}) {
  const normalizedImagePaths = Array.isArray(payload?.imagePaths)
    ? payload.imagePaths
        .map((entry) => String(entry || '').trim())
        .filter(Boolean)
    : [];

  return {
    listingId: String(payload?.listingId || '').trim(),
    name: String(payload?.name || '').trim(),
    category: String(payload?.category || 'equipment-rental').trim().toLowerCase(),
    description: String(payload?.description || '').trim(),
    condition: String(payload?.condition || '').trim(),
    identifier: String(payload?.identifier || '').trim(),
    location: String(payload?.location || '').trim(),
    rate: Number(payload?.rate || payload?.price || 0),
    unit: String(payload?.unit || 'day').trim().toLowerCase(),
    minimumOrder: Number(payload?.minimumOrder || 0),
    quantity: Number(payload?.quantity || 0),
    available: payload?.available !== false,
    ownerRole: String(payload?.ownerRole || '').trim().toLowerCase(),
    status: String(payload?.status || '').trim().toLowerCase() || 'active',
    image: normalizedImagePaths[0] || String(payload?.image || '').trim(),
    imagePaths: normalizedImagePaths,
  };
}

function getMarketplaceListingLocationOptions(user) {
  const options = [];
  const farmLocation = String(user?.profile?.location || '').trim();
  const addressLocation = String(user?.profile?.address || '').trim();

  if (farmLocation) {
    options.push(farmLocation);
  }

  if (addressLocation && addressLocation !== farmLocation) {
    options.push(addressLocation);
  }

  return options;
}

function getRentalListingLocation(user) {
  const profileAddress = String(user?.profile?.address || '').trim();

  if (profileAddress) {
    return profileAddress;
  }

  return String(user?.profile?.location || '').trim();
}

function buildMarketplaceListingRatingSummary(listing = {}) {
  const reviews = Array.isArray(listing?.reviews)
    ? listing.reviews.filter((review) => Number.isFinite(Number(review?.rating || 0)) && Number(review?.rating || 0) > 0)
    : [];

  if (reviews.length === 0) {
    return {
      rating: 0,
      reviewCount: 0,
      reviews: [],
    };
  }

  const totalRating = reviews.reduce((sum, review) => sum + Number(review?.rating || 0), 0);

  return {
    rating: totalRating / reviews.length,
    reviewCount: reviews.length,
    reviews: reviews.map((review) => ({
      id: String(review?.id || '').trim(),
      author: String(review?.author || '').trim(),
      authorUserId: String(review?.authorUserId || '').trim(),
      rating: Number(review?.rating || 0),
      comment: String(review?.comment || '').trim(),
      imagePaths: Array.isArray(review?.imagePaths)
        ? review.imagePaths.map((path) => String(path || '').trim()).filter(Boolean)
        : [],
      imageUrls: Array.isArray(review?.imageUrls)
        ? review.imageUrls.map((url) => String(url || '').trim()).filter(Boolean)
        : [],
      createdAt: review?.createdAt || null,
    })),
  };
}

function ensureMarketplaceOrdersState(user) {
  if (!user.marketplaceOrders) {
    user.marketplaceOrders = {
      purchases: [],
      sales: [],
    };
  }

  if (!Array.isArray(user.marketplaceOrders.purchases)) {
    user.marketplaceOrders.purchases = [];
  }

  if (!Array.isArray(user.marketplaceOrders.sales)) {
    user.marketplaceOrders.sales = [];
  }

  return user.marketplaceOrders;
}

function buildMarketplaceReviewId() {
  return `MPR-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

async function buildMarketplaceOrderResponse(order = {}, fallback = {}) {
  const imagePath = String(order?.imagePath || '').trim();
  let image = '';
  let fallbackSellerPhone = String(order?.sellerPhone || '').trim();
  let fallbackSellerEmail = String(order?.sellerEmail || '').trim().toLowerCase();
  const sellerUserId = String(order?.sellerUserId || '').trim();
  const buyerUserId = String(order?.buyerUserId || '').trim();
  const snapshotSellerCoordinates = normalizeCoordinates(order?.sellerCoordinates);
  const snapshotBuyerCoordinates = normalizeCoordinates(order?.buyerCoordinates);
  const fallbackSellerCoordinates = normalizeCoordinates(fallback?.sellerCoordinates);
  const fallbackBuyerCoordinates = normalizeCoordinates(fallback?.buyerCoordinates);
  const shouldLoadSellerProfile =
    Boolean(sellerUserId) &&
    (
      !String(order?.sellerAddress || fallback?.sellerAddress || '').trim()
      || snapshotSellerCoordinates.lat === null
      || snapshotSellerCoordinates.lng === null
      || !fallbackSellerPhone
      || !fallbackSellerEmail
    );
  const shouldLoadBuyerProfile =
    Boolean(buyerUserId) &&
    (
      !String(order?.buyerAddress || fallback?.buyerAddress || '').trim()
      || snapshotBuyerCoordinates.lat === null
      || snapshotBuyerCoordinates.lng === null
    );
  const [sellerUser, buyerUser] = await Promise.all([
    shouldLoadSellerProfile
      ? User.findById(sellerUserId).select('email phone profile.address profile.location profile.coordinates')
      : null,
    shouldLoadBuyerProfile
      ? User.findById(buyerUserId).select('profile.address profile.location profile.coordinates')
      : null,
  ]);
  const sellerAddress = String(
    order?.sellerAddress
    || fallback?.sellerAddress
    || buildMarketplaceWaybillProfileAddress(sellerUser?.profile || {})
    || sellerUser?.profile?.location
    || order?.location
    || ''
  ).trim();
  const buyerAddress = String(
    order?.buyerAddress
    || fallback?.buyerAddress
    || buildMarketplaceWaybillProfileAddress(buyerUser?.profile || {})
    || buyerUser?.profile?.location
    || ''
  ).trim();
  const sellerCoordinates = getMarketplaceCoordinateSnapshot(
    { profile: { coordinates: snapshotSellerCoordinates } },
    getMarketplaceCoordinateSnapshot(
      { profile: { coordinates: fallbackSellerCoordinates } },
      sellerUser?.profile?.coordinates || {},
    ),
  );
  const buyerCoordinates = getMarketplaceCoordinateSnapshot(
    { profile: { coordinates: snapshotBuyerCoordinates } },
    getMarketplaceCoordinateSnapshot(
      { profile: { coordinates: fallbackBuyerCoordinates } },
      buyerUser?.profile?.coordinates || {},
    ),
  );

  if (imagePath) {
    try {
      const { url } = await createMarketplaceListingSignedUrl(imagePath);
      image = url;
    } catch {
      image = '';
    }
  }

  if ((!fallbackSellerPhone || !fallbackSellerEmail) && sellerUserId) {
    try {
      if (sellerUser) {
        fallbackSellerPhone = fallbackSellerPhone || String(sellerUser.phone || '').trim();
        fallbackSellerEmail = fallbackSellerEmail || String(sellerUser.email || '').trim().toLowerCase();
      }
    } catch {
      // Keep the saved order snapshot when seller lookup is unavailable.
    }
  }

  const logistics = await buildMarketplaceLogisticsView(order, {
    orderId: String(order?.orderId || '').trim(),
    status: String(order?.status || 'paid').trim(),
    createdAt: order?.createdAt || null,
    sellerAddress,
    buyerAddress,
    sellerCoordinates,
    buyerCoordinates,
  });
  const fallbackRefundImageUrls = Array.isArray(order?.refundRequest?.imageUrls)
    ? order.refundRequest.imageUrls.map((url) => String(url || '').trim()).filter(Boolean)
    : [];
  let resolvedRefundImageUrls = fallbackRefundImageUrls;

  if (resolvedRefundImageUrls.length === 0) {
    try {
      const signedRefundImages = await createMarketplaceRefundSignedUrls(
        Array.isArray(order?.refundRequest?.imagePaths) ? order.refundRequest.imagePaths : [],
      );
      resolvedRefundImageUrls = Array.isArray(signedRefundImages?.urls) ? signedRefundImages.urls.filter(Boolean) : [];
    } catch {
      resolvedRefundImageUrls = [];
    }
  }

  return {
    orderId: String(order?.orderId || '').trim(),
    paymentReference: String(order?.paymentReference || '').trim(),
    listingId: String(order?.listingId || '').trim(),
    sellerUserId: String(order?.sellerUserId || '').trim(),
    buyerUserId: String(order?.buyerUserId || '').trim(),
    sellerName: String(order?.sellerName || '').trim(),
    sellerEmail: fallbackSellerEmail,
    sellerPhone: fallbackSellerPhone,
    sellerAddress,
    buyerName: String(order?.buyerName || '').trim(),
    buyerPhone: String(order?.buyerPhone || '').trim(),
    buyerAddress,
    itemName: String(order?.itemName || '').trim(),
    category: String(order?.category || '').trim(),
    unit: String(order?.unit || '').trim(),
    quantity: Number(order?.quantity || 0),
    price: Number(order?.price || 0),
    subtotal: Number(order?.subtotal || 0),
    tax: Number(order?.tax || 0),
    shipping: Number(order?.shipping || 0),
    totalPaid: Number(order?.totalPaid || 0),
    paymentMethod: String(order?.paymentMethod || '').trim(),
    location: String(order?.location || '').trim(),
    image,
    selectedVarietyId: String(order?.selectedVarietyId || '').trim(),
    selectedVarietyLabel: String(order?.selectedVarietyLabel || '').trim(),
    status: String(order?.status || 'paid').trim(),
    reviewed: Boolean(order?.reviewed),
    reviewRating: Number(order?.reviewRating || 0),
    reviewComment: String(order?.reviewComment || '').trim(),
    reviewImagePaths: Array.isArray(order?.reviewImagePaths)
      ? order.reviewImagePaths.map((path) => String(path || '').trim()).filter(Boolean)
      : [],
    reviewImageUrls: Array.isArray(order?.reviewImageUrls)
      ? order.reviewImageUrls.map((url) => String(url || '').trim()).filter(Boolean)
      : [],
    paidAt: order?.paidAt || null,
    preparingAt: order?.preparingAt || null,
    readyForPickupAt: order?.readyForPickupAt || null,
    inTransitAt: order?.inTransitAt || null,
    receivedAt: order?.receivedAt || null,
    completedAt: order?.completedAt || null,
    cancelledAt: order?.cancelledAt || null,
    cancellationReason: String(order?.cancellationReason || '').trim(),
    cancelledBy: String(order?.cancelledBy || '').trim(),
    refundRequest: {
      status: String(order?.refundRequest?.status || 'none').trim(),
      reason: String(order?.refundRequest?.reason || '').trim(),
      imagePaths: Array.isArray(order?.refundRequest?.imagePaths)
        ? order.refundRequest.imagePaths.map((path) => String(path || '').trim()).filter(Boolean)
        : [],
      imageUrls: resolvedRefundImageUrls,
      requestedAt: order?.refundRequest?.requestedAt || null,
      reviewedAt: order?.refundRequest?.reviewedAt || null,
      reviewedByUserId: String(order?.refundRequest?.reviewedByUserId || '').trim(),
      reviewedByName: String(order?.refundRequest?.reviewedByName || '').trim(),
      adminDecisionReason: String(order?.refundRequest?.adminDecisionReason || '').trim(),
      refundedAt: order?.refundRequest?.refundedAt || null,
    },
    waybill: {
      available: canGenerateMarketplaceWaybill(order),
      generatedAt: order?.waybill?.generatedAt || null,
      downloadPath: `/data/marketplace/orders/${String(order?.orderId || '').trim()}/waybill`,
    },
    createdAt: order?.createdAt || null,
    logistics,
  };
}

function getMarketplaceListingValidationMessage(listing) {
  if (!listing.name || !listing.category || !listing.description || !listing.unit || !listing.location) {
    return 'Product name, category, description, unit, and location are required.';
  }

  if (!Number.isFinite(listing.stock) || listing.stock <= 0) {
    return 'Enter a valid available stock quantity.';
  }

  if (!Number.isFinite(listing.minimumOrder) || listing.minimumOrder <= 0) {
    return 'Enter a valid minimum order quantity.';
  }

  if (listing.minimumOrder > listing.stock) {
    return 'Minimum order cannot be higher than available stock.';
  }

  if (!Array.isArray(listing.imagePaths) || listing.imagePaths.length < 1) {
    return 'Upload at least 1 product photo for each listing.';
  }

  if (listing.imagePaths.length > 3) {
    return 'Upload at most 3 product photos for each listing.';
  }

  if (['seeds', 'grains', 'vegetables', 'fruits'].includes(listing.category)) {
    if (!Array.isArray(listing.varieties) || listing.varieties.length === 0) {
      return 'Add at least one variety with its own price and stock.';
    }

    if (listing.varieties.some((variety) => !variety.label || !Number.isFinite(variety.price) || variety.price <= 0 || !Number.isFinite(variety.stock) || variety.stock <= 0)) {
      return 'Each variety needs a name, valid price, and valid stock.';
    }
  }

  if (['fertilizer', 'equipment'].includes(listing.category) && !listing.brand) {
    return 'Brand is required for fertilizer and equipment listings.';
  }

  if (!['seeds', 'grains', 'vegetables', 'fruits'].includes(listing.category)) {
    if (!Number.isFinite(listing.price) || listing.price <= 0) {
      return 'Enter a valid listing price.';
    }
  }

  if (listing.category === 'equipment' && !listing.condition) {
    return 'Condition is required for equipment listings.';
  }

  return '';
}

function getRentalListingValidationMessage(listing) {
  if (!listing.name || !listing.description || !listing.location || !listing.unit) {
    return 'Rental name, description, location, and pricing unit are required.';
  }

  if (!Number.isFinite(listing.rate) || listing.rate <= 0) {
    return 'Enter a valid rental rate.';
  }

  if (!Number.isFinite(listing.quantity) || listing.quantity <= 0) {
    return 'Enter a valid available quantity.';
  }

  if (!Number.isFinite(listing.minimumOrder) || listing.minimumOrder <= 0) {
    return 'Enter a valid minimum rental quantity.';
  }

  if (listing.minimumOrder > listing.quantity) {
    return 'Minimum rental quantity cannot be higher than the available quantity.';
  }

  if (!Array.isArray(listing.imagePaths) || listing.imagePaths.length < 1) {
    return 'Upload at least 1 rental photo for each listing.';
  }

  if (listing.imagePaths.length > 3) {
    return 'Upload at most 3 rental photos for each listing.';
  }

  return '';
}

async function buildMarketplaceListingResponse(listing = {}) {
  const normalized = normalizeMarketplaceListingPayload(listing);
  const ratingSummary = buildMarketplaceListingRatingSummary(normalized);
  let imageUrls = [];

  try {
    const signedImages = await createMarketplaceListingSignedUrls(normalized.imagePaths);
    imageUrls = Array.isArray(signedImages?.urls) ? signedImages.urls : [];
  } catch {
    imageUrls = [];
  }
  const reviews = await Promise.all(
    ratingSummary.reviews.map(async (review) => {
      const fallbackImageUrls = Array.isArray(review?.imageUrls) ? review.imageUrls.filter(Boolean) : [];
      let resolvedImageUrls = fallbackImageUrls;

      if (resolvedImageUrls.length === 0) {
        try {
          const signedReviewImages = await createMarketplaceReviewSignedUrls(
            Array.isArray(review?.imagePaths) ? review.imagePaths : [],
          );
          resolvedImageUrls = Array.isArray(signedReviewImages?.urls) ? signedReviewImages.urls.filter(Boolean) : [];
        } catch {
          resolvedImageUrls = [];
        }
      }

      return {
        ...review,
        imageUrls: resolvedImageUrls,
      };
    }),
  );

  return {
    ...normalized,
    variety: normalized.varieties[0]?.label || normalized.variety || '',
    rating: ratingSummary.rating,
    reviewCount: ratingSummary.reviewCount,
    reviews,
    image: imageUrls[0] || '',
    images: imageUrls.filter(Boolean),
  };
}

async function buildRentalListingResponse(listing = {}, owner = {}) {
  const normalized = normalizeRentalListingPayload(listing);
  let imageUrls = [];

  try {
    const signedImages = await createRentalListingSignedUrls(normalized.imagePaths);
    imageUrls = Array.isArray(signedImages?.urls) ? signedImages.urls.filter(Boolean) : [];
  } catch {
    imageUrls = [];
  }

  const ownerName = String(owner?.name || owner?.provider || owner?.seller || '').trim();
  const ownerRole = String(owner?.ownerRole || normalized.ownerRole || '').trim().toLowerCase();
  const status = normalized.quantity > 0 && normalized.available ? 'active' : 'unavailable';

  return {
    listingId: normalized.listingId,
    id: normalized.listingId,
    name: normalized.name,
    category: normalized.category || 'equipment-rental',
    description: normalized.description,
    condition: normalized.condition,
    identifier: normalized.identifier,
    location: normalized.location,
    rate: Number(normalized.rate || 0),
    price: Number(normalized.rate || 0),
    unit: normalized.unit || 'day',
    minimumOrder: Number(normalized.minimumOrder || 1),
    quantity: Number(normalized.quantity || 0),
    available: status === 'active',
    status,
    ownerRole,
    seller: ownerName,
    provider: ownerName,
    ownerUserId: String(owner?.userId || '').trim(),
    ownerPhone: String(owner?.phone || '').trim(),
    image: imageUrls[0] || normalized.image || '',
    images: imageUrls,
    imagePaths: normalized.imagePaths,
    canEdit: Boolean(owner?.canEdit),
  };
}

function normalizePhilippinePhone(phone) {
  const digits = String(phone || '').replace(/\D/g, '');

  if (digits.startsWith('639') && digits.length === 12) {
    return `0${digits.slice(2)}`;
  }

  if (digits.startsWith('09') && digits.length === 11) {
    return digits;
  }

  return digits;
}

function isValidPhilippineMobile(phone) {
  return /^09\d{9}$/.test(phone);
}

async function issuePhoneVerificationCode(user, phone) {
  const normalizedPhone = normalizePhilippinePhone(phone);

  if (!normalizedPhone || !isValidPhilippineMobile(normalizedPhone)) {
    throw new Error('Please enter a valid Philippine mobile number.');
  }

  const code = buildEmailVerificationCode();
  const { now, expiresAt } = buildVerificationWindow();

  user.phone = normalizedPhone;
  user.phoneVerification = {
    status: 'unverified',
    source: 'email',
    code,
    expiresAt,
    requestedAt: now,
    verifiedAt: null,
    pendingPhone: normalizedPhone,
  };

  await user.save();
  await sendPhoneVerificationCodeEmail({
    toEmail: user.email,
    code,
    name: user.name,
    phone: normalizedPhone,
  });

  return {
    now,
    normalizedPhone,
  };
}

function buildVerificationProfileAddress(profile = {}) {
  const directAddress = String(profile?.address || '').trim();

  if (directAddress) {
    return directAddress;
  }

  return [profile?.streetAddress, profile?.city, profile?.state, profile?.country]
    .map((value) => String(value || '').trim())
    .filter(Boolean)
    .join(', ');
}

function normalizeProvinceToken(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/\bprovince\b/g, '')
    .replace(/\bcity\b/g, '')
    .replace(/\bmunicipality\b/g, '')
    .replace(/\bmetro\b/g, '')
    .replace(/[0-9]/g, ' ')
    .replace(/[^a-z\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function buildProvinceCandidates(profile = {}) {
  const candidates = new Set();
  const pushCandidate = (value) => {
    const normalized = normalizeProvinceToken(value);

    if (!normalized) {
      return;
    }

    candidates.add(normalized);

    const parts = normalized
      .split(/[\s/-]+/)
      .map((part) => part.trim())
      .filter(Boolean);

    if (parts.length > 1) {
      const trailing = parts[parts.length - 1];

      if (trailing.length >= 3) {
        candidates.add(trailing);
      }
    }
  };

  pushCandidate(profile?.state);

  [profile?.city, profile?.address, profile?.location, profile?.streetAddress]
    .map((value) => String(value || '').trim())
    .filter(Boolean)
    .forEach((value) => {
      value
        .split(',')
        .map((segment) => segment.trim())
        .filter(Boolean)
        .forEach(pushCandidate);
    });

  return candidates;
}

function getPrimaryProvinceLabel(profile = {}) {
  const directState = normalizeProvinceToken(profile?.state);

  if (directState) {
    return directState
      .split(' ')
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join(' ');
  }

  const firstCandidate = Array.from(buildProvinceCandidates(profile))[0] || '';

  return firstCandidate
    .split(' ')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

function belongsToSameProvince(currentProfile = {}, workerProfile = {}) {
  const currentCandidates = buildProvinceCandidates(currentProfile);
  const workerCandidates = buildProvinceCandidates(workerProfile);

  if (currentCandidates.size === 0 || workerCandidates.size === 0) {
    return false;
  }

  return Array.from(currentCandidates).some((candidate) => workerCandidates.has(candidate));
}

async function getProfileStats(user) {
  const verification = getVerificationState(user);
  const primaryLaborListing = getLaborListings(user)[0];
  const userId = String(user?._id || '').trim();
  const purchaseOrders = Array.isArray(user?.marketplaceOrders?.purchases)
    ? user.marketplaceOrders.purchases
    : [];
  const salesOrders = Array.isArray(user?.marketplaceOrders?.sales)
    ? user.marketplaceOrders.sales
    : [];
  const buyerActiveBookings = Array.isArray(user?.laborBookings?.activeBookings)
    ? user.laborBookings.activeBookings
    : [];
  const buyerBookingHistory = Array.isArray(user?.laborBookings?.bookingHistory)
    ? user.laborBookings.bookingHistory
    : [];
  const serviceBookings = Array.isArray(user?.serviceProfile?.bookings)
    ? user.serviceProfile.bookings
    : [];
  const activeJobs = Array.isArray(user.laborProfile?.activeBookings)
    ? user.laborProfile.activeBookings.length
    : 0;
  const completedJobs = Array.isArray(user.laborProfile?.bookingHistory)
    ? user.laborProfile.bookingHistory.filter((booking) => booking?.status === 'completed').length
    : 0;
  const laborRate = Number(primaryLaborListing?.rate || 0);
  const laborAvailability = String(primaryLaborListing?.availability || 'Unavailable').trim() || 'Unavailable';
  const laborRating = Number(user.laborProfile?.rating || 0);
  const marketplaceSales = salesOrders
    .filter((order) => String(order?.sellerPayoutStatus || '').trim() === 'released')
    .reduce(
      (sum, order) => sum + Number(order?.sellerPayoutAmount || order?.totalPaid || 0),
      0,
    );
  const [laborSalesResult, rentalSalesResult] = userId
    ? await Promise.all([
        LaborPayment.aggregate([
          {
            $match: {
              workerUserId: userId,
              releaseStatus: 'released',
              refundStatus: { $ne: 'refunded' },
            },
          },
          {
            $group: {
              _id: null,
              total: { $sum: { $ifNull: ['$subtotal', '$total'] } },
            },
          },
        ]),
        ServicePayment.aggregate([
          {
            $match: {
              providerUserId: userId,
              releaseStatus: 'released',
              refundStatus: { $ne: 'refunded' },
            },
          },
          {
            $group: {
              _id: null,
              total: { $sum: { $ifNull: ['$subtotal', '$total'] } },
            },
          },
        ]),
      ])
    : [[], []];
  const laborSales = Number(laborSalesResult?.[0]?.total || 0);
  const rentalSales = Number(rentalSalesResult?.[0]?.total || 0);
  const totalSales = marketplaceSales + laborSales + rentalSales;
  const marketplacePurchases = purchaseOrders
    .filter((order) => String(order?.status || '').trim() === 'completed')
    .reduce(
      (sum, order) => sum + Number(order?.totalPaid || 0),
      0,
    );
  const [laborPurchasesResult, rentalPurchasesResult] = userId
    ? await Promise.all([
        LaborPayment.aggregate([
          {
            $match: {
              buyerUserId: userId,
              releaseStatus: 'released',
              refundStatus: { $ne: 'refunded' },
            },
          },
          {
            $group: {
              _id: null,
              total: { $sum: { $ifNull: ['$total', '$subtotal'] } },
            },
          },
        ]),
        ServicePayment.aggregate([
          {
            $match: {
              buyerUserId: userId,
              releaseStatus: 'released',
              refundStatus: { $ne: 'refunded' },
            },
          },
          {
            $group: {
              _id: null,
              total: { $sum: { $ifNull: ['$total', '$subtotal'] } },
            },
          },
        ]),
      ])
    : [[], []];
  const laborPurchases = Number(laborPurchasesResult?.[0]?.total || 0);
  const rentalPurchases = Number(rentalPurchasesResult?.[0]?.total || 0);
  const totalPurchases = marketplacePurchases + laborPurchases + rentalPurchases;
  const workersHired = buyerActiveBookings.length + buyerBookingHistory.length;
  const servicesBooked = serviceBookings.filter(
    (booking) => String(booking?.status || '').trim() !== 'cancelled',
  ).length;
  const stats = [
    {
      label: 'Total Purchases',
      value: formatPhpCurrency(totalPurchases),
      color: 'text-blue-600',
    },
    {
      label: 'Workers Hired',
      value: String(workersHired),
      color: 'text-purple-600',
    },
    {
      label: 'Services Booked',
      value: String(servicesBooked),
      color: 'text-orange-600',
    },
  ];

  if (verification.seller === 'verified') {
    stats.unshift({
      label: 'Total Sales',
      value: formatPhpCurrency(totalSales),
      color: 'text-green-600',
    });
  }

  if (verification.laborer === 'verified') {
    stats.push({
      label: 'Labor Rate',
      value: formatPhpRate(laborRate),
      color: 'text-emerald-600',
    });
    stats.push({
      label: 'Availability',
      value: laborAvailability,
      color: laborAvailability.toLowerCase() === 'available' ? 'text-green-600' : 'text-amber-600',
    });
    stats.push({
      label: 'Worker Rating',
      value: laborRating > 0 ? laborRating.toFixed(1) : 'Awaiting reviews',
      color: 'text-indigo-600',
    });
    stats.push({
      label: 'Active Jobs',
      value: String(activeJobs),
      color: 'text-teal-600',
    });
    stats.push({
      label: 'Completed Jobs',
      value: String(completedJobs),
      color: 'text-cyan-600',
    });
  }

  return stats;
}

function buildDashboardUpcomingTasks(user) {
  const tasks = [];
  const purchaseOrders = Array.isArray(user?.marketplaceOrders?.purchases)
    ? user.marketplaceOrders.purchases
    : [];
  const activeLaborBookings = Array.isArray(user?.laborBookings?.activeBookings)
    ? user.laborBookings.activeBookings
    : [];
  const serviceBookings = Array.isArray(user?.serviceProfile?.bookings)
    ? user.serviceProfile.bookings
    : [];

  purchaseOrders
    .filter((order) => {
      const orderStatus = String(order?.status || '').trim();
      const refundStatus = String(order?.refundRequest?.status || '').trim();

      if (refundStatus === 'approved') {
        return false;
      }

      return !['received', 'completed', 'cancelled'].includes(orderStatus);
    })
    .forEach((order) => {
      const status = String(order?.status || 'paid').trim();
      tasks.push({
        id: `marketplace-${String(order?.orderId || '').trim()}`,
        task:
          status === 'paid'
            ? `${String(order?.itemName || 'Marketplace order').trim()} is waiting for seller preparation`
            : status === 'preparing'
              ? `${String(order?.itemName || 'Marketplace order').trim()} is being prepared`
              : status === 'ready_for_pickup'
                ? `${String(order?.itemName || 'Marketplace order').trim()} is ready for pickup`
                : `${String(order?.itemName || 'Marketplace order').trim()} is currently in transit`,
        date: [String(order?.sellerName || '').trim(), String(order?.buyerAddress || '').trim()]
          .filter(Boolean)
          .join(' • '),
        priority: status === 'in_transit' ? 'high' : status === 'ready_for_pickup' ? 'medium' : 'low',
        tab: 'marketplace',
        target: 'orders',
        orderId: String(order?.orderId || '').trim(),
      });
    });

  activeLaborBookings
    .filter((booking) => !['completed', 'cancelled'].includes(String(booking?.status || '').trim()))
    .forEach((booking) => {
      const status = String(booking?.status || 'confirmed').trim();
      tasks.push({
        id: `labor-${String(booking?.bookingId || '').trim()}`,
        task:
          status === 'on_the_way'
            ? `${String(booking?.worker || 'Your laborer').trim()} is on the way to your farm`
            : `${String(booking?.worker || 'Your laborer').trim()} is booked for an active farm job`,
        date: [String(booking?.date || '').trim(), String(booking?.time || '').trim()]
          .filter(Boolean)
          .join(' at '),
        priority: status === 'on_the_way' ? 'high' : 'medium',
        tab: 'labor',
        target: 'bookings',
        bookingId: String(booking?.bookingId || '').trim(),
        bookingKind: 'booking',
      });
    });

  serviceBookings
    .filter((booking) => !['completed', 'cancelled'].includes(String(booking?.status || '').trim()))
    .forEach((booking) => {
      const status = String(booking?.status || 'confirmed').trim();
      tasks.push({
        id: `service-${String(booking?.bookingRef || booking?.service || '').trim()}`,
        task:
          status === 'in_progress'
            ? `${String(booking?.service || 'Service booking').trim()} is currently in progress`
            : `${String(booking?.service || 'Service booking').trim()} is actively scheduled`,
        date: [String(booking?.date || '').trim(), String(booking?.time || '').trim()]
          .filter(Boolean)
          .join(' at '),
        priority: status === 'in_progress' ? 'high' : 'medium',
        tab: 'services',
        target: 'bookings',
        bookingRef: String(booking?.bookingRef || '').trim(),
      });
    });

  return tasks.slice(0, 12);
}

function normalizeLaborSkills(skills) {
  if (!Array.isArray(skills)) {
    return [];
  }

  return skills
    .map((skill) => String(skill || '').trim())
    .filter(Boolean);
}

function normalizeClockTime(value) {
  const normalized = String(value || '').trim();

  if (!/^\d{2}:\d{2}$/.test(normalized)) {
    return '';
  }

  const [hours, minutes] = normalized.split(':').map(Number);

  if (!Number.isInteger(hours) || !Number.isInteger(minutes) || hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
    return '';
  }

  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}

function convertBookingClockTimeToMinutes(value) {
  const normalized = normalizeClockTime(value);

  if (!normalized) {
    return null;
  }

  const [hours, minutes] = normalized.split(':').map(Number);
  return hours * 60 + minutes;
}

function formatWorkingHoursRange(start, end) {
  const normalizedStart = normalizeClockTime(start);
  const normalizedEnd = normalizeClockTime(end);

  if (!normalizedStart || !normalizedEnd) {
    return '';
  }

  const [startHours, startMinutes] = normalizedStart.split(':').map(Number);
  const [endHours, endMinutes] = normalizedEnd.split(':').map(Number);
  const formatOptions = { hour: 'numeric', minute: '2-digit' };
  const startLabel = new Date(2000, 0, 1, startHours, startMinutes).toLocaleTimeString('en-US', formatOptions);
  const endLabel = new Date(2000, 0, 1, endHours, endMinutes).toLocaleTimeString('en-US', formatOptions);

  return `${startLabel} - ${endLabel}`;
}

function getDurationHours(value) {
  const match = String(value || '').trim().match(/^(\d+)\s*hour/i);

  if (!match) {
    return null;
  }

  const parsed = Number(match[1]);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function hasLaborBookingTimeConflict(bookings = [], date, requestedStartMinutes, requestedDurationHours, ignoreBookingId = '') {
  const normalizedDate = String(date || '').trim();
  const normalizedIgnoreBookingId = String(ignoreBookingId || '').trim();
  const requestedEndMinutes = requestedStartMinutes + requestedDurationHours * 60;

  return bookings.some((booking) => {
    if (!booking) {
      return false;
    }

    const bookingId = String(booking.bookingId || '').trim();

    if (normalizedIgnoreBookingId && bookingId === normalizedIgnoreBookingId) {
      return false;
    }

    if (String(booking.date || '').trim() !== normalizedDate) {
      return false;
    }

    if (String(booking.status || '').trim().toLowerCase() === 'cancelled') {
      return false;
    }

    const existingStartMinutes = convertClockTimeToMinutes(booking.time);
    const existingDurationHours = getDurationHours(booking.duration);

    if (existingStartMinutes === null || existingDurationHours === null) {
      return false;
    }

    const existingEndMinutes = existingStartMinutes + existingDurationHours * 60;

    return requestedStartMinutes <= existingEndMinutes && existingStartMinutes <= requestedEndMinutes;
  });
}

function buildLaborBookingId() {
  return `LB-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function normalizeCoordinates(coordinates = {}) {
  const rawLat = coordinates?.lat;
  const rawLng = coordinates?.lng;

  if (
    rawLat === null
    || rawLat === undefined
    || rawLat === ''
    || rawLng === null
    || rawLng === undefined
    || rawLng === ''
  ) {
    return {
      lat: null,
      lng: null,
    };
  }

  const lat = Number(rawLat);
  const lng = Number(rawLng);

  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    return {
      lat: null,
      lng: null,
    };
  }

  return {
    lat,
    lng,
  };
}

function createTravelTrackingSnapshot(travelTracking = {}) {
  return {
    isOnTheWay: Boolean(travelTracking?.isOnTheWay),
    startedAt: travelTracking?.startedAt || null,
    updatedAt: travelTracking?.updatedAt || null,
    currentLocation: normalizeCoordinates(travelTracking?.currentLocation),
  };
}

function getCurrentManilaDateString() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Manila',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

function getCurrentManilaDateTimeParts() {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Manila',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  });

  const parts = formatter.formatToParts(new Date());
  const lookup = Object.fromEntries(parts.map((part) => [part.type, part.value]));

  return {
    date: `${lookup.year || '0000'}-${lookup.month || '00'}-${lookup.day || '00'}`,
    time: `${lookup.hour || '00'}:${lookup.minute || '00'}`,
  };
}

function convertClockTimeToMinutes(value) {
  const normalized = String(value || '').trim();

  if (!/^\d{1,2}:\d{2}$/.test(normalized)) {
    return null;
  }

  const [hours, minutes] = normalized.split(':').map(Number);

  if (!Number.isFinite(hours) || !Number.isFinite(minutes)) {
    return null;
  }

  return hours * 60 + minutes;
}

function hasServiceBookingReachedStart(booking = {}) {
  const bookingDate = String(booking?.date || '').trim();
  const bookingTime = String(booking?.time || '').trim();

  if (!bookingDate) {
    return false;
  }

  const { date: currentDate, time: currentTime } = getCurrentManilaDateTimeParts();

  if (bookingDate < currentDate) {
    return true;
  }

  if (bookingDate > currentDate) {
    return false;
  }

  const bookingTimeMinutes = convertBookingClockTimeToMinutes(bookingTime);
  const currentTimeMinutes = convertBookingClockTimeToMinutes(currentTime);

  if (bookingTimeMinutes === null || currentTimeMinutes === null) {
    return true;
  }

  return currentTimeMinutes >= bookingTimeMinutes;
}

function getVerifiedLaborSkills(user) {
  return normalizeLaborSkills(user?.verification?.laborer?.details?.skills);
}

function normalizeLaborOffer(offer) {
  const normalizedReviews = Array.isArray(offer?.reviews)
    ? offer.reviews
        .map((review, index) => ({
          id: String(review?.id || `LBR-${index + 1}`).trim(),
          author: String(review?.author || '').trim(),
          authorUserId: String(review?.authorUserId || '').trim(),
          bookingId: String(review?.bookingId || '').trim(),
          rating: Number(review?.rating || 0),
          comment: String(review?.comment || '').trim(),
          createdAt: review?.createdAt || null,
        }))
        .filter((review) => Number.isFinite(review.rating) && review.rating > 0)
    : [];

  return {
    title: String(offer?.title || '').trim(),
    description: String(offer?.description || '').trim(),
    workerType: String(offer?.workerType || '').trim(),
    rate: Number(offer?.rate || 0),
    availability: String(offer?.availability || '').trim() || 'Unavailable',
    skills: normalizeLaborSkills(offer?.skills),
    distance: String(offer?.distance || '').trim(),
    serviceArea: String(offer?.serviceArea || '').trim(),
    workingHoursStart: normalizeClockTime(offer?.workingHoursStart),
    workingHoursEnd: normalizeClockTime(offer?.workingHoursEnd),
    isPublished: Boolean(offer?.isPublished),
    reviews: normalizedReviews,
    rating: Number(offer?.rating || 0),
    reviewCount: Number(offer?.reviewCount || normalizedReviews.length || 0),
  };
}

function buildLaborListingRatingSummary(listing = {}) {
  const reviews = Array.isArray(listing?.reviews)
    ? listing.reviews.filter((review) => Number.isFinite(Number(review?.rating || 0)) && Number(review?.rating || 0) > 0)
    : [];

  if (reviews.length === 0) {
    return {
      rating: 0,
      reviewCount: 0,
      reviews: [],
    };
  }

  const totalRating = reviews.reduce((sum, review) => sum + Number(review?.rating || 0), 0);

  return {
    rating: totalRating / reviews.length,
    reviewCount: reviews.length,
    reviews: reviews.map((review) => ({
      id: String(review?.id || '').trim(),
      author: String(review?.author || '').trim(),
      authorUserId: String(review?.authorUserId || '').trim(),
      bookingId: String(review?.bookingId || '').trim(),
      rating: Number(review?.rating || 0),
      comment: String(review?.comment || '').trim(),
      createdAt: review?.createdAt || null,
    })),
  };
}

function refreshLaborProfileRating(user) {
  const listings = getLaborListings(user);
  const ratingSummaries = listings.map((listing) => buildLaborListingRatingSummary(listing));
  const totalReviews = ratingSummaries.reduce((sum, summary) => sum + summary.reviewCount, 0);
  const weightedRating = ratingSummaries.reduce((sum, summary) => sum + summary.rating * summary.reviewCount, 0);

  user.laborProfile.rating = totalReviews > 0 ? weightedRating / totalReviews : 0;
}

function getLaborListings(user) {
  const rawListings = Array.isArray(user?.laborProfile?.listings) ? user.laborProfile.listings : [];

  if (rawListings.length > 0) {
    return rawListings
      .map(normalizeLaborOffer)
      .filter((listing) => listing.workerType);
  }

  const legacyOffer = normalizeLaborOffer(user?.laborProfile);

  if (!legacyOffer.workerType) {
    return [];
  }

  return laborOfferIsComplete(user, legacyOffer) ? [legacyOffer] : [];
}

function laborOfferIsComplete(user, offer) {
  const normalizedOffer = normalizeLaborOffer(offer);

  return Boolean(
    normalizedOffer.title &&
    normalizedOffer.description &&
    normalizedOffer.workerType &&
    normalizedOffer.rate > 0 &&
    normalizedOffer.availability &&
    normalizedOffer.skills.length > 0 &&
    normalizedOffer.workingHoursStart &&
    normalizedOffer.workingHoursEnd &&
    String(user?.profile?.experience || '').trim() &&
    String(user?.profile?.location || '').trim() &&
    String(user?.phone || '').trim(),
  );
}

function syncPrimaryLaborProfileFromListings(user) {
  const listings = getLaborListings(user);
  const primaryListing = listings[0];

  if (!primaryListing) {
    user.laborProfile.title = '';
    user.laborProfile.description = '';
    user.laborProfile.workerType = '';
    user.laborProfile.rate = 0;
    user.laborProfile.availability = 'Available';
    user.laborProfile.skills = [];
    user.laborProfile.distance = '';
    user.laborProfile.serviceArea = '';
    user.laborProfile.workingHoursStart = '';
    user.laborProfile.workingHoursEnd = '';
    user.laborProfile.isPublished = false;
    return;
  }

  user.laborProfile.title = primaryListing.title;
  user.laborProfile.description = primaryListing.description;
  user.laborProfile.workerType = primaryListing.workerType;
  user.laborProfile.rate = primaryListing.rate;
  user.laborProfile.availability = primaryListing.availability;
  user.laborProfile.skills = primaryListing.skills;
  user.laborProfile.distance = primaryListing.distance;
  user.laborProfile.serviceArea = primaryListing.serviceArea;
  user.laborProfile.workingHoursStart = primaryListing.workingHoursStart;
  user.laborProfile.workingHoursEnd = primaryListing.workingHoursEnd;
  user.laborProfile.isPublished = primaryListing.isPublished;
}

function buildLaborOfferPayload(user) {
  const listings = getLaborListings(user).map((listing) => {
    const ratingSummary = buildLaborListingRatingSummary(listing);

    return {
      ...listing,
      rating: ratingSummary.rating,
      reviewCount: ratingSummary.reviewCount,
      reviews: ratingSummary.reviews,
    };
  });
  const primaryListing = listings[0];
  const verifiedSkills = getVerifiedLaborSkills(user);

  return {
    title: primaryListing?.title || '',
    description: primaryListing?.description || '',
    workerType: primaryListing?.workerType || '',
    rate: Number(primaryListing?.rate || 0),
    availability: primaryListing?.availability || 'Unavailable',
    skills: primaryListing?.skills || [],
    verifiedSkills,
    distance: primaryListing?.distance || '',
    serviceArea: primaryListing?.serviceArea || '',
    workingHoursStart: primaryListing?.workingHoursStart || '',
    workingHoursEnd: primaryListing?.workingHoursEnd || '',
    workingHoursLabel: formatWorkingHoursRange(primaryListing?.workingHoursStart, primaryListing?.workingHoursEnd),
    rating: Number(primaryListing?.rating || user?.laborProfile?.rating || 0),
    reviewCount: Number(primaryListing?.reviewCount || 0),
    isPublished: Boolean(primaryListing?.isPublished),
    listings,
    experience: formatExperienceYears(user.profile?.experience || ''),
    location: user.profile?.location || '',
    phone: user.phone || '',
  };
}

export async function getCurrentUser(req, res) {
  await reconcileMarketplaceSellerPayouts(req.user);
  res.json({
    user: await sanitizeUser(req.user),
    stats: await getProfileStats(req.user),
  });
}

export async function getWalletSummary(req, res) {
  await reconcileMarketplaceSellerPayouts(req.user);
  res.json({
    wallet: buildWalletSummary(req.user),
  });
}

export async function requestWalletCashOut(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

      const amount = Number(req.body?.amount || 0);
    const destination = normalizeCashOutDestination(req.body || {});

    if (!['gcash', 'paymaya', 'bank'].includes(destination.method)) {
      return res.status(400).json({
        message: 'Choose GCash, PayMaya, or bank account for Xendit cash out.',
      });
    }

    if (!Number.isFinite(amount) || amount <= 0) {
      return res.status(400).json({
        message: 'Enter a valid cash-out amount.',
      });
    }

    if (Number(ensureWalletState(req.user).balance || 0) < amount) {
      return res.status(400).json({
        message: 'Insufficient wallet balance for this cash out.',
      });
    }

    if ((destination.method === 'gcash' || destination.method === 'paymaya')) {
      if (!destination.accountName || !destination.mobileNumber) {
        return res.status(400).json({
          message: 'Account name and mobile number are required for wallet cash outs.',
        });
      }

      if (!isValidPhilippineMobile(destination.mobileNumber)) {
        return res.status(400).json({
          message: 'Enter a valid Philippine mobile number for wallet cash out.',
        });
      }
    }

    if (destination.method === 'bank') {
      if (!destination.accountName || !destination.accountNumber || !destination.bankCode) {
        return res.status(400).json({
          message: 'Account name, bank, and account number are required for bank cash out.',
        });
      }

      if (!isSupportedWalletCashOutBank(destination.bankCode)) {
        return res.status(400).json({
          message: 'Choose a supported bank for Xendit cash out.',
        });
      }
    }

    const reference = buildWalletTransactionId('CASHOUT');
    const destinationLabel = buildCashOutDestinationLabel(destination);
    const payout = await createWalletCashOutPayout({
      reference,
      amount,
      destination,
      destinationLabel,
      user: req.user,
    });
    const payoutStatus = normalizeXenditPayoutStatus(payout?.status);
    const payoutIsTestMode = Boolean(payout?.isTestMode);
    const methodLabel = buildCashOutMethodLabel(destination.method);

    debitWalletForCashOut(req.user, amount, {
      id: reference,
      method: destination.method,
      reference: String(payout?.id || reference).trim(),
      destinationLabel: payoutIsTestMode ? `${destinationLabel} (Test Mode)` : destinationLabel,
      description: payoutIsTestMode
        ? `Cash out to ${methodLabel} via Xendit test mode`
        : `Cash out to ${methodLabel} via Xendit`,
      status: payoutStatus,
    });

    appendActivity(req.user, {
      description:
        payoutIsTestMode
          ? `Recorded a ${formatPhpCurrency(amount)} cash-out to ${methodLabel} in Xendit test mode`
          : payoutStatus === 'completed'
            ? `Cashed out ${formatPhpCurrency(amount)} to ${methodLabel} via Xendit`
            : `Submitted a ${formatPhpCurrency(amount)} cash-out request to ${methodLabel} via Xendit`,
      status: payoutStatus,
    });

    await req.user.save();

    return res.json({
      message:
        payoutIsTestMode
          ? `Wallet cash out to ${methodLabel} was recorded using Xendit test mode.`
          : payoutStatus === 'completed'
            ? `Wallet cash out to ${methodLabel} completed successfully through Xendit.`
            : `Wallet cash out to ${methodLabel} was sent to Xendit and is now processing.`,
      wallet: buildWalletSummary(req.user),
      supportedBanks: getSupportedWalletCashOutBanks(),
      user: await sanitizeUser(req.user),
    });
  } catch (error) {
    next(error);
  }
}

export async function updateCurrentUser(req, res, next) {
  try {
    const { name, email, phone, profile = {} } = req.body;
    const nextName = typeof name === 'string' ? name.trim() : req.user.name;
    const nextEmail = typeof email === 'string' ? email.trim().toLowerCase() : req.user.email;
    const nextPhone = typeof phone === 'string' ? phone.trim() : req.user.phone;
    const nextProfile = {
      ...req.user.profile?.toObject?.(),
      ...req.user.profile,
      ...profile,
    };
    const previousSnapshot = JSON.stringify({
      name: req.user.name,
      email: req.user.email,
      phone: req.user.phone,
      profile: req.user.profile?.toObject?.() || req.user.profile || {},
    });

    if (typeof name === 'string') {
      req.user.name = nextName;
    }

    if (typeof email === 'string') {
      const normalizedEmail = nextEmail;

      if (!normalizedEmail) {
        return res.status(400).json({
          message: 'Email is required.',
        });
      }

      const existingUser = await User.findOne({
        email: normalizedEmail,
        _id: { $ne: req.user._id },
      });

      if (existingUser) {
        return res.status(409).json({
          message: 'That email address is already in use.',
        });
      }

      if (normalizedEmail !== String(req.user.email || '').trim().toLowerCase()) {
        return res.status(400).json({
          message: 'Verify your new email address before it can replace the current one.',
        });
      }
    }

    let phoneVerificationTriggered = false;
    let profileMessage = 'Profile updated successfully.';

    if (typeof phone === 'string') {
      const normalizedPhone = normalizePhilippinePhone(nextPhone);
      const currentPhone = normalizePhilippinePhone(req.user.phone || '');

      if (normalizedPhone && !isValidPhilippineMobile(normalizedPhone)) {
        return res.status(400).json({
          message: 'Please enter a valid Philippine mobile number.',
        });
      }

      if (normalizedPhone !== currentPhone) {
        if (!normalizedPhone) {
          req.user.phone = '';
          req.user.phoneVerification = {
            status: 'unverified',
            source: 'email',
            code: '',
            expiresAt: null,
            requestedAt: null,
            verifiedAt: null,
            pendingPhone: '',
          };
          profileMessage = 'Profile updated successfully. Your phone number has been cleared.';
        } else {
          await issuePhoneVerificationCode(req.user, normalizedPhone);
          phoneVerificationTriggered = true;
          profileMessage =
            'Profile updated successfully. We sent a verification code to your email to verify the new phone number.';
        }
      }
    }

    if (typeof profile.avatarPath === 'string' && profile.avatarPath.trim()) {
      profile.avatarPath = profile.avatarPath.trim();
    }

    req.user.profile = nextProfile;

    if (!req.user.profile.firstName && typeof name === 'string') {
      req.user.profile.firstName = name.trim();
    }

    ensurePrivilegedAccess(req.user);

    const nextSnapshot = JSON.stringify({
      name: req.user.name,
      email: req.user.email,
      phone: req.user.phone,
      profile: req.user.profile,
    });

    if (previousSnapshot !== nextSnapshot) {
      appendActivity(req.user, {
        description: 'Updated profile information',
        status: 'confirmed',
      });
    }

    await req.user.save();

    res.json({
      message: profileMessage,
      user: await sanitizeUser(req.user),
    });
  } catch (error) {
    next(error);
  }
}

export async function requestEmailChange(req, res, next) {
  try {
    const nextEmail = String(req.body?.email || '').trim().toLowerCase();

    if (!nextEmail) {
      return res.status(400).json({
        message: 'New email is required.',
      });
    }

    if (!isValidEmail(nextEmail)) {
      return res.status(400).json({
        message: 'Please enter a valid email address.',
      });
    }

    if (nextEmail === String(req.user.email || '').trim().toLowerCase()) {
      return res.status(400).json({
        message: 'That email is already your current email address.',
      });
    }

    const existingUser = await User.findOne({
      email: nextEmail,
      _id: { $ne: req.user._id },
    });

    if (existingUser) {
      return res.status(409).json({
        message: 'That email address is already in use.',
      });
    }

    const code = buildEmailVerificationCode();
    const { now, expiresAt } = buildVerificationWindow();

    req.user.emailVerification = {
      code,
      expiresAt,
      requestedAt: now,
      verifiedAt: null,
      pendingEmail: nextEmail,
    };

    appendActivity(req.user, {
      description: `Requested email change to ${nextEmail}`,
      status: 'pending',
      createdAt: now,
    });
    await req.user.save();

    await sendEmailChangeVerificationCode({
      toEmail: nextEmail,
      code,
      name: req.user.name,
    });

    res.json({
      message: 'A verification code was sent to your new email address.',
      pendingEmail: nextEmail,
      requestedAt: now.toISOString(),
    });
  } catch (error) {
    next(error);
  }
}

export async function requestPhoneChange(req, res, next) {
  try {
    const requestedPhone = normalizePhilippinePhone(String(req.body?.phone || req.user.phone || '').trim());

    if (!requestedPhone) {
      return res.status(400).json({
        message: 'Enter a phone number first.',
      });
    }

    if (!isValidPhilippineMobile(requestedPhone)) {
      return res.status(400).json({
        message: 'Please enter a valid Philippine mobile number.',
      });
    }

    const { now, normalizedPhone } = await issuePhoneVerificationCode(req.user, requestedPhone);

    appendActivity(req.user, {
      description: `Requested phone verification for ${normalizedPhone}`,
      status: 'pending',
      createdAt: now,
    });
    await req.user.save();

    return res.json({
      message: 'A verification code was sent to your email for the selected phone number.',
      pendingPhone: normalizedPhone,
      requestedAt: now.toISOString(),
    });
  } catch (error) {
    next(error);
  }
}

export async function verifyPhoneChange(req, res, next) {
  try {
    const phone = normalizePhilippinePhone(String(req.body?.phone || '').trim());
    const code = String(req.body?.code || '').trim();
    const pendingPhone = normalizePhilippinePhone(req.user.phoneVerification?.pendingPhone || req.user.phone || '');

    if (!phone || !code) {
      return res.status(400).json({
        message: 'Phone number and verification code are required.',
      });
    }

    if (!pendingPhone || phone !== pendingPhone) {
      return res.status(400).json({
        message: 'There is no pending verification for that phone number.',
      });
    }

    if (
      !req.user.phoneVerification?.code ||
      req.user.phoneVerification.code !== code ||
      !req.user.phoneVerification.expiresAt ||
      new Date(req.user.phoneVerification.expiresAt).getTime() <= Date.now()
    ) {
      return res.status(400).json({
        message: 'The verification code is invalid or has expired.',
      });
    }

    req.user.phone = pendingPhone;
    req.user.phoneVerification = {
      status: 'verified',
      source: 'email',
      code: '',
      expiresAt: null,
      requestedAt: req.user.phoneVerification?.requestedAt || null,
      verifiedAt: new Date(),
      pendingPhone: '',
    };

    appendActivity(req.user, {
      description: `Verified phone number ${pendingPhone}`,
      status: 'completed',
    });
    await req.user.save();

    return res.json({
      message: 'Phone number verified successfully.',
      user: await sanitizeUser(req.user),
    });
  } catch (error) {
    next(error);
  }
}

export async function cancelPhoneChange(req, res, next) {
  try {
    req.user.phoneVerification = {
      status: 'unverified',
      source: 'email',
      code: '',
      expiresAt: null,
      requestedAt: null,
      verifiedAt: null,
      pendingPhone: '',
    };
    await req.user.save();

    return res.json({
      message: 'Phone verification request cancelled.',
      user: await sanitizeUser(req.user),
    });
  } catch (error) {
    next(error);
  }
}

export async function verifyEmailChange(req, res, next) {
  try {
    const nextEmail = String(req.body?.email || '').trim().toLowerCase();
    const code = String(req.body?.code || '').trim();

    if (!nextEmail || !code) {
      return res.status(400).json({
        message: 'Email and verification code are required.',
      });
    }

    if (!req.user.emailVerification?.pendingEmail || req.user.emailVerification.pendingEmail !== nextEmail) {
      return res.status(400).json({
        message: 'There is no pending email change for that address.',
      });
    }

    if (!isEmailVerificationCodeValid(req.user, code)) {
      return res.status(400).json({
        message: 'The verification code is invalid or has expired.',
      });
    }

    const existingUser = await User.findOne({
      email: nextEmail,
      _id: { $ne: req.user._id },
    });

    if (existingUser) {
      return res.status(409).json({
        message: 'That email address is already in use.',
      });
    }

    req.user.email = nextEmail;
    req.user.emailVerified = true;
    req.user.emailVerification = {
      code: '',
      expiresAt: null,
      requestedAt: req.user.emailVerification?.requestedAt || null,
      verifiedAt: new Date(),
      pendingEmail: '',
    };

    appendActivity(req.user, {
      description: `Changed account email to ${nextEmail}`,
      status: 'completed',
    });
    await req.user.save();

    res.json({
      message: 'Email address updated successfully.',
      user: await sanitizeUser(req.user),
    });
  } catch (error) {
    next(error);
  }
}

export async function applyForRole(req, res, next) {
  try {
    const { role, application = {} } = req.body || {};

    if (!['seller', 'laborer'].includes(role)) {
      return res.status(400).json({
        message: 'Only seller and laborer role applications are supported.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    if (req.user.phoneVerification?.status !== 'verified' || !String(req.user.phone || '').trim()) {
      return res.status(403).json({
        message: 'Verify your phone number first before booking a laborer.',
      });
    }

    if (!Array.isArray(req.user.roles) || req.user.roles.length === 0) {
      req.user.roles = ['buyer'];
    }

    const now = new Date();
    const documents = Array.isArray(application.documents) ? application.documents : [];
    const details = application.details || {};
    const idNumber = String(details.idNumber || '').trim();

    if (!details.idType || !idNumber) {
      return res.status(400).json({
        message: 'KYC requires an ID type and ID number.',
      });
    }

    if (!/^\d+$/.test(idNumber)) {
      return res.status(400).json({
        message: 'ID number must contain numbers only.',
      });
    }

    if (!details.addressConfirmed || !details.selfieConfirmed || !details.riskAccepted || !details.consentAccepted) {
      return res.status(400).json({
        message: 'Please complete all identity and consent confirmations before submitting verification.',
      });
    }

    const profileAddress = buildVerificationProfileAddress(req.user.profile);

    if (role === 'seller') {
      const sellerDocumentTypes = new Set(documents.map((document) => document?.type));

      if (!details.farmProofType) {
        return res.status(400).json({
          message: 'Seller KYC requires you to choose the farm proof document type.',
        });
      }

      if (
        !sellerDocumentTypes.has('id-front') ||
        !sellerDocumentTypes.has('id-back') ||
        !sellerDocumentTypes.has('selfie')
      ) {
        return res.status(400).json({
          message: 'Seller KYC requires ID front, ID back, and a clear selfie.',
        });
      }

      if (
        !sellerDocumentTypes.has('farm-proof') &&
        !sellerDocumentTypes.has('barangay-certificate') &&
        !sellerDocumentTypes.has('farm-photos') &&
        !sellerDocumentTypes.has('rsbsa')
      ) {
        return res.status(400).json({
          message: 'Seller verification requires at least one farm proof document.',
        });
      }

      if (!req.user.roles.includes('seller')) {
        req.user.roles.push('seller');
      }

      await deleteVerificationDocuments(req.user.verification?.seller?.documents || []);

      req.user.accountType = 'vendor';
      req.user.verification.seller = {
        status: 'pending',
        submittedAt: now,
        verifiedAt: null,
        rejectedAt: null,
        reviewReason: '',
        documents,
        details: {
          idType: details.idType,
          idNumber,
          farmProofType: details.farmProofType,
          profileAddress,
          addressConfirmed: Boolean(details.addressConfirmed),
          selfieConfirmed: Boolean(details.selfieConfirmed),
          riskAccepted: Boolean(details.riskAccepted),
          consentAccepted: Boolean(details.consentAccepted),
        },
      };
    }

    if (role === 'laborer') {
      const laborerDocumentTypes = new Set(documents.map((document) => document?.type));

      if (
        !laborerDocumentTypes.has('id-front') ||
        !laborerDocumentTypes.has('id-back') ||
        !laborerDocumentTypes.has('selfie')
      ) {
        return res.status(400).json({
          message: 'Laborer KYC requires ID front, ID back, and a clear selfie.',
        });
      }

      if (!Array.isArray(application.skills) || application.skills.length === 0) {
        return res.status(400).json({
          message: 'Choose at least one labor skill before submitting verification.',
        });
      }

      if (!details.laborProofType) {
        return res.status(400).json({
          message: 'Laborer KYC requires you to choose the proof document type.',
        });
      }

      if (!laborerDocumentTypes.has('work-proof')) {
        return res.status(400).json({
          message: 'Laborer KYC requires the selected work proof document.',
        });
      }

      const normalizedExperience = normalizeExperienceYears(application.experience || '');

      if (!normalizedExperience) {
        return res.status(400).json({
          message: 'Laborer KYC requires your work experience.',
        });
      }

      if (!String(application.description || '').trim()) {
        return res.status(400).json({
          message: 'Laborer KYC requires a work summary.',
        });
      }

      if (!req.user.roles.includes('laborer')) {
        req.user.roles.push('laborer');
      }

      await deleteVerificationDocuments(req.user.verification?.laborer?.documents || []);

      req.user.accountType = 'laborer';
      req.user.verification.laborer = {
        status: 'pending',
        submittedAt: now,
        verifiedAt: null,
        rejectedAt: null,
        reviewReason: '',
        documents,
        details: {
          idType: details.idType,
          idNumber,
          farmProofType: '',
          profileAddress,
          addressConfirmed: Boolean(details.addressConfirmed),
          selfieConfirmed: Boolean(details.selfieConfirmed),
          riskAccepted: Boolean(details.riskAccepted),
          consentAccepted: Boolean(details.consentAccepted),
          experience: normalizedExperience,
          description: String(application.description || '').trim(),
          laborProofType: details.laborProofType,
          skills: application.skills,
        },
      };
      req.user.laborProfile.skills = application.skills;
      req.user.laborProfile.availability = req.user.laborProfile.availability || 'Available';
      req.user.profile.experience = normalizedExperience || req.user.profile.experience;
      req.user.profile.specialization = String(application.description || '').trim() || req.user.profile.specialization;
    }

    await req.user.save();

    appendActivity(req.user, {
      description: `${role.charAt(0).toUpperCase() + role.slice(1)} verification submitted`,
      status: 'pending',
      createdAt: now,
    });
    await req.user.save();

    res.json({
      message: `${role.charAt(0).toUpperCase() + role.slice(1)} verification submitted. It is now pending review.`,
      user: await sanitizeUser(req.user),
    });
  } catch (error) {
    next(error);
  }
}

export async function createVerificationUploadUrl(req, res, next) {
  try {
    const { role, documentType, fileName } = req.body || {};

    if (!role || !documentType || !fileName) {
      return res.status(400).json({
        message: 'Role, document type, and file name are required.',
      });
    }

    const upload = await createVerificationUploadTarget({
      userId: req.user._id.toString(),
      role,
      documentType,
      fileName,
    });

    res.json(upload);
  } catch (error) {
    next(error);
  }
}

export async function createProfileAvatarUploadUrl(req, res, next) {
  try {
    const { fileName } = req.body || {};

    if (!fileName) {
      return res.status(400).json({
        message: 'File name is required.',
      });
    }

    const upload = await createProfileAvatarUploadTarget({
      userId: req.user._id.toString(),
      fileName,
    });

    res.json(upload);
  } catch (error) {
    next(error);
  }
}

export async function getDashboardData(req, res, next) {
  try {
    const user = req.user;
    const recentActivities = getUserActivities(user).map((activity, index) => ({
      id: `${new Date(activity.createdAt).getTime()}-${index}`,
      description: activity.description,
      status: activity.status || 'confirmed',
      createdAt: new Date(activity.createdAt).toISOString(),
    }));

      const stats = await getProfileStats(user);

      res.json({
        user: await sanitizeUser(user),
        stats: stats.map((stat, index) => ({
        ...stat,
        change:
          stat.label === 'Total Sales'
            ? 'seller earnings'
            : stat.label === 'Total Purchases'
              ? 'buyer purchases'
              : stat.label === 'Workers Hired'
                ? 'labor bookings'
                : stat.label === 'Labor Rate'
                  ? 'current hourly rate'
                  : stat.label === 'Availability'
                    ? 'booking status'
                    : stat.label === 'Worker Rating'
                      ? 'from completed jobs'
                : stat.label === 'Active Jobs'
                  ? 'worker jobs'
                  : stat.label === 'Completed Jobs'
                    ? 'finished assignments'
                  : 'service bookings',
        tone:
          stat.label === 'Total Sales'
            ? 'sales'
            : stat.label === 'Total Purchases'
              ? 'purchases'
              : stat.label === 'Workers Hired'
                ? 'workers'
                : stat.label === 'Labor Rate'
                  ? 'sales'
                  : stat.label === 'Availability'
                    ? 'laborer'
                    : stat.label === 'Worker Rating'
                      ? 'workers'
                : stat.label === 'Active Jobs'
                  ? 'laborer'
                  : stat.label === 'Completed Jobs'
                    ? 'laborer'
                  : 'services',
        icon:
          stat.label === 'Total Sales'
            ? 'DollarSign'
            : stat.label === 'Total Purchases'
              ? 'DollarSign'
              : stat.label === 'Workers Hired'
                ? 'Users'
                : stat.label === 'Labor Rate'
                  ? 'DollarSign'
                  : stat.label === 'Availability'
                    ? 'Truck'
                    : stat.label === 'Worker Rating'
                      ? 'TrendingUp'
                : stat.label === 'Active Jobs'
                  ? 'TrendingUp'
                  : stat.label === 'Completed Jobs'
                    ? 'TrendingUp'
                  : 'Truck',
          id: index,
        })),
        recentActivities,
        upcomingTasks: buildDashboardUpcomingTasks(user),
      });
  } catch (error) {
    next(error);
  }
}

export async function getMarketplaceData(req, res, next) {
  try {
    if (req.user && hasRole(req.user, 'seller')) {
      await reconcileMarketplaceSellerPayouts(req.user);
    }

    const vendors = await User.find(roleQuery('seller')).select(
      'name email profile.farmName marketplaceListings',
    );
    const visibleVendors = vendors.filter((vendor) => canManageCommercialFeatures(vendor));

    const products = (
      await Promise.all(
        visibleVendors.flatMap((vendor) =>
          vendor.marketplaceListings.map(async (listing, index) => ({
            id: `${vendor._id}-${index}`,
            ...(await buildMarketplaceListingResponse(listing.toObject?.() || listing)),
            seller: vendor.profile?.farmName || vendor.name,
            sellerUserId: vendor._id.toString(),
            vendorEmail: vendor.email,
          })),
        ),
      )
    ).filter(Boolean);

    res.json({
      products,
      myListings:
        hasRole(req.user, 'seller') && canManageCommercialFeatures(req.user)
          ? await Promise.all(req.user.marketplaceListings.map(async (listing, index) => ({
              id: `${req.user._id}-${index}`,
              ...(await buildMarketplaceListingResponse(listing.toObject?.() || listing)),
              sellerUserId: req.user._id.toString(),
              quantity: listing.stock,
              status: Number(listing.stock) > 0 ? 'active' : 'sold out',
            })))
          : [],
      myOrders:
        req.user
          ? await Promise.all(
              (Array.isArray(req.user?.marketplaceOrders?.purchases) ? req.user.marketplaceOrders.purchases : [])
                .slice()
                .sort((left, right) => new Date(right?.createdAt || 0).getTime() - new Date(left?.createdAt || 0).getTime())
                .map((order) =>
                  buildMarketplaceOrderResponse(order.toObject?.() || order, {
                    buyerAddress: req.user?.profile?.address || req.user?.profile?.location || '',
                    buyerCoordinates: req.user?.profile?.coordinates || {},
                  }),
                ),
            )
          : [],
      sellerOrders:
        hasRole(req.user, 'seller') && canManageCommercialFeatures(req.user)
          ? await Promise.all(
              (Array.isArray(req.user?.marketplaceOrders?.sales) ? req.user.marketplaceOrders.sales : [])
                .slice()
                .sort((left, right) => new Date(right?.createdAt || 0).getTime() - new Date(left?.createdAt || 0).getTime())
                .map((order) =>
                  buildMarketplaceOrderResponse(order.toObject?.() || order, {
                    sellerAddress: req.user?.profile?.location || req.user?.profile?.address || '',
                    sellerCoordinates: req.user?.profile?.coordinates || {},
                  }),
                ),
            )
          : [],
      canManageListings: hasRole(req.user, 'seller') && canManageCommercialFeatures(req.user),
      locationOptions: req.user ? getMarketplaceListingLocationOptions(req.user) : [],
    });
  } catch (error) {
    next(error);
  }
}

export async function createMarketplaceListingUploadUrl(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!hasRole(req.user, 'seller')) {
      return res.status(403).json({
        message: 'Only sellers can upload marketplace listing photos.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    const fileName = String(req.body?.fileName || '').trim();

    if (!fileName) {
      return res.status(400).json({
        message: 'A file name is required.',
      });
    }

    const uploadTarget = await createMarketplaceListingUploadTarget({
      userId: req.user._id.toString(),
      fileName,
    });

    return res.json(uploadTarget);
  } catch (error) {
    next(error);
  }
}

export async function createMarketplaceReviewUploadUrl(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    const fileName = String(req.body?.fileName || '').trim();

    if (!fileName) {
      return res.status(400).json({
        message: 'A file name is required.',
      });
    }

    const uploadTarget = await createMarketplaceReviewUploadTarget({
      userId: req.user._id.toString(),
      fileName,
    });

    return res.json(uploadTarget);
  } catch (error) {
    next(error);
  }
}

export async function createMarketplaceRefundUploadUrl(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required.' });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    const fileName = String(req.body?.fileName || '').trim();

    if (!fileName) {
      return res.status(400).json({
        message: 'A file name is required.',
      });
    }

    const signedUpload = await createMarketplaceRefundUploadTarget({
      fileName,
      userId: req.user._id.toString(),
    });

    return res.json(signedUpload);
  } catch (error) {
    next(error);
  }
}

export async function createRentalListingUploadUrl(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!hasRole(req.user, 'seller') && !hasRole(req.user, 'laborer')) {
      return res.status(403).json({
        message: 'Only sellers and laborers can upload rental listing photos.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    const fileName = String(req.body?.fileName || '').trim();

    if (!fileName) {
      return res.status(400).json({
        message: 'A file name is required.',
      });
    }

    const uploadTarget = await createRentalListingUploadTarget({
      userId: req.user._id.toString(),
      fileName,
    });

    return res.json(uploadTarget);
  } catch (error) {
    next(error);
  }
}

export async function upsertMarketplaceListing(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!hasRole(req.user, 'seller')) {
      return res.status(403).json({
        message: 'Only sellers can create marketplace listings.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    if (!Array.isArray(req.user.marketplaceListings)) {
      req.user.marketplaceListings = [];
    }

    const nextListing = normalizeMarketplaceListingPayload(req.body || {});
    const listingId = nextListing.listingId || buildMarketplaceListingId();
    const existingIndex = req.user.marketplaceListings.findIndex(
      (listing) => String(listing?.listingId || '').trim() === listingId,
    );
    const currentListing = existingIndex >= 0
      ? normalizeMarketplaceListingPayload(req.user.marketplaceListings[existingIndex].toObject?.() || req.user.marketplaceListings[existingIndex])
      : null;
    const mergedImagePaths = nextListing.imagePaths.length > 0
      ? nextListing.imagePaths
      : Array.isArray(currentListing?.imagePaths)
        ? currentListing.imagePaths
        : [];
    const preparedListing = {
      ...nextListing,
      listingId,
      varieties: nextListing.varieties.length > 0
        ? nextListing.varieties.map((variety) => ({
            id: variety.id || buildMarketplaceVarietyId(),
            label: variety.label,
            price: Number(variety.price || 0),
            stock: Number(variety.stock || 0),
          }))
        : currentListing?.varieties || [],
      imagePaths: mergedImagePaths,
      image: mergedImagePaths[0] || nextListing.image || currentListing?.image || '',
    };
    const validationMessage = getMarketplaceListingValidationMessage(preparedListing);

    if (validationMessage) {
      return res.status(400).json({
        message: validationMessage,
      });
    }

    const persistedListing = {
      ...currentListing,
      ...preparedListing,
      image: preparedListing.image,
      imagePaths: preparedListing.imagePaths,
      status: Number(preparedListing.stock) > 0 ? 'active' : 'sold out',
      views: Number(currentListing?.views || 0),
      orders: Number(currentListing?.orders || 0),
      reviews: Array.isArray(currentListing?.reviews) ? currentListing.reviews : [],
      rating: Number(currentListing?.rating || 0),
      reviewCount: Number(currentListing?.reviewCount || 0),
    };

    if (existingIndex >= 0) {
      req.user.marketplaceListings[existingIndex] = persistedListing;
    } else {
      req.user.marketplaceListings.push(persistedListing);
    }

    appendActivity(req.user, {
      description: existingIndex >= 0
        ? `Updated marketplace listing: ${persistedListing.name}`
        : `Created marketplace listing: ${persistedListing.name}`,
      status: 'confirmed',
    });

    await req.user.save();

    return res.json({
      message: existingIndex >= 0 ? 'Marketplace listing updated successfully.' : 'Marketplace listing created successfully.',
      listing: await buildMarketplaceListingResponse(persistedListing),
    });
  } catch (error) {
    next(error);
  }
}

export async function upsertRentalListing(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!hasRole(req.user, 'seller') && !hasRole(req.user, 'laborer')) {
      return res.status(403).json({
        message: 'Only sellers and laborers can create rental listings.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    if (!req.user.serviceProfile) {
      req.user.serviceProfile = {
        category: 'Equipment Rentals',
        services: [],
        bookings: [],
        incomingBookings: [],
      };
    }

    if (!Array.isArray(req.user.serviceProfile.services)) {
      req.user.serviceProfile.services = [];
    }

    req.user.serviceProfile.category = 'Equipment Rentals';

    const nextListing = normalizeRentalListingPayload(req.body || {});
    const listingId = nextListing.listingId || buildRentalListingId();
    const existingIndex = req.user.serviceProfile.services.findIndex(
      (listing) => String(listing?.listingId || '').trim() === listingId,
    );
    const currentListing = existingIndex >= 0
      ? normalizeRentalListingPayload(req.user.serviceProfile.services[existingIndex].toObject?.() || req.user.serviceProfile.services[existingIndex])
      : null;
    const mergedImagePaths = nextListing.imagePaths.length > 0
      ? nextListing.imagePaths
      : Array.isArray(currentListing?.imagePaths)
        ? currentListing.imagePaths
        : [];
    const preparedListing = {
      ...currentListing,
      ...nextListing,
      listingId,
      ownerRole: hasRole(req.user, 'seller') ? 'seller' : 'laborer',
      imagePaths: mergedImagePaths,
      image: mergedImagePaths[0] || nextListing.image || currentListing?.image || '',
      available: Number(nextListing.quantity || currentListing?.quantity || 0) > 0,
      status: Number(nextListing.quantity || currentListing?.quantity || 0) > 0 ? 'active' : 'unavailable',
    };
    const validationMessage = getRentalListingValidationMessage(preparedListing);

    if (validationMessage) {
      return res.status(400).json({
        message: validationMessage,
      });
    }

    if (existingIndex >= 0) {
      req.user.serviceProfile.services[existingIndex] = preparedListing;
    } else {
      req.user.serviceProfile.services.unshift(preparedListing);
    }

    await req.user.save();

    return res.json({
      message: existingIndex >= 0 ? 'Rental listing updated successfully.' : 'Rental listing published successfully.',
      listing: await buildRentalListingResponse(preparedListing, {
        userId: req.user._id.toString(),
        name: req.user.name,
        phone: req.user.phone,
        ownerRole: preparedListing.ownerRole,
        canEdit: true,
      }),
    });
  } catch (error) {
    next(error);
  }
}

export async function updateMarketplaceOrderStatus(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required.' });
    }

    if (!hasRole(req.user, 'seller')) {
      return res.status(403).json({ message: 'Only sellers can update marketplace order progress.' });
    }

    const orderId = String(req.params?.orderId || '').trim();
    const nextStatus = String(req.body?.status || '').trim();

    if (!orderId || !nextStatus) {
      return res.status(400).json({ message: 'Order reference and status are required.' });
    }

    ensureMarketplaceOrdersState(req.user);
    const saleIndex = req.user.marketplaceOrders.sales.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (saleIndex < 0) {
      return res.status(404).json({ message: 'That marketplace order could not be found on this seller account.' });
    }

    const allowedTransitions = {
      paid: 'preparing',
      preparing: 'ready_for_pickup',
      ready_for_pickup: 'in_transit',
    };

    const saleOrder = req.user.marketplaceOrders.sales[saleIndex].toObject?.()
      ? req.user.marketplaceOrders.sales[saleIndex].toObject()
      : req.user.marketplaceOrders.sales[saleIndex];
    const currentStatus = String(saleOrder?.status || 'paid').trim();

    if (allowedTransitions[currentStatus] !== nextStatus) {
      return res.status(409).json({
        message: 'This marketplace order cannot move to that status yet.',
      });
    }

    const buyerUserId = String(saleOrder?.buyerUserId || '').trim();
    const buyerUser = buyerUserId ? await User.findById(buyerUserId) : null;

    if (!buyerUser) {
      return res.status(404).json({ message: 'The buyer account for this marketplace order could not be found.' });
    }

    ensureMarketplaceOrdersState(buyerUser);
    const purchaseIndex = buyerUser.marketplaceOrders.purchases.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (purchaseIndex < 0) {
      return res.status(404).json({ message: 'The buyer copy of this marketplace order could not be found.' });
    }

    const now = new Date();
    const timestampPatch =
      nextStatus === 'preparing'
        ? {
            preparingAt: now,
            waybill: {
              generatedAt: saleOrder?.waybill?.generatedAt || now,
              generatedBy: req.user?._id?.toString?.() || '',
            },
          }
        : nextStatus === 'ready_for_pickup'
          ? { readyForPickupAt: now }
          : { inTransitAt: now };
    const sellerAddress = getMarketplaceAddressSnapshot(req.user, saleOrder?.sellerAddress || saleOrder?.location || '');
    const buyerAddress = getMarketplaceAddressSnapshot(buyerUser, saleOrder?.buyerAddress || '');
    const sellerCoordinates = getMarketplaceCoordinateSnapshot(req.user, saleOrder?.sellerCoordinates || {});
    const buyerCoordinates = getMarketplaceCoordinateSnapshot(buyerUser, saleOrder?.buyerCoordinates || {});
    const nextLogistics = await ensureMarketplaceLogisticsSnapshot(
      {
        ...saleOrder,
        status: nextStatus,
        ...timestampPatch,
        logistics: {
          ...(saleOrder?.logistics || {}),
          progressPercent:
            nextStatus === 'in_transit'
              ? Math.max(Number(saleOrder?.logistics?.progressPercent || 0), 18)
              : Number(saleOrder?.logistics?.progressPercent || 0),
        },
      },
      {
        orderId,
        status: nextStatus,
        createdAt: saleOrder?.createdAt || now,
        sellerAddress,
        buyerAddress,
        sellerCoordinates,
        buyerCoordinates,
      },
    );

    req.user.marketplaceOrders.sales[saleIndex] = {
      ...saleOrder,
      status: nextStatus,
      ...timestampPatch,
      sellerAddress,
      buyerAddress,
      sellerCoordinates,
      buyerCoordinates,
      logistics: nextLogistics,
    };

    const purchaseOrder = buyerUser.marketplaceOrders.purchases[purchaseIndex].toObject?.()
      ? buyerUser.marketplaceOrders.purchases[purchaseIndex].toObject()
      : buyerUser.marketplaceOrders.purchases[purchaseIndex];

    buyerUser.marketplaceOrders.purchases[purchaseIndex] = {
      ...purchaseOrder,
      status: nextStatus,
      ...timestampPatch,
      sellerAddress,
      buyerAddress,
      sellerCoordinates,
      buyerCoordinates,
      logistics: nextLogistics,
    };

    appendActivity(req.user, {
      description: `Updated marketplace order ${orderId} to ${nextStatus.replace(/_/g, ' ')}`,
      status: 'confirmed',
    });

    await Promise.all([req.user.save(), buyerUser.save()]);

    return res.json({
      message: 'Marketplace order status updated successfully.',
      order: await buildMarketplaceOrderResponse(req.user.marketplaceOrders.sales[saleIndex]),
    });
  } catch (error) {
    next(error);
  }
}

export async function downloadMarketplaceWaybill(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required.' });
    }

    if (!hasRole(req.user, 'seller')) {
      return res.status(403).json({ message: 'Only sellers can download marketplace waybills.' });
    }

    const orderId = String(req.params?.orderId || '').trim();

    if (!orderId) {
      return res.status(400).json({ message: 'Order reference is required.' });
    }

    ensureMarketplaceOrdersState(req.user);
    const saleIndex = req.user.marketplaceOrders.sales.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (saleIndex < 0) {
      return res.status(404).json({ message: 'That marketplace order could not be found on this seller account.' });
    }

    const saleOrder = req.user.marketplaceOrders.sales[saleIndex].toObject?.()
      ? req.user.marketplaceOrders.sales[saleIndex].toObject()
      : req.user.marketplaceOrders.sales[saleIndex];

    if (!canGenerateMarketplaceWaybill(saleOrder)) {
      return res.status(409).json({
        message: 'Waybill becomes available once the seller starts preparing the parcel.',
      });
    }

    const hydratedOrder = {
      ...saleOrder,
      sellerAddress: String(
        saleOrder?.sellerAddress
        || buildMarketplaceWaybillProfileAddress(req.user?.profile || {})
        || req.user?.profile?.location
        || '',
      ).trim(),
      sellerPhone: String(saleOrder?.sellerPhone || req.user?.phone || '').trim(),
      sellerEmail: String(saleOrder?.sellerEmail || req.user?.email || '').trim(),
    };

    if ((!String(hydratedOrder.buyerAddress || '').trim() || !String(hydratedOrder.buyerPhone || '').trim()) && String(saleOrder?.buyerUserId || '').trim()) {
      const buyerUser = await User.findById(String(saleOrder.buyerUserId).trim()).select('phone profile.address profile.streetAddress profile.city profile.state profile.postalCode profile.country profile.location');

      if (buyerUser) {
        hydratedOrder.buyerAddress = String(
          hydratedOrder.buyerAddress
          || buildMarketplaceWaybillProfileAddress(buyerUser.profile || {})
          || buyerUser?.profile?.location
          || '',
        ).trim();
        hydratedOrder.buyerPhone = String(hydratedOrder.buyerPhone || buyerUser.phone || '').trim();
      }
    }

    const pdfBuffer = await generateMarketplaceWaybillPdf(hydratedOrder);
    const safeOrderId = orderId.replace(/[^A-Z0-9-]/gi, '_');

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="agrihub-waybill-${safeOrderId}.pdf"`);
    res.setHeader('Content-Length', String(pdfBuffer.length));
    return res.send(pdfBuffer);
  } catch (error) {
    next(error);
  }
}

export async function confirmMarketplaceOrderReceived(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required.' });
    }

    const orderId = String(req.params?.orderId || '').trim();

    if (!orderId) {
      return res.status(400).json({ message: 'An order reference is required.' });
    }

    ensureMarketplaceOrdersState(req.user);
    const purchaseIndex = req.user.marketplaceOrders.purchases.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (purchaseIndex < 0) {
      return res.status(404).json({ message: 'That marketplace order could not be found on this buyer account.' });
    }

    const purchaseOrder = req.user.marketplaceOrders.purchases[purchaseIndex].toObject?.()
      ? req.user.marketplaceOrders.purchases[purchaseIndex].toObject()
      : req.user.marketplaceOrders.purchases[purchaseIndex];

    if (String(purchaseOrder?.status || '').trim() !== 'in_transit') {
      return res.status(409).json({ message: 'This marketplace order is not ready to be marked as received yet.' });
    }

    const sellerUserId = String(purchaseOrder?.sellerUserId || '').trim();
    const sellerUser = sellerUserId ? await User.findById(sellerUserId) : null;

    if (!sellerUser) {
      return res.status(404).json({ message: 'The seller account for this marketplace order could not be found.' });
    }

    ensureMarketplaceOrdersState(sellerUser);
    const saleIndex = sellerUser.marketplaceOrders.sales.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (saleIndex < 0) {
      return res.status(404).json({ message: 'The seller copy of this marketplace order could not be found.' });
    }

    const now = new Date();
    req.user.marketplaceOrders.purchases[purchaseIndex] = {
      ...purchaseOrder,
      status: 'received',
      receivedAt: now,
    };

    const saleOrder = sellerUser.marketplaceOrders.sales[saleIndex].toObject?.()
      ? sellerUser.marketplaceOrders.sales[saleIndex].toObject()
      : sellerUser.marketplaceOrders.sales[saleIndex];

    sellerUser.marketplaceOrders.sales[saleIndex] = {
      ...saleOrder,
      status: 'received',
      receivedAt: now,
    };

    await releaseMarketplaceSellerPayout({
      sellerUser,
      saleIndex,
      saleOrder: sellerUser.marketplaceOrders.sales[saleIndex],
      buyerUser: req.user,
      purchaseIndex,
      purchaseOrder: req.user.marketplaceOrders.purchases[purchaseIndex],
    });

    appendActivity(req.user, {
      description: `Confirmed receipt for marketplace order ${orderId}`,
      status: 'completed',
    });

    await Promise.all([req.user.save(), sellerUser.save()]);

    return res.json({
      message: 'Marketplace order marked as received.',
      order: await buildMarketplaceOrderResponse(req.user.marketplaceOrders.purchases[purchaseIndex]),
    });
  } catch (error) {
    next(error);
  }
}

export async function cancelMarketplaceOrder(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required.' });
    }

    const orderId = String(req.params?.orderId || '').trim();
    const reason = String(req.body?.reason || 'Cancelled by buyer before seller preparation').trim();

    if (!orderId) {
      return res.status(400).json({ message: 'An order reference is required.' });
    }

    ensureMarketplaceOrdersState(req.user);
    const purchaseIndex = req.user.marketplaceOrders.purchases.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (purchaseIndex < 0) {
      return res.status(404).json({ message: 'That marketplace order could not be found on this buyer account.' });
    }

    const purchaseOrder = req.user.marketplaceOrders.purchases[purchaseIndex].toObject?.()
      ? req.user.marketplaceOrders.purchases[purchaseIndex].toObject()
      : req.user.marketplaceOrders.purchases[purchaseIndex];

    if (String(purchaseOrder?.status || '').trim() !== 'paid') {
      return res.status(409).json({
        message: 'This marketplace order can only be cancelled before the seller starts preparing the parcel.',
      });
    }

    const sellerUserId = String(purchaseOrder?.sellerUserId || '').trim();
    const sellerUser = sellerUserId ? await User.findById(sellerUserId) : null;

    if (!sellerUser) {
      return res.status(404).json({ message: 'The seller account for this marketplace order could not be found.' });
    }

    ensureMarketplaceOrdersState(sellerUser);
    const saleIndex = sellerUser.marketplaceOrders.sales.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (saleIndex < 0) {
      return res.status(404).json({ message: 'The seller copy of this marketplace order could not be found.' });
    }

    const cancelledAt = new Date();
    const cancelledBy = 'buyer';
    const nextPurchaseOrder = {
      ...purchaseOrder,
      status: 'cancelled',
      cancelledAt,
      cancellationReason: reason,
      cancelledBy,
    };
    req.user.marketplaceOrders.purchases[purchaseIndex] = nextPurchaseOrder;

    const saleOrder = sellerUser.marketplaceOrders.sales[saleIndex].toObject?.()
      ? sellerUser.marketplaceOrders.sales[saleIndex].toObject()
      : sellerUser.marketplaceOrders.sales[saleIndex];
    sellerUser.marketplaceOrders.sales[saleIndex] = {
      ...saleOrder,
      status: 'cancelled',
      cancelledAt,
      cancellationReason: reason,
      cancelledBy,
    };

    const refundAmount = Number(purchaseOrder?.totalPaid || 0);
    if (refundAmount > 0) {
      creditWallet(req.user, refundAmount, {
        id: buildWalletTransactionId('REFUND'),
        method: 'marketplace_refund',
        reference: String(purchaseOrder?.paymentReference || orderId).trim(),
        description: `Refund for cancelled marketplace order ${orderId}`,
        destinationLabel: '',
        status: 'completed',
        createdAt: cancelledAt,
      });
    }

    const paymentReference = String(purchaseOrder?.paymentReference || '').trim();
    if (paymentReference) {
      await MarketplacePayment.findOneAndUpdate(
        { reference: paymentReference },
        {
          $set: {
            fulfillmentStatus: 'failed',
            fulfillmentFailureReason: `Marketplace order ${orderId} cancelled by buyer before seller preparation.`,
          },
        },
      );
    }

    appendActivity(req.user, {
      description: `Cancelled marketplace order ${orderId}`,
      status: 'cancelled',
    });

    appendActivity(sellerUser, {
      description: `Marketplace order ${orderId} was cancelled by the buyer.`,
      status: 'cancelled',
    });

    await Promise.all([req.user.save(), sellerUser.save()]);

    return res.json({
      message: 'Marketplace order cancelled and refunded to your wallet.',
      order: await buildMarketplaceOrderResponse(req.user.marketplaceOrders.purchases[purchaseIndex]),
    });
  } catch (error) {
    next(error);
  }
}

export async function requestMarketplaceOrderRefund(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required.' });
    }

    const orderId = String(req.params?.orderId || '').trim();
    const reason = String(req.body?.reason || '').trim();
    const imagePaths = Array.isArray(req.body?.imagePaths)
      ? req.body.imagePaths.map((path) => String(path || '').trim()).filter(Boolean)
      : [];
    const imageUrls = Array.isArray(req.body?.imageUrls)
      ? req.body.imageUrls.map((url) => String(url || '').trim()).filter(Boolean)
      : [];

    if (!orderId) {
      return res.status(400).json({ message: 'An order reference is required.' });
    }

    if (!reason) {
      return res.status(400).json({ message: 'Please enter the reason for this refund request.' });
    }

    if (imagePaths.length === 0 && imageUrls.length === 0) {
      return res.status(400).json({ message: 'Please upload at least one photo for the refund request.' });
    }

    ensureMarketplaceOrdersState(req.user);
    const purchaseIndex = req.user.marketplaceOrders.purchases.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (purchaseIndex < 0) {
      return res.status(404).json({ message: 'That marketplace order could not be found on this buyer account.' });
    }

    const purchaseOrder = req.user.marketplaceOrders.purchases[purchaseIndex].toObject?.()
      ? req.user.marketplaceOrders.purchases[purchaseIndex].toObject()
      : req.user.marketplaceOrders.purchases[purchaseIndex];
    const normalizedStatus = String(purchaseOrder?.status || '').trim().toLowerCase();

    if (!['in_transit', 'received', 'completed', 'return_refund'].includes(normalizedStatus)) {
      return res.status(409).json({ message: 'This order is not eligible for a refund request right now.' });
    }

    if (String(purchaseOrder?.refundRequest?.status || 'none').trim() === 'pending') {
      return res.status(409).json({ message: 'A refund request for this order is already pending admin review.' });
    }

    const sellerUserId = String(purchaseOrder?.sellerUserId || '').trim();
    const sellerUser = sellerUserId ? await User.findById(sellerUserId) : null;

    if (!sellerUser) {
      return res.status(404).json({ message: 'The seller account for this marketplace order could not be found.' });
    }

    ensureMarketplaceOrdersState(sellerUser);
    const saleIndex = sellerUser.marketplaceOrders.sales.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (saleIndex < 0) {
      return res.status(404).json({ message: 'The seller copy of this marketplace order could not be found.' });
    }

    const requestedAt = new Date();
    const refundRequest = {
      status: 'pending',
      reason,
      imagePaths,
      imageUrls,
      requestedAt,
      reviewedAt: null,
      reviewedByUserId: '',
      reviewedByName: '',
      adminDecisionReason: '',
      refundedAt: null,
    };

    req.user.marketplaceOrders.purchases[purchaseIndex] = {
      ...purchaseOrder,
      status: 'return_refund',
      refundRequest,
    };

    const saleOrder = sellerUser.marketplaceOrders.sales[saleIndex].toObject?.()
      ? sellerUser.marketplaceOrders.sales[saleIndex].toObject()
      : sellerUser.marketplaceOrders.sales[saleIndex];
    sellerUser.marketplaceOrders.sales[saleIndex] = {
      ...saleOrder,
      status: 'return_refund',
      refundRequest,
    };

    appendActivity(req.user, {
      description: `Requested a marketplace refund for order ${orderId}: ${reason}`,
      status: 'pending',
    });
    appendActivity(sellerUser, {
      description: `Buyer requested a refund for marketplace order ${orderId}: ${reason}`,
      status: 'pending',
    });

    await Promise.all([req.user.save(), sellerUser.save()]);

    return res.json({
      message: 'Refund request submitted. An admin will review your reason and photos before any refund is issued.',
      order: await buildMarketplaceOrderResponse(req.user.marketplaceOrders.purchases[purchaseIndex]),
    });
  } catch (error) {
    next(error);
  }
}

export async function submitMarketplaceOrderReview(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required.' });
    }

    const orderId = String(req.params?.orderId || '').trim();
    const rating = Number(req.body?.rating || 0);
    const comment = String(req.body?.comment || '').trim();
    const reviewImagePaths = Array.isArray(req.body?.imagePaths)
      ? req.body.imagePaths.map((path) => String(path || '').trim()).filter(Boolean)
      : [];
    const reviewImageUrls = Array.isArray(req.body?.imageUrls)
      ? req.body.imageUrls.map((url) => String(url || '').trim()).filter(Boolean)
      : [];

    if (!orderId) {
      return res.status(400).json({ message: 'An order reference is required.' });
    }

    if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
      return res.status(400).json({ message: 'Choose a rating from 1 to 5 stars.' });
    }

    ensureMarketplaceOrdersState(req.user);
    const purchaseIndex = req.user.marketplaceOrders.purchases.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (purchaseIndex < 0) {
      return res.status(404).json({ message: 'That marketplace order could not be found on this buyer account.' });
    }

    const purchaseOrder = req.user.marketplaceOrders.purchases[purchaseIndex].toObject?.()
      ? req.user.marketplaceOrders.purchases[purchaseIndex].toObject()
      : req.user.marketplaceOrders.purchases[purchaseIndex];

    if (!['received', 'completed'].includes(String(purchaseOrder?.status || '').trim())) {
      return res.status(409).json({ message: 'You can only review marketplace orders after receiving them.' });
    }

    if (purchaseOrder?.reviewed) {
      return res.status(409).json({ message: 'This marketplace order has already been reviewed.' });
    }

    const sellerUserId = String(purchaseOrder?.sellerUserId || '').trim();
    const listingId = String(purchaseOrder?.listingId || '').trim();
    const sellerUser = sellerUserId ? await User.findById(sellerUserId) : null;

    if (!sellerUser) {
      return res.status(404).json({ message: 'The seller account for this marketplace order could not be found.' });
    }

    ensureMarketplaceOrdersState(sellerUser);
    const saleIndex = sellerUser.marketplaceOrders.sales.findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );
    const listingIndex = Array.isArray(sellerUser.marketplaceListings)
      ? sellerUser.marketplaceListings.findIndex((listing) => String(listing?.listingId || '').trim() === listingId)
      : -1;

    if (saleIndex < 0 || listingIndex < 0) {
      return res.status(404).json({ message: 'The matching seller order or listing could not be found.' });
    }

    const now = new Date();
    const review = {
      id: buildMarketplaceReviewId(),
      author: String(req.user.name || '').trim() || 'Customer',
      authorUserId: req.user._id.toString(),
      rating,
      comment,
      imagePaths: reviewImagePaths,
      imageUrls: reviewImageUrls,
      createdAt: now,
    };

    const listingSnapshot = sellerUser.marketplaceListings[listingIndex].toObject?.()
      ? sellerUser.marketplaceListings[listingIndex].toObject()
      : sellerUser.marketplaceListings[listingIndex];
    const nextListingReviews = [...(Array.isArray(listingSnapshot?.reviews) ? listingSnapshot.reviews : []), review];
    const nextListingRating = nextListingReviews.reduce((sum, entry) => sum + Number(entry?.rating || 0), 0) / nextListingReviews.length;

    sellerUser.marketplaceListings[listingIndex] = {
      ...listingSnapshot,
      reviews: nextListingReviews,
      rating: nextListingRating,
      reviewCount: nextListingReviews.length,
    };

    req.user.marketplaceOrders.purchases[purchaseIndex] = {
      ...purchaseOrder,
      status: 'completed',
      reviewed: true,
      reviewRating: rating,
      reviewComment: comment,
      reviewImagePaths,
      reviewImageUrls,
      completedAt: now,
    };

    const saleOrder = sellerUser.marketplaceOrders.sales[saleIndex].toObject?.()
      ? sellerUser.marketplaceOrders.sales[saleIndex].toObject()
      : sellerUser.marketplaceOrders.sales[saleIndex];

    sellerUser.marketplaceOrders.sales[saleIndex] = {
      ...saleOrder,
      status: 'completed',
      reviewed: true,
      reviewRating: rating,
      reviewComment: comment,
      reviewImagePaths,
      reviewImageUrls,
      completedAt: now,
    };

    appendActivity(req.user, {
      description: `Reviewed marketplace order ${orderId}`,
      status: 'completed',
    });

    await Promise.all([req.user.save(), sellerUser.save()]);

    return res.json({
      message: 'Marketplace order review submitted successfully.',
      order: await buildMarketplaceOrderResponse(req.user.marketplaceOrders.purchases[purchaseIndex]),
    });
  } catch (error) {
    next(error);
  }
}

export async function getLaborData(req, res, next) {
  try {
    const currentUser = req.user || null;
    const laborers = await User.find(roleQuery('laborer'));
    const viewerProvince = getPrimaryProvinceLabel(currentUser?.profile);
    const currentUserActiveBookings = Array.isArray(currentUser?.laborBookings?.activeBookings)
      ? currentUser.laborBookings.activeBookings
      : [];
    const currentUserBookingHistory = Array.isArray(currentUser?.laborBookings?.bookingHistory)
      ? currentUser.laborBookings.bookingHistory
      : [];

    res.json({
      availableWorkers: laborers.flatMap((laborer) =>
        getLaborListings(laborer)
          .filter(
            (listing) =>
              canManageCommercialFeatures(laborer) &&
              listing.isPublished &&
              laborOfferIsComplete(laborer, listing) &&
              (!currentUser || belongsToSameProvince(currentUser?.profile, laborer?.profile)),
          )
          .map((listing) => {
            const ratingSummary = buildLaborListingRatingSummary(listing);

            return {
              id: `${laborer._id.toString()}-${listing.workerType}`,
              workerId: laborer._id.toString(),
              name: laborer.name,
              title: listing.title,
              description: listing.description,
              type: listing.workerType,
              rating: ratingSummary.rating,
              reviewCount: ratingSummary.reviewCount,
              reviews: ratingSummary.reviews,
              experience: formatExperienceYears(laborer.profile.experience),
              rate: listing.rate,
              availability: listing.availability,
              skills: listing.skills,
              distance: listing.distance,
              serviceArea: listing.serviceArea,
              location: laborer.profile.location,
              email: laborer.email,
              phone: laborer.phone,
              bookedSlots: (Array.isArray(laborer.laborProfile?.activeBookings) ? laborer.laborProfile.activeBookings : [])
                .map((booking) => ({
                  bookingId: String(booking?.bookingId || '').trim(),
                  date: String(booking?.date || '').trim(),
                  time: String(booking?.time || '').trim(),
                  duration: String(booking?.duration || '').trim(),
                  status: String(booking?.status || '').trim(),
                }))
                .filter((booking) => booking.date && booking.time && booking.duration),
              workingHoursStart: listing.workingHoursStart,
              workingHoursEnd: listing.workingHoursEnd,
              workingHoursLabel: formatWorkingHoursRange(listing.workingHoursStart, listing.workingHoursEnd),
            };
          }),
      ),
      viewerProvince,
      activeBookings: currentUserActiveBookings.map((booking, bookingIndex) => ({
        id: `my-active-${bookingIndex}`,
        ...(booking.toObject?.() || booking),
      })),
      bookingHistory: currentUserBookingHistory.map((booking, bookingIndex) => ({
        id: `my-history-${bookingIndex}`,
        ...(booking.toObject?.() || booking),
      })),
      canOfferLabor: hasRole(currentUser, 'laborer') && canManageCommercialFeatures(currentUser),
      myLaborProfile:
        hasRole(currentUser, 'laborer') && canManageCommercialFeatures(currentUser)
          ? buildLaborOfferPayload(currentUser)
          : null,
      myActiveJobs:
        hasRole(currentUser, 'laborer') && canManageCommercialFeatures(currentUser)
          ? currentUser.laborProfile.activeBookings || []
          : [],
      myJobHistory:
        hasRole(currentUser, 'laborer') && canManageCommercialFeatures(currentUser)
          ? currentUser.laborProfile.bookingHistory || []
          : [],
    });
  } catch (error) {
    next(error);
  }
}

export async function upsertLaborOffer(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!hasRole(req.user, 'laborer')) {
      return res.status(403).json({
        message: 'Only laborers can create labor offers.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    const workerType = String(req.body?.workerType || '').trim();
    const description = String(req.body?.description || '').trim();
    const availability = String(req.body?.availability || '').trim();
    const location = String(req.body?.location || '').trim();
    const experience = normalizeExperienceYears(req.body?.experience || '');
    const phone = String(req.body?.phone || '').trim();
    const rate = Number(req.body?.rate);
    const workingHoursStart = normalizeClockTime(req.body?.workingHoursStart);
    const workingHoursEnd = normalizeClockTime(req.body?.workingHoursEnd);
    const verifiedSkills = getVerifiedLaborSkills(req.user);
    const existingListings = getLaborListings(req.user);
    const matchedListingIndex = existingListings.findIndex((listing) => listing.workerType === workerType);
    const title = workerType ? `${workerType} Labor` : '';

    if (verifiedSkills.length === 0) {
      return res.status(400).json({
        message: 'No verified labor skills were found for this account.',
      });
    }

    if (!workerType) {
      return res.status(400).json({
        message: 'Choose which labor you will provide from your verified skills.',
      });
    }

    if (!verifiedSkills.includes(workerType)) {
      return res.status(400).json({
        message: 'The selected labor must match one of your verified skills.',
      });
    }

    if (
      !title ||
      !workerType ||
      !description ||
      !availability ||
      !location ||
      !experience ||
      !phone ||
      !workingHoursStart ||
      !workingHoursEnd ||
      !Number.isFinite(rate) ||
      rate <= 0
    ) {
      return res.status(400).json({
        message:
          'Labor type, description, rate, availability, working hours, address verification, experience, and phone are required.',
      });
    }

    if (convertClockTimeToMinutes(workingHoursStart) >= convertClockTimeToMinutes(workingHoursEnd)) {
      return res.status(400).json({
        message: 'Working hours end time must be later than the start time.',
      });
    }

    const hadExistingOffer = matchedListingIndex >= 0;
    const nextListing = {
      title,
      workerType,
      description,
      rate,
      availability,
      skills: verifiedSkills,
      distance: '',
      serviceArea: '',
      workingHoursStart,
      workingHoursEnd,
      isPublished: true,
    };

    req.user.phone = phone;
    req.user.profile.location = location;
    req.user.profile.experience = experience;

    if (!Array.isArray(req.user.laborProfile.listings)) {
      req.user.laborProfile.listings = [];
    }

    if (matchedListingIndex >= 0) {
      req.user.laborProfile.listings[matchedListingIndex] = nextListing;
    } else {
      req.user.laborProfile.listings.push(nextListing);
    }

    syncPrimaryLaborProfileFromListings(req.user);

    appendActivity(req.user, {
      description: hadExistingOffer
        ? `Updated labor offer: ${title}`
        : `Created labor offer: ${title}`,
      status: 'confirmed',
    });

    await req.user.save();

    res.json({
      message: 'Labor offer saved successfully.',
      laborOffer: buildLaborOfferPayload(req.user),
    });
  } catch (error) {
    next(error);
  }
}

export async function createLaborBooking(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!canManageCommercialFeatures(req.user)) {
      return res.status(403).json({
        message: 'This account is currently restricted from marketplace and workforce actions.',
      });
    }

    const workerId = String(req.body?.workerId || '').trim();
    const workerType = String(req.body?.workerType || '').trim();
    const date = String(req.body?.date || '').trim();
    const time = String(req.body?.time || '').trim();
    const duration = String(req.body?.duration || '').trim();
    const location = String(req.body?.location || '').trim();

    if (!workerId || !workerType || !date || !time || !duration || !location) {
      return res.status(400).json({
        message: 'Worker, labor type, date, time, duration, and location are required.',
      });
    }

    if (String(req.user._id || '') === workerId) {
      return res.status(403).json({
        message: 'You cannot book your own labor listing.',
      });
    }

    const worker = await User.findOne({
      _id: workerId,
      ...roleQuery('laborer'),
    });

    const selectedListing = getLaborListings(worker).find((listing) => listing.workerType === workerType);

    if (
      !worker ||
      !selectedListing ||
      !canManageCommercialFeatures(worker) ||
      !selectedListing.isPublished ||
      !laborOfferIsComplete(worker, selectedListing)
    ) {
      return res.status(404).json({
        message: 'Selected worker is not available for booking.',
      });
    }

    const numericRate = Number(selectedListing.rate || req.body?.rate || 0);
    const durationHours = parseInt(duration, 10);
    const bookingCost = Number.isFinite(durationHours) && durationHours > 0
      ? numericRate * durationHours
      : numericRate;
    const bookingType = String(
      req.body?.type || selectedListing.workerType || worker.profile?.specialization || 'Labor',
    ).trim();
    const bookingId = buildLaborBookingId();
    const buyerName = String(req.user.name || '').trim() || 'Authenticated User';
    const buyerEmail = String(req.user.email || '').trim().toLowerCase();
    const buyerPhone = String(req.user.phone || '').trim();
    const requestedTimeMinutes = convertClockTimeToMinutes(time);
    const workingHoursStartMinutes = convertClockTimeToMinutes(selectedListing.workingHoursStart);
    const workingHoursEndMinutes = convertClockTimeToMinutes(selectedListing.workingHoursEnd);
    const durationHoursValue = getDurationHours(duration);

    if (
      requestedTimeMinutes === null ||
      workingHoursStartMinutes === null ||
      workingHoursEndMinutes === null
    ) {
      return res.status(400).json({
        message:
          workingHoursStartMinutes === null || workingHoursEndMinutes === null
            ? 'This labor listing does not have a valid working-hours schedule yet.'
            : 'Enter a valid booking time within the laborer’s working hours.',
      });
    }

    if (requestedTimeMinutes < workingHoursStartMinutes || requestedTimeMinutes > workingHoursEndMinutes) {
      return res.status(400).json({
        message: `Bookings for this laborer are only available from ${formatWorkingHoursRange(selectedListing.workingHoursStart, selectedListing.workingHoursEnd)}.`,
      });
    }

    if (durationHoursValue !== null && requestedTimeMinutes + durationHoursValue * 60 > workingHoursEndMinutes) {
      return res.status(400).json({
        message: `This booking extends past the laborer's working hours of ${formatWorkingHoursRange(selectedListing.workingHoursStart, selectedListing.workingHoursEnd)}.`,
      });
    }

    if (durationHoursValue === null) {
      return res.status(400).json({
        message: 'Choose a valid booking duration in whole hours.',
      });
    }

    const workerActiveBookings = Array.isArray(worker?.laborProfile?.activeBookings)
      ? worker.laborProfile.activeBookings
      : [];

    if (hasLaborBookingTimeConflict(workerActiveBookings, date, requestedTimeMinutes, durationHoursValue)) {
      return res.status(409).json({
        message: 'This worker is already booked for part of that time range on the selected date.',
      });
    }

    const buyerBooking = {
      bookingId,
      worker: worker.name,
      workerId: worker._id.toString(),
      workerEmail: String(worker.email || '').trim().toLowerCase(),
      workerPhone: String(worker.phone || '').trim(),
      type: bookingType,
      date,
      time,
      duration,
      location,
      rate: numericRate,
      status: 'confirmed',
      cost: bookingCost,
      bookedByUserId: req.user._id.toString(),
      bookedByName: buyerName,
      bookedByEmail: buyerEmail,
      bookedByPhone: buyerPhone,
      travelTracking: createTravelTrackingSnapshot(),
    };

    const workerBooking = {
      ...buyerBooking,
      worker: buyerName,
    };

    if (!req.user.laborBookings) {
      req.user.laborBookings = {
        activeBookings: [],
        bookingHistory: [],
      };
    }

    req.user.laborBookings.activeBookings = [
      ...(Array.isArray(req.user.laborBookings.activeBookings) ? req.user.laborBookings.activeBookings : []),
      buyerBooking,
    ];

    worker.laborProfile.activeBookings = [
      ...(Array.isArray(worker.laborProfile?.activeBookings) ? worker.laborProfile.activeBookings : []),
      workerBooking,
    ];

    appendActivity(req.user, {
      description: `Booked worker ${worker.name} for ${date}`,
      status: 'confirmed',
    });

    await Promise.all([req.user.save(), worker.save()]);

    res.status(201).json({
      message: 'Worker booked successfully.',
      booking: buyerBooking,
    });
  } catch (error) {
    next(error);
  }
}

export async function markLaborBookingOnTheWay(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    if (!hasRole(req.user, 'laborer')) {
      return res.status(403).json({
        message: 'Only laborers can update travel tracking for labor bookings.',
      });
    }

    const bookingId = String(req.params?.bookingId || req.body?.bookingId || '').trim();
    const lat = Number(req.body?.lat);
    const lng = Number(req.body?.lng);

    if (!bookingId) {
      return res.status(400).json({
        message: 'A booking reference is required.',
      });
    }

    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return res.status(400).json({
        message: 'A valid current location is required to start travel tracking.',
      });
    }

    const activeBookings = Array.isArray(req.user?.laborProfile?.activeBookings)
      ? req.user.laborProfile.activeBookings
      : [];
    const bookingIndex = activeBookings.findIndex((booking) => String(booking?.bookingId || '').trim() === bookingId);

    if (bookingIndex < 0) {
      return res.status(404).json({
        message: 'That active labor booking could not be found on this worker account.',
      });
    }

    const workerBooking = activeBookings[bookingIndex];

    if (String(workerBooking?.date || '').trim() !== getCurrentManilaDateString()) {
      return res.status(400).json({
        message: 'Travel tracking can only be started on the actual booking day.',
      });
    }

    const buyerUserId = String(workerBooking?.bookedByUserId || '').trim();
    const buyer = buyerUserId ? await User.findById(buyerUserId) : null;

    if (!buyer) {
      return res.status(404).json({
        message: 'The client account for this booking could not be found.',
      });
    }

    const buyerActiveBookings = Array.isArray(buyer?.laborBookings?.activeBookings)
      ? buyer.laborBookings.activeBookings
      : [];
    const buyerBookingIndex = buyerActiveBookings.findIndex((booking) => String(booking?.bookingId || '').trim() === bookingId);

    if (buyerBookingIndex < 0) {
      return res.status(404).json({
        message: 'The mirrored client booking record could not be found.',
      });
    }

    const now = new Date();
    const nextTravelTracking = createTravelTrackingSnapshot({
      ...(workerBooking?.travelTracking?.toObject?.() || workerBooking?.travelTracking || {}),
      isOnTheWay: true,
      startedAt: workerBooking?.travelTracking?.startedAt || now,
      updatedAt: now,
      currentLocation: {
        lat,
        lng,
      },
    });

    req.user.laborProfile.activeBookings[bookingIndex] = {
      ...(workerBooking.toObject?.() || workerBooking),
      status: 'on_the_way',
      travelTracking: nextTravelTracking,
    };

    buyer.laborBookings.activeBookings[buyerBookingIndex] = {
      ...(buyerActiveBookings[buyerBookingIndex].toObject?.() || buyerActiveBookings[buyerBookingIndex]),
      status: 'on_the_way',
      travelTracking: nextTravelTracking,
    };

    await Promise.all([req.user.save(), buyer.save()]);

    res.json({
      message: 'Travel tracking is now live for this booking.',
      booking: buyer.laborBookings.activeBookings[buyerBookingIndex],
    });
  } catch (error) {
    next(error);
  }
}

export async function markLaborBookingCompleted(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    const bookingId = String(req.params?.bookingId || req.body?.bookingId || '').trim();

    if (!bookingId) {
      return res.status(400).json({
        message: 'A booking reference is required.',
      });
    }

    const buyerActiveBookings = Array.isArray(req.user?.laborBookings?.activeBookings)
      ? req.user.laborBookings.activeBookings
      : [];
    const workerActiveBookings = Array.isArray(req.user?.laborProfile?.activeBookings)
      ? req.user.laborProfile.activeBookings
      : [];

    const buyerBookingIndex = buyerActiveBookings.findIndex(
      (booking) => String(booking?.bookingId || '').trim() === bookingId,
    );
    const workerBookingIndex = workerActiveBookings.findIndex(
      (booking) => String(booking?.bookingId || '').trim() === bookingId,
    );

    const isBuyerConfirming = buyerBookingIndex >= 0;
    const isWorkerConfirming = workerBookingIndex >= 0;

    if (!isBuyerConfirming && !isWorkerConfirming) {
      return res.status(404).json({
        message: 'That active labor booking could not be found on this account.',
      });
    }

    const sourceBooking = isBuyerConfirming
      ? buyerActiveBookings[buyerBookingIndex]
      : workerActiveBookings[workerBookingIndex];

    if (String(sourceBooking?.date || '').trim() !== getCurrentManilaDateString()) {
      return res.status(409).json({
        message: 'Labor bookings can only be marked as completed on the booked date.',
      });
    }

    if (String(sourceBooking?.status || '').trim() === 'cancelled') {
      return res.status(409).json({
        message: 'Cancelled labor bookings cannot be marked as completed.',
      });
    }

    const counterpartUserId = isBuyerConfirming
      ? String(sourceBooking?.workerId || '').trim()
      : String(sourceBooking?.bookedByUserId || '').trim();

    const counterpartUser = counterpartUserId ? await User.findById(counterpartUserId) : null;

    if (!counterpartUser) {
      return res.status(404).json({
        message: 'The other party for this labor booking could not be found.',
      });
    }

    if (!counterpartUser.laborBookings) {
      counterpartUser.laborBookings = {
        activeBookings: [],
        bookingHistory: [],
      };
    }

    if (!counterpartUser.laborProfile) {
      counterpartUser.laborProfile = {
        activeBookings: [],
        bookingHistory: [],
      };
    }

    const counterpartActiveBookings = isBuyerConfirming
      ? Array.isArray(counterpartUser?.laborProfile?.activeBookings)
        ? counterpartUser.laborProfile.activeBookings
        : []
      : Array.isArray(counterpartUser?.laborBookings?.activeBookings)
        ? counterpartUser.laborBookings.activeBookings
        : [];

    const counterpartBookingIndex = counterpartActiveBookings.findIndex(
      (booking) => String(booking?.bookingId || '').trim() === bookingId,
    );

    if (counterpartBookingIndex < 0) {
      return res.status(404).json({
        message: 'The matching labor booking record could not be found for the other party.',
      });
    }

    const counterpartBooking = counterpartActiveBookings[counterpartBookingIndex];
    const confirmationTime = new Date();

    const localBookingSnapshot = sourceBooking.toObject?.() || sourceBooking;
    const counterpartBookingSnapshot = counterpartBooking.toObject?.() || counterpartBooking;

    const nextLocalConfirmation = {
      ...(localBookingSnapshot.completionConfirmation || {}),
      ...(isBuyerConfirming
        ? { clientConfirmedAt: confirmationTime }
        : { workerConfirmedAt: confirmationTime }),
    };
    const nextCounterpartConfirmation = {
      ...(counterpartBookingSnapshot.completionConfirmation || {}),
      ...(isBuyerConfirming
        ? { clientConfirmedAt: confirmationTime }
        : { workerConfirmedAt: confirmationTime }),
    };

    const clientConfirmedAt = nextLocalConfirmation.clientConfirmedAt || nextCounterpartConfirmation.clientConfirmedAt;
    const workerConfirmedAt = nextLocalConfirmation.workerConfirmedAt || nextCounterpartConfirmation.workerConfirmedAt;
    const bothConfirmed = Boolean(clientConfirmedAt && workerConfirmedAt);

    const nextLocalBooking = {
      ...localBookingSnapshot,
      completionConfirmation: {
        clientConfirmedAt: clientConfirmedAt || null,
        workerConfirmedAt: workerConfirmedAt || null,
      },
      completedAt: bothConfirmed ? confirmationTime : localBookingSnapshot.completedAt || null,
      status: bothConfirmed ? 'completed' : localBookingSnapshot.status || 'confirmed',
    };
    const nextCounterpartBooking = {
      ...counterpartBookingSnapshot,
      completionConfirmation: {
        clientConfirmedAt: clientConfirmedAt || null,
        workerConfirmedAt: workerConfirmedAt || null,
      },
      completedAt: bothConfirmed ? confirmationTime : counterpartBookingSnapshot.completedAt || null,
      status: bothConfirmed ? 'completed' : counterpartBookingSnapshot.status || 'confirmed',
    };

    if (isBuyerConfirming) {
      req.user.laborBookings.activeBookings[buyerBookingIndex] = nextLocalBooking;
      counterpartUser.laborProfile.activeBookings[counterpartBookingIndex] = nextCounterpartBooking;
    } else {
      req.user.laborProfile.activeBookings[workerBookingIndex] = nextLocalBooking;
      counterpartUser.laborBookings.activeBookings[counterpartBookingIndex] = nextCounterpartBooking;
    }

    if (bothConfirmed) {
      if (isBuyerConfirming) {
        req.user.laborBookings.activeBookings = buyerActiveBookings.filter((_, index) => index !== buyerBookingIndex);
        req.user.laborBookings.bookingHistory = [
          ...(Array.isArray(req.user.laborBookings.bookingHistory) ? req.user.laborBookings.bookingHistory : []),
          nextLocalBooking,
        ];
        counterpartUser.laborProfile.activeBookings = counterpartActiveBookings.filter(
          (_, index) => index !== counterpartBookingIndex,
        );
        counterpartUser.laborProfile.bookingHistory = [
          ...(Array.isArray(counterpartUser?.laborProfile?.bookingHistory)
            ? counterpartUser.laborProfile.bookingHistory
            : []),
          nextCounterpartBooking,
        ];
      } else {
        req.user.laborProfile.activeBookings = workerActiveBookings.filter((_, index) => index !== workerBookingIndex);
        req.user.laborProfile.bookingHistory = [
          ...(Array.isArray(req.user.laborProfile.bookingHistory) ? req.user.laborProfile.bookingHistory : []),
          nextLocalBooking,
        ];
        counterpartUser.laborBookings.activeBookings = counterpartActiveBookings.filter(
          (_, index) => index !== counterpartBookingIndex,
        );
        counterpartUser.laborBookings.bookingHistory = [
          ...(Array.isArray(counterpartUser?.laborBookings?.bookingHistory)
            ? counterpartUser.laborBookings.bookingHistory
            : []),
          nextCounterpartBooking,
        ];
      }

      appendActivity(req.user, {
        description: `Completed labor booking ${bookingId}`,
        status: 'completed',
      });
      appendActivity(counterpartUser, {
        description: `Completed labor booking ${bookingId}`,
        status: 'completed',
      });
    } else {
      appendActivity(req.user, {
        description: `Confirmed completion for labor booking ${bookingId}`,
        status: 'confirmed',
      });
    }

    const laborPayment = await findRelatedLaborPaymentForBooking(sourceBooking);

    if (laborPayment) {
      laborPayment.bookingId = laborPayment.bookingId || bookingId;
      if (bothConfirmed) {
        const workerUser = isBuyerConfirming ? counterpartUser : req.user;

        if (laborPayment.releaseStatus !== 'released') {
          const releaseAmount = Number(laborPayment.subtotal || 0);

          creditWallet(workerUser, releaseAmount, {
            id: buildWalletTransactionId('WALLET'),
            method: 'labor_payment',
            reference: laborPayment.reference || bookingId,
            description: `Labor earnings from booking ${bookingId}`,
            destinationLabel: '',
            status: 'completed',
            createdAt: confirmationTime,
          });

          appendActivity(workerUser, {
            description: `Wallet credited for labor booking ${bookingId}`,
            status: 'completed',
          });
        }

        laborPayment.status = 'released';
        laborPayment.releaseStatus = 'released';
        laborPayment.releasedAt = laborPayment.releasedAt || confirmationTime;
        laborPayment.releaseFailureReason = '';
      } else if (laborPayment.releaseStatus !== 'released') {
        laborPayment.status = 'ready_for_release';
        laborPayment.releaseStatus = 'ready';
        laborPayment.releaseFailureReason = '';
      }
      laborPayment.paidAt = laborPayment.paidAt || confirmationTime;
      await laborPayment.save();
    }

    await Promise.all([req.user.save(), counterpartUser.save()]);

    return res.json({
      message: bothConfirmed
        ? 'Both sides confirmed the labor booking. It has been marked as completed.'
        : isBuyerConfirming
          ? 'Your completion confirmation has been recorded. Waiting for the laborer to confirm.'
          : 'Your completion confirmation has been recorded. Waiting for the client to confirm.',
      booking: isBuyerConfirming
        ? bothConfirmed
          ? nextLocalBooking
          : req.user.laborBookings.activeBookings[buyerBookingIndex]
        : bothConfirmed
          ? nextLocalBooking
          : req.user.laborProfile.activeBookings[workerBookingIndex],
      completed: bothConfirmed,
    });
  } catch (error) {
    next(error);
  }
}

export async function markServiceBookingCompleted(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    const bookingRef = String(req.params?.bookingRef || req.body?.bookingRef || '').trim();

    if (!bookingRef) {
      return res.status(400).json({
        message: 'A booking reference is required.',
      });
    }

    if (!req.user.serviceProfile) {
      req.user.serviceProfile = {
        category: 'Equipment Rentals',
        services: [],
        bookings: [],
        incomingBookings: [],
      };
    }

    const customerBookings = Array.isArray(req.user?.serviceProfile?.bookings)
      ? req.user.serviceProfile.bookings
      : [];
    const providerBookings = Array.isArray(req.user?.serviceProfile?.incomingBookings)
      ? req.user.serviceProfile.incomingBookings
      : [];

    const customerBookingIndex = customerBookings.findIndex(
      (booking) => String(booking?.bookingRef || '').trim() === bookingRef,
    );
    const providerBookingIndex = providerBookings.findIndex(
      (booking) => String(booking?.bookingRef || '').trim() === bookingRef,
    );

    const isCustomerConfirming = customerBookingIndex >= 0;
    const isProviderConfirming = providerBookingIndex >= 0;

    if (!isCustomerConfirming && !isProviderConfirming) {
      return res.status(404).json({
        message: 'That rental booking could not be found on this account.',
      });
    }

    const sourceBooking = isCustomerConfirming
      ? customerBookings[customerBookingIndex]
      : providerBookings[providerBookingIndex];

    if (!hasServiceBookingReachedStart(sourceBooking)) {
      return res.status(409).json({
        message: 'Rental bookings can only be marked as completed once the scheduled date and time has started.',
      });
    }

    const normalizedStatus = String(sourceBooking?.status || '').trim().toLowerCase();

    if (normalizedStatus === 'cancelled') {
      return res.status(409).json({
        message: 'Cancelled rental bookings cannot be marked as completed.',
      });
    }

    if (normalizedStatus === 'completed') {
      return res.status(409).json({
        message: 'This rental booking has already been completed.',
      });
    }

    const relatedPayment = await findRelatedServicePaymentForBooking(sourceBooking);
    const counterpartUserId = isCustomerConfirming
      ? String(sourceBooking?.providerUserId || relatedPayment?.providerUserId || '').trim()
      : String(sourceBooking?.customerUserId || relatedPayment?.buyerUserId || '').trim();
    const counterpartUser = counterpartUserId ? await User.findById(counterpartUserId) : null;

    if (!counterpartUser) {
      return res.status(404).json({
        message: 'The other party for this rental booking could not be found.',
      });
    }

    if (!counterpartUser.serviceProfile) {
      counterpartUser.serviceProfile = {
        category: 'Equipment Rentals',
        services: [],
        bookings: [],
        incomingBookings: [],
      };
    }

    if (!Array.isArray(counterpartUser.serviceProfile.bookings)) {
      counterpartUser.serviceProfile.bookings = [];
    }

    if (!Array.isArray(counterpartUser.serviceProfile.incomingBookings)) {
      counterpartUser.serviceProfile.incomingBookings = [];
    }

    const counterpartBookings = isCustomerConfirming
      ? counterpartUser.serviceProfile.incomingBookings
      : counterpartUser.serviceProfile.bookings;
    const counterpartBookingIndex = counterpartBookings.findIndex(
      (booking) => String(booking?.bookingRef || '').trim() === bookingRef,
    );

    if (counterpartBookingIndex < 0) {
      return res.status(404).json({
        message: 'The matching rental booking record could not be found for the other party.',
      });
    }

    const counterpartBooking = counterpartBookings[counterpartBookingIndex];
    const confirmationTime = new Date();
    const localBookingSnapshot = sourceBooking.toObject?.() || sourceBooking;
    const counterpartBookingSnapshot = counterpartBooking.toObject?.() || counterpartBooking;

    const localPickupConfirmation = localBookingSnapshot.pickupConfirmation || {};
    const counterpartPickupConfirmation = counterpartBookingSnapshot.pickupConfirmation || {};
    const pickupConfirmed = isCustomerConfirming
      ? Boolean(localPickupConfirmation.customerConfirmedAt || counterpartPickupConfirmation.customerConfirmedAt)
      : Boolean(localPickupConfirmation.providerConfirmedAt || counterpartPickupConfirmation.providerConfirmedAt);

    if (!pickupConfirmed) {
      return res.status(409).json({
        message: 'Confirm pickup first before marking this rental booking as completed.',
      });
    }

    const nextLocalConfirmation = {
      ...(localBookingSnapshot.completionConfirmation || {}),
      ...(isCustomerConfirming
        ? { customerConfirmedAt: confirmationTime }
        : { providerConfirmedAt: confirmationTime }),
    };
    const nextCounterpartConfirmation = {
      ...(counterpartBookingSnapshot.completionConfirmation || {}),
      ...(isCustomerConfirming
        ? { customerConfirmedAt: confirmationTime }
        : { providerConfirmedAt: confirmationTime }),
    };

    const customerConfirmedAt =
      nextLocalConfirmation.customerConfirmedAt || nextCounterpartConfirmation.customerConfirmedAt;
    const providerConfirmedAt =
      nextLocalConfirmation.providerConfirmedAt || nextCounterpartConfirmation.providerConfirmedAt;
    const bothConfirmed = Boolean(customerConfirmedAt && providerConfirmedAt);

    const nextLocalBooking = {
      ...localBookingSnapshot,
      completionConfirmation: {
        customerConfirmedAt: customerConfirmedAt || null,
        providerConfirmedAt: providerConfirmedAt || null,
      },
      completedAt: bothConfirmed ? confirmationTime : localBookingSnapshot.completedAt || null,
      status: bothConfirmed ? 'completed' : localBookingSnapshot.status || 'confirmed',
    };
    const nextCounterpartBooking = {
      ...counterpartBookingSnapshot,
      completionConfirmation: {
        customerConfirmedAt: customerConfirmedAt || null,
        providerConfirmedAt: providerConfirmedAt || null,
      },
      completedAt: bothConfirmed ? confirmationTime : counterpartBookingSnapshot.completedAt || null,
      status: bothConfirmed ? 'completed' : counterpartBookingSnapshot.status || 'confirmed',
    };

    if (isCustomerConfirming) {
      req.user.serviceProfile.bookings[customerBookingIndex] = nextLocalBooking;
      counterpartUser.serviceProfile.incomingBookings[counterpartBookingIndex] = nextCounterpartBooking;
    } else {
      req.user.serviceProfile.incomingBookings[providerBookingIndex] = nextLocalBooking;
      counterpartUser.serviceProfile.bookings[counterpartBookingIndex] = nextCounterpartBooking;
    }

    if (bothConfirmed) {
      appendActivity(req.user, {
        description: `Completed rental booking ${bookingRef}`,
        status: 'completed',
      });
      appendActivity(counterpartUser, {
        description: `Completed rental booking ${bookingRef}`,
        status: 'completed',
      });
    } else {
      appendActivity(req.user, {
        description: `Confirmed completion for rental booking ${bookingRef}`,
        status: 'confirmed',
      });
    }

    if (relatedPayment) {
      relatedPayment.bookingRef = relatedPayment.bookingRef || bookingRef;
      if (bothConfirmed) {
        const providerUser = isCustomerConfirming ? counterpartUser : req.user;

        if (relatedPayment.releaseStatus !== 'released') {
          const releaseAmount = Number(relatedPayment.subtotal || 0);

          creditWallet(providerUser, releaseAmount, {
            id: buildWalletTransactionId('WALLET'),
            method: 'rental_payment',
            reference: relatedPayment.reference || bookingRef,
            description: `Rental earnings from booking ${bookingRef}`,
            destinationLabel: '',
            status: 'completed',
            createdAt: confirmationTime,
          });

          appendActivity(providerUser, {
            description: `Wallet credited for rental booking ${bookingRef}`,
            status: 'completed',
          });
        }

        relatedPayment.status = 'released';
        relatedPayment.releaseStatus = 'released';
        relatedPayment.releasedAt = relatedPayment.releasedAt || confirmationTime;
        relatedPayment.releaseFailureReason = '';
      } else if (relatedPayment.releaseStatus !== 'released') {
        relatedPayment.status = 'ready_for_release';
        relatedPayment.releaseStatus = 'ready';
        relatedPayment.releaseFailureReason = '';
      }
      relatedPayment.paidAt = relatedPayment.paidAt || confirmationTime;
      await relatedPayment.save();
    }

    await Promise.all([req.user.save(), counterpartUser.save()]);

    return res.json({
      message: bothConfirmed
        ? 'Both sides confirmed the rental booking. The payout has been released to the owner wallet.'
        : isCustomerConfirming
          ? 'Your completion confirmation has been recorded. Waiting for the owner to confirm.'
          : 'Your completion confirmation has been recorded. Waiting for the customer to confirm.',
      booking: isCustomerConfirming
        ? req.user.serviceProfile.bookings[customerBookingIndex]
        : req.user.serviceProfile.incomingBookings[providerBookingIndex],
      completed: bothConfirmed,
    });
  } catch (error) {
    next(error);
  }
}

export async function markServiceBookingPickedUp(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    const bookingRef = String(req.params?.bookingRef || req.body?.bookingRef || '').trim();

    if (!bookingRef) {
      return res.status(400).json({
        message: 'A booking reference is required.',
      });
    }

    if (!req.user.serviceProfile) {
      req.user.serviceProfile = {
        category: 'Equipment Rentals',
        services: [],
        bookings: [],
        incomingBookings: [],
      };
    }

    const customerBookings = Array.isArray(req.user?.serviceProfile?.bookings)
      ? req.user.serviceProfile.bookings
      : [];
    const providerBookings = Array.isArray(req.user?.serviceProfile?.incomingBookings)
      ? req.user.serviceProfile.incomingBookings
      : [];

    const customerBookingIndex = customerBookings.findIndex(
      (booking) => String(booking?.bookingRef || '').trim() === bookingRef,
    );
    const providerBookingIndex = providerBookings.findIndex(
      (booking) => String(booking?.bookingRef || '').trim() === bookingRef,
    );

    const isCustomerConfirming = customerBookingIndex >= 0;
    const isProviderConfirming = providerBookingIndex >= 0;

    if (!isCustomerConfirming && !isProviderConfirming) {
      return res.status(404).json({
        message: 'That rental booking could not be found on this account.',
      });
    }

    const sourceBooking = isCustomerConfirming
      ? customerBookings[customerBookingIndex]
      : providerBookings[providerBookingIndex];

    if (!hasServiceBookingReachedStart(sourceBooking)) {
      return res.status(409).json({
        message: 'Rental pickup can only be confirmed once the scheduled date and time has started.',
      });
    }

    const normalizedStatus = String(sourceBooking?.status || '').trim().toLowerCase();

    if (normalizedStatus === 'cancelled') {
      return res.status(409).json({
        message: 'Cancelled rental bookings cannot be marked as picked up.',
      });
    }

    if (normalizedStatus === 'completed') {
      return res.status(409).json({
        message: 'Completed rental bookings do not need pickup confirmation.',
      });
    }

    const relatedPayment = await findRelatedServicePaymentForBooking(sourceBooking);
    const counterpartUserId = isCustomerConfirming
      ? String(sourceBooking?.providerUserId || relatedPayment?.providerUserId || '').trim()
      : String(sourceBooking?.customerUserId || relatedPayment?.buyerUserId || '').trim();
    const counterpartUser = counterpartUserId ? await User.findById(counterpartUserId) : null;

    if (!counterpartUser) {
      return res.status(404).json({
        message: 'The other party for this rental booking could not be found.',
      });
    }

    if (!counterpartUser.serviceProfile) {
      counterpartUser.serviceProfile = {
        category: 'Equipment Rentals',
        services: [],
        bookings: [],
        incomingBookings: [],
      };
    }

    if (!Array.isArray(counterpartUser.serviceProfile.bookings)) {
      counterpartUser.serviceProfile.bookings = [];
    }

    if (!Array.isArray(counterpartUser.serviceProfile.incomingBookings)) {
      counterpartUser.serviceProfile.incomingBookings = [];
    }

    const counterpartBookings = isCustomerConfirming
      ? counterpartUser.serviceProfile.incomingBookings
      : counterpartUser.serviceProfile.bookings;
    const counterpartBookingIndex = counterpartBookings.findIndex(
      (booking) => String(booking?.bookingRef || '').trim() === bookingRef,
    );

    if (counterpartBookingIndex < 0) {
      return res.status(404).json({
        message: 'The matching rental booking record could not be found for the other party.',
      });
    }

    const counterpartBooking = counterpartBookings[counterpartBookingIndex];
    const confirmationTime = new Date();
    const localBookingSnapshot = sourceBooking.toObject?.() || sourceBooking;
    const counterpartBookingSnapshot = counterpartBooking.toObject?.() || counterpartBooking;

    const nextLocalPickupConfirmation = {
      ...(localBookingSnapshot.pickupConfirmation || {}),
      ...(isCustomerConfirming
        ? { customerConfirmedAt: confirmationTime }
        : { providerConfirmedAt: confirmationTime }),
    };
    const nextCounterpartPickupConfirmation = {
      ...(counterpartBookingSnapshot.pickupConfirmation || {}),
      ...(isCustomerConfirming
        ? { customerConfirmedAt: confirmationTime }
        : { providerConfirmedAt: confirmationTime }),
    };

    const nextLocalBooking = {
      ...localBookingSnapshot,
      pickupConfirmation: {
        customerConfirmedAt:
          nextLocalPickupConfirmation.customerConfirmedAt || nextCounterpartPickupConfirmation.customerConfirmedAt || null,
        providerConfirmedAt:
          nextLocalPickupConfirmation.providerConfirmedAt || nextCounterpartPickupConfirmation.providerConfirmedAt || null,
      },
    };
    const nextCounterpartBooking = {
      ...counterpartBookingSnapshot,
      pickupConfirmation: {
        customerConfirmedAt:
          nextLocalPickupConfirmation.customerConfirmedAt || nextCounterpartPickupConfirmation.customerConfirmedAt || null,
        providerConfirmedAt:
          nextLocalPickupConfirmation.providerConfirmedAt || nextCounterpartPickupConfirmation.providerConfirmedAt || null,
      },
    };

    if (isCustomerConfirming) {
      req.user.serviceProfile.bookings[customerBookingIndex] = nextLocalBooking;
      counterpartUser.serviceProfile.incomingBookings[counterpartBookingIndex] = nextCounterpartBooking;
    } else {
      req.user.serviceProfile.incomingBookings[providerBookingIndex] = nextLocalBooking;
      counterpartUser.serviceProfile.bookings[counterpartBookingIndex] = nextCounterpartBooking;
    }

    appendActivity(req.user, {
      description: `Confirmed pickup for rental booking ${bookingRef}`,
      status: 'confirmed',
    });

    await Promise.all([req.user.save(), counterpartUser.save()]);

    return res.json({
      message: isCustomerConfirming
        ? 'Your pickup confirmation has been recorded. You can mark this rental as completed when it is finished.'
        : 'Your pickup confirmation has been recorded. You can mark this rental as completed when it is finished.',
      booking: isCustomerConfirming
        ? req.user.serviceProfile.bookings[customerBookingIndex]
        : req.user.serviceProfile.incomingBookings[providerBookingIndex],
      pickedUp: true,
    });
  } catch (error) {
    next(error);
  }
}

export async function cancelServiceBooking(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    const bookingRef = String(req.params?.bookingRef || req.body?.bookingRef || '').trim();
    const cancellationReasonInput = String(req.body?.reason || '').trim();

    if (!bookingRef) {
      return res.status(400).json({
        message: 'A booking reference is required.',
      });
    }

    if (!cancellationReasonInput) {
      return res.status(400).json({
        message: 'A cancellation reason is required.',
      });
    }

    if (!req.user.serviceProfile) {
      req.user.serviceProfile = {
        category: 'Equipment Rentals',
        services: [],
        bookings: [],
        incomingBookings: [],
      };
    }

    const customerBookings = Array.isArray(req.user?.serviceProfile?.bookings)
      ? req.user.serviceProfile.bookings
      : [];
    const providerBookings = Array.isArray(req.user?.serviceProfile?.incomingBookings)
      ? req.user.serviceProfile.incomingBookings
      : [];

    const customerBookingIndex = customerBookings.findIndex(
      (booking) => String(booking?.bookingRef || '').trim() === bookingRef,
    );
    const providerBookingIndex = providerBookings.findIndex(
      (booking) => String(booking?.bookingRef || '').trim() === bookingRef,
    );

    const isCustomerCancelling = customerBookingIndex >= 0;
    const isProviderCancelling = providerBookingIndex >= 0;

    if (!isCustomerCancelling && !isProviderCancelling) {
      return res.status(404).json({
        message: 'That rental booking could not be found on this account.',
      });
    }

    const sourceBooking = isCustomerCancelling
      ? customerBookings[customerBookingIndex]
      : providerBookings[providerBookingIndex];
    const normalizedStatus = String(sourceBooking?.status || '').trim().toLowerCase();

    if (normalizedStatus === 'completed') {
      return res.status(409).json({
        message: 'Completed rental bookings can no longer be cancelled.',
      });
    }

    if (normalizedStatus === 'cancelled') {
      return res.status(409).json({
        message: 'This rental booking has already been cancelled.',
      });
    }

    const pickupConfirmation = sourceBooking?.pickupConfirmation || {};

    if (pickupConfirmation.customerConfirmedAt || pickupConfirmation.providerConfirmedAt) {
      return res.status(409).json({
        message: 'Rental bookings can only be cancelled before pickup is confirmed.',
      });
    }

    const relatedPayment = await findRelatedServicePaymentForBooking(sourceBooking);
    const cancelledAt = new Date();
    const cancelledBy = isCustomerCancelling ? 'customer' : 'owner';
    const cancellationReason = cancellationReasonInput;
    const nextLocalBooking = {
      ...(sourceBooking.toObject?.() || sourceBooking),
      status: 'cancelled',
      cancelledAt,
      cancellationReason,
      cancelledBy,
    };

    const finalizeRentalCancellation = async (options = {}) => {
      const {
        counterpartUser = null,
        counterpartBooking = null,
        counterpartBookingIndex = -1,
      } = options || {};

      if (isCustomerCancelling) {
        req.user.serviceProfile.bookings[customerBookingIndex] = nextLocalBooking;
      } else {
        req.user.serviceProfile.incomingBookings[providerBookingIndex] = nextLocalBooking;
      }

      if (counterpartUser && counterpartBookingIndex >= 0 && counterpartBooking) {
        const nextCounterpartBooking = {
          ...(counterpartBooking.toObject?.() || counterpartBooking),
          status: 'cancelled',
          cancelledAt,
          cancellationReason,
          cancelledBy,
        };

        if (isCustomerCancelling) {
          counterpartUser.serviceProfile.incomingBookings[counterpartBookingIndex] = nextCounterpartBooking;
        } else {
          counterpartUser.serviceProfile.bookings[counterpartBookingIndex] = nextCounterpartBooking;
        }

        appendActivity(counterpartUser, {
          description: `Rental booking ${bookingRef} was cancelled by the ${cancelledBy}: ${cancellationReason}`,
          status: 'cancelled',
        });
      }

      const providerUserId = String(sourceBooking?.providerUserId || relatedPayment?.providerUserId || '').trim();
      const providerUser =
        providerUserId && String(req.user._id || '') === providerUserId
          ? req.user
          : providerUserId && counterpartUser && String(counterpartUser._id || '') === providerUserId
            ? counterpartUser
            : null;

      const listingId = String(sourceBooking?.listingId || relatedPayment?.listingId || '').trim();

      if (providerUser && listingId && Array.isArray(providerUser?.serviceProfile?.services)) {
        const listingIndex = providerUser.serviceProfile.services.findIndex(
          (listing) => String(listing?.listingId || '').trim() === listingId,
        );

        if (listingIndex >= 0) {
          const listingSnapshot = providerUser.serviceProfile.services[listingIndex].toObject?.()
            ? providerUser.serviceProfile.services[listingIndex].toObject()
            : providerUser.serviceProfile.services[listingIndex];
          const nextQuantity = Number(listingSnapshot?.quantity || 0) + 1;

          providerUser.serviceProfile.services[listingIndex] = {
            ...listingSnapshot,
            quantity: nextQuantity,
            available: true,
            status: 'active',
          };
        }
      }

      appendActivity(req.user, {
        description: `Cancelled rental booking ${bookingRef}: ${cancellationReason}`,
        status: 'cancelled',
      });

      let refunded = false;

      if (
        relatedPayment &&
        relatedPayment.refundStatus !== 'refunded' &&
        relatedPayment.releaseStatus !== 'released'
      ) {
        const refundAmount = Number(relatedPayment.total || 0);

        if (refundAmount > 0) {
          const buyerUserId = String(sourceBooking?.customerUserId || relatedPayment.buyerUserId || '').trim();
          const refundRecipient =
            buyerUserId && String(req.user._id || '') === buyerUserId
              ? req.user
              : buyerUserId && counterpartUser && String(counterpartUser._id || '') === buyerUserId
                ? counterpartUser
                : null;

          if (refundRecipient) {
            creditWallet(refundRecipient, refundAmount, {
              id: buildWalletTransactionId('REFUND'),
              method: 'rental_refund',
              reference: relatedPayment.reference || bookingRef,
              description: `Refund for cancelled rental booking ${bookingRef}`,
              destinationLabel: '',
              status: 'completed',
              createdAt: cancelledAt,
            });

            appendActivity(refundRecipient, {
              description: `Wallet refunded for cancelled rental booking ${bookingRef}`,
              status: 'completed',
            });
            refunded = true;
          }
        }

        relatedPayment.status = 'refunded';
        relatedPayment.refundStatus = 'refunded';
        relatedPayment.refundedAt = relatedPayment.refundedAt || cancelledAt;
        relatedPayment.releaseStatus = relatedPayment.releaseStatus === 'released' ? 'released' : 'failed';
        relatedPayment.releaseFailureReason = `Cancelled by the ${cancelledBy}: ${cancellationReason}`;
        await relatedPayment.save();
      }

      const saveTargets = [req.user.save()];

      if (counterpartUser) {
        saveTargets.push(counterpartUser.save());
      }

      await Promise.all(saveTargets);

      return res.json({
        message: refunded
          ? 'Rental booking cancelled successfully. The paid amount was returned to the customer wallet.'
          : 'Rental booking cancelled successfully.',
        booking: nextLocalBooking,
        refunded,
      });
    };

    const counterpartUserId = isCustomerCancelling
      ? String(sourceBooking?.providerUserId || relatedPayment?.providerUserId || '').trim()
      : String(sourceBooking?.customerUserId || relatedPayment?.buyerUserId || '').trim();
    const counterpartUser = counterpartUserId ? await User.findById(counterpartUserId) : null;

    if (!counterpartUser) {
      return finalizeRentalCancellation();
    }

    if (!counterpartUser.serviceProfile) {
      counterpartUser.serviceProfile = {
        category: 'Equipment Rentals',
        services: [],
        bookings: [],
        incomingBookings: [],
      };
    }

    if (!Array.isArray(counterpartUser.serviceProfile.bookings)) {
      counterpartUser.serviceProfile.bookings = [];
    }

    if (!Array.isArray(counterpartUser.serviceProfile.incomingBookings)) {
      counterpartUser.serviceProfile.incomingBookings = [];
    }

    const counterpartBookings = isCustomerCancelling
      ? counterpartUser.serviceProfile.incomingBookings
      : counterpartUser.serviceProfile.bookings;
    const counterpartBookingIndex = counterpartBookings.findIndex(
      (booking) => String(booking?.bookingRef || '').trim() === bookingRef,
    );

    if (counterpartBookingIndex < 0) {
      return finalizeRentalCancellation({
        counterpartUser,
      });
    }
    return finalizeRentalCancellation({
      counterpartUser,
      counterpartBooking: counterpartBookings[counterpartBookingIndex],
      counterpartBookingIndex,
    });
  } catch (error) {
    next(error);
  }
}

export async function submitLaborBookingReview(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    const bookingId = String(req.params?.bookingId || req.body?.bookingId || '').trim();
    const rating = Number(req.body?.rating || 0);
    const comment = String(req.body?.comment || '').trim();

    if (!bookingId) {
      return res.status(400).json({
        message: 'A booking reference is required.',
      });
    }

    if (!Number.isFinite(rating) || rating < 1 || rating > 5) {
      return res.status(400).json({
        message: 'Choose a rating from 1 to 5 stars.',
      });
    }

    const bookingHistory = Array.isArray(req.user?.laborBookings?.bookingHistory)
      ? req.user.laborBookings.bookingHistory
      : [];
    const bookingIndex = bookingHistory.findIndex(
      (booking) => String(booking?.bookingId || '').trim() === bookingId,
    );

    if (bookingIndex < 0) {
      return res.status(404).json({
        message: 'That completed labor booking could not be found on this client account.',
      });
    }

    const bookingRecord = bookingHistory[bookingIndex];

    if (String(bookingRecord?.status || '').trim().toLowerCase() !== 'completed') {
      return res.status(409).json({
        message: 'Only completed labor bookings can be reviewed.',
      });
    }

    if (Number(bookingRecord?.rating || 0) > 0) {
      return res.status(409).json({
        message: 'This labor booking has already been reviewed.',
      });
    }

    const workerUserId = String(bookingRecord?.workerId || '').trim();
    const worker = workerUserId ? await User.findById(workerUserId) : null;

    if (!worker || !hasRole(worker, 'laborer')) {
      return res.status(404).json({
        message: 'The laborer for this booking could not be found.',
      });
    }

    const review = {
      id: buildLaborReviewId(),
      author: String(req.user.name || '').trim() || 'Client',
      authorUserId: req.user._id.toString(),
      bookingId,
      rating,
      comment,
      createdAt: new Date(),
    };

    const workerListings = Array.isArray(worker?.laborProfile?.listings) ? worker.laborProfile.listings : [];
    const workerListingIndex = workerListings.findIndex(
      (listing) => String(listing?.workerType || '').trim() === String(bookingRecord?.type || '').trim(),
    );

    if (workerListingIndex >= 0) {
      const nextListing = {
        ...(workerListings[workerListingIndex].toObject?.() || workerListings[workerListingIndex]),
      };
      nextListing.reviews = [...(Array.isArray(nextListing.reviews) ? nextListing.reviews : []), review];
      const ratingSummary = buildLaborListingRatingSummary(nextListing);
      nextListing.rating = ratingSummary.rating;
      nextListing.reviewCount = ratingSummary.reviewCount;
      worker.laborProfile.listings[workerListingIndex] = nextListing;
    }

    refreshLaborProfileRating(worker);

    const nextClientBooking = {
      ...(bookingRecord.toObject?.() || bookingRecord),
      rating,
      reviewComment: comment,
      reviewedAt: review.createdAt,
    };
    req.user.laborBookings.bookingHistory[bookingIndex] = nextClientBooking;

    const workerHistory = Array.isArray(worker?.laborProfile?.bookingHistory) ? worker.laborProfile.bookingHistory : [];
    const workerHistoryIndex = workerHistory.findIndex(
      (booking) => String(booking?.bookingId || '').trim() === bookingId,
    );

    if (workerHistoryIndex >= 0) {
      worker.laborProfile.bookingHistory[workerHistoryIndex] = {
        ...(workerHistory[workerHistoryIndex].toObject?.() || workerHistory[workerHistoryIndex]),
        rating,
        reviewComment: comment,
        reviewedAt: review.createdAt,
      };
    }

    appendActivity(req.user, {
      description: `Rated labor booking ${bookingId} with ${rating} stars`,
      status: 'completed',
    });
    appendActivity(worker, {
      description: `Received a ${rating}-star labor review for booking ${bookingId}`,
      status: 'completed',
    });

    await Promise.all([req.user.save(), worker.save()]);

    return res.json({
      message: 'Labor review submitted successfully.',
      booking: nextClientBooking,
      laborRating: Number(worker?.laborProfile?.rating || 0),
    });
  } catch (error) {
    next(error);
  }
}

export async function cancelLaborBooking(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({
        message: 'Authentication required.',
      });
    }

    const bookingId = String(req.params?.bookingId || req.body?.bookingId || '').trim();
    const cancellationReason = String(req.body?.reason || '').trim();

    if (!bookingId) {
      return res.status(400).json({
        message: 'A booking reference is required.',
      });
    }

    if (!cancellationReason) {
      return res.status(400).json({
        message: 'A cancellation reason is required.',
      });
    }

    const buyerActiveBookings = Array.isArray(req.user?.laborBookings?.activeBookings)
      ? req.user.laborBookings.activeBookings
      : [];
    const workerActiveBookings = Array.isArray(req.user?.laborProfile?.activeBookings)
      ? req.user.laborProfile.activeBookings
      : [];

    const buyerBookingIndex = buyerActiveBookings.findIndex(
      (booking) => String(booking?.bookingId || '').trim() === bookingId,
    );
    const workerBookingIndex = workerActiveBookings.findIndex(
      (booking) => String(booking?.bookingId || '').trim() === bookingId,
    );

    const isBuyerCancelling = buyerBookingIndex >= 0;
    const isWorkerCancelling = workerBookingIndex >= 0;

    if (!isBuyerCancelling && !isWorkerCancelling) {
      return res.status(404).json({
        message: 'That active labor booking could not be found on this account.',
      });
    }

    const sourceBooking = isBuyerCancelling
      ? buyerActiveBookings[buyerBookingIndex]
      : workerActiveBookings[workerBookingIndex];
    const cancelledBy = buildCancellationActorLabel(isBuyerCancelling);

    if (isBuyerCancelling && String(sourceBooking?.date || '').trim() === getCurrentManilaDateString()) {
      return res.status(409).json({
        message:
          'This labor booking can no longer be cancelled on the booking date. The booked time remains payable whether the client is present or not.',
      });
    }

    const cancelledAt = new Date();
    const nextCancelledBooking = {
      ...(sourceBooking.toObject?.() || sourceBooking),
      status: 'cancelled',
      cancelledAt,
      cancellationReason,
      cancelledBy,
      travelTracking: createTravelTrackingSnapshot(sourceBooking?.travelTracking),
    };

    if (!req.user.laborBookings) {
      req.user.laborBookings = {
        activeBookings: [],
        bookingHistory: [],
      };
    }

    if (!req.user.laborProfile) {
      req.user.laborProfile = {
        activeBookings: [],
        bookingHistory: [],
      };
    }

    const finalizeLocalCancellation = async (message) => {
      if (isBuyerCancelling) {
        req.user.laborBookings.activeBookings = buyerActiveBookings.filter((_, index) => index !== buyerBookingIndex);
        req.user.laborBookings.bookingHistory = [
          ...(Array.isArray(req.user.laborBookings.bookingHistory) ? req.user.laborBookings.bookingHistory : []),
          nextCancelledBooking,
        ];
      } else {
        req.user.laborProfile.activeBookings = workerActiveBookings.filter((_, index) => index !== workerBookingIndex);
        req.user.laborProfile.bookingHistory = [
          ...(Array.isArray(req.user.laborProfile.bookingHistory) ? req.user.laborProfile.bookingHistory : []),
          nextCancelledBooking,
        ];
      }

      appendActivity(req.user, {
        description: `Cancelled labor booking ${bookingId}: ${cancellationReason}`,
        status: 'cancelled',
      });

      await req.user.save();

      return res.json({
        message,
        booking: nextCancelledBooking,
      });
    };

    const counterpartUserId = isBuyerCancelling
      ? String(sourceBooking?.workerId || '').trim()
      : String(sourceBooking?.bookedByUserId || '').trim();

    const counterpartUser = counterpartUserId ? await User.findById(counterpartUserId) : null;

    if (!counterpartUser) {
      return finalizeLocalCancellation(
        isBuyerCancelling
          ? 'Labor booking removed from your account. The worker record was no longer available.'
          : 'Labor booking removed from your account. The client record was no longer available.',
      );
    }

    const counterpartActiveBookings = isBuyerCancelling
      ? Array.isArray(counterpartUser?.laborProfile?.activeBookings)
        ? counterpartUser.laborProfile.activeBookings
        : []
      : Array.isArray(counterpartUser?.laborBookings?.activeBookings)
        ? counterpartUser.laborBookings.activeBookings
        : [];

    const counterpartBookingIndex = counterpartActiveBookings.findIndex(
      (booking) => String(booking?.bookingId || '').trim() === bookingId,
    );

    if (counterpartBookingIndex < 0) {
      return finalizeLocalCancellation(
        'Labor booking removed from your account. The mirrored booking record was no longer available.',
      );
    }

    const nextCounterpartCancelledBooking = {
      ...(counterpartActiveBookings[counterpartBookingIndex].toObject?.() || counterpartActiveBookings[counterpartBookingIndex]),
      status: 'cancelled',
      cancelledAt,
      cancellationReason,
      cancelledBy,
      travelTracking: createTravelTrackingSnapshot(counterpartActiveBookings[counterpartBookingIndex]?.travelTracking),
    };

    if (isBuyerCancelling) {
      req.user.laborBookings.activeBookings = buyerActiveBookings.filter((_, index) => index !== buyerBookingIndex);
      req.user.laborBookings.bookingHistory = [
        ...(Array.isArray(req.user.laborBookings.bookingHistory) ? req.user.laborBookings.bookingHistory : []),
        nextCancelledBooking,
      ];

      counterpartUser.laborProfile.activeBookings = counterpartActiveBookings.filter(
        (_, index) => index !== counterpartBookingIndex,
      );
      counterpartUser.laborProfile.bookingHistory = [
        ...(Array.isArray(counterpartUser?.laborProfile?.bookingHistory) ? counterpartUser.laborProfile.bookingHistory : []),
        nextCounterpartCancelledBooking,
      ];
    } else {
      req.user.laborProfile.activeBookings = workerActiveBookings.filter((_, index) => index !== workerBookingIndex);
      req.user.laborProfile.bookingHistory = [
        ...(Array.isArray(req.user.laborProfile.bookingHistory) ? req.user.laborProfile.bookingHistory : []),
        nextCancelledBooking,
      ];

      counterpartUser.laborBookings.activeBookings = counterpartActiveBookings.filter(
        (_, index) => index !== counterpartBookingIndex,
      );
      counterpartUser.laborBookings.bookingHistory = [
        ...(Array.isArray(counterpartUser?.laborBookings?.bookingHistory) ? counterpartUser.laborBookings.bookingHistory : []),
        nextCounterpartCancelledBooking,
      ];
    }

    appendActivity(req.user, {
      description: `Cancelled labor booking ${bookingId}: ${cancellationReason}`,
      status: 'cancelled',
    });

    appendActivity(counterpartUser, {
      description: `Labor booking ${bookingId} was cancelled by the ${cancelledBy}: ${cancellationReason}`,
      status: 'cancelled',
    });

    const laborPayment = await findRelatedLaborPaymentForBooking(sourceBooking);

    if (
      laborPayment &&
      laborPayment.refundStatus !== 'refunded' &&
      laborPayment.releaseStatus !== 'released'
    ) {
      const refundAmount = Number(laborPayment.total || 0);

      if (refundAmount > 0) {
        const buyerUserId = String(sourceBooking?.bookedByUserId || laborPayment.buyerUserId || '').trim();
        const refundRecipient =
          buyerUserId && String(req.user._id || '') === buyerUserId
            ? req.user
            : buyerUserId && String(counterpartUser._id || '') === buyerUserId
              ? counterpartUser
              : null;

        if (refundRecipient) {
          creditWallet(refundRecipient, refundAmount, {
            id: buildWalletTransactionId('REFUND'),
            method: 'labor_refund',
            reference: laborPayment.reference || bookingId,
            description: `Refund for cancelled labor booking ${bookingId}`,
            destinationLabel: '',
            status: 'completed',
            createdAt: cancelledAt,
          });

          appendActivity(refundRecipient, {
            description: `Wallet refunded for cancelled labor booking ${bookingId}`,
            status: 'completed',
          });
        }
      }

      laborPayment.status = 'refunded';
      laborPayment.refundStatus = 'refunded';
      laborPayment.refundedAt = laborPayment.refundedAt || cancelledAt;
      laborPayment.releaseStatus = laborPayment.releaseStatus === 'released' ? 'released' : 'failed';
      laborPayment.releaseFailureReason = `Cancelled by the ${cancelledBy}: ${cancellationReason}`;
      await laborPayment.save();
    }

    await Promise.all([req.user.save(), counterpartUser.save()]);

    res.json({
      message:
        laborPayment?.refundStatus === 'refunded'
          ? 'Labor booking cancelled successfully. The paid amount was returned to the client wallet.'
          : 'Labor booking cancelled successfully.',
      booking: isBuyerCancelling ? nextCancelledBooking : nextCounterpartCancelledBooking,
    });
  } catch (error) {
    next(error);
  }
}

export async function getServicesData(req, res, next) {
  try {
    const providers = await User.find({
      $or: [roleQuery('seller'), roleQuery('laborer')],
    }).select('name phone roles serviceProfile profile penalty');
    const visibleProviders = providers.filter((provider) => canManageCommercialFeatures(provider));
    const rentals = [];

    for (const provider of visibleProviders) {
      const ownerRole = hasRole(provider, 'seller') ? 'seller' : 'laborer';
      const listings = Array.isArray(provider?.serviceProfile?.services)
        ? provider.serviceProfile.services
        : [];

      for (const listing of listings) {
        const normalized = normalizeRentalListingPayload(listing?.toObject?.() || listing);

        if (!normalized.listingId || normalized.status === 'archived') {
          continue;
        }

        rentals.push(
          await buildRentalListingResponse(normalized, {
            userId: provider._id.toString(),
            name: provider.name,
            phone: provider.phone,
            ownerRole,
            canEdit: req.user ? String(req.user._id || '') === provider._id.toString() : false,
          }),
        );
      }
    }

    const currentUserBookings = Array.isArray(req.user?.serviceProfile?.bookings)
      ? req.user.serviceProfile.bookings
      : [];
    const currentIncomingBookings = Array.isArray(req.user?.serviceProfile?.incomingBookings)
      ? req.user.serviceProfile.incomingBookings
      : [];
    const bookings = currentUserBookings.map((booking, index) => ({
      id: Number(`${index + 1}${index + 1}`),
      ...(booking.toObject?.() || booking),
    }));
    const canManageRentals = Boolean(
      req.user
        && (hasRole(req.user, 'seller') || hasRole(req.user, 'laborer'))
        && canManageCommercialFeatures(req.user),
    );
    const incomingBookingMap = new Map();

    currentIncomingBookings.forEach((booking, index) => {
      const plainBooking = booking.toObject?.() || booking;
      const bookingRef = String(plainBooking?.bookingRef || '').trim();

      if (!bookingRef) {
        return;
      }

      incomingBookingMap.set(bookingRef, {
        id: Number(`9${index + 1}${index + 1}`),
        ...plainBooking,
      });
    });

    if (canManageRentals && req.user?._id) {
      const servicePayments = await ServicePayment.find({
        providerUserId: req.user._id.toString(),
        status: {
          $in: ['booking_created', 'ready_for_release', 'released', 'refunded'],
        },
      })
        .sort({ createdAt: -1 })
        .lean();

      servicePayments.forEach((payment, index) => {
        const bookingRef = String(payment?.bookingRef || '').trim();

        if (!bookingRef) {
          return;
        }

        const paymentStatus = String(payment?.status || '').trim().toLowerCase();
        const derivedBookingStatus =
          paymentStatus === 'released'
            ? 'completed'
            : paymentStatus === 'refunded'
              ? 'cancelled'
              : 'confirmed';
        const existingBooking = incomingBookingMap.get(bookingRef) || {};
        const existingPickupConfirmation = existingBooking?.pickupConfirmation || {};
        const existingCompletionConfirmation = existingBooking?.completionConfirmation || {};
        const completedTimestamp = payment?.releasedAt || payment?.updatedAt || null;
        const cancelledTimestamp = payment?.refundedAt || payment?.updatedAt || null;

        incomingBookingMap.set(bookingRef, {
          ...existingBooking,
          id: existingBooking?.id || Number(`8${index + 1}${index + 1}`),
          service: String(existingBooking?.service || payment?.itemName || '').trim(),
          provider: String(existingBooking?.provider || payment?.providerName || '').trim(),
          providerUserId: String(existingBooking?.providerUserId || payment?.providerUserId || '').trim(),
          customer: String(existingBooking?.customer || payment?.buyerName || '').trim(),
          customerUserId: String(existingBooking?.customerUserId || payment?.buyerUserId || '').trim(),
          listingId: String(existingBooking?.listingId || payment?.listingId || '').trim(),
          date: String(existingBooking?.date || payment?.bookingDate || '').trim(),
          time: String(existingBooking?.time || payment?.bookingTime || '').trim(),
          duration: String(existingBooking?.duration || payment?.bookingDuration || '').trim(),
          location: String(existingBooking?.location || payment?.bookingLocation || '').trim(),
          status:
            derivedBookingStatus === 'completed' || derivedBookingStatus === 'cancelled'
              ? derivedBookingStatus
              : String(existingBooking?.status || derivedBookingStatus).trim(),
          description: String(existingBooking?.description || payment?.bookingNotes || '').trim(),
          rate: String(existingBooking?.rate || `${Number(payment?.rate || 0)}`).trim(),
          contact: String(existingBooking?.contact || payment?.buyerPhone || '').trim(),
          bookingRef,
          pickupConfirmation: {
            customerConfirmedAt: existingPickupConfirmation?.customerConfirmedAt || null,
            providerConfirmedAt: existingPickupConfirmation?.providerConfirmedAt || null,
          },
          completionConfirmation: {
            customerConfirmedAt:
              existingCompletionConfirmation?.customerConfirmedAt
              || (derivedBookingStatus === 'completed' ? completedTimestamp : null),
            providerConfirmedAt:
              existingCompletionConfirmation?.providerConfirmedAt
              || (derivedBookingStatus === 'completed' ? completedTimestamp : null),
          },
          completedAt: existingBooking?.completedAt || (derivedBookingStatus === 'completed' ? completedTimestamp : null),
          cancelledAt: existingBooking?.cancelledAt || (derivedBookingStatus === 'cancelled' ? cancelledTimestamp : null),
        });
      });
    }

    const incomingBookings = Array.from(incomingBookingMap.values());
    const myRentals = canManageRentals
      ? await Promise.all(
          (Array.isArray(req.user?.serviceProfile?.services) ? req.user.serviceProfile.services : []).map((listing) =>
            buildRentalListingResponse(listing.toObject?.() || listing, {
              userId: req.user._id.toString(),
              name: req.user.name,
              phone: req.user.phone,
              ownerRole: hasRole(req.user, 'seller') ? 'seller' : 'laborer',
              canEdit: true,
            }),
          ),
        )
      : [];

    res.json({
      rentals,
      myRentals,
      bookings,
      incomingBookings,
      canManageRentals,
      locationOptions: req.user ? [getRentalListingLocation(req.user)].filter(Boolean) : [],
    });
  } catch (error) {
    next(error);
  }
}
