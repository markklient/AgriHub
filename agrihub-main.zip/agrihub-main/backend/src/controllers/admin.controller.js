import { User } from '../models/User.js';
import {
  getWalletCashOutRealEnabled,
  setWalletCashOutRealEnabled,
} from '../models/PlatformSetting.js';
import { appendActivity } from '../utils/activityLog.js';
import {
  applyMarketplaceLogisticsAction,
  buildMarketplaceLogisticsView,
  ensureMarketplaceLogisticsSnapshot,
  getMarketplaceAddressSnapshot,
  getMarketplaceCoordinateSnapshot,
  getMarketplaceRouteHeadline,
  getShortDeliveryAddress,
} from '../utils/marketplaceLogistics.js';
import {
  canManageCommercialFeatures,
  ensurePrivilegedAccess,
  getPenaltyState,
  getUserRoles,
  getVerificationState,
  hasRole,
  isSuperAdmin,
  roleQuery,
} from '../utils/roles.js';
import { buildMarketplaceWaybillProfileAddress } from '../utils/marketplaceWaybill.js';
import {
  createMarketplaceRefundSignedUrls,
  createMarketplaceReviewSignedUrls,
  createVerificationDocumentSignedUrl,
} from '../utils/verificationStorage.js';

function ensureWalletState(user) {
  if (!user.wallet) {
    user.wallet = {
      balance: 0,
      totalEarned: 0,
      totalWithdrawn: 0,
      transactions: [],
    };
  }

  user.wallet.balance = Number(user.wallet.balance || 0);
  user.wallet.totalEarned = Number(user.wallet.totalEarned || 0);
  user.wallet.totalWithdrawn = Number(user.wallet.totalWithdrawn || 0);

  if (!Array.isArray(user.wallet.transactions)) {
    user.wallet.transactions = [];
  }

  return user.wallet;
}

function buildWalletTransactionId(prefix = 'WAL') {
  return `${prefix}-${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
}

function creditWallet(user, amount, transaction = {}) {
  const numericAmount = Number(amount || 0);

  if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
    return;
  }

  const wallet = ensureWalletState(user);
  wallet.balance += numericAmount;
  wallet.totalEarned += numericAmount;
  wallet.transactions = [
    {
      id: transaction.id || buildWalletTransactionId(),
      type: 'credit',
      amount: numericAmount,
      method: transaction.method || 'admin_refund',
      reference: transaction.reference || '',
      description: transaction.description || 'Wallet credit',
      destinationLabel: transaction.destinationLabel || '',
      status: transaction.status || 'completed',
      createdAt: transaction.createdAt || new Date(),
    },
    ...wallet.transactions,
  ];
}

function sanitizeAdminUser(user) {
  const roles = getUserRoles(user);
  const verification = getVerificationState(user);

  return {
    id: user._id.toString(),
    name: user.name,
    email: user.email,
    phone: user.phone || '',
    role: user.role,
    accountType: user.accountType,
    roles,
    isAdmin: hasRole(user, 'admin'),
    isSuperAdmin: isSuperAdmin(user),
    accountStatus: user.accountStatus || 'active',
    disabledAt: user.disabledAt || null,
    disabledReason: user.disabledReason || '',
    pendingDisableAt: user.pendingDisableAt || null,
    pendingDisableReason: user.pendingDisableReason || '',
    pendingDeleteAt: user.pendingDeleteAt || null,
    pendingDeleteReason: user.pendingDeleteReason || '',
    emailVerified: Boolean(user.emailVerified),
    verification,
    verificationMeta: {
      seller: {
        reviewReason: user.verification?.seller?.reviewReason || '',
        rejectedAt: user.verification?.seller?.rejectedAt || null,
      },
      laborer: {
        reviewReason: user.verification?.laborer?.reviewReason || '',
        rejectedAt: user.verification?.laborer?.rejectedAt || null,
      },
    },
    penalty: getPenaltyState(user),
    canManageCommercialFeatures: canManageCommercialFeatures(user),
    profile: {
      farmName: user.profile?.farmName || '',
      location: user.profile?.location || user.profile?.address || '',
      experience: user.profile?.experience || '',
      specialization: user.profile?.specialization || '',
    },
    counts: {
      listings: Array.isArray(user.marketplaceListings) ? user.marketplaceListings.length : 0,
      laborActiveBookings: Array.isArray(user.laborProfile?.activeBookings)
        ? user.laborProfile.activeBookings.length
        : 0,
      laborHistoryBookings: Array.isArray(user.laborProfile?.bookingHistory)
        ? user.laborProfile.bookingHistory.length
        : 0,
      services: Array.isArray(user.serviceProfile?.services) ? user.serviceProfile.services.length : 0,
      serviceBookings: Array.isArray(user.serviceProfile?.bookings)
        ? user.serviceProfile.bookings.length
        : 0,
    },
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };
}

function hasActiveLaborBookings(user) {
  return Array.isArray(user?.laborProfile?.activeBookings) && user.laborProfile.activeBookings.length > 0;
}

function hasPendingServiceBookings(user) {
  return Array.isArray(user?.serviceProfile?.bookings)
    && user.serviceProfile.bookings.some((booking) => {
      const status = String(booking?.status || '').trim().toLowerCase();
      return status && !['completed', 'cancelled'].includes(status);
    });
}

function hasActiveBuyerBookings(user) {
  return Array.isArray(user?.laborBookings?.activeBookings) && user.laborBookings.activeBookings.length > 0;
}

function hasActiveBookings(user) {
  return hasActiveLaborBookings(user) || hasPendingServiceBookings(user) || hasActiveBuyerBookings(user);
}

async function hasBlockingActiveBookingLinks(userId) {
  const normalizedUserId = String(userId || '').trim();

  if (!normalizedUserId) {
    return false;
  }

  const linkedUser = await User.exists({
    _id: { $ne: normalizedUserId },
    $or: [
      {
        'laborBookings.activeBookings': {
          $elemMatch: {
            workerId: normalizedUserId,
          },
        },
      },
      {
        'laborProfile.activeBookings': {
          $elemMatch: {
            bookedByUserId: normalizedUserId,
          },
        },
      },
    ],
  });

  return Boolean(linkedUser);
}

function clearPendingDisable(user) {
  user.pendingDisableAt = null;
  user.pendingDisableReason = '';
}

function clearPendingDelete(user) {
  user.pendingDeleteAt = null;
  user.pendingDeleteReason = '';
}

function applyDisableState(user, reason = '') {
  user.accountStatus = 'disabled';
  user.disabledAt = new Date();
  user.disabledReason = String(reason || '').trim();
  clearPendingDisable(user);
}

async function applyPendingDisableIfEligible(user) {
  if (!user?.pendingDisableAt || user.accountStatus === 'disabled' || hasActiveBookings(user)) {
    return false;
  }

  applyDisableState(user, user.pendingDisableReason || user.disabledReason || '');
  appendActivity(user, {
    description: `Queued account disable took effect after active bookings finished${user.disabledReason ? `: ${user.disabledReason}` : ''}`,
    status: 'confirmed',
  });
  await user.save();
  return true;
}

async function deleteUserRecord(user) {
  await removeDeletedUserReferences(user._id.toString());
  await User.deleteOne({ _id: user._id });
}

async function applyPendingDeleteIfEligible(user) {
  if (
    !user?.pendingDeleteAt
    || hasActiveBookings(user)
    || await hasBlockingActiveBookingLinks(user._id.toString())
  ) {
    return false;
  }

  await deleteUserRecord(user);
  return true;
}

async function removeDeletedUserReferences(userId) {
  const normalizedUserId = String(userId || '').trim();

  if (!normalizedUserId) {
    return;
  }

  await User.updateMany(
    {},
    {
      $pull: {
        'laborBookings.activeBookings': {
          $or: [{ workerId: normalizedUserId }, { bookedByUserId: normalizedUserId }],
        },
        'laborProfile.activeBookings': {
          $or: [{ workerId: normalizedUserId }, { bookedByUserId: normalizedUserId }],
        },
      },
    },
  );
}

function buildPenaltyPayload({
  status = 'good',
  reason = '',
  notes = '',
  penalizedBy = '',
  expiresAt = null,
} = {}) {
  return {
    status,
    reason: String(reason || '').trim(),
    notes: String(notes || '').trim(),
    penalizedBy: String(penalizedBy || '').trim(),
    penalizedAt: status === 'good' ? null : new Date(),
    expiresAt: expiresAt ? new Date(expiresAt) : null,
  };
}

function flattenMarketplaceListings(vendors) {
  return vendors.flatMap((vendor) =>
    (vendor.marketplaceListings || []).map((listing, listingIndex) => ({
      id: `${vendor._id.toString()}-${listingIndex}`,
      userId: vendor._id.toString(),
      listingIndex,
      seller: vendor.profile?.farmName || vendor.name,
      sellerEmail: vendor.email,
      verification: getVerificationState(vendor).seller,
      ...listing.toObject(),
    })),
  );
}

async function flattenMarketplaceOrders(vendors) {
  const groups = await Promise.all(
    vendors.map(async (vendor) =>
      Promise.all(
        (vendor.marketplaceOrders?.sales || []).map(async (order, orderIndex) => {
          const snapshot = order.toObject?.() || order;
          const buyerUserId = String(snapshot?.buyerUserId || '').trim();
          const buyerUser = buyerUserId
            ? await User.findById(buyerUserId).select('profile.address profile.streetAddress profile.city profile.state profile.postalCode profile.country profile.location profile.coordinates')
            : null;
          const sellerAddress = String(
            snapshot.sellerAddress
            || buildMarketplaceWaybillProfileAddress(vendor.profile || {})
            || vendor.profile?.location
            || ''
          ).trim();
          const buyerAddress = String(
            snapshot.buyerAddress
            || buildMarketplaceWaybillProfileAddress(buyerUser?.profile || {})
            || buyerUser?.profile?.location
            || ''
          ).trim();
          const sellerCoordinates = getMarketplaceCoordinateSnapshot(
            { profile: { coordinates: snapshot.sellerCoordinates || {} } },
            vendor.profile?.coordinates || {},
          );
          const buyerCoordinates = getMarketplaceCoordinateSnapshot(
            { profile: { coordinates: snapshot.buyerCoordinates || {} } },
            buyerUser?.profile?.coordinates || {},
          );
          const logistics = await buildMarketplaceLogisticsView(snapshot, {
            orderId: snapshot.orderId,
            status: snapshot.status,
            createdAt: snapshot.createdAt,
            sellerAddress,
            buyerAddress,
            sellerCoordinates,
            buyerCoordinates,
          });
          let refundImageUrls = Array.isArray(snapshot?.refundRequest?.imageUrls)
            ? snapshot.refundRequest.imageUrls.filter(Boolean)
            : [];

          if (refundImageUrls.length === 0) {
            try {
              const signedRefundImages = await createMarketplaceRefundSignedUrls(
                Array.isArray(snapshot?.refundRequest?.imagePaths) ? snapshot.refundRequest.imagePaths : [],
              );
              refundImageUrls = Array.isArray(signedRefundImages?.urls) ? signedRefundImages.urls.filter(Boolean) : [];
            } catch {
              refundImageUrls = [];
            }
          }

          return {
            id: `${vendor._id.toString()}-order-${orderIndex}`,
            sellerUserId: vendor._id.toString(),
            orderIndex,
            orderId: String(snapshot.orderId || '').trim(),
            paymentReference: String(snapshot.paymentReference || '').trim(),
            sellerName: String(snapshot.sellerName || vendor.profile?.farmName || vendor.name || '').trim(),
            buyerName: String(snapshot.buyerName || '').trim(),
            itemName: String(snapshot.itemName || '').trim(),
            quantity: Number(snapshot.quantity || 0),
            unit: String(snapshot.unit || '').trim(),
            status: String(snapshot.status || 'paid').trim(),
            totalPaid: Number(snapshot.totalPaid || 0),
            sellerAddress,
            buyerAddress,
            logistics,
            refundRequest: {
              ...(snapshot?.refundRequest || {}),
              imageUrls: refundImageUrls,
            },
            routeHeadline: getMarketplaceRouteHeadline(logistics),
            shortSellerAddress: getShortDeliveryAddress(sellerAddress),
            shortBuyerAddress: getShortDeliveryAddress(buyerAddress),
            createdAt: snapshot.createdAt || null,
          };
        }),
      ),
    ),
  );

  return groups.flat();
}

function flattenLaborBookings(laborers) {
  return laborers.flatMap((laborer) => [
    ...(laborer.laborProfile?.activeBookings || []).map((booking, bookingIndex) => ({
      id: `${laborer._id.toString()}-active-${bookingIndex}`,
      userId: laborer._id.toString(),
      bookingIndex,
      bookingType: 'active',
      workerName: laborer.name,
      workerEmail: laborer.email,
      ...booking.toObject(),
    })),
    ...(laborer.laborProfile?.bookingHistory || []).map((booking, bookingIndex) => ({
      id: `${laborer._id.toString()}-history-${bookingIndex}`,
      userId: laborer._id.toString(),
      bookingIndex,
      bookingType: 'history',
      workerName: laborer.name,
      workerEmail: laborer.email,
      ...booking.toObject(),
    })),
  ]);
}

function flattenServiceProviders(providers) {
  return providers.map((provider) => ({
    id: provider._id.toString(),
    name: provider.name,
    email: provider.email,
    category: provider.serviceProfile?.category || '',
    services: (provider.serviceProfile?.services || []).map((service, serviceIndex) => ({
      id: `${provider._id.toString()}-service-${serviceIndex}`,
      serviceIndex,
      ...service.toObject(),
    })),
    bookings: [
      ...((provider.serviceProfile?.bookings || []).map((booking, bookingIndex) => ({
        id: `${provider._id.toString()}-booking-${bookingIndex}`,
        bookingIndex,
        bookingSource: 'bookings',
        ...booking.toObject(),
      }))),
      ...((provider.serviceProfile?.incomingBookings || []).map((booking, bookingIndex) => ({
        id: `${provider._id.toString()}-incoming-${bookingIndex}`,
        bookingIndex,
        bookingSource: 'incomingBookings',
        ...booking.toObject(),
      }))),
    ],
  }));
}

function isTruthyQuery(value) {
  const normalized = String(value || '').trim().toLowerCase();
  return ['1', 'true', 'yes', 'on'].includes(normalized);
}

async function flattenVerifications(users, includeDocuments = false) {
  const verificationGroups = await Promise.all(
    users.map(async (user) => {
    const items = [];

    for (const role of ['seller', 'laborer']) {
      const entry = user.verification?.[role];

      if (!entry || (entry.status === 'unverified' && (!entry.documents || entry.documents.length === 0))) {
        continue;
      }

      items.push({
        id: `${user._id.toString()}-${role}`,
        userId: user._id.toString(),
        userName: user.name,
        userEmail: user.email,
        role,
        status: entry.status || 'unverified',
        submittedAt: entry.submittedAt || null,
        verifiedAt: entry.verifiedAt || null,
        rejectedAt: entry.rejectedAt || null,
        reviewReason: entry.reviewReason || '',
        details: entry.details || {},
        documents: includeDocuments
          ? await Promise.all(
              (entry.documents || []).map(async (document, index) => {
                let signedUrl = '';

                try {
                  const signedDocument = await createVerificationDocumentSignedUrl(
                    document.path,
                    document.bucket,
                  );
                  signedUrl = signedDocument.url;
                } catch {
                  signedUrl = '';
                }

                return {
                  id: `${user._id.toString()}-${role}-${index}`,
                  type: document.type,
                  originalName: document.originalName,
                  uploadedAt: document.uploadedAt,
                  bucket: document.bucket,
                  path: document.path,
                  signedUrl,
                };
              }),
            )
          : (entry.documents || []).map((document, index) => ({
              id: `${user._id.toString()}-${role}-${index}`,
              type: document.type,
              originalName: document.originalName,
              uploadedAt: document.uploadedAt,
              bucket: document.bucket,
              path: document.path,
              signedUrl: '',
            })),
      });
    }

    return items;
    }),
  );

  return verificationGroups.flat();
}

async function buildAdminOverview(includeMarketplaceOrders = false, includeVerificationDocuments = false) {
  const users = await User.find().sort({ createdAt: -1 });

  for (const user of users) {
    if (ensurePrivilegedAccess(user)) {
      await user.save();
    }
  }

  const vendors = users.filter((user) => hasRole(user, 'seller'));
  const laborers = users.filter((user) => hasRole(user, 'laborer'));
  const serviceProviders = users.filter((user) => (
    hasRole(user, 'service')
    || hasRole(user, 'seller')
    || hasRole(user, 'laborer')
  ));
  const walletCashOutRealEnabled = await getWalletCashOutRealEnabled();
  const marketplaceListings = flattenMarketplaceListings(vendors);
  const laborBookings = flattenLaborBookings(laborers);
  const serviceProviderGroups = flattenServiceProviders(serviceProviders);
  const marketplaceOrders = includeMarketplaceOrders
    ? await flattenMarketplaceOrders(vendors).catch((error) => {
        console.error('Admin overview marketplace order aggregation failed:', error);
        return [];
      })
    : [];
  const verifications = await flattenVerifications(users, includeVerificationDocuments).catch((error) => {
    console.error('Admin overview verification aggregation failed:', error);
    return [];
  });

  return {
    metrics: {
      totalUsers: users.length,
      totalAdmins: users.filter((user) => hasRole(user, 'admin')).length,
      totalSellers: vendors.length,
      totalLaborers: laborers.length,
      totalServiceProviders: serviceProviders.length,
      totalMarketplaceItems: marketplaceListings.length,
      totalLaborBookings: laborBookings.length,
      totalServiceBookings: serviceProviderGroups.reduce(
        (sum, provider) => sum + provider.bookings.length,
        0,
      ),
      pendingVerifications: verifications.filter((item) => item.status === 'pending').length,
    },
    platformSettings: {
      walletCashOutRealEnabled,
    },
    users: users.map(sanitizeAdminUser),
    marketplaceListings,
    marketplaceOrders,
    laborBookings,
    serviceProviders: serviceProviderGroups,
    verifications,
  };
}

export async function updateWalletCashOutMode(req, res, next) {
  try {
    const enabled = Boolean(req.body?.enabled);
    const updatedValue = await setWalletCashOutRealEnabled(
      enabled,
      req.user?.email || req.user?.name || 'Super Admin',
    );

    return res.json({
      message: updatedValue
        ? 'Real Xendit wallet cash out is now enabled.'
        : 'Wallet cash out is now using Xendit test mode.',
      platformSettings: {
        walletCashOutRealEnabled: updatedValue,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getAdminOverview(req, res, next) {
  try {
    const includeMarketplaceOrders = isSuperAdmin(req.user)
      && isTruthyQuery(req.query?.includeMarketplaceOrders);
    const includeVerificationDocuments = isTruthyQuery(req.query?.includeVerificationDocuments);

    res.json(await buildAdminOverview(includeMarketplaceOrders, includeVerificationDocuments));
  } catch (error) {
    next(error);
  }
}

export async function updateMarketplaceLogisticsSimulation(req, res, next) {
  try {
    const orderId = String(req.params?.orderId || '').trim();
    const action = String(req.body?.action || 'advance').trim();
    const progressPercent = Number(req.body?.progressPercent || 0);

    if (!orderId) {
      return res.status(400).json({ message: 'A marketplace order reference is required.' });
    }

    if (!['advance', 'rewind', 'reset', 'set_progress', 'pickup'].includes(action)) {
      return res.status(400).json({ message: 'Unsupported logistics simulation action.' });
    }

    const sellerUser = await User.findOne({ 'marketplaceOrders.sales.orderId': orderId });

    if (!sellerUser) {
      return res.status(404).json({ message: 'The seller record for this logistics simulation could not be found.' });
    }

    const saleIndex = (sellerUser.marketplaceOrders?.sales || []).findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (saleIndex < 0) {
      return res.status(404).json({ message: 'The seller order copy could not be found.' });
    }

    const saleOrder = sellerUser.marketplaceOrders.sales[saleIndex].toObject?.()
      ? sellerUser.marketplaceOrders.sales[saleIndex].toObject()
      : sellerUser.marketplaceOrders.sales[saleIndex];

    if (!['ready_for_pickup', 'in_transit'].includes(String(saleOrder?.status || '').trim())) {
      return res.status(409).json({
        message: 'Logistics simulation can only run after the parcel is ready for pickup and before delivery is completed.',
      });
    }

    const buyerUserId = String(saleOrder?.buyerUserId || '').trim();
    const buyerUser = buyerUserId ? await User.findById(buyerUserId) : null;

    if (!buyerUser) {
      return res.status(404).json({ message: 'The buyer record for this logistics simulation could not be found.' });
    }

    const purchaseIndex = (buyerUser.marketplaceOrders?.purchases || []).findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (purchaseIndex < 0) {
      return res.status(404).json({ message: 'The buyer order copy could not be found.' });
    }

    const purchaseOrder = buyerUser.marketplaceOrders.purchases[purchaseIndex].toObject?.()
      ? buyerUser.marketplaceOrders.purchases[purchaseIndex].toObject()
      : buyerUser.marketplaceOrders.purchases[purchaseIndex];
    let nextLogistics = saleOrder?.logistics || {};
    let nextStatus = String(saleOrder?.status || '').trim();
    let inTransitAt = saleOrder?.inTransitAt || null;
    const sellerAddress = getMarketplaceAddressSnapshot(sellerUser, saleOrder?.sellerAddress || saleOrder?.location || '');
    const buyerAddress = getMarketplaceAddressSnapshot(buyerUser, saleOrder?.buyerAddress || '');
    const sellerCoordinates = getMarketplaceCoordinateSnapshot(
      { profile: { coordinates: saleOrder.sellerCoordinates || {} } },
      sellerUser?.profile?.coordinates || {},
    );
    const buyerCoordinates = getMarketplaceCoordinateSnapshot(
      { profile: { coordinates: saleOrder.buyerCoordinates || {} } },
      buyerUser?.profile?.coordinates || {},
    );

    if (action === 'pickup') {
      if (nextStatus !== 'ready_for_pickup') {
        return res.status(409).json({
          message: 'Rider pickup can only be confirmed after the parcel is marked ready for pickup.',
        });
      }

      nextStatus = 'in_transit';
      inTransitAt = new Date();
      nextLogistics = await ensureMarketplaceLogisticsSnapshot(
        {
          ...saleOrder,
          status: nextStatus,
          inTransitAt,
          logistics: {
            ...(saleOrder?.logistics || {}),
            progressPercent: 0,
          },
        },
        {
          orderId,
          status: nextStatus,
          createdAt: saleOrder.createdAt,
          sellerAddress,
          buyerAddress,
          sellerCoordinates,
          buyerCoordinates,
        },
      );
    } else {
      nextLogistics = await applyMarketplaceLogisticsAction(saleOrder, {
        action,
        progressPercent,
      });
    }

    sellerUser.marketplaceOrders.sales[saleIndex] = {
      ...saleOrder,
      status: nextStatus,
      inTransitAt,
      logistics: nextLogistics,
    };
    buyerUser.marketplaceOrders.purchases[purchaseIndex] = {
      ...purchaseOrder,
      status: nextStatus,
      inTransitAt,
      logistics: nextLogistics,
    };

    appendActivity(sellerUser, {
      description: `Super admin updated logistics simulation for marketplace order ${orderId}`,
      status: 'confirmed',
    });
    appendActivity(buyerUser, {
      description: `Marketplace tracking updated for order ${orderId}`,
      status: 'confirmed',
    });

    await Promise.all([sellerUser.save(), buyerUser.save()]);

    return res.json({
      message: 'Marketplace logistics simulation updated.',
      order: {
        orderId,
        status: nextStatus,
        sellerAddress,
        buyerAddress,
        logistics: await buildMarketplaceLogisticsView(
          {
            ...saleOrder,
            status: nextStatus,
            inTransitAt,
            logistics: nextLogistics,
          },
          {
            orderId,
            status: nextStatus,
            createdAt: saleOrder.createdAt,
            sellerAddress,
            buyerAddress,
            sellerCoordinates,
            buyerCoordinates,
          },
        ),
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function reviewMarketplaceRefundRequest(req, res, next) {
  try {
    const orderId = String(req.params?.orderId || '').trim();
    const decision = String(req.body?.decision || '').trim().toLowerCase();
    const adminReason = String(req.body?.reason || '').trim();

    if (!orderId) {
      return res.status(400).json({ message: 'A marketplace order reference is required.' });
    }

    if (!['approved', 'rejected'].includes(decision)) {
      return res.status(400).json({ message: 'Refund decision must be approved or rejected.' });
    }

    if (!adminReason) {
      return res.status(400).json({ message: 'Please enter the admin review reason.' });
    }

    const buyerUser = await User.findOne({ 'marketplaceOrders.purchases.orderId': orderId });

    if (!buyerUser) {
      return res.status(404).json({ message: 'The buyer record for this refund request could not be found.' });
    }

    const purchaseIndex = (buyerUser.marketplaceOrders?.purchases || []).findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (purchaseIndex < 0) {
      return res.status(404).json({ message: 'The buyer order copy could not be found.' });
    }

    const purchaseOrder = buyerUser.marketplaceOrders.purchases[purchaseIndex].toObject?.()
      ? buyerUser.marketplaceOrders.purchases[purchaseIndex].toObject()
      : buyerUser.marketplaceOrders.purchases[purchaseIndex];

    if (String(purchaseOrder?.refundRequest?.status || '').trim() !== 'pending') {
      return res.status(409).json({ message: 'This marketplace order has no pending refund request.' });
    }

    const sellerUserId = String(purchaseOrder?.sellerUserId || '').trim();
    const sellerUser = sellerUserId ? await User.findById(sellerUserId) : null;

    if (!sellerUser) {
      return res.status(404).json({ message: 'The seller record for this refund request could not be found.' });
    }

    const saleIndex = (sellerUser.marketplaceOrders?.sales || []).findIndex(
      (order) => String(order?.orderId || '').trim() === orderId,
    );

    if (saleIndex < 0) {
      return res.status(404).json({ message: 'The seller order copy could not be found.' });
    }

    const saleOrder = sellerUser.marketplaceOrders.sales[saleIndex].toObject?.()
      ? sellerUser.marketplaceOrders.sales[saleIndex].toObject()
      : sellerUser.marketplaceOrders.sales[saleIndex];
    const reviewedAt = new Date();
    const refundStatus = decision === 'approved' ? 'approved' : 'rejected';
    const nextBuyerStatus = decision === 'approved' ? 'return_refund' : (purchaseOrder?.reviewed ? 'completed' : 'received');
    const nextSellerStatus = decision === 'approved' ? 'return_refund' : (saleOrder?.reviewed ? 'completed' : 'received');
    const nextRefundRequest = {
      ...(purchaseOrder?.refundRequest || {}),
      status: refundStatus,
      reviewedAt,
      reviewedByUserId: String(req.user?._id || '').trim(),
      reviewedByName: String(req.user?.name || '').trim(),
      adminDecisionReason: adminReason,
      refundedAt: decision === 'approved' ? reviewedAt : null,
    };

    buyerUser.marketplaceOrders.purchases[purchaseIndex] = {
      ...purchaseOrder,
      status: nextBuyerStatus,
      refundRequest: nextRefundRequest,
      cancelledAt: decision === 'approved' ? reviewedAt : purchaseOrder?.cancelledAt || null,
      cancellationReason: decision === 'approved' ? nextRefundRequest.reason : purchaseOrder?.cancellationReason || '',
      cancelledBy: decision === 'approved' ? 'admin_refund' : purchaseOrder?.cancelledBy || '',
    };
    sellerUser.marketplaceOrders.sales[saleIndex] = {
      ...saleOrder,
      status: nextSellerStatus,
      refundRequest: nextRefundRequest,
      cancelledAt: decision === 'approved' ? reviewedAt : saleOrder?.cancelledAt || null,
      cancellationReason: decision === 'approved' ? nextRefundRequest.reason : saleOrder?.cancellationReason || '',
      cancelledBy: decision === 'approved' ? 'admin_refund' : saleOrder?.cancelledBy || '',
    };

    if (decision === 'approved') {
      const refundAmount = Number(purchaseOrder?.totalPaid || 0);

      if (refundAmount > 0) {
        creditWallet(buyerUser, refundAmount, {
          id: buildWalletTransactionId('REFUND'),
          method: 'marketplace_refund_admin',
          reference: String(purchaseOrder?.paymentReference || orderId).trim(),
          description: `Admin-approved refund for marketplace order ${orderId}`,
          destinationLabel: '',
          status: 'completed',
          createdAt: reviewedAt,
        });
      }
    }

    appendActivity(buyerUser, {
      description:
        decision === 'approved'
          ? `Admin approved your marketplace refund request for order ${orderId}: ${adminReason}`
          : `Admin rejected your marketplace refund request for order ${orderId}: ${adminReason}`,
      status: decision === 'approved' ? 'completed' : 'cancelled',
    });
    appendActivity(sellerUser, {
      description:
        decision === 'approved'
          ? `Marketplace refund approved for order ${orderId}. Buyer reason: ${nextRefundRequest.reason}. Admin note: ${adminReason}`
          : `Marketplace refund rejected for order ${orderId}. Buyer reason: ${nextRefundRequest.reason}. Admin note: ${adminReason}`,
      status: decision === 'approved' ? 'completed' : 'confirmed',
    });

    await Promise.all([buyerUser.save(), sellerUser.save()]);

    return res.json({
      message:
        decision === 'approved'
          ? 'Marketplace refund approved and credited to the buyer wallet.'
          : 'Marketplace refund request rejected.',
    });
  } catch (error) {
    next(error);
  }
}

export async function updateUserAdminAccess(req, res, next) {
  try {
    const { userId } = req.params;
    const { admin } = req.body || {};
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    if (isSuperAdmin(user) && admin === false) {
      return res.status(400).json({ message: 'Super admin access cannot be removed from this account.' });
    }

    const nextRoles = new Set(Array.isArray(user.roles) ? user.roles : []);
    nextRoles.add('buyer');

    if (admin) {
      nextRoles.add('admin');
      user.role = 'admin';
      user.accountType = 'admin';
    } else {
      nextRoles.delete('admin');
      user.role = 'user';
      user.accountType = hasRole(user, 'seller')
        ? 'vendor'
        : hasRole(user, 'laborer')
          ? 'laborer'
          : hasRole(user, 'service')
            ? 'service'
            : hasRole(user, 'operations')
              ? 'operations'
              : 'customer';
    }

    user.roles = Array.from(nextRoles);
    ensurePrivilegedAccess(user);
    appendActivity(user, {
      description: admin ? 'Admin access granted to this account' : 'Admin access removed from this account',
      status: 'confirmed',
    });
    await user.save();

    res.json({
      message: admin ? 'Admin access granted.' : 'Admin access removed.',
      user: sanitizeAdminUser(user),
    });
  } catch (error) {
    next(error);
  }
}

export async function updateVerificationStatus(req, res, next) {
  try {
    const { userId } = req.params;
    const { role, status, reason = '' } = req.body || {};
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    if (!['seller', 'laborer'].includes(role)) {
      return res.status(400).json({ message: 'Unsupported verification role.' });
    }

    if (!['verified', 'pending', 'unverified'].includes(status)) {
      return res.status(400).json({ message: 'Unsupported verification status.' });
    }

    if (status === 'unverified' && !String(reason).trim()) {
      return res.status(400).json({ message: 'A rejection reason is required.' });
    }

    user.verification[role].status = status;
    user.verification[role].verifiedAt = status === 'verified' ? new Date() : null;
    user.verification[role].rejectedAt = status === 'unverified' ? new Date() : null;
    user.verification[role].reviewReason = status === 'unverified' ? String(reason).trim() : '';

    const nextRoles = new Set(Array.isArray(user.roles) ? user.roles : []);
    nextRoles.add('buyer');

    if (status === 'verified') {
      nextRoles.add(role);
      user.accountType = role === 'seller' ? 'vendor' : 'laborer';
    } else if (status === 'unverified') {
      nextRoles.delete(role);
    }

    user.roles = Array.from(nextRoles);
    ensurePrivilegedAccess(user);
    appendActivity(user, {
      description:
        status === 'verified'
          ? `${role.charAt(0).toUpperCase() + role.slice(1)} verification approved`
          : status === 'unverified'
            ? `${role.charAt(0).toUpperCase() + role.slice(1)} verification rejected: ${String(reason).trim()}`
            : `${role.charAt(0).toUpperCase() + role.slice(1)} verification moved back to pending review`,
      status: status === 'verified' ? 'completed' : status === 'unverified' ? 'confirmed' : 'pending',
    });
    await user.save();

    res.json({
      message: `${role} verification updated to ${status}.`,
      user: sanitizeAdminUser(user),
    });
  } catch (error) {
    next(error);
  }
}

export async function updateUserPenalty(req, res, next) {
  try {
    const { userId } = req.params;
    const { status, reason, notes, expiresAt } = req.body || {};
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    if (isSuperAdmin(user)) {
      return res.status(400).json({ message: 'Super admin accounts cannot be penalized.' });
    }

    if (!['good', 'warned', 'restricted', 'suspended'].includes(status)) {
      return res.status(400).json({ message: 'Unsupported penalty status.' });
    }

    if (status !== 'good' && !String(reason || '').trim()) {
      return res.status(400).json({ message: 'Penalty reason is required.' });
    }

    const penaltyPayload = buildPenaltyPayload({
      status,
      reason,
      notes,
      penalizedBy: req.user?.email || req.user?.name || 'Admin',
      expiresAt,
    });

    user.penalty = penaltyPayload;
    user.penaltyHistory = [
      penaltyPayload,
      ...(Array.isArray(user.penaltyHistory) ? user.penaltyHistory : []),
    ].slice(0, 12);

    appendActivity(user, {
      description:
        status === 'good'
          ? 'Account penalty was cleared'
          : `Account status changed to ${status}${penaltyPayload.reason ? `: ${penaltyPayload.reason}` : ''}`,
      status: status === 'warned' ? 'confirmed' : status === 'good' ? 'completed' : 'pending',
    });
    await user.save();

    res.json({
      message:
        status === 'good'
          ? 'User penalty cleared.'
          : `User account marked as ${status}.`,
      user: sanitizeAdminUser(user),
    });
  } catch (error) {
    next(error);
  }
}

export async function softDeleteUser(req, res, next) {
  try {
    const { userId } = req.params;
    const { reason = '' } = req.body || {};
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    if (isSuperAdmin(user)) {
      return res.status(400).json({ message: 'Super admin accounts cannot be disabled.' });
    }

    if (req.user?._id?.toString() === user._id.toString()) {
      return res.status(400).json({ message: 'You cannot disable your own account.' });
    }

    const normalizedReason = String(reason || '').trim();

    if (hasActiveBookings(user) || await hasBlockingActiveBookingLinks(user._id.toString())) {
      user.pendingDisableAt = new Date();
      user.pendingDisableReason = normalizedReason;
      user.disabledReason = normalizedReason;

      appendActivity(user, {
        description: `Account disable queued until all active booking links are cleared${normalizedReason ? `: ${normalizedReason}` : ''}`,
        status: 'pending',
      });
      await user.save();

      return res.json({
        message:
          'User has active bookings or active booking links. The account disable is queued and will only take effect once those active bookings are cleared.',
        user: sanitizeAdminUser(user),
      });
    }

    applyDisableState(user, normalizedReason);

    appendActivity(user, {
      description: `Account disabled by super admin${user.disabledReason ? `: ${user.disabledReason}` : ''}`,
      status: 'confirmed',
    });
    await user.save();

    res.json({
      message: 'User account disabled.',
      user: sanitizeAdminUser(user),
    });
  } catch (error) {
    next(error);
  }
}

export async function restoreUser(req, res, next) {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    user.accountStatus = 'active';
    user.disabledAt = null;
    user.disabledReason = '';
    clearPendingDisable(user);
    clearPendingDelete(user);

    appendActivity(user, {
      description: 'Account restored by super admin',
      status: 'completed',
    });
    await user.save();

    res.json({
      message: 'User account restored.',
      user: sanitizeAdminUser(user),
    });
  } catch (error) {
    next(error);
  }
}

export async function permanentlyDeleteUser(req, res, next) {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    if (isSuperAdmin(user)) {
      return res.status(400).json({ message: 'Super admin accounts cannot be permanently deleted.' });
    }

    if (req.user?._id?.toString() === user._id.toString()) {
      return res.status(400).json({ message: 'You cannot permanently delete your own account.' });
    }

    if (hasActiveBookings(user) || await hasBlockingActiveBookingLinks(user._id.toString())) {
      user.pendingDeleteAt = user.pendingDeleteAt || new Date();

      appendActivity(user, {
        description: 'Account permanent delete queued until all active booking links are cleared',
        status: 'pending',
      });
      await user.save();

      return res.json({
        message:
          'User has active bookings or active booking links. The permanent delete is queued and will only take effect once those active bookings are cleared.',
        user: sanitizeAdminUser(user),
      });
    }

    await deleteUserRecord(user);

    res.json({
      message: 'User account and related listings data were permanently deleted.',
    });
  } catch (error) {
    next(error);
  }
}

export async function deleteMarketplaceListing(req, res, next) {
  try {
    const { userId, listingIndex } = req.params;
    const vendor = await User.findById(userId);

    if (!vendor) {
      return res.status(404).json({ message: 'Seller not found.' });
    }

    const index = Number(listingIndex);

    if (!Number.isInteger(index) || index < 0 || index >= vendor.marketplaceListings.length) {
      return res.status(400).json({ message: 'Invalid listing index.' });
    }

    const removedListing = vendor.marketplaceListings[index];
    vendor.marketplaceListings.splice(index, 1);
    appendActivity(vendor, {
      description: `Marketplace listing removed: ${removedListing?.name || 'listing'}`,
      status: 'confirmed',
    });
    await vendor.save();

    res.json({ message: 'Marketplace listing removed.' });
  } catch (error) {
    next(error);
  }
}

export async function updateLaborBookingStatus(req, res, next) {
  try {
    const { userId, bookingType, bookingIndex } = req.params;
    const { status } = req.body || {};
    const laborer = await User.findById(userId);

    if (!laborer) {
      return res.status(404).json({ message: 'Laborer not found.' });
    }

    if (!['active', 'history'].includes(bookingType)) {
      return res.status(400).json({ message: 'Invalid labor booking type.' });
    }

    const index = Number(bookingIndex);
    const source =
      bookingType === 'active' ? laborer.laborProfile.activeBookings : laborer.laborProfile.bookingHistory;

    if (!Number.isInteger(index) || index < 0 || index >= source.length) {
      return res.status(400).json({ message: 'Invalid labor booking index.' });
    }

    const booking = source[index];
    const bookingDescription = booking?.type || booking?.worker || 'labor booking';
    const counterpartUserId = String(
      source[index]?.bookedByUserId || source[index]?.workerId || '',
    ).trim();
    const nextStatus = String(status || booking.status).trim();
    const bookingId = String(booking?.bookingId || '').trim();
    const statusTimestamp = new Date();
    booking.status = nextStatus;

    if (nextStatus === 'completed') {
      booking.completedAt = booking.completedAt || statusTimestamp;
    }

    if (nextStatus === 'cancelled') {
      booking.cancelledAt = booking.cancelledAt || statusTimestamp;
      booking.cancelledBy = booking.cancelledBy || 'admin';
      booking.cancellationReason = booking.cancellationReason || 'Cancelled by admin.';
    }

    if (bookingType === 'active' && ['completed', 'cancelled'].includes(booking.status)) {
      laborer.laborProfile.bookingHistory.push(booking);
      laborer.laborProfile.activeBookings.splice(index, 1);
    }

    appendActivity(laborer, {
      description: `Labor booking updated: ${bookingDescription} is now ${booking.status}`,
      status: booking.status === 'completed' ? 'completed' : booking.status === 'cancelled' ? 'confirmed' : 'pending',
    });
    await laborer.save();
    await applyPendingDisableIfEligible(laborer);
    await applyPendingDeleteIfEligible(laborer);

    if (counterpartUserId && counterpartUserId !== laborer._id.toString()) {
      const counterpartUser = await User.findById(counterpartUserId);

      if (counterpartUser) {
        const syncCounterpartBooking = (entries = []) => {
          const matchIndex = entries.findIndex((entry) => String(entry?.bookingId || '').trim() === bookingId);

          if (matchIndex < 0) {
            return false;
          }

          entries[matchIndex].status = nextStatus;

          if (nextStatus === 'completed') {
            entries[matchIndex].completedAt = entries[matchIndex].completedAt || statusTimestamp;
          }

          if (nextStatus === 'cancelled') {
            entries[matchIndex].cancelledAt = entries[matchIndex].cancelledAt || statusTimestamp;
            entries[matchIndex].cancelledBy = entries[matchIndex].cancelledBy || 'admin';
            entries[matchIndex].cancellationReason = entries[matchIndex].cancellationReason || 'Cancelled by admin.';
          }

          return true;
        };

        const buyerActiveBookings = Array.isArray(counterpartUser?.laborBookings?.activeBookings)
          ? counterpartUser.laborBookings.activeBookings
          : [];
        const buyerHistoryBookings = Array.isArray(counterpartUser?.laborBookings?.bookingHistory)
          ? counterpartUser.laborBookings.bookingHistory
          : [];

        if (!syncCounterpartBooking(buyerActiveBookings)) {
          syncCounterpartBooking(buyerHistoryBookings);
        }

        if (nextStatus === 'cancelled') {
          const activeIndex = buyerActiveBookings.findIndex((entry) => String(entry?.bookingId || '').trim() === bookingId);

          if (activeIndex >= 0) {
            buyerHistoryBookings.push(buyerActiveBookings[activeIndex]);
            buyerActiveBookings.splice(activeIndex, 1);
          }
        }

        await counterpartUser.save();
        await applyPendingDisableIfEligible(counterpartUser);
        await applyPendingDeleteIfEligible(counterpartUser);
      }
    }

    res.json({ message: 'Labor booking updated.' });
  } catch (error) {
    next(error);
  }
}

export async function updateServiceBookingStatus(req, res, next) {
  try {
    const { userId, bookingIndex } = req.params;
    const { status } = req.body || {};
    const provider = await User.findById(userId);

    if (!provider) {
      return res.status(404).json({ message: 'Service provider not found.' });
    }

    const index = Number(bookingIndex);

    if (
      !Number.isInteger(index) ||
      index < 0 ||
      index >= (provider.serviceProfile?.bookings || []).length
    ) {
      return res.status(400).json({ message: 'Invalid service booking index.' });
    }

    const booking = provider.serviceProfile.bookings[index];
    booking.status = String(status || booking.status);
    appendActivity(provider, {
      description: `Service booking updated: ${booking.service || 'service'} is now ${booking.status}`,
      status: booking.status === 'confirmed' ? 'completed' : booking.status === 'cancelled' ? 'confirmed' : 'pending',
    });
    await provider.save();
    await applyPendingDisableIfEligible(provider);
    await applyPendingDeleteIfEligible(provider);

    res.json({ message: 'Service booking updated.' });
  } catch (error) {
    next(error);
  }
}
