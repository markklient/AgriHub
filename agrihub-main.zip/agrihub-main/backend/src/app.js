import './config/env.js';
import cors from 'cors';
import express from 'express';
import morgan from 'morgan';
import { router as apiRouter } from './routes/index.js';
import { notFoundHandler, errorHandler } from './middleware/errorHandler.js';

const app = express();

function buildAllowedOrigins() {
  const configuredOrigins = [
    process.env.CLIENT_URL,
    ...(process.env.CLIENT_URLS || '')
      .split(',')
      .map((value) => value.trim())
      .filter(Boolean),
    'http://localhost:5173',
  ]
    .map((value) => value?.trim())
    .filter(Boolean);

  return Array.from(new Set(configuredOrigins));
}

const allowedOrigins = buildAllowedOrigins();
const allowVercelPreviews = process.env.ALLOW_VERCEL_PREVIEWS === 'true';

function isAllowedOrigin(origin) {
  if (!origin) {
    return true;
  }

  if (allowedOrigins.includes(origin)) {
    return true;
  }

  if (allowVercelPreviews) {
    try {
      const { hostname, protocol } = new URL(origin);
      return protocol === 'https:' && hostname.endsWith('.vercel.app');
    } catch {
      return false;
    }
  }

  return false;
}

app.use(
  cors({
    origin(origin, callback) {
      if (isAllowedOrigin(origin)) {
        return callback(null, true);
      }

      return callback(new Error('This origin is not allowed by CORS.'));
    },
    credentials: true,
  }),
);
app.use(morgan('dev'));
app.use('/api/v1/planner', express.text({ type: ['application/json', 'application/*+json', 'text/plain'] }));
app.use(express.json());

app.get('/', (_req, res) => {
  res.json({
    message: 'AgriHub MERN backend is running.',
  });
});

app.use('/api/v1', apiRouter);
app.use(notFoundHandler);
app.use(errorHandler);

export default app;
