import '../config/env.js';

const XENDIT_API_BASE_URL = process.env.XENDIT_API_BASE_URL || 'https://api.xendit.co';

function getXenditSecretKey() {
  return String(process.env.XENDIT_SECRET_KEY || '').trim();
}

function getXenditCallbackToken() {
  return String(process.env.XENDIT_WEBHOOK_CALLBACK_TOKEN || '').trim();
}

function createAuthorizationHeader(secretKey) {
  return `Basic ${Buffer.from(`${secretKey}:`).toString('base64')}`;
}

async function xenditRequest(path, options = {}) {
  const secretKey = getXenditSecretKey();

  if (!secretKey) {
    throw new Error('Xendit secret key is not configured.');
  }

  const response = await fetch(`${XENDIT_API_BASE_URL}${path}`, {
    method: options.method || 'GET',
    headers: {
      Authorization: createAuthorizationHeader(secretKey),
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data?.message || data?.error_code || 'Xendit request failed.');
  }

  return data;
}

export function mapLaborPaymentMethodToXendit(paymentMethod) {
  const normalized = String(paymentMethod || '').trim().toLowerCase();

  if (normalized === 'gcash') {
    return 'GCASH';
  }

  if (normalized === 'maya' || normalized === 'paymaya') {
    return 'PAYMAYA';
  }

  return 'CREDIT_CARD';
}

export function mapWalletCashOutMethodToXenditChannel(method) {
  const normalized = String(method || '').trim().toLowerCase();

  if (normalized === 'gcash') {
    return 'PH_GCASH';
  }

  if (normalized === 'paymaya' || normalized === 'maya') {
    return 'PH_PAYMAYA';
  }

  throw new Error('Choose a supported Xendit cash-out channel.');
}

export function getSupportedWalletCashOutBanks() {
  return [
    { code: 'PH_BDO', name: 'BDO Unibank' },
    { code: 'PH_BPI', name: 'Bank of the Philippine Islands (BPI)' },
    { code: 'PH_METROBANK', name: 'Metrobank' },
    { code: 'PH_LANDBANK', name: 'Land Bank of the Philippines' },
    { code: 'PH_UBP', name: 'UnionBank' },
    { code: 'PH_RCBC', name: 'RCBC' },
    { code: 'PH_SEC', name: 'Security Bank' },
    { code: 'PH_PNB', name: 'Philippine National Bank (PNB)' },
    { code: 'PH_CHB', name: 'China Banking Corporation' },
  ];
}

export function isSupportedWalletCashOutBank(code) {
  const normalized = String(code || '').trim().toUpperCase();
  return getSupportedWalletCashOutBanks().some((bank) => bank.code === normalized);
}

export async function createXenditInvoice(payload) {
  return xenditRequest('/v2/invoices', {
    method: 'POST',
    body: payload,
  });
}

export async function createXenditPayout(payload) {
  return xenditRequest('/payouts', {
    method: 'POST',
    body: payload,
  });
}

export async function getXenditInvoice(invoiceId) {
  const normalizedInvoiceId = String(invoiceId || '').trim();

  if (!normalizedInvoiceId) {
    throw new Error('A Xendit invoice id is required.');
  }

  return xenditRequest(`/v2/invoices/${encodeURIComponent(normalizedInvoiceId)}`);
}

export function verifyXenditCallbackToken(receivedToken) {
  const expectedToken = getXenditCallbackToken();

  if (!expectedToken) {
    throw new Error('Xendit webhook callback token is not configured.');
  }

  return String(receivedToken || '').trim() === expectedToken;
}
