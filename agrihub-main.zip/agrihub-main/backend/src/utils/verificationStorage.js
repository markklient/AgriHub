import crypto from 'crypto';
import path from 'path';
import {
  getSupabaseAdminClient,
  getSupabaseBucket,
  getSupabaseMarketplaceBucket,
  getSupabaseMarketplaceRefundBucket,
  getSupabaseProfileBucket,
  getSupabaseRentalsBucket,
  getSupabaseReviewBucket,
} from '../config/supabase.js';

const allowedRoles = new Set(['seller', 'laborer']);
const SIGNED_URL_TTL_SECONDS = 60 * 60 * 24 * 7;
const SIGNED_URL_CACHE_TTL_MS = 60 * 60 * 1000;
const STORAGE_REQUEST_TIMEOUT_MS = Number(process.env.SUPABASE_REQUEST_TIMEOUT_MS || 4000);
const signedUrlCache = new Map();

function withTimeout(promise, label = 'Supabase request') {
  let timeoutId;

  const timeoutPromise = new Promise((_, reject) => {
    timeoutId = setTimeout(() => {
      reject(new Error(`${label} timed out after ${STORAGE_REQUEST_TIMEOUT_MS}ms.`));
    }, STORAGE_REQUEST_TIMEOUT_MS);
  });

  return Promise.race([promise, timeoutPromise]).finally(() => {
    clearTimeout(timeoutId);
  });
}

function sanitizeFileName(fileName = 'upload') {
  const extension = path.extname(fileName).toLowerCase();
  const baseName = path.basename(fileName, extension);
  const normalizedBase = baseName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);

  const safeBase = normalizedBase || 'file';
  const safeExtension = extension.replace(/[^.a-z0-9]/g, '').slice(0, 10) || '.bin';

  return `${safeBase}${safeExtension}`;
}

function buildSignedUploadTarget({ bucket, objectPath }) {
  const supabase = getSupabaseAdminClient();

  return withTimeout(
    supabase.storage
      .from(bucket)
      .createSignedUploadUrl(objectPath),
    'Supabase signed upload URL request',
  );
}

function getSignedUrlCacheKey(bucket, path) {
  return `${bucket}:${String(path || '').trim()}`;
}

function readCachedSignedUrl(bucket, path) {
  const key = getSignedUrlCacheKey(bucket, path);
  const cached = signedUrlCache.get(key);

  if (!cached) {
    return '';
  }

  if (cached.expiresAt <= Date.now()) {
    signedUrlCache.delete(key);
    return '';
  }

  return cached.url;
}

function writeCachedSignedUrl(bucket, path, url) {
  const key = getSignedUrlCacheKey(bucket, path);
  signedUrlCache.set(key, {
    url,
    expiresAt: Date.now() + SIGNED_URL_CACHE_TTL_MS,
  });
}

async function createSignedUrlsWithCache(bucket, paths = []) {
  const normalizedPaths = Array.isArray(paths)
    ? paths.map((entry) => String(entry || '').trim()).filter(Boolean)
    : [];

  if (normalizedPaths.length === 0) {
    return [];
  }

  const results = new Array(normalizedPaths.length).fill('');
  const uncached = [];

  normalizedPaths.forEach((path, index) => {
    const cachedUrl = readCachedSignedUrl(bucket, path);

    if (cachedUrl) {
      results[index] = cachedUrl;
      return;
    }

    uncached.push({ path, index });
  });

  if (uncached.length > 0) {
    const supabase = getSupabaseAdminClient();
    const { data, error } = await withTimeout(
      supabase.storage
        .from(bucket)
        .createSignedUrls(uncached.map((entry) => entry.path), SIGNED_URL_TTL_SECONDS),
      'Supabase signed URL batch request',
    );

    if (error) {
      throw error;
    }

    uncached.forEach((entry, batchIndex) => {
      const url = String(data?.[batchIndex]?.signedUrl || '').trim();

      if (url) {
        writeCachedSignedUrl(bucket, entry.path, url);
        results[entry.index] = url;
      }
    });
  }

  return results;
}

export async function createVerificationUploadTarget({
  userId,
  role,
  documentType,
  fileName,
}) {
  if (!allowedRoles.has(role)) {
    throw new Error('Unsupported verification role.');
  }

  const bucket = getSupabaseBucket();
  const safeFileName = sanitizeFileName(fileName);
  const objectPath = `${userId}/${role}/${documentType}-${crypto.randomUUID()}-${safeFileName}`;

  const { data, error } = await buildSignedUploadTarget({ bucket, objectPath });

  if (error) {
    throw error;
  }

  return {
    bucket,
    path: objectPath,
    token: data.token,
    signedUrl: data.signedUrl,
  };
}

export async function createProfileAvatarUploadTarget({
  userId,
  fileName,
}) {
  const bucket = getSupabaseProfileBucket();
  const safeFileName = sanitizeFileName(fileName);
  const objectPath = `${userId}/avatar-${crypto.randomUUID()}-${safeFileName}`;
  const { data, error } = await buildSignedUploadTarget({ bucket, objectPath });

  if (error) {
    throw error;
  }

  return {
    bucket,
    path: objectPath,
    token: data.token,
    signedUrl: data.signedUrl,
  };
}

export async function createMarketplaceListingUploadTarget({
  userId,
  fileName,
}) {
  const bucket = getSupabaseMarketplaceBucket();
  const safeFileName = sanitizeFileName(fileName);
  const objectPath = `${userId}/marketplace/${crypto.randomUUID()}-${safeFileName}`;
  const { data, error } = await buildSignedUploadTarget({ bucket, objectPath });

  if (error) {
    throw error;
  }

  return {
    bucket,
    path: objectPath,
    token: data.token,
    signedUrl: data.signedUrl,
  };
}

export async function createMarketplaceReviewUploadTarget({
  userId,
  fileName,
}) {
  const bucket = getSupabaseReviewBucket();
  const safeFileName = sanitizeFileName(fileName);
  const objectPath = `${userId}/marketplace-review/${crypto.randomUUID()}-${safeFileName}`;
  const { data, error } = await buildSignedUploadTarget({ bucket, objectPath });

  if (error) {
    throw error;
  }

  return {
    bucket,
    path: objectPath,
    token: data.token,
    signedUrl: data.signedUrl,
  };
}

export async function createMarketplaceRefundUploadTarget({
  userId,
  fileName,
}) {
  const bucket = getSupabaseMarketplaceRefundBucket();
  const safeFileName = sanitizeFileName(fileName);
  const objectPath = `${userId}/marketplace-refund/${crypto.randomUUID()}-${safeFileName}`;
  const { data, error } = await buildSignedUploadTarget({ bucket, objectPath });

  if (error) {
    throw error;
  }

  return {
    bucket,
    path: objectPath,
    token: data.token,
    signedUrl: data.signedUrl,
  };
}

export async function createRentalListingUploadTarget({
  userId,
  fileName,
}) {
  const bucket = getSupabaseRentalsBucket();
  const safeFileName = sanitizeFileName(fileName);
  const objectPath = `${userId}/rentals/${crypto.randomUUID()}-${safeFileName}`;
  const { data, error } = await buildSignedUploadTarget({ bucket, objectPath });

  if (error) {
    throw error;
  }

  return {
    bucket,
    path: objectPath,
    token: data.token,
    signedUrl: data.signedUrl,
  };
}

export function getProfileAvatarPublicUrl(path) {
  const bucket = getSupabaseProfileBucket();
  const supabase = getSupabaseAdminClient();
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);

  return {
    bucket,
    url: data.publicUrl,
  };
}

export async function createProfileAvatarSignedUrl(path) {
  const bucket = getSupabaseProfileBucket();
  const [url] = await createSignedUrlsWithCache(bucket, [path]);

  return {
    bucket,
    url,
  };
}

export async function createMarketplaceListingSignedUrl(path) {
  const bucket = getSupabaseMarketplaceBucket();
  const [url] = await createSignedUrlsWithCache(bucket, [path]);

  return {
    bucket,
    url,
  };
}

export async function createMarketplaceListingSignedUrls(paths = []) {
  const bucket = getSupabaseMarketplaceBucket();
  const urls = await createSignedUrlsWithCache(bucket, paths);

  return {
    bucket,
    urls,
  };
}

export async function createMarketplaceReviewSignedUrl(path) {
  const bucket = getSupabaseReviewBucket();
  const [url] = await createSignedUrlsWithCache(bucket, [path]);

  return {
    bucket,
    url,
  };
}

export async function createMarketplaceReviewSignedUrls(paths = []) {
  const bucket = getSupabaseReviewBucket();
  const urls = await createSignedUrlsWithCache(bucket, paths);

  return {
    bucket,
    urls,
  };
}

export async function createMarketplaceRefundSignedUrl(path) {
  const bucket = getSupabaseMarketplaceRefundBucket();
  const [url] = await createSignedUrlsWithCache(bucket, [path]);

  return {
    bucket,
    url,
  };
}

export async function createMarketplaceRefundSignedUrls(paths = []) {
  const bucket = getSupabaseMarketplaceRefundBucket();
  const urls = await createSignedUrlsWithCache(bucket, paths);

  return {
    bucket,
    urls,
  };
}

export async function createRentalListingSignedUrl(path) {
  const bucket = getSupabaseRentalsBucket();
  const [url] = await createSignedUrlsWithCache(bucket, [path]);

  return {
    bucket,
    url,
  };
}

export async function createRentalListingSignedUrls(paths = []) {
  const bucket = getSupabaseRentalsBucket();
  const urls = await createSignedUrlsWithCache(bucket, paths);

  return {
    bucket,
    urls,
  };
}

export async function createVerificationDocumentSignedUrl(path, bucket = getSupabaseBucket()) {
  const [url] = await createSignedUrlsWithCache(bucket, [path]);

  return {
    bucket,
    url,
  };
}

export async function deleteVerificationDocuments(documents = []) {
  const groupedDocuments = documents.reduce((groups, document) => {
    if (!document?.bucket || !document?.path) {
      return groups;
    }

    if (!groups[document.bucket]) {
      groups[document.bucket] = [];
    }

    groups[document.bucket].push(document.path);
    return groups;
  }, {});

  const supabase = getSupabaseAdminClient();

  await Promise.all(
    Object.entries(groupedDocuments).map(async ([bucket, paths]) => {
      if (!Array.isArray(paths) || paths.length === 0) {
        return;
      }

      const { error } = await supabase.storage.from(bucket).remove(paths);

      if (error) {
        throw error;
      }
    }),
  );
}

export function extractProfileAvatarPath(sourceUrl = '') {
  const bucket = getSupabaseProfileBucket();
  const marker = `/storage/v1/object/public/${bucket}/`;

  if (!sourceUrl.includes(marker)) {
    return '';
  }

  const [, pathWithQuery = ''] = sourceUrl.split(marker);
  return pathWithQuery.split('?')[0] || '';
}
