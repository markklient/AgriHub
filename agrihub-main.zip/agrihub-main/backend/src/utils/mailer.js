import nodemailer from 'nodemailer';

let transporterPromise;
const BREVO_SEND_URL = 'https://api.brevo.com/v3/smtp/email';

function requireMailEnv(name) {
  const value = process.env[name]?.trim();

  if (!value) {
    throw new Error(`${name} is missing. Add it to .env to enable password reset emails.`);
  }

  return value;
}

function getFromAddress() {
  return (
    process.env.EMAIL_FROM?.trim() ||
    process.env.SMTP_FROM?.trim() ||
    process.env.BREVO_SENDER?.trim() ||
    process.env.SMTP_USER?.trim() ||
    ''
  );
}

function getBrevoApiKey() {
  return process.env.BREVO_API_KEY?.trim() || '';
}

async function getTransporter() {
  if (!transporterPromise) {
    transporterPromise = (async () => {
      const host = requireMailEnv('SMTP_HOST');
      const port = Number(process.env.SMTP_PORT || '587');
      const user = requireMailEnv('SMTP_USER');
      const pass = requireMailEnv('SMTP_PASS');

      const transporter = nodemailer.createTransport({
        host,
        port,
        secure: port === 465,
        auth: {
          user,
          pass,
        },
        connectionTimeout: 10000,
        greetingTimeout: 10000,
        socketTimeout: 15000,
      });

      await transporter.verify();
      return transporter;
    })().catch((error) => {
      transporterPromise = undefined;
      throw error;
    });
  }

  return transporterPromise;
}

async function sendWithBrevo({ toEmail, subject, text, html }) {
  const apiKey = getBrevoApiKey();
  const sender = getFromAddress();

  if (!apiKey) {
    throw new Error('BREVO_API_KEY is missing. Add it to your environment variables to enable Brevo email delivery.');
  }

  if (!sender) {
    throw new Error('EMAIL_FROM or SMTP_FROM is missing. Add a verified sender email to your environment variables.');
  }

  const response = await fetch(BREVO_SEND_URL, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'api-key': apiKey,
    },
    body: JSON.stringify({
      sender: {
        email: sender.includes('<') ? sender.slice(sender.indexOf('<') + 1, sender.indexOf('>')).trim() : sender,
        name: sender.includes('<') ? sender.slice(0, sender.indexOf('<')).trim().replace(/^"|"$/g, '') : undefined,
      },
      to: [{ email: toEmail }],
      subject,
      textContent: text,
      htmlContent: html,
    }),
    signal: AbortSignal.timeout(15000),
  });

  if (!response.ok) {
    const body = await response.text().catch(() => '');
    throw new Error(`Brevo API request failed (${response.status}): ${body || response.statusText}`);
  }
}

async function sendWithSmtp({ toEmail, subject, text, html }) {
  const transporter = await getTransporter();
  const from = getFromAddress() || requireMailEnv('SMTP_USER');

  await transporter.sendMail({
    from,
    to: toEmail,
    subject,
    text,
    html,
  });
}

async function sendEmail(payload) {
  if (getBrevoApiKey()) {
    await sendWithBrevo(payload);
    return;
  }

  await sendWithSmtp(payload);
}

export async function sendPasswordResetCode({ toEmail, code, name }) {
  const appName = 'AgriHub';
  const greetingName = name?.trim() || 'there';
  const subject = `${appName} password reset code`;
  const text = `Hello ${greetingName},

We received a request to reset your AgriHub password.

Your verification code is: ${code}

This code expires in 15 minutes. If you did not request a password reset, you can ignore this email.
`;
  const html = `
    <div style="font-family: Arial, sans-serif; color: #0f172a; line-height: 1.6;">
      <h2 style="margin-bottom: 8px;">AgriHub password reset</h2>
      <p>Hello ${greetingName},</p>
      <p>We received a request to reset your AgriHub password.</p>
      <p style="margin: 24px 0;">
        <span style="display: inline-block; padding: 12px 18px; border-radius: 12px; background: #16a34a; color: white; font-size: 24px; font-weight: 700; letter-spacing: 4px;">
          ${code}
        </span>
      </p>
      <p>This code expires in 15 minutes.</p>
      <p>If you did not request a password reset, you can ignore this email.</p>
    </div>
  `;

  await sendEmail({
    toEmail,
    subject,
    text,
    html,
  });
}

export async function sendEmailVerificationCode({ toEmail, code, name }) {
  const appName = 'AgriHub';
  const greetingName = name?.trim() || 'there';
  const subject = `${appName} email verification code`;
  const text = `Hello ${greetingName},

Welcome to AgriHub.

Your email verification code is: ${code}

This code expires in 15 minutes. If you did not create an account, you can ignore this email.
`;
  const html = `
    <div style="font-family: Arial, sans-serif; color: #0f172a; line-height: 1.6;">
      <h2 style="margin-bottom: 8px;">Verify your AgriHub email</h2>
      <p>Hello ${greetingName},</p>
      <p>Welcome to AgriHub. Use this code to verify your email address.</p>
      <p style="margin: 24px 0;">
        <span style="display: inline-block; padding: 12px 18px; border-radius: 12px; background: #16a34a; color: white; font-size: 24px; font-weight: 700; letter-spacing: 4px;">
          ${code}
        </span>
      </p>
      <p>This code expires in 15 minutes.</p>
      <p>If you did not create an account, you can ignore this email.</p>
    </div>
  `;

  await sendEmail({
    toEmail,
    subject,
    text,
    html,
  });
}

export async function sendEmailChangeVerificationCode({ toEmail, code, name }) {
  const appName = 'AgriHub';
  const greetingName = name?.trim() || 'there';
  const subject = `${appName} email change verification code`;
  const text = `Hello ${greetingName},

We received a request to change the email address on your AgriHub account.

Your verification code is: ${code}

This code expires in 15 minutes. Your account email will only be updated after this code is confirmed.
`;
  const html = `
    <div style="font-family: Arial, sans-serif; color: #0f172a; line-height: 1.6;">
      <h2 style="margin-bottom: 8px;">Confirm your new AgriHub email</h2>
      <p>Hello ${greetingName},</p>
      <p>We received a request to change the email address on your AgriHub account.</p>
      <p style="margin: 24px 0;">
        <span style="display: inline-block; padding: 12px 18px; border-radius: 12px; background: #16a34a; color: white; font-size: 24px; font-weight: 700; letter-spacing: 4px;">
          ${code}
        </span>
      </p>
      <p>This code expires in 15 minutes.</p>
      <p>Your account email will only be updated after this code is confirmed.</p>
    </div>
  `;

  await sendEmail({
    toEmail,
    subject,
    text,
    html,
  });
}

export async function sendPhoneVerificationCodeEmail({ toEmail, code, name, phone }) {
  const appName = 'AgriHub';
  const greetingName = name?.trim() || 'there';
  const formattedPhone = String(phone || '').trim() || 'the phone number on your account';
  const subject = `${appName} phone verification code`;
  const text = `Hello ${greetingName},

We received a request to verify the phone number on your AgriHub account.

Phone number: ${formattedPhone}
Verification code: ${code}

This code expires in 15 minutes. If you did not request this change, you can ignore this email.
`;
  const html = `
    <div style="font-family: Arial, sans-serif; color: #0f172a; line-height: 1.6;">
      <h2 style="margin-bottom: 8px;">Verify your AgriHub phone number</h2>
      <p>Hello ${greetingName},</p>
      <p>We received a request to verify the phone number on your AgriHub account.</p>
      <p><strong>Phone number:</strong> ${formattedPhone}</p>
      <p style="margin: 24px 0;">
        <span style="display: inline-block; padding: 12px 18px; border-radius: 12px; background: #16a34a; color: white; font-size: 24px; font-weight: 700; letter-spacing: 4px;">
          ${code}
        </span>
      </p>
      <p>This code expires in 15 minutes.</p>
      <p>If you did not request this change, you can ignore this email.</p>
    </div>
  `;

  await sendEmail({
    toEmail,
    subject,
    text,
    html,
  });
}
