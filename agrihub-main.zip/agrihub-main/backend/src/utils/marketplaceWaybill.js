import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

function trimValue(value) {
  return String(value || '').trim();
}

function resolvePythonExecutable() {
  const configuredCandidates = [
    trimValue(process.env.WORKSPACE_PYTHON_PATH),
    trimValue(process.env.PYTHON_EXECUTABLE),
  ].filter(Boolean);

  if (process.platform === 'win32') {
    return [
      ...configuredCandidates,
      'python',
      'py',
      'C:\\Users\\earlj\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe',
    ];
  }

  return [
    ...configuredCandidates,
    'python3',
    'python',
  ];
}

const currentFilePath = fileURLToPath(import.meta.url);
const currentDirectoryPath = path.dirname(currentFilePath);
const waybillScriptPath = path.join(currentDirectoryPath, 'scripts', 'generate_marketplace_waybill.py');

function formatCurrency(amount) {
  const value = Number(amount || 0);
  return `PHP ${value.toFixed(2)}`;
}

function buildAddressLines(address) {
  return trimValue(address)
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
}

function splitPostalProvince(value) {
  const raw = trimValue(value);

  if (!raw) {
    return { province: '', postalCode: '' };
  }

  let match = raw.match(/^(\d{4,5})\s+(.+)$/);
  if (match) {
    return { postalCode: match[1], province: trimValue(match[2]) };
  }

  match = raw.match(/^(.+?)\s+(\d{4,5})$/);
  if (match) {
    return { province: trimValue(match[1]), postalCode: match[2] };
  }

  return { province: raw, postalCode: '' };
}

function getAddressMeta(address) {
  const parts = buildAddressLines(address);
  const looksLikeCountry = parts.length >= 4 && /^[A-Za-z\s]+$/.test(parts[parts.length - 1] || '');
  const country = looksLikeCountry ? parts[parts.length - 1] : '';
  const localityIndex = parts.length - (country ? 2 : 1);
  const cityIndex = localityIndex - 1;
  const locality = splitPostalProvince(parts[localityIndex] || '');
  const streetLines = parts.slice(0, Math.max(cityIndex, 0));
  const district = streetLines[streetLines.length - 1] || '';

  return {
    parts,
    streetLines,
    district,
    barangay: district || parts[0] || '',
    city: parts[cityIndex] || parts[0] || '',
    province: locality.province || parts[localityIndex] || '',
    region: country,
    country,
    postalCode: locality.postalCode || '',
  };
}

function extractPostalCode(address) {
  const match = trimValue(address).match(/\b(\d{4,5})\b/);
  return match ? match[1] : '';
}

function buildCodeFragment(value, fallback = 'AG') {
  const cleaned = trimValue(value).replace(/[^A-Z0-9]/gi, '').toUpperCase();
  return cleaned.slice(0, 4) || fallback;
}

function buildRouteCode(order = {}) {
  const buyerMeta = getAddressMeta(order?.buyerAddress);
  const sellerMeta = getAddressMeta(order?.sellerAddress || order?.location);
  return `${buildCodeFragment(sellerMeta.city, 'ORG')}-${buildCodeFragment(buyerMeta.city, 'DST')}`;
}

function buildHandlingMark(order = {}) {
  const categoryPrefix = buildCodeFragment(order?.category, 'P').slice(0, 1) || 'P';
  const idSource = trimValue(order?.logistics?.trackingNumber || order?.orderId).replace(/[^0-9]/g, '');
  const suffix = (idSource.slice(-2) || '01').padStart(2, '0');
  return `${categoryPrefix}${suffix}`;
}

function splitTrackingNumber(trackingNumber = '') {
  const value = trimValue(trackingNumber).toUpperCase();
  const match = value.match(/^([A-Z]+)([0-9]+)([A-Z0-9-]*)$/);

  if (!match) {
    return {
      prefix: value ? `${value.slice(0, 3)}-` : '',
      main: value.slice(3) || value || '0000000000',
      suffix: '',
    };
  }

  return {
    prefix: match[1] ? `${match[1]}-` : '',
    main: match[2] || '0000000000',
    suffix: match[3] || '',
  };
}

function getAddressLine(addressLines = [], index = 0) {
  return trimValue(addressLines[index] || '');
}

function buildProfileAddress(profile = {}) {
  const fullAddress = trimValue(profile?.address);

  if (fullAddress) {
    return fullAddress;
  }

  const parts = [
    trimValue(profile?.streetAddress),
    trimValue(profile?.city),
    trimValue(profile?.state),
    trimValue(profile?.postalCode),
    trimValue(profile?.country),
  ].filter(Boolean);

  return parts.join(', ');
}

function buildTemplateAddressBlock(addressMeta, fallbackAddress) {
  const streetLines = Array.isArray(addressMeta?.streetLines) ? addressMeta.streetLines.filter(Boolean) : [];
  const city = trimValue(addressMeta?.city);
  const province = trimValue(addressMeta?.province);
  const postalCode = trimValue(addressMeta?.postalCode);

  if (!streetLines.length) {
    return {
      line1: trimValue(fallbackAddress),
      line2: '',
    };
  }

  if (streetLines.length === 1) {
    const locality = [city, province, postalCode].filter(Boolean).join(', ').replace(', ,', ',');
    return {
      line1: streetLines[0],
      line2: locality,
    };
  }

  const leading = streetLines.slice(0, streetLines.length - 1).join(', ');
  const trailing = streetLines[streetLines.length - 1];
  const localityTail = [city, province, postalCode].filter(Boolean).join(', ').replace(', ,', ',');

  return {
    line1: leading || trailing,
    line2: [trailing, localityTail].filter(Boolean).join(', '),
  };
}

export function canGenerateMarketplaceWaybill(order = {}) {
  const status = trimValue(order?.status);
  return ['preparing', 'ready_for_pickup', 'in_transit', 'received', 'completed'].includes(status);
}

export function buildMarketplaceWaybillProfileAddress(profile = {}) {
  return buildProfileAddress(profile);
}

export function buildMarketplaceWaybillPayload(order = {}) {
  const trackingNumber = trimValue(order?.logistics?.trackingNumber);
  const quantity = Number(order?.quantity || 0);
  const unit = trimValue(order?.unit);
  const sellerAddress = trimValue(order?.sellerAddress || order?.location);
  const buyerAddress = trimValue(order?.buyerAddress);
  const sellerMeta = getAddressMeta(sellerAddress);
  const buyerMeta = getAddressMeta(buyerAddress);
  const trackingParts = splitTrackingNumber(trackingNumber);
  const buyerAddressBlock = buildTemplateAddressBlock(buyerMeta, buyerAddress);
  const sellerAddressBlock = buildTemplateAddressBlock(sellerMeta, sellerAddress);
  const productQuantity = quantity > 0
    ? `${quantity} ${unit || 'item'}${quantity > 1 ? 's' : ''}`
    : trimValue(order?.unit) || '1 item';
  const routeCode = buildRouteCode(order);
  const referenceCode = trimValue(order?.paymentReference || trackingNumber || order?.orderId);

  return {
    brand_name: 'AGRIHUB',
    brand_sub: 'EXPRESS',
    tracking_prefix: trackingParts.prefix,
    tracking_main: trackingParts.main,
    tracking_suffix: trackingParts.suffix,
    order_id: trimValue(order?.orderId),
    service_type: routeCode,
    reference_code: referenceCode,
    buyer_name: trimValue(order?.buyerName),
    buyer_address1: buyerAddressBlock.line1,
    buyer_address2: buyerAddressBlock.line2,
    buyer_city: trimValue(buyerMeta.city),
    buyer_city_sub: trimValue(buyerMeta.district || buyerMeta.barangay),
    buyer_province: trimValue(buyerMeta.province),
    buyer_region: trimValue(buyerMeta.country || buyerMeta.region),
    seller_name: trimValue(order?.sellerName),
    seller_address: [sellerAddressBlock.line1, sellerAddressBlock.line2].filter(Boolean).join(', '),
    seller_city: trimValue(sellerMeta.city),
    seller_city_sub: trimValue(sellerMeta.district || sellerMeta.barangay),
    seller_province: trimValue(sellerMeta.province),
    seller_region: trimValue(sellerMeta.country || sellerMeta.region),
    sort_code: buildHandlingMark(order),
    product_qty: productQuantity,
    weight: trimValue(order?.weight),
    cod: trimValue(order?.paymentMethod).toLowerCase() === 'cod',
    trackingNumber,
    routeCode,
    itemName: trimValue(order?.itemName),
    selectedVarietyLabel: trimValue(order?.selectedVarietyLabel),
    totalPaidLabel: formatCurrency(order?.totalPaid),
    generatedAt: new Date().toISOString(),
  };
}

export async function generateMarketplaceWaybillPdf(order = {}) {
  if (!canGenerateMarketplaceWaybill(order)) {
    const error = new Error('Waybill can only be generated after the seller starts preparing the parcel.');
    error.status = 409;
    throw error;
  }

  const pythonCandidates = resolvePythonExecutable();
  const payload = buildMarketplaceWaybillPayload(order);

  let lastError = null;

  for (const pythonExecutable of pythonCandidates) {
    try {
      // Keep trying sensible runtime candidates so deployed Linux containers
      // do not fail on a Windows-only local development path.
      // eslint-disable-next-line no-await-in-loop
      return await new Promise((resolve, reject) => {
        const child = spawn(pythonExecutable, [waybillScriptPath], {
          stdio: ['pipe', 'pipe', 'pipe'],
        });
        const stdoutChunks = [];
        const stderrChunks = [];

        child.stdout.on('data', (chunk) => {
          stdoutChunks.push(Buffer.from(chunk));
        });

        child.stderr.on('data', (chunk) => {
          stderrChunks.push(Buffer.from(chunk));
        });

        child.on('error', (error) => {
          reject(error);
        });

        child.on('close', (code) => {
          if (code !== 0) {
            const stderrOutput = Buffer.concat(stderrChunks).toString('utf8').trim();
            reject(new Error(stderrOutput || `Waybill PDF generation failed with exit code ${code}.`));
            return;
          }

          resolve(Buffer.concat(stdoutChunks));
        });

        child.stdin.write(JSON.stringify(payload));
        child.stdin.end();
      });
    } catch (error) {
      if (error?.code === 'ENOENT') {
        lastError = error;
        continue;
      }

      throw error;
    }
  }

  const missingRuntimeError = new Error(
    'Waybill PDF generation is unavailable because Python is not installed on the server runtime.',
  );
  missingRuntimeError.status = 500;
  missingRuntimeError.cause = lastError;
  throw missingRuntimeError;
}
