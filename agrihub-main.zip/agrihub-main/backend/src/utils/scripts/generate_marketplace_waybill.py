import io
import json
import sys

from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas


PAGE_WIDTH = 100 * mm
PAGE_HEIGHT = 150 * mm
STROKE_COLOR = colors.black


def read_payload():
    raw = sys.stdin.read()
    if not raw.strip():
        return {}
    return json.loads(raw)


def mm_value(value):
    return value * mm


def draw_line(pdf, x1, y1, x2, y2, line_width=0.5):
    pdf.saveState()
    pdf.setStrokeColor(STROKE_COLOR)
    pdf.setLineWidth(line_width)
    pdf.line(x1, y1, x2, y2)
    pdf.restoreState()


def draw_rect(pdf, x, y, width, height, line_width=0.5):
    pdf.saveState()
    pdf.setStrokeColor(STROKE_COLOR)
    pdf.setLineWidth(line_width)
    pdf.rect(x, y, width, height, stroke=1, fill=0)
    pdf.restoreState()


def fit_text_size(value, font_name, max_size, min_size, max_width):
    text = str(value or "")
    size = max_size
    while size > min_size and stringWidth(text, font_name, size) > max_width:
        size -= 0.2
    return max(size, min_size)


def draw_text(pdf, x, y, text, font="Helvetica", size=8):
    pdf.setFont(font, size)
    pdf.setFillColor(colors.black)
    pdf.drawString(x, y, str(text or ""))


def draw_centered(pdf, x, y, width, text, font="Helvetica", size=8):
    pdf.setFont(font, size)
    pdf.setFillColor(colors.black)
    pdf.drawCentredString(x + (width / 2), y, str(text or ""))


def wrap_lines(value, font_name, font_size, max_width, max_lines):
    words = str(value or "").split()
    if not words:
        return [""]

    lines = []
    current = words[0]

    for word in words[1:]:
        candidate = f"{current} {word}"
        if stringWidth(candidate, font_name, font_size) <= max_width:
            current = candidate
        else:
            lines.append(current)
            current = word
            if len(lines) >= max_lines - 1:
                break

    if len(lines) < max_lines:
        lines.append(current)

    if len(lines) == max_lines:
        remaining = " ".join(words)
        visible = " ".join(lines)
        if len(remaining) > len(visible):
            last_line = lines[-1]
            ellipsis = "..."
            while last_line and stringWidth(last_line + ellipsis, font_name, font_size) > max_width:
                last_line = last_line[:-1]
            lines[-1] = (last_line.rstrip() + ellipsis) if last_line else ellipsis

    return lines[:max_lines]


def wrap_order_id(value, font_name, font_size, max_width, max_lines=2):
    text = str(value or "").strip()
    if not text:
        return [""]

    parts = [part for part in text.split("-") if part]
    if len(parts) <= 1:
        return wrap_lines(text, font_name, font_size, max_width, max_lines)

    lines = []
    current = parts[0]

    for part in parts[1:]:
      candidate = f"{current}-{part}"
      if stringWidth(candidate, font_name, font_size) <= max_width:
          current = candidate
      else:
          lines.append(current)
          current = part
          if len(lines) >= max_lines - 1:
              break

    if len(lines) < max_lines:
        lines.append(current)

    return lines[:max_lines]


def draw_wrapped(pdf, x, top_y, value, width, font="Helvetica", size=8, leading=8.5, max_lines=3):
    lines = wrap_lines(value, font, size, width, max_lines)
    current_y = top_y
    for line in lines:
        draw_text(pdf, x, current_y, line, font=font, size=size)
        current_y -= leading


def draw_vertical_label(pdf, x, y, label):
    pdf.saveState()
    pdf.translate(x, y)
    pdf.rotate(90)
    pdf.setFont("Helvetica-Bold", 6)
    pdf.drawString(0, 0, label)
    pdf.restoreState()


def draw_party_block(pdf, left, right, top, bottom, tab_w, name, line1, line2, city, city_sub, province, region, label):
    draw_rect(pdf, left, bottom, right - left, top - bottom, 0.8)
    draw_line(pdf, left + tab_w, bottom, left + tab_w, top, 0.5)

    pdf.saveState()
    pdf.translate(left + (tab_w / 2) + mm_value(1.5), bottom + ((top - bottom) / 2))
    pdf.rotate(90)
    pdf.setFont("Helvetica-Bold", 6)
    pdf.drawString(-mm_value(4.2), -mm_value(1), label)
    pdf.restoreState()

    available = right - (left + tab_w + mm_value(2)) - mm_value(1)
    half = available / 2
    content_x = left + tab_w + mm_value(2)
    name_size = fit_text_size(name, "Helvetica-Bold", 8, 6.4, available)

    draw_text(pdf, content_x, top - mm_value(3.5), name, font="Helvetica-Bold", size=name_size)
    draw_wrapped(pdf, content_x, top - mm_value(7.8), line1, available, font="Helvetica", size=6.4, leading=7.0, max_lines=1)
    draw_wrapped(pdf, content_x, top - mm_value(11.3), line2, available, font="Helvetica", size=6.4, leading=7.0, max_lines=1)

    draw_text(pdf, content_x, bottom + mm_value(11.5), city, font="Helvetica-Bold", size=7.2)
    draw_text(pdf, content_x + half, bottom + mm_value(11.5), province, font="Helvetica-Bold", size=7.2)
    draw_text(pdf, content_x, bottom + mm_value(7), city_sub, font="Helvetica", size=6.4)
    draw_text(pdf, content_x + half, bottom + mm_value(7), region, font="Helvetica", size=6.4)


def draw_attempt_section(pdf, left, right, top, bottom):
    width = right - left
    total_h = top - bottom
    row_h = total_h / 2
    label_w = width * 0.42
    cell_w = (width - label_w) / 3

    draw_rect(pdf, left, bottom, width, total_h, 0.8)
    draw_line(pdf, left, bottom + row_h, right, bottom + row_h, 0.5)
    draw_line(pdf, left + label_w, bottom, left + label_w, top, 0.5)

    label_font_size = 6.4
    number_font_size = 10
    delivery_label_y = bottom + row_h + ((row_h - label_font_size) / 2) - mm_value(0.2)
    return_label_y = bottom + ((row_h - label_font_size) / 2) - mm_value(0.2)
    delivery_number_y = bottom + row_h + ((row_h - number_font_size) / 2) - mm_value(0.1)
    return_number_y = bottom + ((row_h - number_font_size) / 2) - mm_value(0.1)

    draw_centered(pdf, left, delivery_label_y, label_w, "Delivery Attempt", font="Helvetica-Bold", size=label_font_size)
    draw_centered(pdf, left, return_label_y, label_w, "Return Attempt", font="Helvetica-Bold", size=label_font_size)

    for index in range(3):
        cell_x = left + label_w + (cell_w * index)
        draw_line(pdf, cell_x, bottom, cell_x, top, 0.5)
        draw_centered(pdf, cell_x, delivery_number_y, cell_w, str(index + 1), font="Helvetica-Bold", size=number_font_size)
        draw_centered(pdf, cell_x, return_number_y, cell_w, str(index + 1), font="Helvetica-Bold", size=number_font_size)


def draw_waybill(pdf, data):
    left = mm_value(3)
    right = PAGE_WIDTH - mm_value(3)
    width = right - left
    logo_w = mm_value(22)
    tab_w = mm_value(6)

    # Row 1
    r1_top = mm_value(148)
    r1_bottom = mm_value(132)
    r1_h = r1_top - r1_bottom

    draw_rect(pdf, left, r1_bottom, width, r1_h, 0.8)
    draw_rect(pdf, left, r1_bottom, logo_w, r1_h, 0.8)

    draw_centered(pdf, left, r1_bottom + (r1_h * 0.60), logo_w, data.get("brand_name", ""), font="Helvetica-BoldOblique", size=11)
    draw_centered(pdf, left, r1_bottom + (r1_h * 0.35), logo_w, data.get("brand_sub", ""), font="Helvetica", size=5)

    tracking_x = left + logo_w + mm_value(3)
    prefix = str(data.get("tracking_prefix") or "")
    main = str(data.get("tracking_main") or "")
    suffix = str(data.get("tracking_suffix") or "")
    base_y = r1_bottom + (r1_h * 0.52)

    draw_text(pdf, tracking_x, base_y + mm_value(2.8), prefix, font="Helvetica-Bold", size=9)
    prefix_w = stringWidth(prefix, "Helvetica-Bold", 9)
    main_size = fit_text_size(main, "Helvetica-Bold", 22, 16, width - logo_w - mm_value(16))
    draw_text(pdf, tracking_x + prefix_w, base_y, main, font="Helvetica-Bold", size=main_size)
    main_w = stringWidth(main, "Helvetica-Bold", main_size)
    draw_text(pdf, tracking_x + prefix_w + main_w + mm_value(1), base_y + mm_value(2.8), suffix, font="Helvetica-Bold", size=10)

    # Row 2
    r2_top = r1_bottom
    r2_h = mm_value(14)
    r2_bottom = r2_top - r2_h

    draw_rect(pdf, left, r2_bottom, width, r2_h, 0.8)
    draw_line(pdf, left + logo_w, r2_bottom, left + logo_w, r2_top, 0.5)
    draw_text(pdf, left + mm_value(1), r2_top - mm_value(4.5), "Order ID", font="Helvetica", size=5.5)
    order_id_size = fit_text_size(data.get("order_id"), "Helvetica", 5.2, 4.0, logo_w - mm_value(2.2))
    order_id_lines = wrap_order_id(data.get("order_id"), "Helvetica", order_id_size, logo_w - mm_value(2.2), 2)
    order_id_y = r2_top - mm_value(7.8)
    for index, line in enumerate(order_id_lines):
        draw_text(pdf, left + mm_value(1), order_id_y - (index * mm_value(2.8)), line, font="Helvetica", size=order_id_size)

    service = str(data.get("service_type") or "")
    service_size = fit_text_size(service, "Helvetica-Bold", 20, 15, width - logo_w - mm_value(8))
    draw_text(pdf, left + logo_w + mm_value(3), r2_bottom + mm_value(2.5), service, font="Helvetica-Bold", size=service_size)

    # Row 3
    r3_top = r2_bottom
    r3_h = mm_value(8)
    r3_bottom = r3_top - r3_h
    draw_rect(pdf, left, r3_bottom, width, r3_h, 0.5)
    ref_size = fit_text_size(data.get("reference_code"), "Helvetica-Bold", 9, 7, width - mm_value(4))
    draw_centered(pdf, left, r3_bottom + mm_value(2.2), width, data.get("reference_code"), font="Helvetica-Bold", size=ref_size)

    # Row 4 buyer
    r4_top = r3_bottom
    r4_h = mm_value(30)
    r4_bottom = r4_top - r4_h
    draw_party_block(
        pdf,
        left,
        right,
        r4_top,
        r4_bottom,
        tab_w,
        str(data.get("buyer_name") or ""),
        str(data.get("buyer_address1") or ""),
        str(data.get("buyer_address2") or ""),
        str(data.get("buyer_city") or ""),
        str(data.get("buyer_city_sub") or ""),
        str(data.get("buyer_province") or ""),
        str(data.get("buyer_region") or ""),
        "BUYER",
    )

    # Row 5 seller
    r5_top = r4_bottom
    r5_h = mm_value(26)
    r5_bottom = r5_top - r5_h
    draw_party_block(
        pdf,
        left,
        right,
        r5_top,
        r5_bottom,
        tab_w,
        str(data.get("seller_name") or ""),
        str(data.get("seller_address") or ""),
        "",
        str(data.get("seller_city") or ""),
        str(data.get("seller_city_sub") or ""),
        str(data.get("seller_province") or ""),
        str(data.get("seller_region") or ""),
        "SELLER",
    )

    if data.get("cod"):
        pdf.saveState()
        pdf.translate(PAGE_WIDTH / 2, (r4_top + r5_bottom) / 2)
        pdf.rotate(-30)
        pdf.setFillColor(colors.HexColor("#d0d0d0"))
        pdf.setFillAlpha(0.18)
        pdf.setFont("Helvetica-Bold", 52)
        pdf.drawString(-mm_value(16), -mm_value(7), "COD")
        pdf.restoreState()

    # Row 6
    r6_top = r5_bottom
    r6_h = mm_value(18)
    r6_bottom = r6_top - r6_h
    sort_w = mm_value(24)

    draw_rect(pdf, left, r6_bottom, width, r6_h, 0.8)
    draw_line(pdf, left + sort_w, r6_bottom, left + sort_w, r6_top, 0.8)
    sort_code = str(data.get("sort_code") or "")
    sort_size = fit_text_size(sort_code, "Helvetica-Bold", 26, 20, sort_w - mm_value(4))
    draw_centered(pdf, left, r6_bottom + (r6_h / 2) - mm_value(4), sort_w, sort_code, font="Helvetica-Bold", size=sort_size)

    product_x = left + sort_w + mm_value(3)
    product_width = right - product_x - mm_value(3)
    draw_text(pdf, product_x, r6_top - mm_value(5), f"Product Quantity: {data.get('product_qty', '')}", font="Helvetica", size=6.5)
    draw_text(pdf, product_x, r6_top - mm_value(9.5), f"Weight: {data.get('weight', '')}", font="Helvetica", size=6.5)

    # Row 7
    r7_top = r6_bottom
    r7_bottom = mm_value(2)
    draw_attempt_section(pdf, left, right, r7_top, r7_bottom)


def main():
    payload = read_payload()
    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=(PAGE_WIDTH, PAGE_HEIGHT))
    pdf.setTitle(f"AgriHub Waybill {payload.get('order_id', '')}")
    draw_waybill(pdf, payload)
    pdf.showPage()
    pdf.save()
    sys.stdout.buffer.write(buffer.getvalue())


if __name__ == "__main__":
    main()
