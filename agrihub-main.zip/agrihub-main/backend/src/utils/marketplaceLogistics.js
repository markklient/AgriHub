import { findMarketplaceRouteHubs } from '../data/marketplaceHubs.js';

const HOUR_IN_MS = 60 * 60 * 1000;
const ROUTING_REQUEST_TIMEOUT_MS = Number(process.env.ROUTING_REQUEST_TIMEOUT_MS || 4000);

function trimValue(value) {
  return String(value || '').trim();
}

function normalizeCoordinatePair(input = {}) {
  const rawLat = input?.lat;
  const rawLng = input?.lng;

  if (
    rawLat === null
    || rawLat === undefined
    || rawLat === ''
    || rawLng === null
    || rawLng === undefined
    || rawLng === ''
  ) {
    return { lat: null, lng: null };
  }

  const lat = Number(rawLat);
  const lng = Number(rawLng);

  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    return { lat: null, lng: null };
  }

  return { lat, lng };
}

function hasCoordinates(input = {}) {
  return normalizeCoordinatePair(input).lat !== null && normalizeCoordinatePair(input).lng !== null;
}

function splitAddress(address) {
  return trimValue(address)
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
}

function shortenAddress(address, preferredParts = 2) {
  const parts = splitAddress(address);

  if (parts.length === 0) {
    return 'Address unavailable';
  }

  return parts.slice(Math.max(parts.length - preferredParts, 0)).join(', ');
}

function getAddressMeta(address) {
  const parts = splitAddress(address);

  return {
    parts,
    barangay: parts[0] || '',
    city: parts.length >= 3 ? parts[parts.length - 3] : parts[0] || '',
    province: parts.length >= 2 ? parts[parts.length - 2] : parts[0] || '',
    region: parts[parts.length - 1] || '',
  };
}

function buildAreaLabel(address, fallback = 'Unknown area') {
  const meta = getAddressMeta(address);

  if (meta.city && meta.province && meta.city.toLowerCase() !== meta.province.toLowerCase()) {
    return `${meta.city}, ${meta.province}`;
  }

  if (meta.province) {
    return meta.province;
  }

  if (meta.city) {
    return meta.city;
  }

  return fallback;
}

function buildTrackingNumber(orderId) {
  const source = trimValue(orderId).replace(/[^A-Z0-9]/gi, '').toUpperCase();
  const suffix = source.slice(-10) || `${Date.now()}`.slice(-10);
  return `AGX${suffix}`;
}

function clampProgress(value) {
  const parsed = Number(value);

  if (!Number.isFinite(parsed)) {
    return 0;
  }

  return Math.max(0, Math.min(100, Math.round(parsed)));
}

function getProviderConfig() {
  return {
    orsBaseUrl: trimValue(process.env.ORS_BASE_URL) || 'http://127.0.0.1:8080/ors',
    orsApiKey: trimValue(process.env.ORS_API_KEY),
    graphHopperBaseUrl: trimValue(process.env.GRAPHHOPPER_BASE_URL) || 'http://127.0.0.1:8989',
    graphHopperApiKey: trimValue(process.env.GRAPHHOPPER_API_KEY),
    osrmBaseUrl: trimValue(process.env.OSRM_BASE_URL) || 'http://127.0.0.1:5001',
    optaPlannerBaseUrl: trimValue(process.env.OPTAPLANNER_BASE_URL) || 'http://127.0.0.1:8090',
  };
}

async function requestJson(url, options = {}) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => {
    controller.abort();
  }, ROUTING_REQUEST_TIMEOUT_MS);

  let response;

  try {
    response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new Error(`Routing request timed out after ${ROUTING_REQUEST_TIMEOUT_MS}ms.`);
    }

    throw error;
  } finally {
    clearTimeout(timeoutId);
  }

  if (!response.ok) {
    const body = await response.text().catch(() => '');
    throw new Error(`${response.status} ${response.statusText}${body ? ` - ${body.slice(0, 240)}` : ''}`);
  }

  return response.json();
}

function normalizeRouteWaypointList(waypoints = []) {
  return Array.isArray(waypoints)
    ? waypoints.map((point) => normalizeCoordinatePair(point)).filter(hasCoordinates)
    : [];
}

async function requestOpenRouteServiceRoute(config, sellerCoordinates, buyerCoordinates, waypoints = []) {
  const coordinateList = normalizeRouteWaypointList(
    waypoints.length >= 2 ? waypoints : [sellerCoordinates, buyerCoordinates],
  );

  if (!config.orsBaseUrl || coordinateList.length < 2) {
    return null;
  }

  try {
    const payload = {
      coordinates: coordinateList.map((point) => [Number(point.lng), Number(point.lat)]),
    };
    const headers = {
      'Content-Type': 'application/json',
    };

    if (config.orsApiKey) {
      headers.Authorization = config.orsApiKey;
    }

    const result = await requestJson(`${config.orsBaseUrl}/v2/directions/driving-car/geojson`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    const feature = Array.isArray(result?.features) ? result.features[0] : null;
    const summary = feature?.properties?.summary || {};
    const instructions = Array.isArray(feature?.properties?.segments)
      ? feature.properties.segments.flatMap((segment = {}) =>
          Array.isArray(segment?.steps)
            ? segment.steps.map((step = {}) => ({
                text: trimValue(step.instruction || step.name || ''),
                instruction: trimValue(step.instruction || ''),
                name: trimValue(step.name || ''),
                distanceMeters: Number(step.distance || 0),
                durationMinutes: Number(step.duration || 0) / 60,
                geometryIndex: Array.isArray(step.way_points)
                  ? Number(step.way_points[1] || step.way_points[0] || 0)
                  : 0,
              }))
            : [],
        )
      : [];
    const coordinates = Array.isArray(feature?.geometry?.coordinates)
      ? feature.geometry.coordinates
          .filter((pair) => Array.isArray(pair) && pair.length >= 2)
          .map((pair) => ({ lat: Number(pair[1]), lng: Number(pair[0]) }))
          .filter(hasCoordinates)
      : [];

    return {
      provider: 'openrouteservice',
      distanceKm: Number(summary.distance || 0) / 1000,
      durationMinutes: Number(summary.duration || 0) / 60,
      geometry: coordinates,
      instructions,
    };
  } catch {
    return null;
  }
}

async function requestOsrmRoute(config, sellerCoordinates, buyerCoordinates, waypoints = []) {
  const coordinateList = normalizeRouteWaypointList(
    waypoints.length >= 2 ? waypoints : [sellerCoordinates, buyerCoordinates],
  );

  if (!config.osrmBaseUrl || coordinateList.length < 2) {
    return null;
  }

  try {
    const coordinatesPath = coordinateList
      .map((point) => `${Number(point.lng)},${Number(point.lat)}`)
      .join(';');
    const result = await requestJson(
      `${config.osrmBaseUrl}/route/v1/driving/${coordinatesPath}?overview=full&geometries=geojson&steps=true`,
    );
    const route = Array.isArray(result?.routes) ? result.routes[0] : null;
    const geometry = Array.isArray(route?.geometry?.coordinates)
      ? route.geometry.coordinates
          .filter((pair) => Array.isArray(pair) && pair.length >= 2)
          .map((pair) => ({ lat: Number(pair[1]), lng: Number(pair[0]) }))
          .filter(hasCoordinates)
      : [];
    const instructions = Array.isArray(route?.legs)
      ? route.legs.flatMap((leg = {}) =>
          Array.isArray(leg?.steps)
            ? leg.steps.map((step = {}) => ({
                text: trimValue(step?.name || step?.maneuver?.modifier || step?.maneuver?.type || ''),
                instruction: trimValue(step?.name || step?.maneuver?.modifier || step?.maneuver?.type || ''),
                name: trimValue(step?.name || ''),
                distanceMeters: Number(step?.distance || 0),
                durationMinutes: Number(step?.duration || 0) / 60,
                geometryIndex: 0,
              }))
            : [],
        )
      : [];

    return {
      provider: 'osrm',
      distanceKm: Number(route?.distance || 0) / 1000,
      durationMinutes: Number(route?.duration || 0) / 60,
      geometry,
      instructions,
    };
  } catch {
    return null;
  }
}

async function requestGraphHopperRoute(config, sellerCoordinates, buyerCoordinates, waypoints = []) {
  const coordinateList = normalizeRouteWaypointList(
    waypoints.length >= 2 ? waypoints : [sellerCoordinates, buyerCoordinates],
  );

  if (!config.graphHopperBaseUrl || coordinateList.length < 2) {
    return null;
  }

  try {
    const params = new URLSearchParams();
    coordinateList.forEach((point, index) => {
      if (index === 0) {
        params.set('point', `${Number(point.lat)},${Number(point.lng)}`);
        return;
      }

      params.append('point', `${Number(point.lat)},${Number(point.lng)}`);
    });
    params.set('profile', 'car');
    params.set('points_encoded', 'false');

    if (config.graphHopperApiKey) {
      params.set('key', config.graphHopperApiKey);
    }

    const result = await requestJson(`${config.graphHopperBaseUrl}/route?${params.toString()}`);
    const path = Array.isArray(result?.paths) ? result.paths[0] : null;
    const geometry = Array.isArray(path?.points?.coordinates)
      ? path.points.coordinates
          .filter((pair) => Array.isArray(pair) && pair.length >= 2)
          .map((pair) => ({ lat: Number(pair[1]), lng: Number(pair[0]) }))
          .filter(hasCoordinates)
      : [];
    const instructions = Array.isArray(path?.instructions)
      ? path.instructions.map((instruction = {}) => ({
          text: trimValue(instruction?.text || instruction?.street_name || ''),
          instruction: trimValue(instruction?.text || ''),
          name: trimValue(instruction?.street_name || instruction?.text || ''),
          distanceMeters: Number(instruction?.distance || 0),
          durationMinutes: Number(instruction?.time || 0) / (60 * 1000),
          geometryIndex: Array.isArray(instruction?.interval)
            ? Number(instruction.interval[1] || instruction.interval[0] || 0)
            : 0,
        }))
      : [];

    return {
      provider: 'graphhopper',
      distanceKm: Number(path?.distance || 0) / 1000,
      durationMinutes: Number(path?.time || 0) / (60 * 1000),
      geometry,
      instructions,
    };
  } catch {
    return null;
  }
}

function interpolatePoint(start, end, ratio) {
  return {
    lat: Number(start.lat) + (Number(end.lat) - Number(start.lat)) * ratio,
    lng: Number(start.lng) + (Number(end.lng) - Number(start.lng)) * ratio,
  };
}

function calculateCoordinateDistanceKm(first = {}, second = {}) {
  if (!hasCoordinates(first) || !hasCoordinates(second)) {
    return Number.POSITIVE_INFINITY;
  }

  const earthRadiusKm = 6371;
  const deltaLat = ((Number(second.lat) - Number(first.lat)) * Math.PI) / 180;
  const deltaLng = ((Number(second.lng) - Number(first.lng)) * Math.PI) / 180;
  const firstLatRadians = (Number(first.lat) * Math.PI) / 180;
  const secondLatRadians = (Number(second.lat) * Math.PI) / 180;
  const a =
    Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(firstLatRadians) *
      Math.cos(secondLatRadians) *
      Math.sin(deltaLng / 2) *
      Math.sin(deltaLng / 2);

  return earthRadiusKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function getGeometryPoint(geometry = [], index = 0, fallback = {}) {
  if (!Array.isArray(geometry) || geometry.length === 0) {
    return normalizeCoordinatePair(fallback);
  }

  const safeIndex = Math.max(0, Math.min(Number(index || 0), geometry.length - 1));
  return normalizeCoordinatePair(geometry[safeIndex] || fallback);
}

function pickCheckpointInstructions(instructions = []) {
  if (!Array.isArray(instructions) || instructions.length === 0) {
    return [];
  }

  const filtered = instructions
    .filter((instruction) => trimValue(instruction?.text || instruction?.name || instruction?.instruction))
    .filter((instruction) => Number(instruction?.distanceMeters || 0) >= 700)
    .filter((instruction) => trimValue(instruction?.name || '').toLowerCase() !== '-');

  return filtered.filter((instruction, index, collection) => {
    const geometryIndex = Number(instruction?.geometryIndex || 0);
    const stopName = trimValue(instruction?.name || instruction?.text || instruction?.instruction).toLowerCase();

    return collection.findIndex((candidate) => {
      const candidateGeometryIndex = Number(candidate?.geometryIndex || 0);
      const candidateStopName = trimValue(candidate?.name || candidate?.text || candidate?.instruction).toLowerCase();
      return candidateGeometryIndex === geometryIndex || candidateStopName === stopName;
    }) === index;
  });
}

async function buildStopCandidates({
  sellerAddress,
  buyerAddress,
  sellerCoordinates,
  buyerCoordinates,
  distanceKm = 0,
  instructionGeometry = [],
}) {
  const sellerArea = buildAreaLabel(sellerAddress, 'Seller area');
  const buyerArea = buildAreaLabel(buyerAddress, 'Buyer area');
  const sellerMeta = getAddressMeta(sellerAddress);
  const buyerMeta = getAddressMeta(buyerAddress);
  const routeHubs = await findMarketplaceRouteHubs({
    sellerAddress,
    buyerAddress,
    sellerCoordinates,
    buyerCoordinates,
    routeGeometry: Array.isArray(instructionGeometry)
      ? instructionGeometry.map((point) => normalizeCoordinatePair(point)).filter(hasCoordinates)
      : [],
  });

  const baseStops = [
    {
      id: 'pickup',
      type: 'pickup',
      label: `Pickup from ${sellerMeta.city || sellerArea}`,
      address: trimValue(sellerAddress) || sellerArea,
      coordinates: normalizeCoordinatePair(sellerCoordinates),
    },
  ];

  routeHubs.sortingHubs.forEach((hub, index) => {
    baseStops.push({
      id: trimValue(hub.id) || `sorting_hub_${index + 1}`,
      type: 'hub',
      label: trimValue(hub.name) || `Sorting hub near ${sellerMeta.city || sellerArea}`,
      address: trimValue(hub.address) || sellerArea,
      coordinates: normalizeCoordinatePair(hub.coordinates),
    });
  });

  if (routeHubs.deliveryHub) {
    baseStops.push({
      id: trimValue(routeHubs.deliveryHub.id) || 'destination_hub',
      type: 'hub',
      label: trimValue(routeHubs.deliveryHub.name) || `Delivery hub near ${buyerMeta.city || buyerArea}`,
      address: trimValue(routeHubs.deliveryHub.address) || buyerArea,
      coordinates: normalizeCoordinatePair(routeHubs.deliveryHub.coordinates),
    });
  }

  baseStops.push({
    id: 'destination',
    type: 'destination',
    label: `Deliver to ${buyerMeta.city || buyerArea}`,
    address: trimValue(buyerAddress) || buyerArea,
    coordinates: normalizeCoordinatePair(buyerCoordinates),
  });

  return baseStops.filter((stop, index, collection) => {
    if (!stop.label) {
      return false;
    }

    const previous = collection[index - 1];
    if (!previous) {
      return true;
    }

    return (stop.label !== previous.label) && (
      !hasCoordinates(stop.coordinates)
      || !hasCoordinates(previous.coordinates)
      || stop.coordinates.lat !== previous.coordinates.lat
      || stop.coordinates.lng !== previous.coordinates.lng
    );
  });
}

async function optimizeStopsWithOptaPlanner(config, stops = [], context = {}) {
  if (!config.optaPlannerBaseUrl || stops.length <= 2) {
    return {
      stops,
      provider: '',
    };
  }

  // Marketplace parcel tracking should follow the courier route sequence as-built,
  // so we keep the original ordered hub list instead of re-optimizing it.
  return {
    stops,
    provider: '',
  };
}

function assignStopEtas(stops = [], totalDurationMinutes = 0, startTime = new Date()) {
  if (stops.length === 0) {
    return [];
  }

  const totalLegs = Math.max(stops.length - 1, 1);
  const legDurationMinutes = Math.max(totalDurationMinutes / totalLegs, 12);
  let cursor = new Date(startTime);

  return stops.map((stop, index) => {
    if (index === 0) {
      return {
        ...stop,
        estimatedAt: cursor,
        arrivedAt: cursor,
        departedAt: null,
      };
    }

    cursor = new Date(cursor.getTime() + legDurationMinutes * 60 * 1000);
    return {
      ...stop,
      estimatedAt: cursor,
      arrivedAt: null,
      departedAt: null,
    };
  });
}

function buildFallbackGeometry(sellerCoordinates, buyerCoordinates, stops = []) {
  const geometry = [];

  if (hasCoordinates(sellerCoordinates)) {
    geometry.push(normalizeCoordinatePair(sellerCoordinates));
  }

  stops.forEach((stop) => {
    if (hasCoordinates(stop?.coordinates)) {
      geometry.push(normalizeCoordinatePair(stop.coordinates));
    }
  });

  if (hasCoordinates(buyerCoordinates)) {
    geometry.push(normalizeCoordinatePair(buyerCoordinates));
  }

  return geometry.filter((point, index, collection) => {
    const previous = collection[index - 1];
    if (!previous) {
      return true;
    }

    return previous.lat !== point.lat || previous.lng !== point.lng;
  });
}

function buildCurrentLocation(stops = [], currentStopIndex = 0, progressPercent = 0) {
  const currentStop = stops[currentStopIndex];
  const nextStop = stops[currentStopIndex + 1];

  if (!hasCoordinates(currentStop?.coordinates)) {
    return { lat: null, lng: null };
  }

  if (!nextStop || !hasCoordinates(nextStop?.coordinates)) {
    return normalizeCoordinatePair(currentStop.coordinates);
  }

  return normalizeCoordinatePair(
    interpolatePoint(currentStop.coordinates, nextStop.coordinates, clampProgress(progressPercent) / 100),
  );
}

function buildTimelineEvents(logistics = {}, order = {}) {
  const normalizedStatus = trimValue(order?.status || 'paid');
  const statusEvents = [];

  if (order?.completedAt && (normalizedStatus === 'completed' || order?.reviewed)) {
    statusEvents.push({
      key: 'completed',
      title: 'Product rated',
      detail: order?.reviewComment
        ? `You rated this order ${Number(order?.reviewRating || 0).toFixed(1)} stars and left a review.`
        : `You rated this order ${Number(order?.reviewRating || 0).toFixed(1)} stars.`,
      timestamp: order.completedAt,
      tone: 'success',
    });
  }

  if (order?.receivedAt && ['received', 'completed'].includes(normalizedStatus)) {
    statusEvents.push({
      key: 'received',
      title: 'Order received',
      detail: 'You confirmed that the parcel arrived safely.',
      timestamp: order.receivedAt,
      tone: 'success',
    });
  }

  if (normalizedStatus === 'in_transit' && order?.inTransitAt) {
    statusEvents.push({
      key: 'transit',
      title: 'Parcel is in transit',
      detail: 'The parcel has left the seller side and is moving through the delivery route.',
      timestamp: order.inTransitAt,
      tone: 'info',
    });
  }

  if (['ready_for_pickup', 'in_transit', 'received', 'completed'].includes(normalizedStatus) && order?.readyForPickupAt) {
    statusEvents.push({
      key: 'pickup',
      title: 'Ready for pickup',
      detail: 'The seller has finished preparing the parcel and released it to logistics pickup.',
      timestamp: order.readyForPickupAt,
      tone: 'info',
    });
  }

  if (['preparing', 'ready_for_pickup', 'in_transit', 'received', 'completed'].includes(normalizedStatus) && order?.preparingAt) {
    statusEvents.push({
      key: 'preparing',
      title: 'Seller is preparing the product',
      detail: 'The seller already started packing your order.',
      timestamp: order.preparingAt,
      tone: 'info',
    });
  }

  statusEvents.push({
    key: 'paid',
    title: 'Order placed',
    detail: normalizedStatus === 'paid'
      ? 'Payment was confirmed. Waiting for the seller to start preparing your parcel.'
      : 'Payment was confirmed and the seller has received the order request.',
    timestamp: order?.paidAt || order?.createdAt || null,
    tone: 'neutral',
  });

  if (!['in_transit', 'received', 'completed'].includes(normalizedStatus)) {
    return statusEvents
      .filter((event) => event.title)
      .sort((left, right) => new Date(right.timestamp || 0).getTime() - new Date(left.timestamp || 0).getTime())
      .filter((event, index, collection) => collection.findIndex((entry) => entry.key === event.key) === index);
  }

  const routeEvents = Array.isArray(logistics?.routeStops)
    ? logistics.routeStops.map((stop = {}, index) => {
        const state = trimValue(stop?.state || 'pending');
        let title = '';
        let detail = trimValue(stop?.address || '');
        let tone = 'neutral';

        if (state === 'completed') {
          title = index === logistics.routeStops.length - 1 ? 'Parcel delivered to buyer' : `Parcel reached ${stop.label}`;
          detail = detail || 'Checkpoint completed.';
          tone = 'success';
        } else if (state === 'current') {
          title = `Parcel is at ${stop.label}`;
          detail = detail || 'The parcel is currently being processed at this checkpoint.';
          tone = 'info';
        } else if (state === 'up_next') {
          title = `Next hub: ${stop.label}`;
          detail = detail || 'This is the next expected checkpoint on the route.';
        } else if (!logistics.simulationEnabled && index === 0) {
          title = `Tracking will start at ${stop.label}`;
          detail = detail || 'The parcel is still waiting for pickup release.';
        } else {
          title = `Upcoming stop: ${stop.label}`;
          detail = detail || 'Planned route checkpoint.';
        }

        return {
          key: `route-${stop.id || index}`,
          title,
          detail,
          timestamp: stop?.arrivedAt || stop?.estimatedAt || null,
          tone,
        };
      })
    : [];

  return [...routeEvents, ...statusEvents]
    .filter((event) => event.title)
    .sort((left, right) => new Date(right.timestamp || 0).getTime() - new Date(left.timestamp || 0).getTime())
    .filter((event, index, collection) => collection.findIndex((entry) => entry.key === event.key) === index);
}

async function buildProviderRoutePlan({ sellerCoordinates, buyerCoordinates, sellerAddress, buyerAddress }) {
  const config = getProviderConfig();
  const initialWaypoints = [sellerCoordinates, buyerCoordinates];
  const [orsRoute, osrmRoute, graphHopperRoute] = await Promise.all([
    requestOpenRouteServiceRoute(config, sellerCoordinates, buyerCoordinates, initialWaypoints),
    requestOsrmRoute(config, sellerCoordinates, buyerCoordinates, initialWaypoints),
    requestGraphHopperRoute(config, sellerCoordinates, buyerCoordinates, initialWaypoints),
  ]);

  const etaRoute = orsRoute || graphHopperRoute || osrmRoute;
  const geometryRoute = osrmRoute || graphHopperRoute || orsRoute;
  const instructionRoute = orsRoute?.instructions?.length
    ? orsRoute
    : graphHopperRoute?.instructions?.length
      ? graphHopperRoute
      : osrmRoute;
  const distanceKm = Number(etaRoute?.distanceKm || geometryRoute?.distanceKm || 0);
  const durationMinutes = Number(etaRoute?.durationMinutes || geometryRoute?.durationMinutes || 0);
  const optimizationResult = await optimizeStopsWithOptaPlanner(
    config,
    await buildStopCandidates({
      sellerAddress,
      buyerAddress,
      sellerCoordinates,
      buyerCoordinates,
      distanceKm,
      instructionGeometry: instructionRoute?.geometry || geometryRoute?.geometry || [],
    }),
    {
      distanceKm,
      durationMinutes,
    },
  );
  const optimizedStops = optimizationResult.stops;

  return {
    distanceKm,
    durationMinutes,
    geometry: Array.isArray(geometryRoute?.geometry) && geometryRoute.geometry.length > 1
      ? geometryRoute.geometry
      : buildFallbackGeometry(sellerCoordinates, buyerCoordinates, optimizedStops),
    providers: {
      eta: etaRoute?.provider || '',
      geometry: geometryRoute?.provider || '',
      optimization: optimizationResult.provider,
    },
    routeStops: optimizedStops,
  };
}

async function buildServiceBackedSnapshot({
  orderId = '',
  status = 'paid',
  createdAt = new Date(),
  sellerAddress = '',
  buyerAddress = '',
  sellerCoordinates = {},
  buyerCoordinates = {},
  currentStopIndex = 0,
  progressPercent = 0,
  lastUpdatedAt = null,
} = {}) {
  const trackingNumber = buildTrackingNumber(orderId);
  const simulationEnabled = ['ready_for_pickup', 'in_transit'].includes(trimValue(status));
  const simulationLockedReason = simulationEnabled
    ? ''
    : status === 'preparing'
      ? 'Tracking becomes available when the parcel is ready for pickup.'
      : status === 'paid'
        ? 'Tracking becomes available when the parcel is ready for pickup.'
        : 'Tracking is unavailable for this order status.';
  const coordinatesReady = hasCoordinates(sellerCoordinates) && hasCoordinates(buyerCoordinates);
  const plannedAt = lastUpdatedAt ? new Date(lastUpdatedAt) : new Date(createdAt || Date.now());

  if (!coordinatesReady) {
    const sellerStop = {
      id: 'pickup',
      type: 'pickup',
      label: 'Seller pickup point',
      address: trimValue(sellerAddress) || 'Address unavailable',
      coordinates: normalizeCoordinatePair(sellerCoordinates),
    };
    const buyerStop = {
      id: 'destination',
      type: 'destination',
      label: 'Buyer delivery address',
      address: trimValue(buyerAddress) || 'Address unavailable',
      coordinates: normalizeCoordinatePair(buyerCoordinates),
    };
    const routeStops = assignStopEtas([sellerStop, buyerStop], 120, plannedAt);

    return {
      trackingNumber,
      providerMeta: {
        eta: '',
        geometry: '',
        optimization: '',
      },
      simulationEnabled: false,
      simulationLockedReason: simulationLockedReason || 'Add map coordinates to both seller and buyer addresses to enable routing.',
      currentStopIndex: 0,
      progressPercent: 0,
      currentLocation: { lat: null, lng: null },
      distanceKm: 0,
      durationMinutes: 0,
      lastUpdatedAt: plannedAt,
      estimatedArrivalAt: routeStops[routeStops.length - 1]?.estimatedAt || plannedAt,
      routeGeometry: [],
      routeStops,
    };
  }

  const routePlan = await buildProviderRoutePlan({
    sellerCoordinates,
    buyerCoordinates,
    sellerAddress,
    buyerAddress,
  });
  const safeStopIndex = Math.max(0, Math.min(Number(currentStopIndex || 0), Math.max(routePlan.routeStops.length - 1, 0)));
  const safeProgress = clampProgress(progressPercent);
  const routeStops = assignStopEtas(routePlan.routeStops, routePlan.durationMinutes, plannedAt);

  return {
    trackingNumber,
    providerMeta: routePlan.providers,
    simulationEnabled,
    simulationLockedReason,
    currentStopIndex: safeStopIndex,
    progressPercent: simulationEnabled ? safeProgress : 0,
    currentLocation: simulationEnabled
      ? buildCurrentLocation(routeStops, safeStopIndex, safeProgress)
      : normalizeCoordinatePair(sellerCoordinates),
    distanceKm: routePlan.distanceKm,
    durationMinutes: routePlan.durationMinutes,
    lastUpdatedAt: plannedAt,
    estimatedArrivalAt: routeStops[routeStops.length - 1]?.estimatedAt || plannedAt,
    routeGeometry: routePlan.geometry.map((point) => normalizeCoordinatePair(point)).filter(hasCoordinates),
    routeStops,
  };
}

export async function buildMarketplaceLogisticsSnapshot({
  orderId = '',
  status = 'paid',
  createdAt = new Date(),
  sellerAddress = '',
  buyerAddress = '',
  sellerCoordinates = {},
  buyerCoordinates = {},
} = {}) {
  return buildServiceBackedSnapshot({
    orderId,
    status,
    createdAt,
    sellerAddress,
    buyerAddress,
    sellerCoordinates,
    buyerCoordinates,
    currentStopIndex: 0,
    progressPercent: 0,
  });
}

export async function ensureMarketplaceLogisticsSnapshot(order = {}, fallback = {}) {
  const sellerAddress = trimValue(order?.sellerAddress || fallback?.sellerAddress);
  const buyerAddress = trimValue(order?.buyerAddress || fallback?.buyerAddress);
  const sellerCoordinates = getMarketplaceCoordinateSnapshot(
    { profile: { coordinates: order?.sellerCoordinates || {} } },
    fallback?.sellerCoordinates || {},
  );
  const buyerCoordinates = getMarketplaceCoordinateSnapshot(
    { profile: { coordinates: order?.buyerCoordinates || {} } },
    fallback?.buyerCoordinates || {},
  );
  const rawLogistics = order?.logistics || {};

  return buildServiceBackedSnapshot({
    orderId: order?.orderId || fallback?.orderId || '',
    status: trimValue(order?.status || fallback?.status || 'paid'),
    createdAt: order?.createdAt || fallback?.createdAt || new Date(),
    sellerAddress,
    buyerAddress,
    sellerCoordinates,
    buyerCoordinates,
    currentStopIndex: Number(rawLogistics?.currentStopIndex || 0),
    progressPercent: Number(rawLogistics?.progressPercent || 0),
    lastUpdatedAt: rawLogistics?.lastUpdatedAt || null,
  });
}

export async function buildMarketplaceLogisticsView(order = {}, fallback = {}) {
  const logistics = await ensureMarketplaceLogisticsSnapshot(order, fallback);
  const lastStopIndex = Math.max(logistics.routeStops.length - 1, 0);
  const currentStopIndex = Math.max(0, Math.min(Number(logistics.currentStopIndex || 0), lastStopIndex));
  const progressPercent = clampProgress(logistics.progressPercent);

  const routeStops = logistics.routeStops.map((stop, index) => ({
    ...stop,
    state:
      index < currentStopIndex
        ? 'completed'
        : index === currentStopIndex
          ? currentStopIndex === lastStopIndex && progressPercent === 100 ? 'completed' : 'current'
          : index === currentStopIndex + 1 && progressPercent > 0
            ? 'up_next'
            : 'pending',
  }));

  return {
    trackingNumber: logistics.trackingNumber,
    providerMeta: logistics.providerMeta,
    simulationEnabled: logistics.simulationEnabled,
    simulationLockedReason: logistics.simulationLockedReason,
    currentStopIndex,
    progressPercent,
    currentLocation: logistics.currentLocation,
    distanceKm: logistics.distanceKm,
    durationMinutes: logistics.durationMinutes,
    parcelPhase:
      currentStopIndex === lastStopIndex
        ? progressPercent === 100 ? 'arrived_at_destination' : 'final_approach'
        : progressPercent > 0
          ? 'in_transit'
          : 'processing_stop',
    lastUpdatedAt: logistics.lastUpdatedAt,
    estimatedArrivalAt: logistics.estimatedArrivalAt,
    currentStop: routeStops[currentStopIndex] || null,
    nextStop: routeStops[currentStopIndex + 1] || null,
    totalStops: routeStops.length,
    completedStops: routeStops.filter((stop) => stop.state === 'completed').length,
    routeGeometry: Array.isArray(logistics.routeGeometry) ? logistics.routeGeometry : [],
    routeStops,
    timeline: buildTimelineEvents(
      {
        ...logistics,
        routeStops,
      },
      order,
    ),
  };
}

export async function applyMarketplaceLogisticsAction(order = {}, {
  action = 'advance',
  progressPercent = 0,
} = {}) {
  const current = await ensureMarketplaceLogisticsSnapshot(order);
  const lastStopIndex = Math.max(current.routeStops.length - 1, 0);
  let nextStopIndex = Number(current.currentStopIndex || 0);
  let nextProgress = clampProgress(current.progressPercent);

  if (action === 'reset') {
    nextStopIndex = 0;
    nextProgress = 0;
  } else if (action === 'rewind') {
    nextStopIndex = Math.max(0, nextStopIndex - 1);
    nextProgress = 0;
  } else if (action === 'set_progress') {
    nextProgress = clampProgress(progressPercent);
  } else if (action === 'advance') {
    if (nextStopIndex < lastStopIndex) {
      nextStopIndex += 1;
      nextProgress = 0;
    } else {
      nextProgress = 100;
    }
  }

  return buildServiceBackedSnapshot({
    orderId: order?.orderId || '',
    status: trimValue(order?.status || 'paid'),
    createdAt: order?.createdAt || new Date(),
    sellerAddress: order?.sellerAddress || '',
    buyerAddress: order?.buyerAddress || '',
    sellerCoordinates: getMarketplaceCoordinateSnapshot(
      { profile: { coordinates: order?.sellerCoordinates || {} } },
      {},
    ),
    buyerCoordinates: getMarketplaceCoordinateSnapshot(
      { profile: { coordinates: order?.buyerCoordinates || {} } },
      {},
    ),
    currentStopIndex: nextStopIndex,
    progressPercent: nextProgress,
    lastUpdatedAt: new Date(),
  });
}

export function getMarketplaceAddressSnapshot(user = {}, fallbackAddress = '') {
  const profileAddress = trimValue(user?.profile?.address);
  const farmLocation = trimValue(user?.profile?.location);
  return profileAddress || farmLocation || trimValue(fallbackAddress);
}

export function getMarketplaceCoordinateSnapshot(user = {}, fallbackCoordinates = {}) {
  const profileCoordinates = normalizeCoordinatePair(user?.profile?.coordinates || {});

  if (hasCoordinates(profileCoordinates)) {
    return profileCoordinates;
  }

  return normalizeCoordinatePair(fallbackCoordinates);
}

export function getMarketplaceRouteHeadline(logisticsView = {}) {
  const currentStop = trimValue(logisticsView?.currentStop?.label);
  const nextStop = trimValue(logisticsView?.nextStop?.label);

  if (currentStop && nextStop) {
    return `${currentStop} to ${nextStop}`;
  }

  if (currentStop) {
    return currentStop;
  }

  return 'Route service pending';
}

export function getShortDeliveryAddress(address = '') {
  return shortenAddress(address, 3);
}
