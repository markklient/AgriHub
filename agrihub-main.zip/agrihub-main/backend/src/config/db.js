import mongoose from 'mongoose';
import { User } from '../models/User.js';

async function repairGoogleIdIndex() {
  const collection = User.collection;
  let indexes = [];

  try {
    indexes = await collection.indexes();
  } catch (error) {
    const namespaceMissing = error?.code === 26
      || String(error?.message || '').includes('ns does not exist');

    // A fresh database may not have created the collection yet.
    if (namespaceMissing) {
      return;
    }

    throw error;
  }

  const googleIndex = indexes.find((index) => index.name === 'googleId_1');

  if (
    googleIndex &&
    !googleIndex.partialFilterExpression
  ) {
    await collection.dropIndex('googleId_1');
  }

  await collection.createIndex(
    { googleId: 1 },
    {
      name: 'googleId_1',
      unique: true,
      partialFilterExpression: {
        googleId: {
          $type: 'string',
        },
      },
    },
  );
}

export async function connectToDatabase() {
  const mongoUri = process.env.MONGODB_URI;

  if (!mongoUri) {
    throw new Error('MONGODB_URI is missing. Add it to your environment variables or .env file.');
  }

  await mongoose.connect(mongoUri);
  await repairGoogleIdIndex();
  console.log('MongoDB connected');
}
