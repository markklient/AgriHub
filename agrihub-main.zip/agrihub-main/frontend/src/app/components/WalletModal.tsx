import { useEffect, useState } from 'react';
import { Building2, Smartphone, Wallet, X } from 'lucide-react';
import { getWalletSummary, requestWalletCashOut } from '../../features/app/api';
import { SessionUser } from '../../shared/auth/session';
import { formatPhpCurrency } from '../../shared/format/currency';

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessionUser: SessionUser | null;
  onUserUpdated: (user: any) => void;
}

const cashOutOptions = [
  { id: 'gcash' as const, label: 'GCash', icon: Wallet },
  { id: 'paymaya' as const, label: 'PayMaya', icon: Smartphone },
  { id: 'bank' as const, label: 'Bank', icon: Building2 },
];

const supportedBanks = [
  { code: 'PH_BDO', name: 'BDO Unibank' },
  { code: 'PH_BPI', name: 'Bank of the Philippine Islands (BPI)' },
  { code: 'PH_METROBANK', name: 'Metrobank' },
  { code: 'PH_LANDBANK', name: 'Land Bank of the Philippines' },
  { code: 'PH_UBP', name: 'UnionBank' },
  { code: 'PH_RCBC', name: 'RCBC' },
  { code: 'PH_SEC', name: 'Security Bank' },
  { code: 'PH_PNB', name: 'Philippine National Bank (PNB)' },
  { code: 'PH_CHB', name: 'China Banking Corporation' },
];

export function WalletModal({ isOpen, onClose, sessionUser, onUserUpdated }: WalletModalProps) {
  const [wallet, setWallet] = useState<any>(sessionUser?.wallet || null);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'gcash' | 'paymaya' | 'bank'>('gcash');
  const [accountName, setAccountName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [bankCode, setBankCode] = useState(supportedBanks[0]?.code || '');
  const [accountNumber, setAccountNumber] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (!isOpen || !sessionUser) {
      return;
    }

    setWallet(sessionUser.wallet || null);
    setLoading(true);
    setMessage(null);

    getWalletSummary()
      .then((response) => {
        setWallet(response.wallet || null);
      })
      .catch((error) => {
        setMessage({
          type: 'error',
          text: error instanceof Error ? error.message : 'Unable to load wallet details right now.',
        });
      })
      .finally(() => setLoading(false));
  }, [isOpen, sessionUser]);

  if (!isOpen || !sessionUser) {
    return null;
  }

  const balance = Number(wallet?.balance || 0);
  const totalEarned = Number(wallet?.totalEarned || 0);
  const totalWithdrawn = Number(wallet?.totalWithdrawn || 0);
  const transactions = Array.isArray(wallet?.transactions) ? wallet.transactions.slice(0, 5) : [];

  const resetCashOutFields = () => {
    setAmount('');
    setAccountName('');
    setMobileNumber('');
    setBankCode(supportedBanks[0]?.code || '');
    setAccountNumber('');
  };

  const handleCashOut = async () => {
    setSubmitting(true);
    setMessage(null);

    try {
      if (!accountName.trim()) {
        throw new Error('Account name is required.');
      }

      if (method !== 'bank' && !mobileNumber.trim()) {
        throw new Error('Mobile number is required.');
      }

      if (method === 'bank' && !accountNumber.trim()) {
        throw new Error('Account number is required.');
      }

      const response = await requestWalletCashOut({
        amount: Number(amount),
        method,
        accountName,
        mobileNumber,
        bankCode: method === 'bank' ? bankCode : undefined,
        bankName: method === 'bank' ? supportedBanks.find((bank) => bank.code === bankCode)?.name || '' : undefined,
        accountNumber: method === 'bank' ? accountNumber : undefined,
      });

      setWallet(response.wallet || null);
      onUserUpdated(response.user);
      setMessage({
        type: 'success',
        text: response.message || 'Wallet cash out completed successfully.',
      });
      resetCashOutFields();
    } catch (error) {
      setMessage({
        type: 'error',
        text: error instanceof Error ? error.message : 'Unable to process the cash out right now.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 py-6 responsive-modal-shell">
      <button type="button" aria-label="Close wallet" className="absolute inset-0 cursor-default" onClick={onClose} />
      <div className="responsive-modal-panel relative z-10 flex w-full max-w-3xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
        <div className="responsive-modal-header rounded-t-3xl bg-gradient-to-r from-emerald-600 to-green-500 text-white">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-emerald-100">AgriHub Wallet</p>
              <h3 className="mt-2 text-2xl font-semibold">Your earnings in one place</h3>
              <p className="mt-1 text-sm text-emerald-50">
                Completed labor earnings go here automatically. Cash out anytime to GCash, PayMaya, or bank account through Xendit.
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-white/30 p-2 text-white transition-colors hover:bg-white/10"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="responsive-modal-body space-y-6 overflow-y-auto">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-2xl border border-emerald-100 bg-emerald-50/80 p-5">
              <p className="text-xs uppercase tracking-wide text-emerald-600">Available Balance</p>
              <p className="mt-2 text-2xl font-bold text-emerald-700">{formatPhpCurrency(balance)}</p>
            </div>
            <div className="rounded-2xl border border-gray-200 bg-gray-50 p-5">
              <p className="text-xs uppercase tracking-wide text-gray-500">Total Earned</p>
              <p className="mt-2 text-xl font-semibold text-gray-900">{formatPhpCurrency(totalEarned)}</p>
            </div>
            <div className="rounded-2xl border border-gray-200 bg-gray-50 p-5">
              <p className="text-xs uppercase tracking-wide text-gray-500">Total Cashed Out</p>
              <p className="mt-2 text-xl font-semibold text-gray-900">{formatPhpCurrency(totalWithdrawn)}</p>
            </div>
          </div>

          <div className="responsive-modal-grid grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
            <div className="rounded-2xl border border-gray-200 p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-semibold text-gray-900">Cash Out</h4>
                  <p className="mt-1 text-sm text-gray-500">Choose where to send your wallet balance.</p>
                </div>
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-3">
                {cashOutOptions.map((option) => {
                  const Icon = option.icon;
                  const isSelected = method === option.id;

                  return (
                    <button
                      key={option.id}
                      type="button"
                      onClick={() => setMethod(option.id)}
                      className={`rounded-2xl border px-4 py-4 text-left transition-colors ${
                        isSelected
                          ? 'border-green-500 bg-green-50 shadow-sm'
                          : 'border-gray-200 bg-white hover:border-green-200 hover:bg-green-50/50'
                      }`}
                    >
                      <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${
                        isSelected ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-600'
                      }`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <p className="mt-3 text-sm font-semibold text-gray-900">{option.label}</p>
                    </button>
                  );
                })}
              </div>

              <div className="mt-5 space-y-4">
                <div>
                  <label className="mb-2 block text-sm font-medium text-gray-700">Amount</label>
                  <input
                    type="number"
                    min="1"
                    step="0.01"
                    value={amount}
                    onChange={(event) => setAmount(event.target.value)}
                    placeholder="0.00"
                    className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm font-medium text-gray-700">Account Name</label>
                  <input
                    type="text"
                    value={accountName}
                    onChange={(event) => setAccountName(event.target.value)}
                    className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                {method === 'bank' ? (
                  <>
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Bank</label>
                      <select
                        value={bankCode}
                        onChange={(event) => setBankCode(event.target.value)}
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        {supportedBanks.map((bank) => (
                          <option key={bank.code} value={bank.code}>
                            {bank.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Account Number</label>
                      <input
                        type="text"
                        value={accountNumber}
                        onChange={(event) => setAccountNumber(event.target.value)}
                        placeholder="Enter bank account number"
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </>
                ) : (
                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700">Mobile Number</label>
                    <input
                      type="tel"
                      value={mobileNumber}
                      onChange={(event) => setMobileNumber(event.target.value)}
                      placeholder="09XXXXXXXXX"
                      className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                )}

                <p className="text-xs text-gray-500">
                  This cash-out request is sent to Xendit using your selected {method === 'bank' ? 'bank' : 'wallet'} channel.
                </p>
              </div>

              {message ? (
                <div
                  className={`mt-5 rounded-2xl border px-4 py-3 text-sm ${
                    message.type === 'success'
                      ? 'border-green-200 bg-green-50 text-green-700'
                      : 'border-red-200 bg-red-50 text-red-700'
                  }`}
                >
                  {message.text}
                </div>
              ) : null}

              <div className="mt-5 flex gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  disabled={submitting}
                  className="flex-1 rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={handleCashOut}
                  disabled={submitting || loading}
                  className="flex-1 rounded-2xl bg-emerald-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-emerald-700 disabled:cursor-not-allowed disabled:bg-emerald-300"
                >
                  {submitting ? 'Processing...' : 'Cash Out'}
                </button>
              </div>
            </div>

            <div className="rounded-2xl border border-gray-200 p-5">
              <h4 className="text-sm font-semibold text-gray-900">Recent Wallet Activity</h4>
              <div className="mt-4 space-y-3">
                {loading ? (
                  <p className="text-sm text-gray-500">Loading wallet activity...</p>
                ) : transactions.length === 0 ? (
                  <p className="text-sm text-gray-500">No wallet activity yet.</p>
                ) : (
                  transactions.map((transaction: any) => (
                    <div key={transaction.id} className="rounded-xl border border-gray-100 bg-gray-50 px-4 py-3">
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <p className="text-sm font-medium text-gray-900">{transaction.description || transaction.type}</p>
                          <p className="mt-1 text-xs text-gray-500">
                            {transaction.destinationLabel || transaction.method || 'Wallet'}
                          </p>
                        </div>
                        <p className={`text-sm font-semibold ${transaction.type === 'credit' ? 'text-green-700' : 'text-gray-900'}`}>
                          {transaction.type === 'credit' ? '+' : '-'}
                          {formatPhpCurrency(Number(transaction.amount || 0))}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
