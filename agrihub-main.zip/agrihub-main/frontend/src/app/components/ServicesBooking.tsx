import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from 'react';
import {
  Calendar,
  Camera,
  Clock3,
  Eye,
  FolderKanban,
  ImagePlus,
  MapPin,
  PackageCheck,
  Phone,
  Plus,
  Truck,
  UserCircle2,
  Wrench,
  X,
} from 'lucide-react';
import { useSearchParams } from 'react-router';
import {
  cancelServiceBooking,
  createRentalListingUploadUrl,
  getCurrentUserProfile,
  getServicesData,
  markServiceBookingCompleted,
  markServiceBookingPickedUp,
  upsertRentalListing,
} from '../../features/app/api';
import { persistSessionUser } from '../../shared/auth/session';
import { SessionUser } from '../../shared/auth/session';
import { formatPhpCurrency } from '../../shared/format/currency';
import { addStoredNotification } from '../../shared/notifications/store';
import { requireSupabaseClient } from '../../shared/supabase/client';

interface ServicesBookingProps {
  onBookService: (service: any) => void;
  currentUser: SessionUser | null;
}

interface RentalListing {
  listingId: string;
  name: string;
  category: string;
  description: string;
  condition?: string;
  identifier?: string;
  location: string;
  rate: number;
  price?: number;
  unit: string;
  minimumOrder: number;
  quantity: number;
  available: boolean;
  status: string;
  ownerRole?: string;
  seller?: string;
  provider?: string;
  ownerUserId?: string;
  ownerPhone?: string;
  image?: string;
  images?: string[];
  imagePaths?: string[];
  canEdit?: boolean;
}

interface RentalBooking {
  id: number;
  service: string;
  provider: string;
  providerUserId?: string;
  customer?: string;
  customerUserId?: string;
  listingId?: string;
  date: string;
  time: string;
  duration: string;
  location: string;
  status: 'confirmed' | 'pending' | 'cancelled' | string;
  description: string;
  rate: string;
  contact: string;
  bookingRef: string;
  pickupConfirmation?: {
    customerConfirmedAt?: string | null;
    providerConfirmedAt?: string | null;
  };
  completionConfirmation?: {
    customerConfirmedAt?: string | null;
    providerConfirmedAt?: string | null;
  };
  completedAt?: string | null;
}

interface RentalListingFormState {
  listingId: string;
  name: string;
  description: string;
  condition: string;
  identifier: string;
  location: string;
  rate: string;
  unit: string;
  quantity: string;
}

interface RentalCancellationState {
  booking: RentalBooking | null;
  reason: string;
}

type OwnerDashboardSection = 'listings' | 'requests' | 'history';

const ownerDashboardSectionContent = {
  listings: {
    title: 'My Equipment Rental Listings',
    subtitle: 'Manage your active rental inventory and update the details customers can see.',
  },
  requests: {
    title: 'Rental Requests',
    subtitle: 'Review incoming bookings for your equipment rentals and take action from one place.',
  },
  history: {
    title: 'Rental History',
    subtitle: 'Review completed and cancelled rental activity from your owner side.',
  },
} as const;

const rentalUnits = ['hour', 'day', 'week', 'trip'];

function getServicesViewFromSearchParams(searchParams: URLSearchParams) {
  const requestedView = String(searchParams.get('servicesTab') || '').trim().toLowerCase();

  if (requestedView === 'bookings') {
    return 'bookings' as const;
  }

  if (requestedView === 'history') {
    return 'history' as const;
  }

  if (requestedView === 'dashboard' || requestedView === 'listings' || requestedView === 'requests') {
    return 'dashboard' as const;
  }

  return 'browse' as const;
}

function getOwnerDashboardSectionFromSearchParams(searchParams: URLSearchParams): OwnerDashboardSection {
  const requestedSection = String(searchParams.get('rentalDashboardSection') || '').trim().toLowerCase();

  if (requestedSection === 'requests' || requestedSection === 'history') {
    return requestedSection;
  }

  return 'listings';
}

function buildEmptyRentalForm(locationOptions: string[] = []): RentalListingFormState {
  return {
    listingId: '',
    name: '',
    description: '',
    condition: '',
    identifier: '',
    location: locationOptions[0] || '',
    rate: '',
    unit: 'day',
    quantity: '1',
  };
}

function normalizeBookingStatus(status: string) {
  const normalized = String(status || '').trim().toLowerCase();

  if (normalized === 'completed') {
    return {
      label: 'Completed',
      className: 'bg-emerald-100 text-emerald-800',
    };
  }

  if (normalized === 'confirmed') {
    return {
      label: 'Confirmed',
      className: 'bg-emerald-50 text-emerald-700',
    };
  }

  if (normalized === 'cancelled') {
    return {
      label: 'Cancelled',
      className: 'bg-red-50 text-red-600',
    };
  }

  return {
    label: 'Pending',
    className: 'bg-amber-50 text-amber-700',
  };
}

function summarizeRentalLocation(location: string) {
  const segments = String(location || '')
    .split(',')
    .map((segment) => segment.trim())
    .filter(Boolean);

  if (segments.length === 0) {
    return 'Pickup location not specified';
  }

  return segments.slice(0, 2).join(', ');
}

function formatBookingTimeLabel(value: string) {
  const trimmed = String(value || '').trim();

  if (!/^\d{1,2}:\d{2}$/.test(trimmed)) {
    return trimmed || 'Not specified';
  }

  const [hours, minutes] = trimmed.split(':').map(Number);
  const period = hours >= 12 ? 'PM' : 'AM';
  const normalizedHours = hours % 12 || 12;
  return `${normalizedHours}:${String(minutes).padStart(2, '0')} ${period}`;
}

function convertClockTimeToMinutes(value: string) {
  const normalized = String(value || '').trim();

  if (!/^\d{1,2}:\d{2}$/.test(normalized)) {
    return null;
  }

  const [hours, minutes] = normalized.split(':').map(Number);

  if (!Number.isFinite(hours) || !Number.isFinite(minutes)) {
    return null;
  }

  return hours * 60 + minutes;
}

function getCurrentManilaDateTimeParts() {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Manila',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  });
  const lookup = Object.fromEntries(formatter.formatToParts(new Date()).map((part) => [part.type, part.value]));

  return {
    date: `${lookup.year || '0000'}-${lookup.month || '00'}-${lookup.day || '00'}`,
    time: `${lookup.hour || '00'}:${lookup.minute || '00'}`,
  };
}

function hasRentalBookingStarted(booking: RentalBooking) {
  const bookingDate = String(booking?.date || '').trim();
  const bookingTime = String(booking?.time || '').trim();

  if (!bookingDate) {
    return false;
  }

  const { date: currentDate, time: currentTime } = getCurrentManilaDateTimeParts();

  if (bookingDate < currentDate) {
    return true;
  }

  if (bookingDate > currentDate) {
    return false;
  }

  const bookingMinutes = convertClockTimeToMinutes(bookingTime);
  const currentMinutes = convertClockTimeToMinutes(currentTime);

  if (bookingMinutes === null || currentMinutes === null) {
    return true;
  }

  return currentMinutes >= bookingMinutes;
}

function hasCustomerConfirmedCompletion(booking: RentalBooking) {
  return Boolean(booking?.completionConfirmation?.customerConfirmedAt);
}

function hasProviderConfirmedCompletion(booking: RentalBooking) {
  return Boolean(booking?.completionConfirmation?.providerConfirmedAt);
}

function hasCustomerConfirmedPickup(booking: RentalBooking) {
  return Boolean(booking?.pickupConfirmation?.customerConfirmedAt);
}

function hasProviderConfirmedPickup(booking: RentalBooking) {
  return Boolean(booking?.pickupConfirmation?.providerConfirmedAt);
}

function haveBothSidesConfirmedPickup(booking: RentalBooking) {
  return hasCustomerConfirmedPickup(booking) && hasProviderConfirmedPickup(booking);
}

function hasAnyPickupConfirmation(booking: RentalBooking) {
  return hasCustomerConfirmedPickup(booking) || hasProviderConfirmedPickup(booking);
}

function getRentalCompletionNotice(booking: RentalBooking, isOwnerView: boolean) {
  const customerPickedUp = hasCustomerConfirmedPickup(booking);
  const providerPickedUp = hasProviderConfirmedPickup(booking);
  const customerConfirmed = hasCustomerConfirmedCompletion(booking);
  const providerConfirmed = hasProviderConfirmedCompletion(booking);

  if (customerConfirmed && providerConfirmed) {
    return 'Completed by both sides. The payout has been released to the owner wallet.';
  }

  if (!hasRentalBookingStarted(booking)) {
    return `Confirm Pickup becomes available once the booking starts at ${formatBookingTimeLabel(booking.time)} on ${booking.date}.`;
  }

  if (isOwnerView) {
    if (!providerPickedUp) {
      return 'Confirm pickup once the equipment has been handed to the customer.';
    }

    return providerConfirmed
      ? 'Pickup confirmed on your side. Waiting for the customer to confirm.'
      : customerPickedUp
        ? 'Pickup is confirmed. Mark the rental completed when it has been returned or finished.'
        : 'Pickup confirmed on your side. Waiting for the customer to confirm pickup.';
  }

  if (!customerPickedUp) {
    return 'Confirm pickup after you receive the rental from the owner.';
  }

  return customerConfirmed
    ? 'Pickup confirmed on your side. Waiting for the owner to confirm.'
    : providerPickedUp
      ? 'Pickup is confirmed. Mark the rental completed when you are done with it.'
      : 'Pickup confirmed on your side. Waiting for the owner to confirm pickup.';
}

export function ServicesBooking({ onBookService, currentUser }: ServicesBookingProps) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [activeView, setActiveView] = useState<'browse' | 'bookings' | 'history' | 'dashboard'>(() => getServicesViewFromSearchParams(searchParams));
  const [rentals, setRentals] = useState<RentalListing[]>([]);
  const [myRentals, setMyRentals] = useState<RentalListing[]>([]);
  const [bookings, setBookings] = useState<RentalBooking[]>([]);
  const [incomingBookings, setIncomingBookings] = useState<RentalBooking[]>([]);
  const [canManageRentals, setCanManageRentals] = useState(false);
  const [locationOptions, setLocationOptions] = useState<string[]>([]);
  const [selectedRental, setSelectedRental] = useState<RentalListing | null>(null);
  const [viewingBooking, setViewingBooking] = useState<RentalBooking | null>(null);
  const [isListingModalOpen, setIsListingModalOpen] = useState(false);
  const [cancellationState, setCancellationState] = useState<RentalCancellationState>({ booking: null, reason: '' });
  const [ownerDashboardSection, setOwnerDashboardSection] = useState<OwnerDashboardSection>(() => getOwnerDashboardSectionFromSearchParams(searchParams));
  const [listingForm, setListingForm] = useState<RentalListingFormState>(() => buildEmptyRentalForm([]));
  const [listingImages, setListingImages] = useState<File[]>([]);
  const [listingImagePreviews, setListingImagePreviews] = useState<string[]>([]);
  const [listingError, setListingError] = useState('');
  const [isSavingListing, setIsSavingListing] = useState(false);
  const [cancellingBookingRef, setCancellingBookingRef] = useState('');
  const [pickingUpBookingRef, setPickingUpBookingRef] = useState('');
  const [completingBookingRef, setCompletingBookingRef] = useState('');
  const isCommerciallyRestricted = currentUser?.canManageCommercialFeatures === false;

  const loadServicesData = () => {
    getServicesData()
      .then((payload) => {
        setRentals(Array.isArray(payload?.rentals) ? payload.rentals : []);
        setMyRentals(Array.isArray(payload?.myRentals) ? payload.myRentals : []);
        setBookings(Array.isArray(payload?.bookings) ? payload.bookings : []);
        setIncomingBookings(Array.isArray(payload?.incomingBookings) ? payload.incomingBookings : []);
        setCanManageRentals(Boolean(payload?.canManageRentals));
        setLocationOptions(Array.isArray(payload?.locationOptions) ? payload.locationOptions.filter(Boolean) : []);
      })
      .catch(() => undefined);
  };

  useEffect(() => {
    loadServicesData();

    const handleServicesUpdated = () => {
      loadServicesData();
    };

    window.addEventListener('agrihub:service-bookings-updated', handleServicesUpdated);

    return () => {
      window.removeEventListener('agrihub:service-bookings-updated', handleServicesUpdated);
    };
  }, []);

  useEffect(() => {
    setListingForm((current) => {
      if (current.location || locationOptions.length === 0) {
        return current;
      }

      return {
        ...current,
        location: locationOptions[0],
      };
    });
  }, [locationOptions]);

  useEffect(() => {
    const nextView = getServicesViewFromSearchParams(searchParams);
    setActiveView((current) => (current === nextView ? current : nextView));
  }, [searchParams]);

  useEffect(() => {
    const nextSection = getOwnerDashboardSectionFromSearchParams(searchParams);
    setOwnerDashboardSection((current) => (current === nextSection ? current : nextSection));
  }, [searchParams]);

  useEffect(() => {
    const requestedBookingRef = String(searchParams.get('serviceBookingRef') || '').trim();

    if (!requestedBookingRef) {
      return;
    }

    const matchingBooking = bookings.find(
      (booking) => String(booking?.bookingRef || '').trim() === requestedBookingRef,
    );

    if (matchingBooking) {
      setViewingBooking(matchingBooking);
      setActiveView('bookings');
      setSearchParams((current) => {
        const next = new URLSearchParams(current);
        next.delete('serviceBookingRef');
        return next;
      }, { replace: true });
    }
  }, [bookings, searchParams, setSearchParams]);

  const updateServicesView = (nextView: 'browse' | 'bookings' | 'history' | 'dashboard') => {
    setActiveView(nextView);

    const nextParams = new URLSearchParams(searchParams);
    nextParams.set('servicesTab', nextView);
    if (nextView !== 'dashboard') {
      nextParams.delete('rentalDashboardSection');
    } else if (!nextParams.get('rentalDashboardSection')) {
      nextParams.set('rentalDashboardSection', ownerDashboardSection);
    }
    setSearchParams(nextParams, { replace: true });
  };

  const updateOwnerDashboardSection = (nextSection: OwnerDashboardSection) => {
    setOwnerDashboardSection(nextSection);
    setSearchParams((current) => {
      const next = new URLSearchParams(current);
      next.set('servicesTab', 'dashboard');
      next.set('rentalDashboardSection', nextSection);
      return next;
    }, { replace: true });
  };

  const availableRentals = useMemo(
    () => rentals.filter((listing) => listing.status === 'active' && listing.available),
    [rentals],
  );
  const activeCustomerBookings = useMemo(
    () => bookings.filter((booking) => !['completed', 'cancelled'].includes(String(booking.status || '').trim().toLowerCase())),
    [bookings],
  );
  const customerBookingHistory = useMemo(
    () => bookings.filter((booking) => ['completed', 'cancelled'].includes(String(booking.status || '').trim().toLowerCase())),
    [bookings],
  );
  const ownerActiveRequests = useMemo(
    () => incomingBookings.filter((booking) => !['completed', 'cancelled'].includes(String(booking.status || '').trim().toLowerCase())),
    [incomingBookings],
  );
  const ownerBookingHistory = useMemo(
    () => incomingBookings.filter((booking) => ['completed', 'cancelled'].includes(String(booking.status || '').trim().toLowerCase())),
    [incomingBookings],
  );
  const bookingListingLookup = useMemo(() => {
    const lookup = new Map<string, RentalListing>();
    [...rentals, ...myRentals].forEach((listing) => {
      const key = `${String(listing.name || '').trim().toLowerCase()}::${String(listing.provider || listing.seller || '').trim().toLowerCase()}`;

      if (!lookup.has(key)) {
        lookup.set(key, listing);
      }
    });
    return lookup;
  }, [myRentals, rentals]);

  const handleConfirmRentalCompleted = async (booking: RentalBooking, isOwnerView: boolean) => {
    const bookingRef = String(booking?.bookingRef || '').trim();

    if (!bookingRef || !currentUser?.id) {
      return;
    }

    setCompletingBookingRef(bookingRef);

    try {
      const response = await markServiceBookingCompleted(bookingRef);

      addStoredNotification(currentUser.id, {
        sourceKey: `rental-completion-${bookingRef}-${response.completed ? 'completed' : 'confirmed'}`,
        type: response.completed ? 'success' : 'info',
        title: response.completed ? 'Rental booking completed' : 'Completion recorded',
        message: response.message,
      });

      await getCurrentUserProfile()
        .then(({ user }) => {
          if (user) {
            persistSessionUser(user);
          }
        })
        .catch(() => undefined);

      loadServicesData();
      window.dispatchEvent(new Event('agrihub:service-bookings-updated'));

      setViewingBooking((current) =>
        current && String(current.bookingRef || '').trim() === bookingRef
          ? { ...current, ...(response.booking || {}) }
          : current,
      );
    } catch (error) {
      addStoredNotification(currentUser.id, {
        sourceKey: `rental-completion-${bookingRef}-error`,
        type: 'warning',
        title: isOwnerView ? 'Owner completion failed' : 'Customer completion failed',
        message: error instanceof Error ? error.message : 'Unable to mark the rental booking as completed right now.',
      });
    } finally {
      setCompletingBookingRef('');
    }
  };

  const handleConfirmRentalPickup = async (booking: RentalBooking, isOwnerView: boolean) => {
    const bookingRef = String(booking?.bookingRef || '').trim();

    if (!bookingRef || !currentUser?.id) {
      return;
    }

    setPickingUpBookingRef(bookingRef);

    try {
      const response = await markServiceBookingPickedUp(bookingRef);

      addStoredNotification(currentUser.id, {
        sourceKey: `rental-pickup-${bookingRef}`,
        type: 'success',
        title: 'Pickup confirmed',
        message: response.message,
      });

      loadServicesData();
      window.dispatchEvent(new Event('agrihub:service-bookings-updated'));
      setViewingBooking((current) =>
        current && String(current.bookingRef || '').trim() === bookingRef
          ? { ...current, ...(response.booking || {}) }
          : current,
      );
    } catch (error) {
      addStoredNotification(currentUser.id, {
        sourceKey: `rental-pickup-${bookingRef}-error`,
        type: 'warning',
        title: isOwnerView ? 'Owner pickup confirmation failed' : 'Customer pickup confirmation failed',
        message: error instanceof Error ? error.message : 'Unable to confirm rental pickup right now.',
      });
    } finally {
      setPickingUpBookingRef('');
    }
  };

  const handleCallBookingContact = (booking: RentalBooking) => {
    const phoneNumber = String(booking?.contact || '').trim();

    if (!phoneNumber || !currentUser?.id) {
      if (currentUser?.id) {
        addStoredNotification(currentUser.id, {
          sourceKey: `rental-contact-${booking.bookingRef || booking.id}`,
          type: 'warning',
          title: 'No contact number',
          message: 'No phone number is available for this rental booking right now.',
        });
      }
      return;
    }

    const normalizedPhoneNumber = phoneNumber.replace(/[^\d+]/g, '');
    window.location.href = `tel:${normalizedPhoneNumber || phoneNumber}`;
  };

  const handleOpenRentalCancellation = (booking: RentalBooking) => {
    setCancellationState({
      booking,
      reason: '',
    });
  };

  const handleCancelRentalBooking = async () => {
    const booking = cancellationState.booking;
    const bookingRef = String(booking?.bookingRef || '').trim();

    if (!bookingRef || !currentUser?.id) {
      return;
    }

    const cancellationReason = cancellationState.reason.trim();

    if (!cancellationReason) {
      addStoredNotification(currentUser.id, {
        sourceKey: `rental-cancel-${bookingRef}-missing-reason`,
        type: 'warning',
        title: 'Cancellation reason required',
        message: 'Please enter a reason before cancelling this rental booking.',
      });
      return;
    }

    setCancellingBookingRef(bookingRef);

    try {
      const response = await cancelServiceBooking(bookingRef, cancellationReason);

      addStoredNotification(currentUser.id, {
        sourceKey: `rental-cancel-${bookingRef}`,
        type: response.refunded ? 'success' : 'info',
        title: 'Rental booking cancelled',
        message: response.message,
      });

      await getCurrentUserProfile()
        .then(({ user }) => {
          if (user) {
            persistSessionUser(user);
          }
        })
        .catch(() => undefined);

      loadServicesData();
      window.dispatchEvent(new Event('agrihub:service-bookings-updated'));
      setViewingBooking((current) =>
        current && String(current.bookingRef || '').trim() === bookingRef
          ? { ...current, ...(response.booking || {}) }
          : current,
      );
      setCancellationState({ booking: null, reason: '' });
    } catch (error) {
      addStoredNotification(currentUser.id, {
        sourceKey: `rental-cancel-${bookingRef}-error`,
        type: 'warning',
        title: 'Rental cancellation failed',
        message: error instanceof Error ? error.message : 'Unable to cancel this rental booking right now.',
      });
    } finally {
      setCancellingBookingRef('');
    }
  };

  const segmentedOptions = [
    {
      id: 'browse' as const,
      label: 'Browse Rentals',
      count: availableRentals.length,
      icon: Truck,
      disabled: false,
    },
    {
      id: 'bookings' as const,
      label: 'Rental Bookings',
      count: activeCustomerBookings.length,
      icon: PackageCheck,
      disabled: false,
    },
    {
      id: 'history' as const,
      label: 'History',
      count: customerBookingHistory.length,
      icon: FolderKanban,
      disabled: false,
    },
    {
      id: 'dashboard' as const,
      label: 'My Rental Dashboard',
      count: myRentals.length + ownerActiveRequests.length + ownerBookingHistory.length,
      icon: Wrench,
      disabled: !canManageRentals,
      hidden: !canManageRentals,
    },
  ].filter((option) => !option.hidden);

  const ownerDashboardOptions: Array<{
    id: OwnerDashboardSection;
    label: string;
    count: number;
  }> = [
    {
      id: 'listings',
      label: 'My Equipment Rental Listings',
      count: myRentals.length,
    },
    {
      id: 'requests',
      label: 'Rental Requests',
      count: ownerActiveRequests.length,
    },
    {
      id: 'history',
      label: 'Rental History',
      count: ownerBookingHistory.length,
    },
  ];

  const openCreateListingModal = () => {
    setListingForm(buildEmptyRentalForm(locationOptions));
    setListingImages([]);
    setListingImagePreviews([]);
    setListingError('');
    setIsListingModalOpen(true);
  };

  const openEditListingModal = (listing: RentalListing) => {
      setListingForm({
        listingId: listing.listingId,
        name: listing.name,
        description: listing.description,
        condition: String(listing.condition || ''),
        identifier: String(listing.identifier || ''),
        location: listing.location,
        rate: String(listing.rate || listing.price || ''),
        unit: listing.unit || 'day',
        quantity: String(listing.quantity || 1),
      });
    setListingImages([]);
    setListingImagePreviews(Array.isArray(listing.images) ? listing.images.slice(0, 3) : listing.image ? [listing.image] : []);
    setListingError('');
    setIsListingModalOpen(true);
  };

  const handleImageSelection = (event: ChangeEvent<HTMLInputElement>) => {
    const imageFiles = Array.from(event.target.files || []).slice(0, 3);
    setListingImages(imageFiles);
    setListingImagePreviews(imageFiles.map((file) => URL.createObjectURL(file)));
    setListingError('');
  };

  const handleSaveListing = async (event: FormEvent) => {
    event.preventDefault();
    setListingError('');

    try {
      if (!canManageRentals) {
        throw new Error('Only sellers and laborers can publish equipment rentals.');
      }

      if (!listingForm.name.trim() || !listingForm.description.trim() || !listingForm.location.trim()) {
        throw new Error('Rental name, description, and location are required.');
      }

      if (!listingForm.listingId && listingImages.length < 1) {
        throw new Error('Upload at least 1 rental photo.');
      }

      if (listingImages.length > 3 || listingImagePreviews.length > 3) {
        throw new Error('Upload at most 3 rental photos.');
      }

      setIsSavingListing(true);
      const supabase = requireSupabaseClient();
      let nextImagePaths = listingForm.listingId
        ? myRentals.find((listing) => listing.listingId === listingForm.listingId)?.imagePaths || []
        : [];

      if (listingImages.length > 0) {
        nextImagePaths = [];

        for (const file of listingImages) {
          const uploadTarget = await createRentalListingUploadUrl({ fileName: file.name });
          const { error } = await supabase.storage
            .from(uploadTarget.bucket)
            .uploadToSignedUrl(uploadTarget.path, uploadTarget.token, file);

          if (error) {
            throw error;
          }

          nextImagePaths.push(uploadTarget.path);
        }
      }

      const response = await upsertRentalListing({
        listingId: listingForm.listingId || undefined,
        name: listingForm.name.trim(),
        category: 'equipment-rental',
        description: listingForm.description.trim(),
        condition: listingForm.condition.trim(),
        identifier: listingForm.identifier.trim(),
        location: listingForm.location.trim(),
        rate: Number(listingForm.rate || 0),
        unit: listingForm.unit,
        minimumOrder: 1,
        quantity: Number(listingForm.quantity || 0),
        imagePaths: nextImagePaths,
      });

      const savedListing = response.listing as RentalListing;
      setMyRentals((current) => {
        const existingIndex = current.findIndex((listing) => listing.listingId === savedListing.listingId);

        if (existingIndex >= 0) {
          const next = [...current];
          next[existingIndex] = savedListing;
          return next;
        }

        return [savedListing, ...current];
      });
      setRentals((current) => {
        const existingIndex = current.findIndex((listing) => listing.listingId === savedListing.listingId);

        if (existingIndex >= 0) {
          const next = [...current];
          next[existingIndex] = savedListing;
          return next;
        }

        return [savedListing, ...current];
      });
      setIsListingModalOpen(false);
    } catch (error) {
      setListingError(error instanceof Error ? error.message : 'Unable to save the rental listing right now.');
    } finally {
      setIsSavingListing(false);
    }
  };

  const renderRentalCard = (listing: RentalListing) => (
    <div
      key={listing.listingId}
      role="button"
      tabIndex={0}
      onClick={() => setSelectedRental(listing)}
      onKeyDown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          setSelectedRental(listing);
        }
      }}
      className="overflow-hidden rounded-[1.75rem] border border-gray-100 bg-white text-left shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="aspect-[1.25/1] overflow-hidden bg-slate-100">
        {listing.image ? (
          <img src={listing.image} alt={listing.name} className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full items-center justify-center bg-gradient-to-br from-emerald-50 to-cyan-50 text-5xl text-emerald-500">
            <Truck className="h-14 w-14" />
          </div>
        )}
      </div>

      <div className="space-y-4 p-5">
        <div className="space-y-2">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">{listing.name}</h3>
              <p className="mt-1 text-sm text-gray-500">{listing.provider || listing.seller}</p>
            </div>
            <span className={`rounded-full px-3 py-1 text-xs font-semibold ${listing.available ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-gray-500'}`}>
              {listing.available ? 'Available' : 'Unavailable'}
            </span>
          </div>
        </div>

        <div className="grid gap-3 rounded-2xl border border-gray-100 bg-gray-50/80 p-4 text-sm text-gray-600">
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Rental Rate</span>
            <span className="font-semibold text-emerald-700">{formatPhpCurrency(listing.rate)} / {listing.unit}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Minimum Quantity</span>
            <span className="font-medium text-gray-900">{listing.minimumOrder}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Available Units</span>
            <span className="font-medium text-gray-900">{listing.quantity}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-sm text-gray-500">
          <MapPin className="h-4 w-4 text-emerald-600" />
          <span className="line-clamp-1">{listing.location}</span>
        </div>

        {listing.canEdit ? (
          activeView === 'dashboard' ? (
            <div className="flex gap-3">
              <button
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  openEditListingModal(listing);
                }}
                className="w-full rounded-2xl bg-emerald-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-emerald-700"
              >
                Edit Listing
              </button>
            </div>
          ) : null
        ) : (
          <div className="flex gap-3">
            <button
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                setSelectedRental(listing);
              }}
              className="flex-1 rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
            >
              View Details
            </button>
            <button
              type="button"
              disabled={!listing.available || isCommerciallyRestricted}
              onClick={(event) => {
                event.stopPropagation();
                onBookService(listing);
              }}
              className={`flex-1 rounded-2xl px-4 py-3 text-sm font-semibold transition-colors ${
                listing.available && !isCommerciallyRestricted
                  ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                  : 'cursor-not-allowed bg-gray-200 text-gray-500'
              }`}
            >
              Book Now
            </button>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {isCommerciallyRestricted && (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700">
          Your account is currently restricted. Rental listing and booking actions are limited until an admin clears the penalty.
        </div>
      )}

      <div className="rounded-[2rem] border border-gray-100 bg-white p-4 shadow-sm">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-emerald-600">Equipment Rentals</p>
            <h2 className="mt-2 text-2xl font-semibold text-gray-900">Equipment Rentals</h2>
          </div>
        </div>

        <div className={`mt-5 grid gap-3 ${segmentedOptions.length >= 4 ? 'md:grid-cols-4' : 'md:grid-cols-3'}`}>
          {segmentedOptions.map((option) => {
            const Icon = option.icon;
            const active = activeView === option.id;

            return (
              <button
                key={option.id}
                type="button"
                disabled={option.disabled}
                onClick={() => {
                  if (!option.disabled) {
                    updateServicesView(option.id);
                  }
                }}
                className={`rounded-[1.5rem] border px-5 py-4 text-left transition-all ${
                  active
                    ? 'border-emerald-500 bg-emerald-50 shadow-sm'
                    : option.disabled
                      ? 'cursor-not-allowed border-gray-200 bg-gray-50 text-gray-400'
                      : 'border-gray-200 bg-white hover:border-emerald-200 hover:bg-emerald-50/40'
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className={`flex h-11 w-11 items-center justify-center rounded-2xl ${
                    active
                      ? 'bg-emerald-600 text-white'
                      : option.disabled
                        ? 'bg-gray-100 text-gray-400'
                        : 'bg-gray-100 text-gray-600'
                  }`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className={`rounded-full px-3 py-1 text-xs font-semibold ${
                    active
                      ? 'bg-white text-emerald-700'
                      : option.disabled
                        ? 'bg-white text-gray-400'
                        : 'bg-gray-100 text-gray-500'
                  }`}>
                    {option.count}
                  </span>
                </div>
                <p className="mt-4 text-base font-semibold text-gray-900">{option.label}</p>
              </button>
            );
          })}
        </div>
      </div>

      {activeView === 'browse' && (
        <div className="rounded-[2rem] border border-gray-100 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Available Equipment Rentals</h3>
            </div>
            <span className="rounded-full bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-700">
              {availableRentals.length} active
            </span>
          </div>

          {availableRentals.length === 0 ? (
            <div className="mt-6 rounded-[1.75rem] border border-dashed border-gray-200 bg-gray-50 px-6 py-12 text-center">
              <Truck className="mx-auto h-12 w-12 text-gray-300" />
              <p className="mt-4 text-lg font-semibold text-gray-700">No equipment rentals yet</p>
              <p className="mt-2 text-sm text-gray-500">Published rentals from sellers and laborers will appear here once they add listings.</p>
            </div>
          ) : (
            <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {availableRentals.map(renderRentalCard)}
            </div>
          )}
        </div>
      )}

      {activeView === 'dashboard' && (
        <div className="rounded-[2rem] border border-gray-100 bg-white p-6 shadow-sm">
          {canManageRentals ? (
            <div className="mt-5 grid gap-3 md:grid-cols-3">
              {ownerDashboardOptions.map((option) => {
                const active = ownerDashboardSection === option.id;

                return (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => updateOwnerDashboardSection(option.id)}
                    className={`rounded-2xl border px-4 py-4 text-left transition-colors ${
                      active
                        ? 'border-emerald-500 bg-emerald-50'
                        : 'border-gray-200 bg-white hover:border-emerald-200 hover:bg-emerald-50/40'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <p className="text-sm font-semibold text-gray-900">{option.label}</p>
                      <span className={`rounded-full px-3 py-1 text-xs font-semibold ${
                        active ? 'bg-white text-emerald-700' : 'bg-gray-100 text-gray-500'
                      }`}>
                        {option.count}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          ) : null}

          {canManageRentals ? (
            <div className="mt-6 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              <div className="flex flex-col gap-3">
                <div className="flex flex-wrap items-center gap-3">
                  <h3 className="text-xl font-semibold text-gray-900">{ownerDashboardSectionContent[ownerDashboardSection].title}</h3>
                  <span className="rounded-full bg-slate-100 px-4 py-2 text-sm font-semibold text-slate-600">
                    {ownerDashboardSection === 'listings'
                      ? `${myRentals.length} listing${myRentals.length === 1 ? '' : 's'}`
                      : ownerDashboardSection === 'requests'
                        ? `${ownerActiveRequests.length} request${ownerActiveRequests.length === 1 ? '' : 's'}`
                        : `${ownerBookingHistory.length} record${ownerBookingHistory.length === 1 ? '' : 's'}`}
                  </span>
                </div>
                <p className="text-sm text-gray-500">{ownerDashboardSectionContent[ownerDashboardSection].subtitle}</p>
              </div>
              {ownerDashboardSection === 'listings' ? (
                <button
                  type="button"
                  onClick={openCreateListingModal}
                  className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-emerald-700"
                >
                  <Plus className="h-4 w-4" />
                  Add Rental Listing
                </button>
              ) : null}
            </div>
          ) : null}

          {!canManageRentals ? (
            <div className="mt-6 rounded-[1.75rem] border border-dashed border-gray-200 bg-gray-50 px-6 py-12 text-center">
              <UserCircle2 className="mx-auto h-12 w-12 text-gray-300" />
              <p className="mt-4 text-lg font-semibold text-gray-700">Listing access is limited</p>
              <p className="mt-2 text-sm text-gray-500">Only seller and laborer accounts can publish equipment rental listings.</p>
            </div>
          ) : ownerDashboardSection === 'listings' && myRentals.length === 0 ? (
            <div className="mt-6 rounded-[1.75rem] border border-dashed border-gray-200 bg-gray-50 px-6 py-12 text-center">
              <Wrench className="mx-auto h-12 w-12 text-gray-300" />
              <p className="mt-4 text-lg font-semibold text-gray-700">No rental listings yet</p>
              <p className="mt-2 text-sm text-gray-500">Create your first equipment rental listing to start receiving bookings.</p>
            </div>
          ) : ownerDashboardSection === 'listings' ? (
            <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {myRentals.map(renderRentalCard)}
            </div>
          ) : ownerDashboardSection === 'requests' ? (
            ownerActiveRequests.length === 0 ? (
              <div className="mt-6 rounded-[1.75rem] border border-dashed border-gray-200 bg-gray-50 px-6 py-12 text-center">
                <PackageCheck className="mx-auto h-12 w-12 text-gray-300" />
                <p className="mt-4 text-lg font-semibold text-gray-700">No active rental requests</p>
                <p className="mt-2 text-sm text-gray-500">Incoming rental requests that still need attention will appear here.</p>
              </div>
            ) : (
              <div className="mt-6 space-y-4">
              {ownerActiveRequests.map((booking) => {
                  const status = normalizeBookingStatus(booking.status);
                  const hasStarted = hasRentalBookingStarted(booking);
                  const isCompleted = String(booking.status || '').trim().toLowerCase() === 'completed';
                  const isCancelled = String(booking.status || '').trim().toLowerCase() === 'cancelled';
                  const providerPickedUp = hasProviderConfirmedPickup(booking);
                  const hasAnyPickup = hasAnyPickupConfirmation(booking);
                  const bothSidesPickedUp = haveBothSidesConfirmedPickup(booking);
                  const providerConfirmed = hasProviderConfirmedCompletion(booking);
                  const bookingListing = bookingListingLookup.get(
                    `${String(booking.service || '').trim().toLowerCase()}::${String(currentUser?.name || '').trim().toLowerCase()}`,
                  );

                  return (
                    <div key={`${booking.bookingRef}-${booking.id}`} className="rounded-[1.75rem] border border-gray-100 bg-white p-5 shadow-sm">
                      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                        <div className="flex min-w-0 items-center gap-4">
                          <div className="h-20 w-20 shrink-0 overflow-hidden rounded-2xl border border-gray-100 bg-slate-100">
                            {bookingListing?.image ? (
                              <img src={bookingListing.image} alt={booking.service} className="h-full w-full object-cover" />
                            ) : (
                              <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-emerald-50 to-cyan-50 text-emerald-500">
                                <Truck className="h-8 w-8" />
                              </div>
                            )}
                          </div>
                          <div className="min-w-0 space-y-3">
                            <div className="flex flex-wrap items-center gap-3">
                              <h4 className="text-lg font-semibold text-gray-900">{booking.service}</h4>
                              <span className={`rounded-full px-3 py-1 text-xs font-semibold ${status.className}`}>
                                {status.label}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600">Booked by {booking.customer || 'Customer'}</p>
                            <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-gray-500">
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-emerald-600" />
                                <span>{booking.date}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Clock3 className="h-4 w-4 text-emerald-600" />
                                <span>{booking.time}</span>
                              </div>
                              <div className="flex min-w-0 items-center gap-2">
                                <MapPin className="h-4 w-4 shrink-0 text-emerald-600" />
                                <span className="truncate">{summarizeRentalLocation(booking.location)}</span>
                              </div>
                            </div>
                            <p className="text-sm text-emerald-700">
                              {getRentalCompletionNotice(booking, true)}
                            </p>
                          </div>
                        </div>
                        <div className="grid w-full gap-3 sm:grid-cols-2 lg:w-[22rem]">
                          <button
                            type="button"
                            onClick={() => handleCallBookingContact(booking)}
                            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-emerald-200 px-4 py-3 text-sm font-medium text-emerald-700 transition-colors hover:bg-emerald-50"
                          >
                            <Phone className="h-4 w-4" />
                            Contact
                          </button>
                          {hasStarted && !isCompleted && !providerPickedUp ? (
                            <button
                              type="button"
                              onClick={() => handleConfirmRentalPickup(booking, true)}
                              disabled={pickingUpBookingRef === booking.bookingRef}
                              className="inline-flex items-center justify-center rounded-2xl bg-emerald-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-emerald-700 disabled:cursor-not-allowed disabled:bg-emerald-300"
                            >
                              {pickingUpBookingRef === booking.bookingRef ? 'Saving...' : 'Confirm Pickup'}
                            </button>
                          ) : hasStarted && !isCompleted && bothSidesPickedUp ? (
                            <button
                              type="button"
                              onClick={() => handleConfirmRentalCompleted(booking, true)}
                              disabled={completingBookingRef === booking.bookingRef || providerConfirmed}
                              className={`inline-flex items-center justify-center rounded-2xl px-4 py-3 text-sm font-semibold transition-colors ${
                                providerConfirmed
                                  ? 'cursor-not-allowed bg-emerald-100 text-emerald-700'
                                  : 'bg-emerald-600 text-white hover:bg-emerald-700'
                              }`}
                            >
                              {completingBookingRef === booking.bookingRef
                                ? 'Saving...'
                                : providerConfirmed
                                  ? 'Waiting for Customer'
                                  : 'Mark Completed'}
                            </button>
                          ) : (
                            <div className="hidden sm:block" />
                          )}
                          {!isCancelled && !isCompleted && !hasAnyPickup ? (
                            <button
                              type="button"
                              onClick={() => handleOpenRentalCancellation(booking)}
                              disabled={cancellingBookingRef === booking.bookingRef}
                              className="inline-flex items-center justify-center rounded-2xl border border-red-200 px-4 py-3 text-sm font-semibold text-red-600 transition-colors hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-60"
                            >
                              {cancellingBookingRef === booking.bookingRef ? 'Cancelling...' : 'Cancel'}
                            </button>
                          ) : (
                            <div className="hidden sm:block" />
                          )}
                          <button
                            type="button"
                            onClick={() => setViewingBooking(booking)}
                            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
                          >
                            <Eye className="h-4 w-4" />
                            View Details
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          ) : ownerBookingHistory.length === 0 ? (
            <div className="mt-6 rounded-[1.75rem] border border-dashed border-gray-200 bg-gray-50 px-6 py-12 text-center">
              <PackageCheck className="mx-auto h-12 w-12 text-gray-300" />
              <p className="mt-4 text-lg font-semibold text-gray-700">No rental history yet</p>
              <p className="mt-2 text-sm text-gray-500">Finished and cancelled incoming rental bookings will appear here.</p>
            </div>
          ) : (
            <div className="mt-6 space-y-4">
              {ownerBookingHistory.map((booking) => {
                const status = normalizeBookingStatus(booking.status);
                const bookingListing = bookingListingLookup.get(
                  `${String(booking.service || '').trim().toLowerCase()}::${String(currentUser?.name || '').trim().toLowerCase()}`,
                );

                return (
                  <div key={`${booking.bookingRef}-${booking.id}`} className="rounded-[1.75rem] border border-gray-100 bg-white p-5 shadow-sm">
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                      <div className="flex min-w-0 items-center gap-4">
                        <div className="h-20 w-20 shrink-0 overflow-hidden rounded-2xl border border-gray-100 bg-slate-100">
                          {bookingListing?.image ? (
                            <img src={bookingListing.image} alt={booking.service} className="h-full w-full object-cover" />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-emerald-50 to-cyan-50 text-emerald-500">
                              <Truck className="h-8 w-8" />
                            </div>
                          )}
                        </div>
                        <div className="min-w-0 space-y-3">
                          <div className="flex flex-wrap items-center gap-3">
                            <h4 className="text-lg font-semibold text-gray-900">{booking.service}</h4>
                            <span className={`rounded-full px-3 py-1 text-xs font-semibold ${status.className}`}>
                              {status.label}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600">Booked by {booking.customer || 'Customer'}</p>
                          <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-gray-500">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-emerald-600" />
                              <span>{booking.date}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock3 className="h-4 w-4 text-emerald-600" />
                              <span>{booking.time}</span>
                            </div>
                            <div className="flex min-w-0 items-center gap-2">
                              <MapPin className="h-4 w-4 shrink-0 text-emerald-600" />
                              <span className="truncate">{summarizeRentalLocation(booking.location)}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => setViewingBooking(booking)}
                        className="inline-flex items-center justify-center gap-2 rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
                      >
                        <Eye className="h-4 w-4" />
                        View Details
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {activeView === 'bookings' && (
        <div className="rounded-[2rem] border border-gray-100 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Rental Bookings</h3>
              <p className="mt-1 text-sm text-gray-500">Keep track of your active equipment rental requests.</p>
            </div>
            <span className="rounded-full bg-slate-100 px-4 py-2 text-sm font-semibold text-slate-600">
              {activeCustomerBookings.length} booking{activeCustomerBookings.length === 1 ? '' : 's'}
            </span>
          </div>

          {activeCustomerBookings.length === 0 ? (
            <div className="mt-6 rounded-[1.75rem] border border-dashed border-gray-200 bg-gray-50 px-6 py-12 text-center">
              <PackageCheck className="mx-auto h-12 w-12 text-gray-300" />
              <p className="mt-4 text-lg font-semibold text-gray-700">No active rental bookings</p>
              <p className="mt-2 text-sm text-gray-500">Your in-progress rental bookings will appear here.</p>
            </div>
          ) : (
            <div className="mt-6 space-y-4">
              {activeCustomerBookings.map((booking) => {
                const status = normalizeBookingStatus(booking.status);
                const hasStarted = hasRentalBookingStarted(booking);
                const isCompleted = String(booking.status || '').trim().toLowerCase() === 'completed';
                const isCancelled = String(booking.status || '').trim().toLowerCase() === 'cancelled';
                const customerPickedUp = hasCustomerConfirmedPickup(booking);
                const hasAnyPickup = hasAnyPickupConfirmation(booking);
                const bothSidesPickedUp = haveBothSidesConfirmedPickup(booking);
                const customerConfirmed = hasCustomerConfirmedCompletion(booking);
                const bookingListing = bookingListingLookup.get(
                  `${String(booking.service || '').trim().toLowerCase()}::${String(booking.provider || '').trim().toLowerCase()}`,
                );

                return (
                  <div key={`${booking.bookingRef}-${booking.id}`} className="rounded-[1.75rem] border border-gray-100 bg-white p-5 shadow-sm">
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                      <div className="flex min-w-0 items-center gap-4">
                        <div className="h-20 w-20 shrink-0 overflow-hidden rounded-2xl border border-gray-100 bg-slate-100">
                          {bookingListing?.image ? (
                            <img src={bookingListing.image} alt={booking.service} className="h-full w-full object-cover" />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-emerald-50 to-cyan-50 text-emerald-500">
                              <Truck className="h-8 w-8" />
                            </div>
                          )}
                        </div>
                        <div className="min-w-0 space-y-3">
                          <div className="flex flex-wrap items-center gap-3">
                            <h4 className="text-lg font-semibold text-gray-900">{booking.service}</h4>
                            <span className={`rounded-full px-3 py-1 text-xs font-semibold ${status.className}`}>
                              {status.label}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600">{booking.provider}</p>
                          <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-gray-500">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-emerald-600" />
                              <span>{booking.date}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock3 className="h-4 w-4 text-emerald-600" />
                              <span>{booking.time}</span>
                            </div>
                            <div className="flex min-w-0 items-center gap-2">
                              <MapPin className="h-4 w-4 shrink-0 text-emerald-600" />
                              <span className="truncate">{summarizeRentalLocation(booking.location)}</span>
                            </div>
                          </div>
                          <p className="text-sm text-emerald-700">
                            {getRentalCompletionNotice(booking, false)}
                          </p>
                        </div>
                      </div>
                      <div className="grid w-full gap-3 sm:grid-cols-2 lg:w-[22rem]">
                        <button
                          type="button"
                          onClick={() => handleCallBookingContact(booking)}
                          className="inline-flex items-center justify-center gap-2 rounded-2xl border border-emerald-200 px-4 py-3 text-sm font-medium text-emerald-700 transition-colors hover:bg-emerald-50"
                        >
                          <Phone className="h-4 w-4" />
                          Contact
                        </button>
                        {hasStarted && !isCompleted && !customerPickedUp ? (
                          <button
                            type="button"
                            onClick={() => handleConfirmRentalPickup(booking, false)}
                            disabled={pickingUpBookingRef === booking.bookingRef}
                            className="inline-flex items-center justify-center rounded-2xl bg-emerald-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-emerald-700 disabled:cursor-not-allowed disabled:bg-emerald-300"
                          >
                            {pickingUpBookingRef === booking.bookingRef ? 'Saving...' : 'Confirm Pickup'}
                          </button>
                        ) : hasStarted && !isCompleted && bothSidesPickedUp ? (
                          <button
                            type="button"
                            onClick={() => handleConfirmRentalCompleted(booking, false)}
                            disabled={completingBookingRef === booking.bookingRef || customerConfirmed}
                            className={`inline-flex items-center justify-center rounded-2xl px-4 py-3 text-sm font-semibold transition-colors ${
                              customerConfirmed
                                ? 'cursor-not-allowed bg-emerald-100 text-emerald-700'
                                : 'bg-emerald-600 text-white hover:bg-emerald-700'
                            }`}
                          >
                            {completingBookingRef === booking.bookingRef
                              ? 'Saving...'
                              : customerConfirmed
                                ? 'Waiting for Owner'
                                : 'Mark Completed'}
                          </button>
                        ) : (
                          <div className="hidden sm:block" />
                        )}
                        {!isCancelled && !isCompleted && !hasAnyPickup ? (
                          <button
                            type="button"
                            onClick={() => handleOpenRentalCancellation(booking)}
                            disabled={cancellingBookingRef === booking.bookingRef}
                            className="inline-flex items-center justify-center rounded-2xl border border-red-200 px-4 py-3 text-sm font-semibold text-red-600 transition-colors hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-60"
                          >
                            {cancellingBookingRef === booking.bookingRef ? 'Cancelling...' : 'Cancel'}
                          </button>
                        ) : (
                          <div className="hidden sm:block" />
                        )}
                        <button
                          type="button"
                          onClick={() => setViewingBooking(booking)}
                          className="inline-flex items-center justify-center gap-2 rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
                        >
                          <Eye className="h-4 w-4" />
                          View Details
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {activeView === 'history' && (
        <div className="rounded-[2rem] border border-gray-100 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-semibold text-gray-900">Rental History</h3>
              <p className="mt-1 text-sm text-gray-500">Completed and cancelled rental bookings from your customer side appear here.</p>
            </div>
            <span className="rounded-full bg-slate-100 px-4 py-2 text-sm font-semibold text-slate-600">
              {customerBookingHistory.length} record{customerBookingHistory.length === 1 ? '' : 's'}
            </span>
          </div>

          {customerBookingHistory.length === 0 ? (
            <div className="mt-6 rounded-[1.75rem] border border-dashed border-gray-200 bg-gray-50 px-6 py-12 text-center">
              <PackageCheck className="mx-auto h-12 w-12 text-gray-300" />
              <p className="mt-4 text-lg font-semibold text-gray-700">No rental history yet</p>
              <p className="mt-2 text-sm text-gray-500">Completed and cancelled rental bookings will appear here.</p>
            </div>
          ) : (
            <div className="mt-6 space-y-4">
              {customerBookingHistory.map((booking) => {
                const status = normalizeBookingStatus(booking.status);
                const bookingListing = bookingListingLookup.get(
                  `${String(booking.service || '').trim().toLowerCase()}::${String(booking.provider || '').trim().toLowerCase()}`,
                );

                return (
                  <div key={`${booking.bookingRef}-${booking.id}`} className="rounded-[1.75rem] border border-gray-100 bg-white p-5 shadow-sm">
                    <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                      <div className="flex min-w-0 items-center gap-4">
                        <div className="h-20 w-20 shrink-0 overflow-hidden rounded-2xl border border-gray-100 bg-slate-100">
                          {bookingListing?.image ? (
                            <img src={bookingListing.image} alt={booking.service} className="h-full w-full object-cover" />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-emerald-50 to-cyan-50 text-emerald-500">
                              <Truck className="h-8 w-8" />
                            </div>
                          )}
                        </div>
                        <div className="min-w-0 space-y-3">
                          <div className="flex flex-wrap items-center gap-3">
                            <h4 className="text-lg font-semibold text-gray-900">{booking.service}</h4>
                            <span className={`rounded-full px-3 py-1 text-xs font-semibold ${status.className}`}>
                              {status.label}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600">{booking.provider}</p>
                          <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-gray-500">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-emerald-600" />
                              <span>{booking.date}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock3 className="h-4 w-4 text-emerald-600" />
                              <span>{booking.time}</span>
                            </div>
                            <div className="flex min-w-0 items-center gap-2">
                              <MapPin className="h-4 w-4 shrink-0 text-emerald-600" />
                              <span className="truncate">{summarizeRentalLocation(booking.location)}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => setViewingBooking(booking)}
                        className="inline-flex items-center justify-center gap-2 rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
                      >
                        <Eye className="h-4 w-4" />
                        View Details
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}


      {selectedRental && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 py-6 responsive-modal-shell">
          <button type="button" aria-label="Close rental details" className="absolute inset-0 cursor-default" onClick={() => setSelectedRental(null)} />
          <div className="responsive-modal-panel relative z-10 flex w-full max-w-5xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="responsive-modal-header rounded-t-3xl bg-gradient-to-r from-emerald-600 to-green-500 text-white">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-emerald-100">Equipment Rental</p>
                  <h3 className="mt-2 text-2xl font-semibold">{selectedRental.name}</h3>
                  <p className="mt-1 text-sm text-emerald-50">{selectedRental.provider || selectedRental.seller}</p>
                </div>
                <button type="button" onClick={() => setSelectedRental(null)} className="rounded-xl border border-white/30 p-2 text-white transition-colors hover:bg-white/10">
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="responsive-modal-body overflow-y-auto">
              <div className="responsive-modal-grid grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
              <div className="space-y-4">
                <div className="responsive-modal-media overflow-hidden rounded-[2rem] border border-gray-100 bg-slate-100">
                  {selectedRental.image ? (
                    <img src={selectedRental.image} alt={selectedRental.name} className="aspect-[1.4/1] w-full object-cover" />
                  ) : (
                    <div className="flex aspect-[1.4/1] items-center justify-center bg-gradient-to-br from-emerald-50 to-cyan-50">
                      <Truck className="h-16 w-16 text-emerald-500" />
                    </div>
                  )}
                </div>
                {Array.isArray(selectedRental.images) && selectedRental.images.length > 1 ? (
                  <div className="grid grid-cols-3 gap-3">
                    {selectedRental.images.map((image, index) => (
                      <div key={`${selectedRental.listingId}-image-${index}`} className="overflow-hidden rounded-2xl border border-gray-100 bg-slate-100">
                        <img src={image} alt={`${selectedRental.name} preview ${index + 1}`} className="aspect-square w-full object-cover" />
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>

              <div className="space-y-5">
                <div className="rounded-[1.75rem] border border-gray-100 bg-gray-50/70 p-5">
                  <div className="flex items-center justify-between gap-4">
                    <span className="text-sm text-gray-500">Rental rate</span>
                    <span className="text-2xl font-semibold text-emerald-700">{formatPhpCurrency(selectedRental.rate)} / {selectedRental.unit}</span>
                  </div>
                  <div className="mt-5 grid gap-4 md:grid-cols-2">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Minimum Quantity</p>
                      <p className="mt-2 text-base font-semibold text-gray-900">{selectedRental.minimumOrder}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Available Units</p>
                      <p className="mt-2 text-base font-semibold text-gray-900">{selectedRental.quantity}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Condition</p>
                      <p className="mt-2 text-base font-semibold text-gray-900">{selectedRental.condition || 'Not specified'}</p>
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Listed By</p>
                      <p className="mt-2 text-base font-semibold text-gray-900">
                        {selectedRental.provider || selectedRental.seller} {selectedRental.ownerRole ? `(${selectedRental.ownerRole})` : ''}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="rounded-[1.75rem] border border-gray-100 bg-white p-5 shadow-sm">
                  <h4 className="text-lg font-semibold text-gray-900">Pickup Location</h4>
                  <div className="mt-3 flex items-start gap-3 text-sm text-gray-600">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                    <span>{selectedRental.location}</span>
                  </div>
                </div>

              </div>
            </div>

            <div className="mt-6 rounded-[1.75rem] border border-gray-100 bg-white p-5 shadow-sm">
              <h4 className="text-lg font-semibold text-gray-900">Rental Overview</h4>
              <p className="mt-3 text-sm leading-7 text-gray-600">{selectedRental.description}</p>
            </div>

            <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
              {selectedRental.canEdit ? (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedRental(null);
                    openEditListingModal(selectedRental);
                  }}
                  className="w-full rounded-2xl bg-emerald-600 px-5 py-4 text-sm font-semibold text-white transition-colors hover:bg-emerald-700 lg:w-auto lg:min-w-[21rem]"
                >
                  Edit Listing
                </button>
              ) : (
                <button
                  type="button"
                  disabled={!selectedRental.available || isCommerciallyRestricted}
                  onClick={() => onBookService(selectedRental)}
                  className={`w-full rounded-2xl px-5 py-4 text-sm font-semibold transition-colors lg:w-auto lg:min-w-[21rem] ${
                    selectedRental.available && !isCommerciallyRestricted
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                      : 'cursor-not-allowed bg-gray-200 text-gray-500'
                  }`}
                >
                  Book This Equipment
                </button>
              )}
              <button
                type="button"
                onClick={() => setSelectedRental(null)}
                className="w-full rounded-2xl border border-gray-200 px-5 py-4 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50 sm:w-auto"
              >
                Close
              </button>
            </div>
            </div>
          </div>
        </div>
      )}

      {viewingBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 py-6 responsive-modal-shell">
          <button type="button" aria-label="Close booking details" className="absolute inset-0 cursor-default" onClick={() => setViewingBooking(null)} />
          <div className="responsive-modal-card relative z-10 w-full max-w-2xl overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="responsive-modal-header rounded-t-3xl bg-gradient-to-r from-emerald-600 to-green-500 text-white">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-emerald-100">Rental Booking</p>
                  <h3 className="mt-2 text-2xl font-semibold">{viewingBooking.service}</h3>
                  <p className="mt-1 text-sm text-emerald-50">
                    {viewingBooking.customer ? `Booked by ${viewingBooking.customer}` : viewingBooking.provider}
                  </p>
                </div>
                <button type="button" onClick={() => setViewingBooking(null)} className="rounded-xl border border-white/30 p-2 text-white transition-colors hover:bg-white/10">
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="responsive-modal-body space-y-5">
              {(() => {
                const isOwnerView = incomingBookings.some(
                  (booking) => String(booking?.bookingRef || '').trim() === String(viewingBooking.bookingRef || '').trim(),
                );
                const hasStarted = hasRentalBookingStarted(viewingBooking);
                const isCompleted = String(viewingBooking.status || '').trim().toLowerCase() === 'completed';
                const isCancelled = String(viewingBooking.status || '').trim().toLowerCase() === 'cancelled';
                const alreadyPickedUp = isOwnerView
                  ? hasProviderConfirmedPickup(viewingBooking)
                  : hasCustomerConfirmedPickup(viewingBooking);
                const hasAnyPickup = hasAnyPickupConfirmation(viewingBooking);
                const bothSidesPickedUp = haveBothSidesConfirmedPickup(viewingBooking);
                const alreadyConfirmed = isOwnerView
                  ? hasProviderConfirmedCompletion(viewingBooking)
                  : hasCustomerConfirmedCompletion(viewingBooking);

                return (
                  <>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-2xl border border-gray-100 bg-gray-50/70 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Booking Reference</p>
                  <p className="mt-2 text-base font-semibold text-gray-900">{viewingBooking.bookingRef}</p>
                </div>
                <div className="rounded-2xl border border-gray-100 bg-gray-50/70 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Status</p>
                  <p className="mt-2 text-base font-semibold text-gray-900">{normalizeBookingStatus(viewingBooking.status).label}</p>
                </div>
                <div className="rounded-2xl border border-gray-100 bg-gray-50/70 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Schedule</p>
                  <p className="mt-2 text-base font-semibold text-gray-900">{viewingBooking.date} at {formatBookingTimeLabel(viewingBooking.time)}</p>
                </div>
                <div className="rounded-2xl border border-gray-100 bg-gray-50/70 p-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Duration</p>
                  <p className="mt-2 text-base font-semibold text-gray-900">{viewingBooking.duration}</p>
                </div>
              </div>

              <div className="rounded-2xl border border-emerald-100 bg-emerald-50/70 p-4">
                <p className="text-sm font-medium text-emerald-800">
                  {getRentalCompletionNotice(viewingBooking, isOwnerView)}
                </p>
              </div>

              <div className="rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Location</p>
                <p className="mt-2 text-sm leading-6 text-gray-600">{viewingBooking.location}</p>
              </div>

              <div className="rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Description</p>
                <p className="mt-2 text-sm leading-6 text-gray-600">{viewingBooking.description || 'No description provided.'}</p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => handleCallBookingContact(viewingBooking)}
                  className="inline-flex items-center gap-2 rounded-2xl border border-emerald-200 px-5 py-3 text-sm font-medium text-emerald-700 transition-colors hover:bg-emerald-50"
                >
                  <Phone className="h-4 w-4" />
                  Contact
                </button>
                {!isCancelled && !isCompleted && !hasAnyPickup ? (
                  <button
                    type="button"
                    onClick={() => handleOpenRentalCancellation(viewingBooking)}
                    disabled={cancellingBookingRef === viewingBooking.bookingRef}
                    className="rounded-2xl border border-red-200 px-5 py-3 text-sm font-semibold text-red-600 transition-colors hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {cancellingBookingRef === viewingBooking.bookingRef ? 'Cancelling...' : 'Cancel'}
                  </button>
                ) : (
                  <div className="hidden sm:block" />
                )}
                {hasStarted && !isCompleted && !alreadyPickedUp ? (
                  <button
                    type="button"
                    onClick={() => handleConfirmRentalPickup(viewingBooking, isOwnerView)}
                    disabled={pickingUpBookingRef === viewingBooking.bookingRef}
                    className="rounded-2xl bg-emerald-600 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-emerald-700 disabled:cursor-not-allowed disabled:bg-emerald-300"
                  >
                    {pickingUpBookingRef === viewingBooking.bookingRef ? 'Saving...' : 'Confirm Pickup'}
                  </button>
                ) : null}
                {hasStarted && !isCompleted && bothSidesPickedUp ? (
                  <button
                    type="button"
                    onClick={() => handleConfirmRentalCompleted(viewingBooking, isOwnerView)}
                    disabled={completingBookingRef === viewingBooking.bookingRef || alreadyConfirmed}
                    className={`rounded-2xl px-5 py-3 text-sm font-semibold transition-colors ${
                      alreadyConfirmed
                        ? 'cursor-not-allowed bg-emerald-100 text-emerald-700'
                        : 'bg-emerald-600 text-white hover:bg-emerald-700'
                    }`}
                  >
                    {completingBookingRef === viewingBooking.bookingRef
                      ? 'Saving...'
                      : alreadyConfirmed
                        ? isOwnerView
                          ? 'Waiting for Customer'
                          : 'Waiting for Owner'
                        : 'Mark Completed'}
                  </button>
                ) : null}
              </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {isListingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 py-6 responsive-modal-shell">
          <button type="button" aria-label="Close rental form" className="absolute inset-0 cursor-default" onClick={() => setIsListingModalOpen(false)} />
          <div className="responsive-modal-panel relative z-10 flex w-full max-w-5xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="responsive-modal-header rounded-t-3xl bg-gradient-to-r from-emerald-600 to-green-500 text-white">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-emerald-100">Rental Listing</p>
                  <h3 className="mt-2 text-2xl font-semibold">{listingForm.listingId ? 'Edit equipment rental' : 'Create equipment rental'}</h3>
                  <p className="mt-1 text-sm text-emerald-50">Use 1 to 3 equipment photos and keep the listing details aligned with the equipment you can actually release.</p>
                </div>
                <button type="button" onClick={() => setIsListingModalOpen(false)} className="rounded-xl border border-white/30 p-2 text-white transition-colors hover:bg-white/10">
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <form onSubmit={handleSaveListing} className="responsive-modal-body space-y-6 overflow-y-auto">
              <div className="responsive-modal-grid grid gap-6 lg:grid-cols-[1.08fr_0.92fr]">
                <div className="space-y-4">
                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700">Equipment Name</label>
                    <input
                      type="text"
                      value={listingForm.name}
                      onChange={(event) => setListingForm((current) => ({ ...current, name: event.target.value }))}
                      className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700">Description</label>
                    <textarea
                      value={listingForm.description}
                      onChange={(event) => setListingForm((current) => ({ ...current, description: event.target.value }))}
                      rows={7}
                      className="h-[17.2rem] w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-[1fr_0.9fr]">
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Rental Rate</label>
                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={listingForm.rate}
                        onChange={(event) => setListingForm((current) => ({ ...current, rate: event.target.value }))}
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 [appearance:textfield] focus:outline-none focus:ring-2 focus:ring-emerald-500 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Unit</label>
                      <select
                        value={listingForm.unit}
                        onChange={(event) => setListingForm((current) => ({ ...current, unit: event.target.value }))}
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        {rentalUnits.map((unit) => (
                          <option key={unit} value={unit}>{unit}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-[0.78fr_1.22fr]">
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Available Units</label>
                      <input
                        type="number"
                        min="1"
                        value={listingForm.quantity}
                        onChange={(event) => setListingForm((current) => ({ ...current, quantity: event.target.value }))}
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 [appearance:textfield] focus:outline-none focus:ring-2 focus:ring-emerald-500 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Plate No. / Serial ID</label>
                      <input
                        type="text"
                        value={listingForm.identifier}
                        onChange={(event) => setListingForm((current) => ({ ...current, identifier: event.target.value }))}
                        placeholder="e.g. NAA-1234 or EQP-20458"
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700">Pickup Location</label>
                    <input
                      type="text"
                      value={listingForm.location}
                      readOnly
                      className="w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-gray-600 focus:outline-none"
                    />
                    <p className="mt-2 text-xs text-gray-500">This uses the saved address from your profile.</p>
                  </div>

                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700">Condition</label>
                    <select
                      value={listingForm.condition}
                      onChange={(event) => setListingForm((current) => ({ ...current, condition: event.target.value }))}
                      className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="">Select condition</option>
                      <option value="Excellent">Excellent</option>
                      <option value="Good">Good</option>
                      <option value="Operational">Operational</option>
                      <option value="Used but functional">Used but functional</option>
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700">Rental Photos</label>
                <div className="responsive-modal-grid grid items-start gap-4 lg:grid-cols-[1.15fr_0.85fr]">
                  <label className="flex min-h-[12rem] cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-gray-300 bg-gray-50 px-4 py-6 text-center hover:border-emerald-400 hover:bg-emerald-50/40">
                    <ImagePlus className="h-8 w-8 text-gray-400" />
                    <span className="mt-3 text-sm font-medium text-gray-700">Upload 1 to 3 photos</span>
                    <span className="mt-1 text-xs text-gray-500">JPG, PNG, or WebP. Stored in the Rentals-picture bucket.</span>
                    <input type="file" multiple accept="image/*" className="hidden" onChange={handleImageSelection} />
                  </label>

                  <div className="grid grid-cols-3 gap-3">
                    {Array.from({ length: 3 }).map((_, index) => {
                      const preview = listingImagePreviews[index];

                      return (
                        <div key={`rental-photo-slot-${index}`} className="aspect-square overflow-hidden rounded-xl border border-gray-200 bg-gray-100">
                          {preview ? (
                            <img src={preview} alt={`Rental preview ${index + 1}`} className="h-full w-full object-cover" />
                          ) : (
                            <div className="flex h-full items-center justify-center text-[11px] font-medium text-gray-400">
                              <Camera className="h-4 w-4" />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {listingError ? (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {listingError}
                </div>
              ) : null}

              <div className="responsive-modal-sticky-actions sticky bottom-0 flex flex-col gap-3 border-t border-gray-100 bg-white pt-4 sm:flex-row">
                <button
                  type="button"
                  onClick={() => setIsListingModalOpen(false)}
                  disabled={isSavingListing}
                  className="flex-1 rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingListing}
                  className="flex-1 rounded-2xl bg-emerald-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-emerald-700 disabled:cursor-not-allowed disabled:bg-emerald-300"
                >
                  {isSavingListing ? 'Saving Listing...' : listingForm.listingId ? 'Update Listing' : 'Publish Listing'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {cancellationState.booking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 py-6">
          <button
            type="button"
            aria-label="Close rental cancellation form"
            className="absolute inset-0 cursor-default"
            onClick={() => setCancellationState({ booking: null, reason: '' })}
          />
          <div className="relative z-10 w-full max-w-xl overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="rounded-t-3xl bg-gradient-to-r from-red-500 to-rose-500 px-6 py-5 text-white">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-rose-100">Cancel Rental Booking</p>
                  <h3 className="mt-2 text-2xl font-semibold">{cancellationState.booking.service}</h3>
                  <p className="mt-1 text-sm text-rose-50">Enter the reason for cancelling this booking before pickup is confirmed.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setCancellationState({ booking: null, reason: '' })}
                  className="rounded-xl border border-white/30 p-2 text-white transition-colors hover:bg-white/10"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="space-y-5 px-6 py-6">
              <div className="rounded-2xl border border-gray-100 bg-gray-50/70 p-4">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Booking Reference</p>
                <p className="mt-2 text-base font-semibold text-gray-900">{cancellationState.booking.bookingRef}</p>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700">Cancellation Reason</label>
                <textarea
                  value={cancellationState.reason}
                  onChange={(event) => setCancellationState((current) => ({ ...current, reason: event.target.value }))}
                  rows={5}
                  placeholder="Explain why this rental booking is being cancelled."
                  className="w-full rounded-2xl border border-gray-300 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => setCancellationState({ booking: null, reason: '' })}
                  className="rounded-2xl border border-gray-200 px-5 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
                >
                  Keep Booking
                </button>
                <button
                  type="button"
                  onClick={() => void handleCancelRentalBooking()}
                  disabled={cancellingBookingRef === cancellationState.booking.bookingRef}
                  className="rounded-2xl bg-red-500 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-red-600 disabled:cursor-not-allowed disabled:bg-red-300"
                >
                  {cancellingBookingRef === cancellationState.booking.bookingRef ? 'Cancelling...' : 'Confirm Cancel'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
