import { useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Circle,
  Filter,
  ImagePlus,
  Loader2,
  MapPin,
  MessageSquare,
  Package,
  Plus,
  Search,
  ShieldCheck,
  ShoppingCart,
  Star,
  Store,
  Truck,
  X,
} from 'lucide-react';
import {
  cancelMarketplaceOrder,
  confirmMarketplaceOrderReceived,
  createMarketplaceListingUploadUrl,
  createMarketplaceRefundUploadUrl,
  createMarketplaceReviewUploadUrl,
  downloadMarketplaceWaybill,
  getMarketplaceData,
  requestMarketplaceOrderRefund,
  submitMarketplaceOrderReview,
  updateMarketplaceOrderStatus,
  upsertMarketplaceListing,
} from '../../features/app/api';
import deliveryTruckIconUrl from '../../assets/delivery-truck.png';
import deliveryTruckMirroredIconUrl from '../../assets/delivery-truck-mirrored.png';
import motorbikeIconUrl from '../../assets/motorbike.png';
import motorbikeMirroredIconUrl from '../../assets/motorbike-mirrored.png';
import { useSearchParams } from 'react-router';
import { SessionUser } from '../../shared/auth/session';
import { formatPhpCurrency } from '../../shared/format/currency';
import { requireSupabaseClient } from '../../shared/supabase/client';

interface MarketplaceProps {
  onAddToCart: (product: any) => void;
  currentUser: SessionUser | null;
  isCartOpen: boolean;
}

interface ListingVarietyFormState {
  id: string;
  label: string;
  price: string;
  stock: string;
}

interface ListingFormState {
  listingId: string;
  name: string;
  category: string;
  description: string;
  brand: string;
  condition: string;
  harvestDate: string;
  location: string;
  minimumOrder: string;
  unit: string;
  basePrice: string;
  baseStock: string;
  varieties: ListingVarietyFormState[];
}

const categories = ['all', 'seeds', 'fertilizer', 'grains', 'vegetables', 'fruits', 'equipment'];
const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY?.trim() || '';
const MARKETPLACE_GOOGLE_MAPS_SCRIPT_ID = 'agrihub-google-maps-marketplace-tracking';
const LOGISTICS_PREVIEW_STORAGE_KEY = 'agrihub-marketplace-logistics-preview';
const MARKETPLACE_CACHE_STORAGE_KEY = 'agrihub-marketplace-cache-v1';
const MAX_REVIEW_PHOTOS = 4;
const MAX_REFUND_PHOTOS = 4;
const unitOptions: Record<string, string[]> = {
  seeds: ['pack', 'kg', 'sack'],
  fertilizer: ['bag', 'kg', 'liter'],
  grains: ['kg', 'sack', 'ton'],
  vegetables: ['kg', 'bundle', 'crate'],
  fruits: ['kg', 'box', 'crate'],
  equipment: ['piece', 'unit', 'set'],
};

function getReviewImageList(review: any) {
  if (Array.isArray(review?.imageUrls) && review.imageUrls.length > 0) {
    return review.imageUrls.filter(Boolean);
  }

  return Array.isArray(review?.imagePaths) ? review.imagePaths.filter(Boolean) : [];
}

function getRefundImageList(refundRequest: any) {
  if (Array.isArray(refundRequest?.imageUrls) && refundRequest.imageUrls.length > 0) {
    return refundRequest.imageUrls.filter(Boolean);
  }

  return Array.isArray(refundRequest?.imagePaths) ? refundRequest.imagePaths.filter(Boolean) : [];
}

function readMarketplaceCache() {
  if (typeof window === 'undefined') {
    return null;
  }

  try {
    const raw = window.localStorage.getItem(MARKETPLACE_CACHE_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function writeMarketplaceCache(payload: any) {
  if (typeof window === 'undefined') {
    return;
  }

  try {
    window.localStorage.setItem(MARKETPLACE_CACHE_STORAGE_KEY, JSON.stringify(payload));
  } catch {
    // Ignore cache write failures.
  }
}

function buildVarietyDraft(): ListingVarietyFormState {
  return {
    id: `draft-${Date.now()}-${Math.floor(Math.random() * 100000)}`,
    label: '',
    price: '',
    stock: '',
  };
}

function buildLocationOptions(currentUser: SessionUser | null) {
  const address = String(currentUser?.profile?.address || '').trim();
  return address ? [address] : [];
}

function buildEmptyListingForm(currentUser: SessionUser | null): ListingFormState {
  const locations = buildLocationOptions(currentUser);

  return {
    listingId: '',
    name: '',
    category: 'seeds',
    description: '',
    brand: '',
    condition: '',
    harvestDate: '',
    location: locations[0] || '',
    minimumOrder: '1',
    unit: 'pack',
    basePrice: '',
    baseStock: '',
    varieties: [buildVarietyDraft()],
  };
}

function supportsVarieties(category: string) {
  return ['seeds', 'grains', 'vegetables', 'fruits'].includes(category);
}

function getProductSoldCount(product: any) {
  return Number(product?.orders || 0);
}

function getProductRating(product: any) {
  const reviews = Array.isArray(product?.reviews) ? product.reviews : [];

  if (reviews.length === 0) {
    return 0;
  }

  return reviews.reduce((sum: number, review: any) => sum + Number(review?.rating || 0), 0) / reviews.length;
}

function getProductReviewCount(product: any) {
  return Array.isArray(product?.reviews) ? product.reviews.length : 0;
}

function getProductVarieties(product: any) {
  return Array.isArray(product?.varieties) ? product.varieties : [];
}

function getSelectedProductVariety(product: any, selectedVarietyId: string) {
  const varieties = getProductVarieties(product);

  if (varieties.length === 0) {
    return null;
  }

  return varieties.find((variety: any) => String(variety?.id || '') === selectedVarietyId) || varieties[0];
}

function getMarketplaceViewFromSearchParams(searchParams: URLSearchParams) {
  const requestedView = String(searchParams.get('marketTab') || '').trim().toLowerCase();
  if (requestedView === 'orders') {
    return 'orders';
  }
  return requestedView === 'sell' ? 'sell' : 'buy';
}

function getMarketplaceSellerSectionFromSearchParams(searchParams: URLSearchParams) {
  return String(searchParams.get('marketSellerTab') || '').trim().toLowerCase() === 'orders'
    ? 'orders'
    : 'listings';
}

function getMarketplaceBuyerOrderTabFromSearchParams(searchParams: URLSearchParams) {
  const requestedTab = String(searchParams.get('marketOrdersTab') || '').trim().toLowerCase();
  const supportedTabs = new Set(['all', 'to_pay', 'to_ship', 'to_receive', 'completed', 'cancelled', 'return_refund']);

  return supportedTabs.has(requestedTab) ? requestedTab as 'all' | 'to_pay' | 'to_ship' | 'to_receive' | 'completed' | 'cancelled' | 'return_refund' : 'all';
}

function formatOrderDateTime(value: string | number | Date | null | undefined) {
  if (!value) {
    return 'Waiting for update';
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return 'Waiting for update';
  }

  return new Intl.DateTimeFormat('en-PH', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
}

function getTimelineDateParts(value: string | number | Date | null | undefined) {
  if (!value) {
    return {
      dateLabel: 'Waiting',
      timeLabel: 'for update',
    };
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return {
      dateLabel: 'Waiting',
      timeLabel: 'for update',
    };
  }

  return {
    dateLabel: new Intl.DateTimeFormat('en-PH', {
      day: 'numeric',
      month: 'short',
    }).format(date),
    timeLabel: new Intl.DateTimeFormat('en-PH', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    }).format(date),
  };
}

function getOrderStatusRank(statusOrOrder: string | any) {
  const order = typeof statusOrOrder === 'string' ? null : statusOrOrder;
  const status = typeof statusOrOrder === 'string'
    ? statusOrOrder
    : String(statusOrOrder?.status || 'paid');
  const ranks: Record<string, number> = {
    paid: 0,
    preparing: 1,
    ready_for_pickup: 2,
    in_transit: 3,
    received: 4,
    completed: 5,
  };

  if (typeof ranks[status] === 'number') {
    return ranks[status];
  }

  if (!order) {
    return 0;
  }

  if (String(order?.status || '').trim() === 'return_refund') {
    if (Boolean(order?.reviewed) || String(order?.status || '').trim() === 'completed') {
      return 5;
    }

    if (order?.receivedAt || getMarketplaceRouteProgressPercent(order) >= 100) {
      return 4;
    }

    if (order?.inTransitAt || getMarketplaceRouteProgressPercent(order) > 0) {
      return 3;
    }

    if (order?.readyForPickupAt) {
      return 2;
    }

    if (order?.preparingAt) {
      return 1;
    }
  }

  return 0;
}

function isApprovedMarketplaceRefund(order: any) {
  return (
    String(order?.status || '').trim() === 'return_refund'
    && String(order?.refundRequest?.status || '').trim() === 'approved'
  );
}

function getRefundStatusButtonLabel(refundRequest: any) {
  const refundStatus = String(refundRequest?.status || '').trim().toLowerCase();

  if (refundStatus === 'approved') {
    return 'View Approved Refund';
  }

  if (refundStatus === 'rejected') {
    return 'View Rejected Refund';
  }

  return 'View Pending Refund';
}

function getRefundStatusButtonClassName(refundRequest: any) {
  const refundStatus = String(refundRequest?.status || '').trim().toLowerCase();

  if (refundStatus === 'approved') {
    return 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100';
  }

  if (refundStatus === 'rejected') {
    return 'border-slate-200 bg-slate-100 text-slate-700 hover:bg-slate-200';
  }

  return 'border-amber-200 bg-amber-50 text-amber-800 hover:bg-amber-100';
}

function getBuyerOrderProgressSteps(order: any) {
  const statusRank = getOrderStatusRank(order);
  const isCompleted = String(order?.status || '') === 'completed' || Boolean(order?.reviewed);
  const isRefunded = isApprovedMarketplaceRefund(order);
  const isCancelled = String(order?.status || '').trim() === 'cancelled';
  const cancellationReason = String(order?.cancellationReason || '').trim();

  return [
    {
      key: 'placed',
      label: 'Order Placed',
      description: 'Payment confirmed and order recorded.',
      timestamp: order?.paidAt || order?.createdAt,
      done: statusRank >= 0,
      active: !isCancelled && statusRank === 0,
      icon: Package,
    },
    {
      key: 'preparing',
      label: 'Preparing',
      description: 'Seller is packing and preparing the parcel.',
      timestamp: order?.preparingAt,
      done: statusRank >= 1,
      active: !isCancelled && statusRank === 1,
      icon: Store,
    },
    {
      key: 'pickup',
      label: 'Ready for Pickup',
      description: 'Parcel is packed and waiting for rider pickup.',
      timestamp: order?.readyForPickupAt,
      done: statusRank >= 2,
      active: !isCancelled && statusRank === 2,
      icon: CheckCircle2,
    },
    {
      key: 'transit',
      label: 'In Transit',
      description: 'Parcel is already on the way to you.',
      timestamp: order?.inTransitAt,
      done: statusRank >= 3,
      active: !isCancelled && statusRank === 3,
      icon: Truck,
    },
    {
      key: isCancelled ? 'cancelled' : 'received',
      label: isCancelled ? 'Cancelled' : isRefunded ? 'Refunded' : isCompleted ? 'Received & Rated' : 'Order Received',
      description: isCancelled
        ? (cancellationReason
            ? `Cancellation reason: ${cancellationReason}`
            : 'This order was cancelled before the seller started preparing the parcel.')
        : isRefunded
        ? 'This order was refunded after the refund request was approved.'
        : isCompleted
          ? 'Buyer received the parcel and sent a rating.'
          : 'Buyer confirmed the parcel was received.',
      timestamp: isCancelled
        ? order?.cancelledAt
        : isRefunded
          ? (order?.refundRequest?.refundedAt || order?.refundRequest?.reviewedAt || order?.cancelledAt)
          : (order?.completedAt || order?.receivedAt),
      done: statusRank >= 4,
      active: isCancelled || statusRank === 4 || statusRank === 5,
      icon: isCancelled ? X : Star,
    },
  ];
}

function getBuyerOrderTimeline(order: any) {
  const logisticsTimeline = buildBuyerLogisticsTimeline(order);
  const isRefunded = isApprovedMarketplaceRefund(order);
  const cancellationReason = String(order?.cancellationReason || '').trim();
  const standardTimeline = [
    {
      key: 'cancelled',
      title: 'Order cancelled',
      detail: cancellationReason
        ? `Cancellation reason: ${cancellationReason}`
        : 'This order was cancelled before the seller started preparing the parcel.',
      timestamp: order?.cancelledAt,
      visible: String(order?.status || '') === 'cancelled',
      tone: 'neutral',
    },
    {
      key: 'completed',
      title: 'Product rated',
      detail: order?.reviewComment
        ? `You rated this order ${Number(order?.reviewRating || 0).toFixed(1)} stars and left a review.`
        : `You rated this order ${Number(order?.reviewRating || 0).toFixed(1)} stars.`,
      timestamp: order?.completedAt,
      visible: String(order?.status || '') === 'completed' || Boolean(order?.reviewed),
      tone: 'success',
    },
    {
      key: 'received',
      title: isRefunded ? 'Refunded' : 'Order received',
      detail: isRefunded
        ? 'The refund request was approved and the order has been refunded.'
        : 'You confirmed that the parcel arrived safely.',
      timestamp: isRefunded
        ? (order?.refundRequest?.refundedAt || order?.refundRequest?.reviewedAt || order?.cancelledAt)
        : order?.receivedAt,
      visible: isRefunded || ['received', 'completed'].includes(String(order?.status || '')),
      tone: 'success',
    },
    {
      key: 'transit',
      title: 'Parcel is in transit',
      detail: 'The parcel has left the seller side and is on the way to your address.',
      timestamp: order?.inTransitAt,
      visible: ['in_transit', 'received', 'completed', 'return_refund'].includes(String(order?.status || '')),
      tone: 'info',
    },
    {
      key: 'pickup',
      title: 'Seller is done preparing waiting for our logistics partner to pick up',
      detail: 'The seller finished preparing your order and it is now waiting for our logistics partner to pick it up.',
      timestamp: order?.readyForPickupAt,
      visible: ['ready_for_pickup', 'in_transit', 'received', 'completed', 'return_refund'].includes(String(order?.status || '')),
      tone: 'info',
    },
    {
      key: 'preparing',
      title: 'Seller is preparing your order',
      detail: 'The seller has started preparing your order.',
      timestamp: order?.preparingAt,
      visible: ['preparing', 'ready_for_pickup', 'in_transit', 'received', 'completed', 'return_refund'].includes(String(order?.status || '')),
      tone: 'info',
    },
    {
      key: 'paid',
      title: 'Order placed',
      detail: String(order?.status || '') === 'paid'
        ? 'Payment was confirmed. Waiting for the seller to start preparing your parcel.'
        : 'Payment was confirmed and the seller has received the order request.',
      timestamp: order?.paidAt || order?.createdAt,
      visible: true,
      tone: 'neutral',
    },
  ].filter((event) => event.visible);

  if (logisticsTimeline.length === 0) {
    return standardTimeline;
  }

  const earlyOrderEvents = standardTimeline.filter((event) =>
    ['paid', 'preparing'].includes(String(event.key || '').trim()),
  );

  return [...logisticsTimeline, ...earlyOrderEvents]
    .sort((left, right) => new Date(right.timestamp || 0).getTime() - new Date(left.timestamp || 0).getTime())
    .filter((event, index, collection) => collection.findIndex((entry) => entry.key === event.key) === index);
}

function getMarketplaceLogistics(order: any) {
  return order?.logistics && Array.isArray(order.logistics.routeStops)
    ? order.logistics
    : null;
}

function hasMarketplaceTracking(order: any) {
  return Boolean(getMarketplaceLogistics(order)?.simulationEnabled);
}

function hasMarketplaceTransitStarted(order: any) {
  const normalizedStatus = String(order?.status || '').trim();
  return ['in_transit', 'received', 'completed'].includes(normalizedStatus) || Boolean(order?.inTransitAt);
}

function canShowTrackingNumber(order: any) {
  const status = String(order?.status || '').trim();
  return ['ready_for_pickup', 'in_transit', 'received', 'completed'].includes(status);
}

function getMarketplaceRouteProgressPercent(order: any) {
  const logistics = getMarketplaceLogistics(order);

  if (!logistics) {
    return 0;
  }

  const routeStops = Array.isArray(logistics.routeStops) ? logistics.routeStops : [];
  const totalLegs = Math.max(routeStops.length - 1, 1);
  const currentStopIndex = Math.max(0, Math.min(Number(logistics.currentStopIndex || 0), Math.max(routeStops.length - 1, 0)));
  const legProgressPercent = Math.max(0, Math.min(100, Math.round(Number(logistics.progressPercent || 0))));

  if (currentStopIndex >= totalLegs) {
    return 100;
  }

  return Math.max(0, Math.min(100, Math.round(((currentStopIndex + (legProgressPercent / 100)) / totalLegs) * 100)));
}

function canConfirmMarketplaceOrderReceived(order: any) {
  return (
    String(order?.status || '').trim() === 'in_transit'
    && getMarketplaceRouteProgressPercent(order) >= 100
    && String(order?.refundRequest?.status || 'none').trim() === 'none'
  );
}

function getMarketplaceTrackingHeadline(order: any) {
  const logistics = getMarketplaceLogistics(order);
  const routeProgressPercent = getMarketplaceRouteProgressPercent(order);
  const isRefunded = isApprovedMarketplaceRefund(order);

  if (!logistics || !logistics.simulationEnabled) {
    return 'Route simulation pending';
  }

  if (isRefunded) {
    return 'Refunded';
  }

  if (routeProgressPercent >= 100) {
    return 'Order Received';
  }

  if (routeProgressPercent >= 80) {
    return 'Parcel is out for delivery';
  }

  return logistics.currentStop?.label || 'Route simulation pending';
}

function getMarketplaceLogisticsPhaseLabel(order: any) {
  const phase = String(getMarketplaceLogistics(order)?.parcelPhase || '').trim();

  if (!phase) {
    return 'Simulation pending';
  }

  return phase.replace(/_/g, ' ');
}

function getMarketplaceLogisticsStatusCopy(order: any) {
  const logistics = getMarketplaceLogistics(order);
  const routeProgressPercent = getMarketplaceRouteProgressPercent(order);
  const isRefunded = isApprovedMarketplaceRefund(order);

  if (!logistics) {
    return 'Route simulation has not started yet.';
  }

  if (!logistics.simulationEnabled) {
    return logistics.simulationLockedReason || 'Tracking becomes available when the parcel is ready for pickup.';
  }

  if (isRefunded) {
    return 'The refund request was approved and the order has been refunded.';
  }

  if (routeProgressPercent >= 100 || logistics.parcelPhase === 'arrived_at_destination') {
    return 'The parcel has reached the buyer destination and is waiting for final handoff or confirmation.';
  }

  if (routeProgressPercent >= 80 || logistics.parcelPhase === 'final_approach') {
    return 'The parcel is already on its final approach to the buyer.';
  }

  if (logistics.parcelPhase === 'in_transit') {
    return `The parcel is travelling from ${logistics.currentStop?.label || 'the current stop'} to ${logistics.nextStop?.label || 'the next stop'}.`;
  }

  return `The parcel is currently processing at ${logistics.currentStop?.label || 'the current stop'}.`;
}

function loadMarketplaceGoogleMapsScript() {
  if (typeof window === 'undefined') {
    return Promise.reject(new Error('Google Maps is only available in the browser.'));
  }

  const existingGoogle = (window as any).google;

  if (existingGoogle?.maps?.Map) {
    return Promise.resolve(existingGoogle);
  }

  if (!GOOGLE_MAPS_API_KEY) {
    return Promise.reject(new Error('Google Maps API key is not configured.'));
  }

  const existingScript = document.getElementById(MARKETPLACE_GOOGLE_MAPS_SCRIPT_ID) as HTMLScriptElement | null;

  if (existingScript) {
    return new Promise((resolve, reject) => {
      existingScript.addEventListener('load', () => resolve((window as any).google), { once: true });
      existingScript.addEventListener('error', () => reject(new Error('Unable to load Google Maps.')), { once: true });
    });
  }

  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.id = MARKETPLACE_GOOGLE_MAPS_SCRIPT_ID;
    script.async = true;
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(GOOGLE_MAPS_API_KEY)}`;
    script.onload = () => resolve((window as any).google);
    script.onerror = () => reject(new Error('Unable to load Google Maps.'));
    document.head.appendChild(script);
  });
}

function isValidCoordinateRange(lat: number, lng: number) {
  return Number.isFinite(lat) && Number.isFinite(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
}

function isLikelyPhilippineCoordinate(lat: number, lng: number) {
  return lat >= 4 && lat <= 22 && lng >= 116 && lng <= 127.5;
}

function normalizeMapCoordinate(point: any) {
  const directLat = Number(point?.lat);
  const directLng = Number(point?.lng);
  const swappedLat = directLng;
  const swappedLng = directLat;
  const directValid = isValidCoordinateRange(directLat, directLng);
  const swappedValid = isValidCoordinateRange(swappedLat, swappedLng);

  if (directValid && swappedValid) {
    const directPhilippines = isLikelyPhilippineCoordinate(directLat, directLng);
    const swappedPhilippines = isLikelyPhilippineCoordinate(swappedLat, swappedLng);

    if (swappedPhilippines && !directPhilippines) {
      return { lat: swappedLat, lng: swappedLng };
    }

    return { lat: directLat, lng: directLng };
  }

  if (directValid) {
    return { lat: directLat, lng: directLng };
  }

  if (swappedValid) {
    return { lat: swappedLat, lng: swappedLng };
  }

  return null;
}

function hasMapCoordinates(point: any) {
  return Boolean(normalizeMapCoordinate(point));
}

function splitAddressParts(address: string) {
  return String(address || '')
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);
}

function normalizeProvinceToken(value: string) {
  return String(value || '')
    .toLowerCase()
    .replace(/\bphilippines\b/g, '')
    .replace(/\bprovince\b/g, '')
    .replace(/\bcity\b/g, '')
    .replace(/\bmunicipality\b/g, '')
    .replace(/\bmetro\b/g, '')
    .replace(/[0-9]/g, ' ')
    .replace(/[^a-z\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractProvinceLabel(address: string) {
  const parts = splitAddressParts(address);
  const candidates = [...parts].reverse();

  for (const part of candidates) {
    const normalized = normalizeProvinceToken(part);

    if (normalized && normalized !== 'philippines') {
      return normalized;
    }
  }

  return '';
}

function isSameProvinceRoute(order: any) {
  const sellerProvince = extractProvinceLabel(String(order?.sellerAddress || order?.location || ''));
  const buyerProvince = extractProvinceLabel(String(order?.buyerAddress || order?.location || ''));

  return Boolean(sellerProvince && buyerProvince && sellerProvince === buyerProvince);
}

function buildMarkerSvgDataUrl(fill: string, stroke: string, glyph: string) {
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48">
      <circle cx="24" cy="24" r="16" fill="${fill}" stroke="${stroke}" stroke-width="3" />
      <text x="24" y="29" font-size="16" text-anchor="middle" fill="#ffffff" font-family="Arial, sans-serif" font-weight="700">${glyph}</text>
    </svg>
  `)}`;
}

function getVehicleMarkerIconUrl(
  vehicle: 'truck' | 'motorcycle',
  direction: 'left' | 'right',
) {
  if (vehicle === 'motorcycle') {
    return direction === 'left' ? motorbikeMirroredIconUrl : motorbikeIconUrl;
  }

  return direction === 'left' ? deliveryTruckMirroredIconUrl : deliveryTruckIconUrl;
}

function buildAreaLabel(address: string, fallback: string) {
  const parts = splitAddressParts(address);

  for (let index = parts.length - 1; index >= 0; index -= 1) {
    const part = parts[index];
    const cleaned = String(part || '')
      .replace(/\bphilippines\b/gi, '')
      .replace(/\bregion\b/gi, '')
      .replace(/[0-9]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (cleaned) {
      return cleaned;
    }
  }

  return fallback;
}

function interpolateMapPoint(start: { lat: number; lng: number }, end: { lat: number; lng: number }, ratio: number) {
  return {
    lat: start.lat + (end.lat - start.lat) * ratio,
    lng: start.lng + (end.lng - start.lng) * ratio,
  };
}

function buildSyntheticDestinationHub(order: any, logistics: any) {
  const buyerAddress = String(order?.buyerAddress || order?.location || '').trim();
  const destinationStop = Array.isArray(logistics?.routeStops)
    ? logistics.routeStops.find((stop: any) => String(stop?.type || '').trim() === 'destination')
    : null;
  const destinationCoordinates = normalizeMapCoordinate(
    destinationStop?.coordinates || order?.buyerCoordinates || logistics?.routeStops?.[logistics.routeStops.length - 1]?.coordinates,
  );
  const routeGeometry = Array.isArray(logistics?.routeGeometry)
    ? logistics.routeGeometry.map((point: any) => normalizeMapCoordinate(point)).filter(Boolean) as Array<{ lat: number; lng: number }>
    : [];
  const fallbackStart = normalizeMapCoordinate(
    logistics?.routeStops?.[0]?.coordinates || order?.sellerCoordinates || logistics?.currentLocation,
  );

  if (!destinationCoordinates || !fallbackStart) {
    return null;
  }

  const geometryCandidate = routeGeometry.length >= 3
    ? routeGeometry[Math.max(1, Math.min(routeGeometry.length - 2, Math.floor(routeGeometry.length * 0.78)))]
    : null;
  const interpolatedCandidate = interpolateMapPoint(fallbackStart, destinationCoordinates, 0.82);
  const selectedCoordinates =
    geometryCandidate && calculateCoordinateDistanceKm(geometryCandidate, destinationCoordinates) > 0.35
      ? geometryCandidate
      : interpolatedCandidate;

  return {
    id: 'destination_hub',
    type: 'hub',
    label: `Delivery hub near ${buildAreaLabel(buyerAddress, 'buyer area')}`,
    address: buildAreaLabel(buyerAddress, 'Buyer area'),
    coordinates: selectedCoordinates,
    estimatedAt: destinationStop?.estimatedAt || null,
    arrivedAt: null,
    departedAt: null,
    state: 'pending',
  };
}

function getDisplayRouteStops(order: any) {
  const logistics = getMarketplaceLogistics(order);

  if (!logistics || !Array.isArray(logistics.routeStops)) {
    return [];
  }

  const existingDestinationHub = logistics.routeStops.find((stop: any) => String(stop?.id || '').trim() === 'destination_hub');
  if (existingDestinationHub) {
    return logistics.routeStops;
  }

  const destinationStopIndex = logistics.routeStops.findIndex((stop: any) => String(stop?.type || '').trim() === 'destination');
  if (destinationStopIndex < 0) {
    return logistics.routeStops;
  }

  const syntheticDestinationHub = buildSyntheticDestinationHub(order, logistics);
  if (!syntheticDestinationHub) {
    return logistics.routeStops;
  }

  const nextStops = [...logistics.routeStops];
  nextStops.splice(destinationStopIndex, 0, syntheticDestinationHub);
  return nextStops;
}

function getTimelineRouteStops(order: any) {
  const logistics = getMarketplaceLogistics(order);
  const routeStops = getDisplayRouteStops(order);

  if (!logistics || routeStops.length === 0) {
    return [];
  }

  const rawStops = Array.isArray(logistics.routeStops) ? logistics.routeStops : [];
  const rawCurrentStopIndex = Math.max(0, Math.min(Number(logistics.currentStopIndex || 0), Math.max(rawStops.length - 1, 0)));
  const progressPercent = Number(logistics.progressPercent || 0);
  const routeProgressPercent = getMarketplaceRouteProgressPercent(order);
  const revealBuyerDestination = shouldRevealBuyerDestination(order);
  const destinationHubIndex = routeStops.findIndex((stop: any) => String(stop?.id || '').trim() === 'destination_hub');
  const rawLastStopIndex = Math.max(rawStops.length - 1, 0);
  let displayCurrentStopIndex = Math.min(rawCurrentStopIndex, Math.max(routeStops.length - 1, 0));

  if (destinationHubIndex >= 0 && routeStops.length > rawStops.length && rawCurrentStopIndex >= rawLastStopIndex) {
    displayCurrentStopIndex = revealBuyerDestination
      ? routeStops.length - 1
      : destinationHubIndex;
  } else if (
    destinationHubIndex >= 0
    && routeStops.length > rawStops.length
    && revealBuyerDestination
    && routeProgressPercent >= 80
  ) {
    displayCurrentStopIndex = Math.max(destinationHubIndex, displayCurrentStopIndex);
  }

  return routeStops.map((stop: any, index: number) => ({
    ...stop,
    state:
      index < displayCurrentStopIndex
        ? 'completed'
        : index === displayCurrentStopIndex
          ? index === routeStops.length - 1 && progressPercent === 100 ? 'completed' : 'current'
          : index === displayCurrentStopIndex + 1 && progressPercent > 0
            ? 'up_next'
            : 'pending',
  }));
}

function getDestinationHubIndex(order: any) {
  return getDisplayRouteStops(order).findIndex((stop: any) => String(stop?.id || '').trim() === 'destination_hub');
}

function shouldRevealBuyerDestination(order: any) {
  const logistics = getMarketplaceLogistics(order);
  const routeProgressPercent = getMarketplaceRouteProgressPercent(order);

  if (!logistics) {
    return false;
  }

  const destinationHubIndex = getDestinationHubIndex(order);

  if (destinationHubIndex < 0) {
    return true;
  }

  const rawStopCount = Array.isArray(logistics.routeStops) ? logistics.routeStops.length : 0;
  const rawLastStopIndex = Math.max(rawStopCount - 1, 0);

  if (Number(logistics.currentStopIndex || 0) >= destinationHubIndex) {
    return true;
  }

  if (routeProgressPercent >= 80) {
    return true;
  }

  return Number(logistics.currentStopIndex || 0) >= rawLastStopIndex && Number(logistics.progressPercent || 0) >= 80;
}

function getVisibleRouteStops(order: any) {
  const logistics = getMarketplaceLogistics(order);
  return Array.isArray(logistics?.routeStops) ? logistics.routeStops : [];
}

function clampPreviewPercent(value: number) {
  return Math.max(0, Math.min(100, Math.round(Number(value || 0))));
}

function buildPreviewLogistics(order: any, routeProgressPercent: number) {
  const logistics = getMarketplaceLogistics(order);

  if (!logistics) {
    return order?.logistics || null;
  }

  const safeProgress = clampPreviewPercent(routeProgressPercent);
  const routeStops = Array.isArray(logistics.routeStops) ? logistics.routeStops : [];
  const lastStopIndex = Math.max(routeStops.length - 1, 0);
  const totalLegs = Math.max(routeStops.length - 1, 1);
  const rawLegPosition = (safeProgress / 100) * totalLegs;
  const currentStopIndex = safeProgress >= 100
    ? lastStopIndex
    : Math.max(0, Math.min(Math.floor(rawLegPosition), Math.max(totalLegs - 1, 0)));
  const legProgressPercent = safeProgress >= 100
    ? 100
    : clampPreviewPercent((rawLegPosition - currentStopIndex) * 100);
  const currentStop = routeStops[currentStopIndex] || null;
  const nextStop = routeStops[currentStopIndex + 1] || null;
  const currentLocation = currentStop && nextStop
    ? interpolateMapPoint(
        normalizeMapCoordinate(currentStop.coordinates) || currentStop.coordinates,
        normalizeMapCoordinate(nextStop.coordinates) || nextStop.coordinates,
        legProgressPercent / 100,
      )
    : normalizeMapCoordinate(logistics.currentLocation) || normalizeMapCoordinate(currentStop?.coordinates);

  return {
    ...logistics,
    currentStopIndex,
    progressPercent: legProgressPercent,
    currentStop,
    nextStop,
    currentLocation,
  };
}

function applyPreviewToOrder(order: any, previewProgressByOrderId: Record<string, number>) {
  const orderId = String(order?.orderId || '').trim();
  const previewProgress = previewProgressByOrderId[orderId];

  if (!orderId || typeof previewProgress !== 'number' || !Number.isFinite(previewProgress)) {
    return order;
  }

  return {
    ...order,
    logistics: buildPreviewLogistics(order, previewProgress),
  };
}

function applyPreviewToOrders(orders: any[], previewProgressByOrderId: Record<string, number>) {
  return orders.map((order) => applyPreviewToOrder(order, previewProgressByOrderId));
}

function trimGeometryToStop(order: any, geometry: Array<{ lat: number; lng: number }>, targetStopId: string) {
  const routeStops = getDisplayRouteStops(order);
  if (routeStops.length === 0 || geometry.length === 0) {
    return geometry;
  }

  const targetStop = routeStops.find((stop: any) => String(stop?.id || '').trim() === targetStopId);
  const targetCoordinate = normalizeMapCoordinate(targetStop?.coordinates);

  if (!targetCoordinate) {
    return geometry;
  }

  const nearestIndex = geometry.reduce((bestIndex, point, index) => {
    const currentDistance = calculateCoordinateDistanceKm(point, targetCoordinate);
    const bestDistance = calculateCoordinateDistanceKm(geometry[bestIndex], targetCoordinate);
    return currentDistance < bestDistance ? index : bestIndex;
  }, 0);

  return geometry.slice(0, nearestIndex + 1);
}

function getVisibleRouteGeometry(order: any, geometry: Array<{ lat: number; lng: number }>) {
  return geometry;
}

function getVehicleKind(order: any) {
  return shouldRevealBuyerDestination(order) ? 'motorcycle' : 'truck';
}

function getVehicleDirection(
  from: { lat: number; lng: number } | null,
  to: { lat: number; lng: number } | null,
) {
  if (!from || !to) {
    return 'right' as const;
  }

  const lngDelta = to.lng - from.lng;

  if (Math.abs(lngDelta) >= 0.0008) {
    return lngDelta < 0 ? 'left' as const : 'right' as const;
  }

  return to.lat < from.lat ? 'left' as const : 'right' as const;
}

function getVisibleBuyerOrderTimeline(order: any) {
  return getBuyerOrderTimeline(order);
}

function getVisibleBuyerAddress(order: any) {
  return order?.buyerAddress || order?.location || 'Waiting for buyer address update';
}

function shiftTimelineTimestamp(value: string | number | Date | null | undefined, minutes: number) {
  if (!value) {
    return null;
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return null;
  }

  date.setMinutes(date.getMinutes() + minutes);
  return date.toISOString();
}

function buildIntermediateTimelineTimestamp(
  startValue: string | number | Date | null | undefined,
  endValue: string | number | Date | null | undefined,
  fallbackValue: string | number | Date | null | undefined,
) {
  const startDate = startValue ? new Date(startValue) : null;
  const endDate = endValue ? new Date(endValue) : null;

  if (startDate && endDate && !Number.isNaN(startDate.getTime()) && !Number.isNaN(endDate.getTime())) {
    const gapMs = endDate.getTime() - startDate.getTime();

    if (gapMs > 60 * 1000) {
      return new Date(startDate.getTime() + Math.max(60 * 1000, Math.floor(gapMs / 2))).toISOString();
    }

    return new Date(Math.max(startDate.getTime(), endDate.getTime() - 60 * 1000)).toISOString();
  }

  if (endDate && !Number.isNaN(endDate.getTime())) {
    return new Date(endDate.getTime() - 60 * 1000).toISOString();
  }

  if (startDate && !Number.isNaN(startDate.getTime())) {
    return new Date(startDate.getTime() + 60 * 1000).toISOString();
  }

  return fallbackValue || null;
}

function buildLatestTimelineTimestamp(
  primaryValue: string | number | Date | null | undefined,
  comparisonValue: string | number | Date | null | undefined,
  offsetMinutes = 1,
) {
  const primaryDate = primaryValue ? new Date(primaryValue) : null;
  const comparisonDate = comparisonValue ? new Date(comparisonValue) : null;
  const safePrimary = primaryDate && !Number.isNaN(primaryDate.getTime()) ? primaryDate.getTime() : null;
  const safeComparison = comparisonDate && !Number.isNaN(comparisonDate.getTime()) ? comparisonDate.getTime() : null;

  if (safePrimary === null && safeComparison === null) {
    return null;
  }

  if (safePrimary !== null && safeComparison !== null) {
    return new Date(Math.max(safePrimary, safeComparison + (offsetMinutes * 60 * 1000))).toISOString();
  }

  if (safePrimary !== null) {
    return new Date(safePrimary).toISOString();
  }

  return new Date((safeComparison || Date.now()) + (offsetMinutes * 60 * 1000)).toISOString();
}

function getHubShortLabel(stop: any) {
  const address = String(stop?.address || '').trim();
  const label = String(stop?.label || '').trim();
  const parts = address
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean);

  if (parts.length > 0) {
    return parts[0];
  }

  return label.replace(/^Sorting hub near\s*/i, '').replace(/^Delivery hub near\s*/i, '').trim() || 'Hub';
}

function buildBuyerLogisticsTimeline(order: any) {
  const logistics = getMarketplaceLogistics(order);
  const timelineRouteStops = getTimelineRouteStops(order);
  const normalizedStatus = String(order?.status || 'paid').trim();

  if (!logistics || timelineRouteStops.length === 0) {
    return [];
  }

  const revealBuyerDestination = shouldRevealBuyerDestination(order);
  const routeProgressPercent = getMarketplaceRouteProgressPercent(order);
  const isRefunded = isApprovedMarketplaceRefund(order);
  const isOrderReceived = ['received', 'completed'].includes(String(order?.status || '').trim()) || Boolean(order?.receivedAt);
  const hasTransitStarted = ['in_transit', 'received', 'completed'].includes(normalizedStatus) || Boolean(order?.inTransitAt);
  const destinationHubStop = timelineRouteStops.find((stop: any) => String(stop?.id || '').trim() === 'destination_hub');
  const destinationHubTimelineTimestamp = destinationHubStop?.estimatedAt
    ? shiftTimelineTimestamp(destinationHubStop.estimatedAt, -12)
    : null;
  const pickupEventTimestamp = buildIntermediateTimelineTimestamp(
    order?.readyForPickupAt,
    order?.inTransitAt,
    order?.inTransitAt || order?.readyForPickupAt || order?.createdAt || null,
  );
  const transitToNextLocationTimestamp = buildIntermediateTimelineTimestamp(
    pickupEventTimestamp,
    destinationHubTimelineTimestamp || order?.receivedAt || destinationHubStop?.estimatedAt || null,
    shiftTimelineTimestamp(pickupEventTimestamp, 10),
  );
  const routeEvents = !hasTransitStarted ? [] : timelineRouteStops.flatMap((stop: any, index: number) => {
    const stopType = String(stop?.type || '').trim();
    const state = String(stop?.state || 'pending').trim();
    const timestamp = stop?.arrivedAt || stop?.estimatedAt || null;
    const detail = String(stop?.address || '').trim() || 'Planned route checkpoint.';
    const eventStack: Array<{ key: string; title: string; detail: string; timestamp: string | number | Date | null; tone: string }> = [];

    if (stopType === 'destination' && !revealBuyerDestination) {
      return [];
    }

    if (stopType === 'destination') {
      if (routeProgressPercent >= 81 && revealBuyerDestination) {
        eventStack.push({
          key: `route-${String(stop?.id || index).trim()}-out`,
          title: 'Parcel is out for delivery',
          detail: 'The rider is already heading to the buyer address.',
          timestamp: shiftTimelineTimestamp(timestamp, -6),
          tone: 'info',
        });
      }

      if (isRefunded || isOrderReceived) {
        const deliveredTimestamp = isRefunded
          ? (order?.refundRequest?.refundedAt || order?.refundRequest?.reviewedAt || order?.cancelledAt || order?.receivedAt || timestamp)
          : buildLatestTimelineTimestamp(order?.receivedAt, timestamp, 1);
        eventStack.push({
          key: `route-${String(stop?.id || index).trim()}-delivered`,
          title: isRefunded ? 'Refunded' : 'Order received',
          detail: isRefunded
            ? 'The refund request was approved and the order has been refunded.'
            : 'The parcel has reached the buyer address and the delivery is complete.',
          timestamp: deliveredTimestamp,
          tone: 'success',
        });
      }
      return eventStack;
    }

    if (state !== 'current' && state !== 'completed') {
      return [];
    }

    if (stopType === 'hub') {
      const isDeliveryHub = String(stop?.id || '').trim() === 'destination_hub';
      const hubLabel = getHubShortLabel(stop);

      if (isDeliveryHub) {
        if (routeProgressPercent >= 80) {
          eventStack.push({
          key: `route-${String(stop?.id || index).trim()}-arrived`,
          title: `Your parcel has arrived at the delivery hub: ${hubLabel}`,
          detail,
          timestamp: shiftTimelineTimestamp(timestamp, -12),
          tone: 'info',
          });
        }
      } else {
        if (state === 'completed' || state === 'current') {
          eventStack.push({
          key: `route-${String(stop?.id || index).trim()}-arrived`,
          title: `Parcel has arrived at sorting facility: ${hubLabel}`,
          detail,
          timestamp,
          tone: state === 'completed' ? 'success' : 'info',
          });
        }
      }

      return eventStack;
    }

    if (stopType === 'pickup') {
      eventStack.push({
        key: `route-${String(stop?.id || index).trim()}-picked-up`,
        title: 'Your parcel has been picked up by our logistics partner',
        detail,
        timestamp: pickupEventTimestamp,
        tone: state === 'completed' ? 'success' : 'info',
      });

      if (state === 'completed') {
        eventStack.push({
          key: `route-${String(stop?.id || index).trim()}-moving`,
          title: 'The order is in transit and is on its way to the next location.',
          detail: 'The parcel has left the pickup point and is moving to the next facility.',
          timestamp: transitToNextLocationTimestamp,
          tone: 'info',
        });
      }

      return eventStack;
    }

    return eventStack;
  });

  const statusEvents = [];

  if (['ready_for_pickup', 'in_transit', 'received', 'completed'].includes(normalizedStatus) && order?.readyForPickupAt) {
    statusEvents.push({
      key: 'pickup',
      title: 'Seller is done preparing waiting for our logistics partner to pick up',
      detail: 'The seller finished preparing your order and it is now waiting for our logistics partner to pick it up.',
      timestamp: order.readyForPickupAt,
      tone: 'info',
    });
  }

  return [...routeEvents, ...statusEvents]
    .filter((event) => event.title)
    .sort((left, right) => new Date(right.timestamp || 0).getTime() - new Date(left.timestamp || 0).getTime())
    .filter((event, index, collection) => collection.findIndex((entry) => entry.key === event.key) === index);
}

function filterGeometryToAnchors(geometry: any[], anchors: Array<{ lat: number; lng: number }>) {
  if (!Array.isArray(geometry) || geometry.length === 0) {
    return [];
  }

  const normalizedGeometry = geometry
    .map((point) => normalizeMapCoordinate(point))
    .filter(Boolean) as Array<{ lat: number; lng: number }>;

  if (normalizedGeometry.length === 0) {
    return [];
  }

  if (!Array.isArray(anchors) || anchors.length === 0) {
    return normalizedGeometry;
  }

  const latitudes = anchors.map((point) => point.lat);
  const longitudes = anchors.map((point) => point.lng);
  const minLat = Math.min(...latitudes) - 1.5;
  const maxLat = Math.max(...latitudes) + 1.5;
  const minLng = Math.min(...longitudes) - 1.5;
  const maxLng = Math.max(...longitudes) + 1.5;

  const anchoredGeometry = normalizedGeometry.filter(
    (point) => point.lat >= minLat && point.lat <= maxLat && point.lng >= minLng && point.lng <= maxLng,
  );

  return anchoredGeometry.length >= 2 ? anchoredGeometry : normalizedGeometry;
}

function calculateCoordinateDistanceKm(
  first: { lat: number; lng: number },
  second: { lat: number; lng: number },
) {
  const earthRadiusKm = 6371;
  const deltaLat = ((second.lat - first.lat) * Math.PI) / 180;
  const deltaLng = ((second.lng - first.lng) * Math.PI) / 180;
  const firstLatRadians = (first.lat * Math.PI) / 180;
  const secondLatRadians = (second.lat * Math.PI) / 180;
  const a =
    Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
    Math.cos(firstLatRadians) *
      Math.cos(secondLatRadians) *
      Math.sin(deltaLng / 2) *
      Math.sin(deltaLng / 2);

  return earthRadiusKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function pickTrustedCurrentLocation(
  point: { lat: number; lng: number } | null,
  anchors: Array<{ lat: number; lng: number }>,
) {
  if (!point || anchors.length === 0) {
    return point;
  }

  const nearestDistanceKm = anchors.reduce((smallest, anchor) => {
    const distanceKm = calculateCoordinateDistanceKm(point, anchor);
    return Math.min(smallest, distanceKm);
  }, Number.POSITIVE_INFINITY);

  return nearestDistanceKm <= 50 ? point : null;
}

function snapPointToRoute(
  point: { lat: number; lng: number } | null,
  route: Array<{ lat: number; lng: number }>,
) {
  if (!point || route.length === 0) {
    return point;
  }

  const nearestPoint = route.reduce(
    (best, candidate) => {
      const distanceKm = calculateCoordinateDistanceKm(point, candidate);

      if (distanceKm < best.distanceKm) {
        return {
          distanceKm,
          point: candidate,
        };
      }

      return best;
    },
    {
      distanceKm: Number.POSITIVE_INFINITY,
      point,
    },
  );

  return nearestPoint.distanceKm <= 3 ? nearestPoint.point : point;
}

function getLogisticsProviderSummary(order: any) {
  const logistics = getMarketplaceLogistics(order);

  if (!logistics?.providerMeta) {
    return 'Route service pending';
  }

  const providers = [
    logistics.providerMeta.optimization,
    logistics.providerMeta.geometry,
    logistics.providerMeta.eta,
  ]
    .map((value: string) => String(value || '').trim())
    .filter(Boolean);

  if (providers.length === 0) {
    return 'Route service pending';
  }

  return providers
    .map((provider: string) => provider.replace(/_/g, ' '))
    .map((provider: string) => provider.charAt(0).toUpperCase() + provider.slice(1))
    .filter((provider: string, index: number, collection: string[]) => collection.indexOf(provider) === index)
    .join(' - ');
}

function getRouteHeadingCopy(order: any) {
  const logistics = getMarketplaceLogistics(order);

  if (!logistics) {
    return 'Waiting for route planning details.';
  }

  if (!logistics.simulationEnabled) {
    return logistics.simulationLockedReason || 'Tracking becomes available when the parcel is ready for pickup.';
  }

  if (logistics.nextStop?.label) {
    return `Heading to ${logistics.nextStop.label}`;
  }

  if (logistics.currentStop?.label) {
    return `Arriving at ${logistics.currentStop.label}`;
  }

  return 'Final destination reached.';
}

function getStopStateLabel(stop: any) {
  if (stop?.state === 'completed') {
    return 'Completed';
  }

  if (stop?.state === 'current') {
    return 'Current';
  }

  if (stop?.state === 'up_next') {
    return 'Up next';
  }

  return 'Pending';
}

function LogisticsTrackerPanel({ order }: { order: any }) {
  const logistics = getMarketplaceLogistics(order);
  const mapRef = useRef<HTMLDivElement | null>(null);
  const [mapError, setMapError] = useState('');
  const sameProvinceRoute = isSameProvinceRoute(order);
  const shouldShowMap = Boolean(logistics?.simulationEnabled) && hasMarketplaceTransitStarted(order);

  useEffect(() => {
    if (!shouldShowMap || !mapRef.current) {
      setMapError('');
      return undefined;
    }

    const stopPoints = getVisibleRouteStops(order)
      ? getVisibleRouteStops(order)
          .map((stop: any) => ({
            ...stop,
            coordinates: normalizeMapCoordinate(stop?.coordinates),
          }))
          .filter((stop: any) => stop.coordinates)
      : [];
    const anchorPoints = stopPoints.map((stop: any) => stop.coordinates);
    const geometryPoints = getVisibleRouteGeometry(order, filterGeometryToAnchors(
      Array.isArray(logistics.routeGeometry) ? logistics.routeGeometry : [],
      anchorPoints,
    ));
    const currentLocationCandidate =
      normalizeMapCoordinate(logistics.currentLocation) || normalizeMapCoordinate(logistics.currentStop?.coordinates);
    const routeAnchorPoints = geometryPoints.length > 0 ? [...geometryPoints, ...anchorPoints] : anchorPoints;
    const currentLocation = snapPointToRoute(
      pickTrustedCurrentLocation(currentLocationCandidate, routeAnchorPoints),
      geometryPoints,
    );
    const destinationStop = stopPoints[stopPoints.length - 1] || null;
    const vehicleDirection = getVehicleDirection(
      currentLocation,
      normalizeMapCoordinate(destinationStop?.coordinates),
    );

    if (geometryPoints.length === 0 && stopPoints.length === 0 && !currentLocation) {
      setMapError('No route coordinates are available for this parcel yet.');
      return undefined;
    }

    let isCancelled = false;
    let routePolyline: any = null;
    const markers: any[] = [];
    setMapError('');

    loadMarketplaceGoogleMapsScript()
      .then((google) => {
        if (isCancelled || !mapRef.current) {
          return;
        }

        const map = new google.maps.Map(mapRef.current, {
          center: currentLocation || geometryPoints[0] || stopPoints[0]?.coordinates || { lat: 10.3157, lng: 123.8854 },
          zoom: sameProvinceRoute ? 13 : 7,
          mapTypeControl: false,
          fullscreenControl: false,
          streetViewControl: false,
          clickableIcons: false,
        });

        if (geometryPoints.length >= 2) {
          routePolyline = new google.maps.Polyline({
            map,
            path: geometryPoints,
            strokeColor: '#ef4444',
            strokeOpacity: 0.92,
            strokeWeight: 5,
          });
        }

        if (geometryPoints.length < 2 && stopPoints.length >= 2) {
          routePolyline = new google.maps.Polyline({
            map,
            path: stopPoints.map((stop: any) => stop.coordinates),
            strokeColor: '#ef4444',
            strokeOpacity: 0.92,
            strokeWeight: 5,
          });
        }

        stopPoints.forEach((stop: any, index: number) => {
          const fill =
            stop.state === 'completed'
              ? '#16a34a'
              : stop.state === 'current'
                ? '#0ea5e9'
                : stop.state === 'up_next'
                  ? '#f59e0b'
                  : '#94a3b8';
          const marker = new google.maps.Marker({
            map,
            position: stop.coordinates,
            title: stop.label || `Stop ${index + 1}`,
            icon: {
              url: buildMarkerSvgDataUrl(fill, '#ffffff', ''),
              scaledSize: new google.maps.Size(24, 24),
              anchor: new google.maps.Point(12, 12),
            },
          });
          markers.push(marker);
        });

        if (currentLocation) {
          const vehicleKind = getVehicleKind(order);
          const vehicleSize = vehicleKind === 'motorcycle' ? 42 : 42;
          const currentMarker = new google.maps.Marker({
            map,
            position: currentLocation,
            title: logistics.currentStop?.label || 'Current parcel location',
            icon: {
              url: getVehicleMarkerIconUrl(vehicleKind, vehicleDirection),
              scaledSize: new google.maps.Size(vehicleSize, vehicleSize),
              anchor: new google.maps.Point(Math.round(vehicleSize / 2), Math.round(vehicleSize * 0.78)),
            },
            zIndex: 1000,
          });
          markers.push(currentMarker);
        }

        const bounds = new google.maps.LatLngBounds();

        stopPoints.forEach((stop: any) => bounds.extend(stop.coordinates));
        geometryPoints.forEach((point: any) => bounds.extend(point));

        if (!bounds.isEmpty()) {
          map.fitBounds(bounds, sameProvinceRoute ? 24 : 56);
          google.maps.event.addListenerOnce(map, 'idle', () => {
            if (isCancelled) {
              return;
            }

            const currentZoom = Number(map.getZoom() || 0);

            if (sameProvinceRoute && currentZoom > 13) {
              map.setZoom(13);
              return;
            }

            if (!sameProvinceRoute && currentZoom > 9) {
              map.setZoom(9);
            }
          });
        }
      })
      .catch((error) => {
        if (!isCancelled) {
          setMapError(error instanceof Error ? error.message : 'Unable to load the parcel map.');
        }
      });

    return () => {
      isCancelled = true;
      if (routePolyline) {
        routePolyline.setMap(null);
      }
      markers.forEach((marker) => marker.setMap(null));
    };
  }, [logistics, order, sameProvinceRoute, shouldShowMap]);

  if (!shouldShowMap) {
    return null;
  }

  return (
    <div className="rounded-[2rem] border border-sky-100 bg-gradient-to-br from-sky-50 via-white to-emerald-50 p-5 shadow-sm">
      <div className="relative overflow-hidden rounded-[1.75rem] border border-white/70 bg-slate-100 shadow-sm">
        <div ref={mapRef} className="h-[23rem] w-full" />

        {mapError ? (
          <div className="absolute inset-x-4 top-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-700 shadow-sm">
            {mapError}
          </div>
        ) : null}
      </div>
    </div>
  );
}

export function Marketplace({ onAddToCart, currentUser, isCartOpen }: MarketplaceProps) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState<'buy' | 'sell' | 'orders'>(() => getMarketplaceViewFromSearchParams(searchParams));
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [products, setProducts] = useState<any[]>([]);
  const [myListings, setMyListings] = useState<any[]>([]);
  const [locationOptions, setLocationOptions] = useState<string[]>([]);
  const [canManageListings, setCanManageListings] = useState(false);
  const [myOrders, setMyOrders] = useState<any[]>([]);
  const [sellerOrders, setSellerOrders] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isListingModalOpen, setIsListingModalOpen] = useState(false);
  const [listingForm, setListingForm] = useState<ListingFormState>(() => buildEmptyListingForm(currentUser));
  const [listingImages, setListingImages] = useState<File[]>([]);
  const [listingImagePreviews, setListingImagePreviews] = useState<string[]>([]);
  const [listingError, setListingError] = useState('');
  const [listingSuccess, setListingSuccess] = useState('');
  const [isSavingListing, setIsSavingListing] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);
  const [selectedProductImage, setSelectedProductImage] = useState('');
  const [selectedReviewImage, setSelectedReviewImage] = useState('');
  const [selectedProductVarietyId, setSelectedProductVarietyId] = useState('');
  const [marketplaceActionError, setMarketplaceActionError] = useState('');
  const [updatingOrderId, setUpdatingOrderId] = useState('');
  const [reviewingOrder, setReviewingOrder] = useState<any | null>(null);
  const [reviewRating, setReviewRating] = useState(5);
  const [hoveredReviewRating, setHoveredReviewRating] = useState(0);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewImageFiles, setReviewImageFiles] = useState<File[]>([]);
  const [reviewImagePreviews, setReviewImagePreviews] = useState<string[]>([]);
  const [reviewModalError, setReviewModalError] = useState('');
  const [refundingOrder, setRefundingOrder] = useState<any | null>(null);
  const [refundReason, setRefundReason] = useState('');
  const [refundImageFiles, setRefundImageFiles] = useState<File[]>([]);
  const [refundImagePreviews, setRefundImagePreviews] = useState<string[]>([]);
  const [refundModalError, setRefundModalError] = useState('');
  const [cancellingOrder, setCancellingOrder] = useState<any | null>(null);
  const [cancelReason, setCancelReason] = useState('Cancelled by buyer before seller preparation');
  const [cancelModalError, setCancelModalError] = useState('');
  const [selectedBuyerOrderId, setSelectedBuyerOrderId] = useState('');
  const [selectedBuyerOrderTab, setSelectedBuyerOrderTab] = useState<'all' | 'to_pay' | 'to_ship' | 'to_receive' | 'completed' | 'cancelled' | 'return_refund'>(() => getMarketplaceBuyerOrderTabFromSearchParams(searchParams));
  const [selectedSellerSection, setSelectedSellerSection] = useState<'listings' | 'orders'>(() => getMarketplaceSellerSectionFromSearchParams(searchParams));
  const [selectedSellerOrderId, setSelectedSellerOrderId] = useState('');
  const [selectedBuyerRefundDetails, setSelectedBuyerRefundDetails] = useState<any | null>(null);
  const [selectedSellerRefundDetails, setSelectedSellerRefundDetails] = useState<any | null>(null);
  const [previewProgressByOrderId, setPreviewProgressByOrderId] = useState<Record<string, number>>({});
  const previewProgressByOrderIdRef = useRef<Record<string, number>>({});

  const isSeller = currentUser?.roles?.includes('seller') || canManageListings;
  const isCommerciallyRestricted = currentUser?.canManageCommercialFeatures === false;

  useEffect(() => {
    previewProgressByOrderIdRef.current = previewProgressByOrderId;
  }, [previewProgressByOrderId]);

  const derivedLocationOptions = useMemo(() => {
    const fallbackOptions = buildLocationOptions(currentUser);
    return locationOptions.length > 0 ? locationOptions : fallbackOptions;
  }, [currentUser, locationOptions]);

  const loadMarketplace = () => {
    const previewMap = previewProgressByOrderIdRef.current;
    const cachedPayload = readMarketplaceCache();

    if (cachedPayload) {
      setProducts(cachedPayload.products || []);
      setMyListings(cachedPayload.myListings || []);
      setMyOrders(applyPreviewToOrders(cachedPayload.myOrders || [], previewMap));
      setSellerOrders(applyPreviewToOrders(cachedPayload.sellerOrders || [], previewMap));
      setCanManageListings(Boolean(cachedPayload.canManageListings));
      setLocationOptions(Array.isArray(cachedPayload.locationOptions) ? cachedPayload.locationOptions.filter(Boolean) : []);
    }

    getMarketplaceData()
      .then((payload) => {
        setProducts(payload.products || []);
        setMyListings(payload.myListings || []);
        setMyOrders(applyPreviewToOrders(payload.myOrders || [], previewMap));
        setSellerOrders(applyPreviewToOrders(payload.sellerOrders || [], previewMap));
        setCanManageListings(Boolean(payload.canManageListings));
        setLocationOptions(Array.isArray(payload.locationOptions) ? payload.locationOptions.filter(Boolean) : []);
        writeMarketplaceCache({
          products: payload.products || [],
          myListings: payload.myListings || [],
          myOrders: payload.myOrders || [],
          sellerOrders: payload.sellerOrders || [],
          canManageListings: Boolean(payload.canManageListings),
          locationOptions: Array.isArray(payload.locationOptions) ? payload.locationOptions.filter(Boolean) : [],
        });
      })
      .catch(() => undefined);
  };

  useEffect(() => {
    loadMarketplace();
  }, []);

  useEffect(() => {
    const handleMarketplaceUpdated = () => {
      loadMarketplace();
    };

    window.addEventListener('agrihub:marketplace-updated', handleMarketplaceUpdated);
    return () => window.removeEventListener('agrihub:marketplace-updated', handleMarketplaceUpdated);
  }, []);

  useEffect(() => {
    if (!currentUser?.id) {
      return undefined;
    }

    const shouldPollMarketplace =
      activeTab === 'orders'
      || activeTab === 'sell';

    if (!shouldPollMarketplace) {
      return undefined;
    }

    const intervalId = window.setInterval(() => {
      loadMarketplace();
    }, 10000);

    return () => window.clearInterval(intervalId);
  }, [activeTab, currentUser?.id, selectedSellerSection]);

  useEffect(() => () => {
    reviewImagePreviews.forEach((preview) => {
      if (preview.startsWith('blob:')) {
        URL.revokeObjectURL(preview);
      }
    });
  }, [reviewImagePreviews]);

  useEffect(() => {
    const applyPreview = (payload: any) => {
      const orderId = String(payload?.orderId || '').trim();
      const progressPercent = Number(payload?.progressPercent);

      if (!orderId || !Number.isFinite(progressPercent)) {
        return;
      }

      const safeProgress = clampPreviewPercent(progressPercent);
      previewProgressByOrderIdRef.current = {
        ...previewProgressByOrderIdRef.current,
        [orderId]: safeProgress,
      };

      setPreviewProgressByOrderId((current) => ({
        ...current,
        [orderId]: safeProgress,
      }));
      setMyOrders((current) => applyPreviewToOrders(current, {
        [orderId]: safeProgress,
      }));
      setSellerOrders((current) => applyPreviewToOrders(current, {
        [orderId]: safeProgress,
      }));
    };

    const handleStorage = (event: StorageEvent) => {
      if (event.key !== LOGISTICS_PREVIEW_STORAGE_KEY || !event.newValue) {
        return;
      }

      try {
        applyPreview(JSON.parse(event.newValue));
      } catch {
        // Ignore malformed preview sync payloads.
      }
    };

    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  useEffect(() => {
    const nextView = getMarketplaceViewFromSearchParams(searchParams);
    setActiveTab((current) => (current === nextView ? current : nextView));
  }, [searchParams]);

  useEffect(() => {
    const nextSellerSection = getMarketplaceSellerSectionFromSearchParams(searchParams);
    setSelectedSellerSection((current) => (current === nextSellerSection ? current : nextSellerSection));
  }, [searchParams]);

  useEffect(() => {
    const nextBuyerOrderTab = getMarketplaceBuyerOrderTabFromSearchParams(searchParams);
    setSelectedBuyerOrderTab((current) => (current === nextBuyerOrderTab ? current : nextBuyerOrderTab));
  }, [searchParams]);

  useEffect(() => {
    const requestedOrderId = String(searchParams.get('marketOrderId') || '').trim();

    if (!requestedOrderId || activeTab !== 'orders') {
      return;
    }

    const matchingBuyerOrder = myOrders.find((order) => String(order?.orderId || '').trim() === requestedOrderId);

    if (matchingBuyerOrder) {
      setSelectedBuyerOrderId(requestedOrderId);
      setSearchParams((current) => {
        const next = new URLSearchParams(current);
        next.delete('marketOrderId');
        return next;
      }, { replace: true });
    }
  }, [activeTab, myOrders, searchParams, setSearchParams]);

  useEffect(() => {
    setSelectedBuyerRefundDetails(null);
  }, [selectedBuyerOrderId]);

  useEffect(() => {
    setSelectedSellerRefundDetails(null);
  }, [selectedSellerOrderId]);

  useEffect(() => {
    if (!isCartOpen) {
      return;
    }

    setSelectedProduct(null);
  }, [isCartOpen]);

  const filteredProducts = useMemo(() => {
    const normalizedSearch = searchTerm.trim().toLowerCase();

    return products
      .filter((product) => selectedCategory === 'all' ? true : product.category === selectedCategory)
      .filter((product) => {
        if (!normalizedSearch) {
          return true;
        }

        const varietyLabels = getProductVarieties(product).map((variety: any) => String(variety?.label || '').toLowerCase());

        return [
          product.name,
          product.category,
          product.description,
          product.brand,
          product.seller,
          product.location,
          ...varietyLabels,
        ]
          .map((value) => String(value || '').toLowerCase())
          .some((value) => value.includes(normalizedSearch));
      });
  }, [products, searchTerm, selectedCategory]);

  const unitChoices = unitOptions[listingForm.category] || ['piece'];
  const listingSupportsVarieties = supportsVarieties(listingForm.category);
  const showBrandField = ['fertilizer', 'equipment'].includes(listingForm.category);
  const showConditionField = listingForm.category === 'equipment';
  const showHarvestDateField = ['vegetables', 'fruits'].includes(listingForm.category);
  const selectedProductImages = Array.isArray(selectedProduct?.images) && selectedProduct.images.length > 0
    ? selectedProduct.images
    : selectedProduct?.image
      ? [selectedProduct.image]
      : [];
  const selectedVariety = selectedProduct ? getSelectedProductVariety(selectedProduct, selectedProductVarietyId) : null;
  const selectedBuyerOrder = selectedBuyerOrderId
    ? myOrders.find((order) => String(order?.orderId || '') === selectedBuyerOrderId) || null
    : null;
  const selectedSellerOrder = selectedSellerOrderId
    ? sellerOrders.find((order) => String(order?.orderId || '') === selectedSellerOrderId) || null
    : null;

  const resetListingForm = () => {
    setListingForm(buildEmptyListingForm(currentUser));
    setListingImages([]);
    setListingImagePreviews([]);
  };

  const handleOpenCreateListing = () => {
    setListingError('');
    setListingSuccess('');
    resetListingForm();
    setIsListingModalOpen(true);
  };

  const updateMarketplaceView = (nextView: 'buy' | 'sell' | 'orders') => {
    setActiveTab(nextView);

    const nextParams = new URLSearchParams(searchParams);
    nextParams.set('marketTab', nextView);
    setSearchParams(nextParams, { replace: true });
  };

  const updateMarketplaceSellerSection = (nextSection: 'listings' | 'orders') => {
    setSelectedSellerSection(nextSection);

    const nextParams = new URLSearchParams(searchParams);
    nextParams.set('marketTab', 'sell');
    nextParams.set('marketSellerTab', nextSection);
    setSearchParams(nextParams, { replace: true });
  };

  const updateMarketplaceBuyerOrderTab = (
    nextTab: 'all' | 'to_pay' | 'to_ship' | 'to_receive' | 'completed' | 'cancelled' | 'return_refund',
  ) => {
    setSelectedBuyerOrderTab(nextTab);

    const nextParams = new URLSearchParams(searchParams);
    nextParams.set('marketTab', 'orders');
    nextParams.set('marketOrdersTab', nextTab);
    setSearchParams(nextParams, { replace: true });
  };

  const handleOpenProductDetails = (product: any) => {
    setSelectedProduct(product);
    setSelectedProductImage(Array.isArray(product?.images) && product.images.length > 0 ? product.images[0] : String(product?.image || ''));
    setSelectedProductVarietyId(String(getProductVarieties(product)[0]?.id || ''));
  };

  const handleEditListing = (listing: any) => {
    const listingVarieties = getProductVarieties(listing);
    setListingError('');
    setListingSuccess('');
    setListingForm({
      listingId: String(listing.listingId || ''),
      name: String(listing.name || ''),
      category: String(listing.category || 'seeds'),
      description: String(listing.description || ''),
      brand: String(listing.brand || ''),
      condition: String(listing.condition || ''),
      harvestDate: String(listing.harvestDate || ''),
      location: String(listing.location || derivedLocationOptions[0] || ''),
      minimumOrder: String(listing.minimumOrder || 1),
      unit: String(listing.unit || 'piece'),
      basePrice: String(listing.price || ''),
      baseStock: String(listing.stock || ''),
      varieties: listingVarieties.length > 0
        ? listingVarieties.map((variety: any) => ({
            id: String(variety.id || buildVarietyDraft().id),
            label: String(variety.label || ''),
            price: String(variety.price || ''),
            stock: String(variety.stock || ''),
          }))
        : [buildVarietyDraft()],
    });
    setListingImages([]);
    setListingImagePreviews(Array.isArray(listing.images) ? listing.images.slice(0, 3) : []);
    setIsListingModalOpen(true);
  };

  const handleImageSelection = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);

    if (files.length === 0) {
      return;
    }

    const imageFiles = files.filter((file) => file.type.startsWith('image/')).slice(0, 3);
    setListingImages(imageFiles);
    setListingImagePreviews(imageFiles.map((file) => URL.createObjectURL(file)));
    setListingError('');
    event.target.value = '';
  };

  const handleAddVarietyRow = () => {
    setListingForm((current) => ({
      ...current,
      varieties: [...current.varieties, buildVarietyDraft()],
    }));
  };

  const handleUpdateVarietyRow = (id: string, field: 'label' | 'price' | 'stock', value: string) => {
    setListingForm((current) => ({
      ...current,
      varieties: current.varieties.map((variety) => (
        variety.id === id ? { ...variety, [field]: value } : variety
      )),
    }));
  };

  const handleRemoveVarietyRow = (id: string) => {
    setListingForm((current) => ({
      ...current,
      varieties: current.varieties.length > 1 ? current.varieties.filter((variety) => variety.id !== id) : current.varieties,
    }));
  };

  const handleSaveListing = async (event: React.FormEvent) => {
    event.preventDefault();
    setListingError('');
    setListingSuccess('');
    setIsSavingListing(true);

    try {
      if (!listingForm.name.trim() || !listingForm.description.trim() || !listingForm.location.trim()) {
        throw new Error('Product name, description, and location are required.');
      }

      if (!listingForm.listingId && listingImagePreviews.length < 1) {
        throw new Error('Upload at least 1 photo for a new listing.');
      }

      if (listingImagePreviews.length > 3 || listingImages.length > 3) {
        throw new Error('Upload at most 3 photos per listing.');
      }

      const normalizedVarieties = listingSupportsVarieties
        ? listingForm.varieties
            .map((variety) => ({
              id: variety.id,
              label: variety.label.trim(),
              price: Number(variety.price),
              stock: Number(variety.stock),
            }))
            .filter((variety) => variety.label || variety.price || variety.stock)
        : [];

      if (listingSupportsVarieties) {
        if (normalizedVarieties.length === 0) {
          throw new Error('Add at least one variety with its own price and stock.');
        }

        if (normalizedVarieties.some((variety) => !variety.label || !Number.isFinite(variety.price) || variety.price <= 0 || !Number.isFinite(variety.stock) || variety.stock <= 0)) {
          throw new Error('Each variety needs a name, valid price, and valid stock.');
        }
      } else {
        if (!Number.isFinite(Number(listingForm.basePrice)) || Number(listingForm.basePrice) <= 0) {
          throw new Error('Enter a valid listing price.');
        }

        if (!Number.isFinite(Number(listingForm.baseStock)) || Number(listingForm.baseStock) <= 0) {
          throw new Error('Enter a valid available stock quantity.');
        }
      }

      const imagePaths: string[] = [];

      if (listingImages.length > 0) {
        const supabase = requireSupabaseClient();

        for (const file of listingImages) {
          const uploadTarget = await createMarketplaceListingUploadUrl({ fileName: file.name });
          const { error } = await supabase.storage
            .from(uploadTarget.bucket)
            .uploadToSignedUrl(uploadTarget.path, uploadTarget.token, file);

          if (error) {
            throw new Error(error.message || 'Unable to upload one of the listing photos.');
          }

          imagePaths.push(uploadTarget.path);
        }
      }

      const firstVariety = normalizedVarieties[0];
      const totalVarietyStock = normalizedVarieties.reduce((sum, variety) => sum + variety.stock, 0);

      const response = await upsertMarketplaceListing({
        listingId: listingForm.listingId || undefined,
        name: listingForm.name.trim(),
        category: listingForm.category,
        description: listingForm.description.trim(),
        brand: listingForm.brand.trim(),
        condition: listingForm.condition.trim(),
        harvestDate: listingForm.harvestDate,
        location: listingForm.location.trim(),
        price: listingSupportsVarieties ? Number(firstVariety?.price || 0) : Number(listingForm.basePrice),
        unit: listingForm.unit,
        stock: listingSupportsVarieties ? totalVarietyStock : Number(listingForm.baseStock),
        minimumOrder: Number(listingForm.minimumOrder),
        varieties: normalizedVarieties,
        imagePaths,
      });

      setListingSuccess(response.message || 'Listing saved successfully.');
      setIsListingModalOpen(false);
      loadMarketplace();
    } catch (error) {
      setListingError(error instanceof Error ? error.message : 'Unable to save your listing right now.');
    } finally {
      setIsSavingListing(false);
    }
  };

  const handleAddToCartFromProduct = (product: any) => {
    const chosenVariety = getSelectedProductVariety(product, selectedProductVarietyId);

    if (getProductVarieties(product).length > 0 && !chosenVariety) {
      return;
    }

    const unit = String(product?.unit || '').trim();
    const varietyLabel = String(chosenVariety?.label || '').trim();

    onAddToCart({
      ...product,
      id: varietyLabel ? `${product.id}-${chosenVariety.id}` : product.id,
      price: Number(chosenVariety?.price || product.price || 0),
      stock: Number(chosenVariety?.stock || product.stock || 0),
      sellerUserId: String(product?.sellerUserId || ''),
      listingId: String(product?.listingId || ''),
      selectedVarietyId: chosenVariety?.id || '',
      selectedVarietyLabel: varietyLabel,
      variety: varietyLabel || product.variety || '',
      name: varietyLabel ? `${product.name} - ${varietyLabel}` : product.name,
      unit,
    });
  };

  const handleSelectPreviousProductImage = () => {
    if (selectedProductImages.length <= 1 || !selectedProductImage) {
      return;
    }

    const currentIndex = selectedProductImages.findIndex((image) => image === selectedProductImage);
    const nextIndex = currentIndex <= 0 ? selectedProductImages.length - 1 : currentIndex - 1;
    setSelectedProductImage(selectedProductImages[nextIndex]);
  };

  const handleSelectNextProductImage = () => {
    if (selectedProductImages.length <= 1 || !selectedProductImage) {
      return;
    }

    const currentIndex = selectedProductImages.findIndex((image) => image === selectedProductImage);
    const nextIndex = currentIndex >= selectedProductImages.length - 1 ? 0 : currentIndex + 1;
    setSelectedProductImage(selectedProductImages[nextIndex]);
  };

  const renderProductSpecs = (product: any) => {
    const specs = [
      { label: 'Category', value: product.category },
      { label: 'Unit', value: product.unit },
      { label: 'Available Stock', value: product.stock ? `${product.stock} ${product.unit}` : '' },
      { label: 'Minimum Order', value: product.minimumOrder ? `${product.minimumOrder} ${product.unit}` : '' },
      { label: 'Brand', value: product.brand },
      { label: 'Condition', value: product.condition },
      { label: 'Harvest Date', value: product.harvestDate },
      { label: 'Pickup Location', value: product.location },
      { label: 'Variety Count', value: getProductVarieties(product).length > 0 ? String(getProductVarieties(product).length) : '' },
    ].filter((spec) => String(spec.value || '').trim());

    return (
      <div className="grid gap-3 sm:grid-cols-2">
        {specs.map((spec) => (
          <div key={spec.label} className="rounded-2xl border border-gray-100 bg-gray-50 px-4 py-3">
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-gray-400">{spec.label}</p>
            <p className="mt-1 text-sm font-medium text-gray-700">{spec.value}</p>
          </div>
        ))}
      </div>
    );
  };

  const renderProductReviews = (product: any) => {
    const reviews = Array.isArray(product?.reviews) ? product.reviews : [];

    if (reviews.length === 0) {
      return (
        <div className="rounded-2xl border border-dashed border-gray-200 bg-gray-50 px-5 py-6 text-sm text-gray-500">
          No customer reviews yet for this product.
        </div>
      );
    }

      return (
        <div className="space-y-3">
          {reviews.map((review: any, index: number) => (
            <div key={`${review?.id || review?.author || 'review'}-${index}`} className="rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4">
              <div className="flex items-center justify-between gap-3">
                <p className="text-sm font-semibold text-gray-800">{review?.author || 'Customer'}</p>
                <div className="flex items-center gap-1 text-amber-500">
                  <Star className="h-4 w-4 fill-current" />
                  <span className="text-sm font-medium text-gray-700">{Number(review?.rating || 0).toFixed(1)}</span>
                </div>
              </div>
              {getReviewImageList(review).length > 0 && (
                  <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                    {getReviewImageList(review).map((image: string, imageIndex: number) => (
                      <button
                        key={`${review?.id || 'review'}-image-${imageIndex}`}
                        type="button"
                        onClick={() => setSelectedReviewImage(image)}
                        className="overflow-hidden rounded-2xl border border-gray-200 bg-white transition hover:border-green-300 hover:shadow-sm"
                      >
                        <img src={image} alt={`Review photo ${imageIndex + 1}`} className="aspect-square w-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              <p className="mt-4 text-sm leading-6 text-gray-600">{review?.comment || 'No written comment provided.'}</p>
            </div>
          ))}
        </div>
      );
  };

  const buyerOrderTabs = [
    { key: 'all' as const, label: 'All', statuses: [] as string[] },
    { key: 'to_pay' as const, label: 'To Pay', statuses: ['pending_payment'] },
    { key: 'to_ship' as const, label: 'To Ship', statuses: ['paid', 'preparing', 'ready_for_pickup'] },
    { key: 'to_receive' as const, label: 'To Receive', statuses: ['in_transit'] },
    { key: 'completed' as const, label: 'Completed', statuses: ['received', 'completed'] },
    { key: 'cancelled' as const, label: 'Cancelled', statuses: ['cancelled'] },
    { key: 'return_refund' as const, label: 'Return Refund', statuses: ['return_refund'] },
  ];

  const filteredBuyerOrders = myOrders.filter((order) => {
    if (selectedBuyerOrderTab === 'all') {
      return true;
    }

    const currentTab = buyerOrderTabs.find((tab) => tab.key === selectedBuyerOrderTab);
    return currentTab ? currentTab.statuses.includes(String(order?.status || '')) : true;
  });

  const selectedBuyerOrderTabCount = selectedBuyerOrderTab === 'all'
    ? myOrders.length
    : filteredBuyerOrders.length;

  const getOrderStatusLabel = (status: string) => {
    switch (status) {
      case 'paid':
        return 'Payment confirmed. Waiting for seller to start preparing';
      case 'preparing':
        return 'Seller is preparing the product';
      case 'ready_for_pickup':
        return 'Done preparing, waiting for rider pickup';
      case 'in_transit':
        return 'Parcel is on the way';
      case 'received':
        return 'Order received, waiting for your rating';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'Order cancelled';
      case 'return_refund':
        return 'Refund request in review';
      default:
        return status.replace(/_/g, ' ');
    }
  };

  const getOrderDisplayStatusLabel = (order: any) => {
    if (String(order?.status || '').trim() === 'return_refund') {
      const refundStatus = String(order?.refundRequest?.status || '').trim();

      if (refundStatus === 'approved') {
        return 'Refunded';
      }

      if (refundStatus === 'rejected') {
        return 'Refund rejected';
      }
    }

    return getOrderStatusLabel(String(order?.status || '').trim());
  };

  const getSellerAction = (order: any) => {
    if (order.status === 'paid') {
      return { status: 'preparing' as const, label: 'Start Preparing' };
    }

    if (order.status === 'preparing') {
      return { status: 'ready_for_pickup' as const, label: 'Done Preparing' };
    }

    return null;
  };

  const handleSellerOrderStatusUpdate = async (order: any, status: 'preparing' | 'ready_for_pickup') => {
    setUpdatingOrderId(order.orderId);
    setMarketplaceActionError('');

    try {
      await updateMarketplaceOrderStatus(order.orderId, status);
      loadMarketplace();
      window.dispatchEvent(new Event('agrihub:marketplace-updated'));
    } catch (error) {
      setMarketplaceActionError(error instanceof Error ? error.message : 'Unable to update the marketplace order status right now.');
    } finally {
      setUpdatingOrderId('');
    }
  };

  const handleDownloadSellerWaybill = async (order: any) => {
    setUpdatingOrderId(String(order?.orderId || ''));
    setMarketplaceActionError('');

    try {
      const blob = await downloadMarketplaceWaybill(String(order?.orderId || ''));
      const objectUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = objectUrl;
      link.download = `agrihub-waybill-${String(order?.orderId || 'order')}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(objectUrl);
    } catch (error) {
      setMarketplaceActionError(error instanceof Error ? error.message : 'Unable to download the marketplace waybill right now.');
    } finally {
      setUpdatingOrderId('');
    }
  };

  const handleConfirmOrderReceived = async (order: any) => {
    setUpdatingOrderId(order.orderId);
    setMarketplaceActionError('');

    try {
      await confirmMarketplaceOrderReceived(order.orderId);
      loadMarketplace();
      window.dispatchEvent(new Event('agrihub:marketplace-updated'));
    } catch (error) {
      setMarketplaceActionError(error instanceof Error ? error.message : 'Unable to confirm receipt for this order right now.');
    } finally {
      setUpdatingOrderId('');
    }
  };

  const openCancelMarketplaceOrderModal = (order: any) => {
    setCancellingOrder(order);
    setCancelReason('Cancelled by buyer before seller preparation');
    setCancelModalError('');
  };

  const closeCancelMarketplaceOrderModal = () => {
    setCancellingOrder(null);
    setCancelReason('Cancelled by buyer before seller preparation');
    setCancelModalError('');
  };

  const handleCancelMarketplaceOrder = async (order: any, reason: string) => {
    const trimmedReason = String(reason || '').trim();

    if (!trimmedReason) {
      setCancelModalError('Please enter a reason for cancelling this order.');
      return;
    }

    setUpdatingOrderId(order.orderId);
    setMarketplaceActionError('');
    setCancelModalError('');

    try {
      await cancelMarketplaceOrder(order.orderId, trimmedReason);
      if (selectedBuyerOrderId === order.orderId) {
        setSelectedBuyerOrderId('');
      }
      closeCancelMarketplaceOrderModal();
      loadMarketplace();
      window.dispatchEvent(new Event('agrihub:marketplace-updated'));
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to cancel this marketplace order right now.';
      setMarketplaceActionError(message);
      setCancelModalError(message);
    } finally {
      setUpdatingOrderId('');
    }
  };

  const handleContactSeller = (order: any) => {
    const sellerPhone = String(order?.sellerPhone || '').trim();

    if (!sellerPhone) {
      setMarketplaceActionError('This seller has no contact number available right now.');
      return;
    }

    const normalizedPhoneNumber = sellerPhone.replace(/[^\d+]/g, '');
    window.location.href = `tel:${normalizedPhoneNumber || sellerPhone}`;
  };

  const handleRequestRefund = (order: any) => {
    setRefundingOrder(order);
    setRefundReason(order?.refundRequest?.reason || '');
    setRefundModalError('');
    setRefundImageFiles([]);
    setRefundImagePreviews((current) => {
      current.forEach((preview) => {
        if (preview.startsWith('blob:')) {
          URL.revokeObjectURL(preview);
        }
      });
      return [];
    });
  };

  const resetRefundComposer = () => {
    setRefundingOrder(null);
    setRefundReason('');
    setRefundModalError('');
    setRefundImageFiles([]);
    setRefundImagePreviews((current) => {
      current.forEach((preview) => {
        if (preview.startsWith('blob:')) {
          URL.revokeObjectURL(preview);
        }
      });
      return [];
    });
  };

  const resetReviewComposer = () => {
    setReviewingOrder(null);
    setReviewRating(5);
    setHoveredReviewRating(0);
    setReviewComment('');
    setReviewModalError('');
    setReviewImageFiles([]);
    setReviewImagePreviews((current) => {
      current.forEach((preview) => {
        if (preview.startsWith('blob:')) {
          URL.revokeObjectURL(preview);
        }
      });
      return [];
    });
  };

  const handleReviewImageSelection = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || []).filter((file) => file.type.startsWith('image/'));

    if (selectedFiles.length === 0) {
      return;
    }

    const remainingSlots = Math.max(0, MAX_REVIEW_PHOTOS - reviewImageFiles.length);

    if (remainingSlots <= 0) {
      setReviewModalError(`You can upload up to ${MAX_REVIEW_PHOTOS} review photos only.`);
      event.target.value = '';
      return;
    }

    const acceptedFiles = selectedFiles.slice(0, remainingSlots);

    if (acceptedFiles.length < selectedFiles.length) {
      setReviewModalError(`Only the first ${MAX_REVIEW_PHOTOS} review photos can be uploaded.`);
    } else {
      setReviewModalError('');
    }

    const nextPreviews = acceptedFiles.map((file) => URL.createObjectURL(file));
    setReviewImageFiles((current) => [...current, ...acceptedFiles]);
    setReviewImagePreviews((current) => [...current, ...nextPreviews]);
    event.target.value = '';
  };

  const handleRemoveReviewImage = (indexToRemove: number) => {
    setReviewImageFiles((current) => current.filter((_, index) => index !== indexToRemove));
    setReviewImagePreviews((current) => {
      const previewToRemove = current[indexToRemove];

      if (previewToRemove?.startsWith('blob:')) {
        URL.revokeObjectURL(previewToRemove);
      }

      return current.filter((_, index) => index !== indexToRemove);
    });
  };

  const handleRefundImageSelection = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || []).filter((file) => file.type.startsWith('image/'));

    if (selectedFiles.length === 0) {
      return;
    }

    const remainingSlots = Math.max(0, MAX_REFUND_PHOTOS - refundImageFiles.length);

    if (remainingSlots <= 0) {
      setRefundModalError(`You can upload up to ${MAX_REFUND_PHOTOS} refund photos only.`);
      event.target.value = '';
      return;
    }

    const acceptedFiles = selectedFiles.slice(0, remainingSlots);

    if (acceptedFiles.length < selectedFiles.length) {
      setRefundModalError(`Only the first ${MAX_REFUND_PHOTOS} refund photos can be uploaded.`);
    } else {
      setRefundModalError('');
    }

    const nextPreviews = acceptedFiles.map((file) => URL.createObjectURL(file));
    setRefundImageFiles((current) => [...current, ...acceptedFiles]);
    setRefundImagePreviews((current) => [...current, ...nextPreviews]);
    event.target.value = '';
  };

  const handleRemoveRefundImage = (indexToRemove: number) => {
    setRefundImageFiles((current) => current.filter((_, index) => index !== indexToRemove));
    setRefundImagePreviews((current) => {
      const previewToRemove = current[indexToRemove];

      if (previewToRemove?.startsWith('blob:')) {
        URL.revokeObjectURL(previewToRemove);
      }

      return current.filter((_, index) => index !== indexToRemove);
    });
  };

  const uploadMarketplaceReviewImages = async (orderId: string, files: File[]) => {
    if (files.length === 0) {
      return {
        imagePaths: [] as string[],
        imageUrls: [] as string[],
      };
    }

    const supabase = requireSupabaseClient();
    const uploaded = await Promise.all(
      files.map(async (file, index) => {
        const uploadTarget = await createMarketplaceReviewUploadUrl({ fileName: file.name });
        const uploadResult = await supabase.storage
          .from(uploadTarget.bucket)
          .uploadToSignedUrl(uploadTarget.path, uploadTarget.token, file);

        if (uploadResult.error) {
          throw new Error(uploadResult.error.message || 'Unable to upload one of the review photos right now.');
        }

        return {
          path: uploadTarget.path,
          url: '',
        };
      }),
    );

    return {
      imagePaths: uploaded.map((entry) => entry.path),
      imageUrls: uploaded.map((entry) => entry.url).filter(Boolean),
    };
  };

  const uploadMarketplaceRefundImages = async (orderId: string, files: File[]) => {
    if (files.length === 0) {
      return {
        imagePaths: [] as string[],
        imageUrls: [] as string[],
      };
    }

    const supabase = requireSupabaseClient();
    const uploaded = await Promise.all(
      files.map(async (file) => {
        const uploadTarget = await createMarketplaceRefundUploadUrl({ fileName: file.name });
        const uploadResult = await supabase.storage
          .from(uploadTarget.bucket)
          .uploadToSignedUrl(uploadTarget.path, uploadTarget.token, file);

        if (uploadResult.error) {
          throw new Error(uploadResult.error.message || 'Unable to upload one of the refund photos right now.');
        }

        return {
          path: uploadTarget.path,
          url: '',
        };
      }),
    );

    return {
      imagePaths: uploaded.map((entry) => entry.path),
      imageUrls: uploaded.map((entry) => entry.url).filter(Boolean),
    };
  };

  const handleSubmitMarketplaceReview = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!reviewingOrder) {
      return;
    }

    setUpdatingOrderId(reviewingOrder.orderId);
    setMarketplaceActionError('');
    setReviewModalError('');

    try {
      const uploadedImages = await uploadMarketplaceReviewImages(reviewingOrder.orderId, reviewImageFiles);

      await submitMarketplaceOrderReview(reviewingOrder.orderId, {
        rating: reviewRating,
        comment: reviewComment,
        imagePaths: uploadedImages.imagePaths,
        imageUrls: uploadedImages.imageUrls,
      });
      resetReviewComposer();
      loadMarketplace();
      window.dispatchEvent(new Event('agrihub:marketplace-updated'));
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to submit your marketplace review right now.';
      setMarketplaceActionError(message);
      setReviewModalError(message);
    } finally {
      setUpdatingOrderId('');
    }
  };

  const handleSubmitMarketplaceRefundRequest = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!refundingOrder) {
      return;
    }

    const trimmedReason = refundReason.trim();

    if (!trimmedReason) {
      setRefundModalError('Please enter the reason for the refund request.');
      return;
    }

    if (refundImageFiles.length === 0) {
      setRefundModalError('Please upload at least one photo for the refund request.');
      return;
    }

    setUpdatingOrderId(refundingOrder.orderId);
    setMarketplaceActionError('');
    setRefundModalError('');

    try {
      const uploadedImages = await uploadMarketplaceRefundImages(refundingOrder.orderId, refundImageFiles);
      await requestMarketplaceOrderRefund(refundingOrder.orderId, {
        reason: trimmedReason,
        imagePaths: uploadedImages.imagePaths,
        imageUrls: uploadedImages.imageUrls,
      });
      resetRefundComposer();
      loadMarketplace();
      window.dispatchEvent(new Event('agrihub:marketplace-updated'));
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to submit your marketplace refund request right now.';
      setMarketplaceActionError(message);
      setRefundModalError(message);
    } finally {
      setUpdatingOrderId('');
    }
  };

  const openReviewModal = (order: any) => {
    setReviewingOrder(order);
    setReviewRating(5);
    setHoveredReviewRating(0);
    setReviewComment(order?.reviewComment || '');
    setReviewImageFiles([]);
    setReviewImagePreviews((current) => {
      current.forEach((preview) => {
        if (preview.startsWith('blob:')) {
          URL.revokeObjectURL(preview);
        }
      });
      return [];
    });
    setMarketplaceActionError('');
    setReviewModalError('');
  };

  const openBuyerOrderDetails = (order: any) => {
    setSelectedBuyerOrderId(String(order?.orderId || ''));
  };

  const openSellerOrderDetails = (order: any) => {
    setSelectedSellerOrderId(String(order?.orderId || ''));
  };

  const renderSellerOrdersContent = () => (
    <div className="space-y-4">
      {sellerOrders.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-gray-200 px-5 py-8 text-center text-sm text-gray-500">
          Paid orders from buyers will appear here.
        </div>
      ) : sellerOrders.map((order) => {
        const sellerAction = getSellerAction(order);

        return (
          <div
            key={order.orderId}
            role="button"
            tabIndex={0}
            onClick={() => openSellerOrderDetails(order)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                openSellerOrderDetails(order);
              }
            }}
            className="rounded-2xl border border-gray-100 p-5 shadow-sm transition hover:border-green-200 hover:shadow-md"
          >
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                <div className="flex min-w-0 gap-4">
                  <div className="h-20 w-20 overflow-hidden rounded-2xl bg-gray-100">
                    {order.image ? (
                      <img src={order.image} alt={order.itemName} className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full items-center justify-center text-xs text-gray-400">No image</div>
                  )}
                </div>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-3">
                      <p className="text-lg font-semibold text-gray-900">{order.itemName}</p>
                      <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">{getOrderDisplayStatusLabel(order)}</span>
                    </div>
                    <p className="mt-1 text-sm text-gray-500">Buyer: {order.buyerName}</p>
                    <div className="mt-3 flex flex-wrap gap-3 text-sm text-gray-600">
                      <span>{order.quantity} {order.unit}</span>
                      <span>{formatPhpCurrency(order.price)} each</span>
                      {order.selectedVarietyLabel ? <span>{order.selectedVarietyLabel}</span> : null}
                    </div>
                    <p className="mt-3 text-sm text-gray-500">{order.location}</p>
                    <p className="mt-3 text-xs font-semibold uppercase tracking-[0.18em] text-green-700">
                      Tap to view parcel timeline and order details
                    </p>
                  </div>
                </div>
              <div className="flex w-full flex-col gap-3 lg:w-auto lg:min-w-[17rem]">
                <div className="rounded-2xl border border-gray-100 bg-gray-50 px-4 py-3 text-right">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Paid Amount</p>
                  <p className="mt-1 text-2xl font-bold text-emerald-700">{formatPhpCurrency(order.totalPaid)}</p>
                </div>
                {sellerAction ? (
                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      handleSellerOrderStatusUpdate(order, sellerAction.status);
                    }}
                    disabled={updatingOrderId === order.orderId}
                    className="rounded-2xl bg-gradient-to-r from-green-500 to-green-600 px-4 py-3 text-sm font-semibold text-white transition hover:shadow-lg hover:shadow-green-500/30 disabled:cursor-not-allowed disabled:bg-green-300"
                  >
                    {updatingOrderId === order.orderId ? 'Updating...' : sellerAction.label}
                  </button>
                ) : (
                  <div className="rounded-2xl border border-gray-100 bg-gray-50 px-4 py-3 text-sm text-gray-600">
                    {order.status === 'in_transit'
                      ? 'Waiting for the buyer to confirm receipt.'
                      : order.reviewed
                        ? `Rated ${Number(order.reviewRating || 0).toFixed(1)} stars`
                      : 'No seller action needed right now.'}
                  </div>
                )}
                <button
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    openSellerOrderDetails(order);
                  }}
                  className="rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition hover:bg-gray-50"
                >
                  View Details
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="space-y-6">
      {isCommerciallyRestricted && (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700">
          Your account is currently restricted. Marketplace selling tools are disabled until an admin clears the penalty.
        </div>
      )}
      {listingSuccess && (
        <div className="rounded-2xl border border-green-200 bg-green-50 px-5 py-4 text-sm text-green-700">
          {listingSuccess}
        </div>
      )}
      {marketplaceActionError && (
        <div className="rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700">
          {marketplaceActionError}
        </div>
      )}

      <div className={`grid gap-2 rounded-2xl border border-gray-100 bg-white p-2 shadow-sm ${isSeller ? 'grid-cols-3' : 'grid-cols-3'}`}>
        <button
          onClick={() => updateMarketplaceView('buy')}
          className={`rounded-xl px-4 py-3 font-medium transition-all duration-200 ${
            activeTab === 'buy' ? 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg shadow-green-500/30' : 'text-gray-600 hover:bg-gray-50'
          }`}
        >
          Buy Products
        </button>
        <button
          onClick={() => isSeller && !isCommerciallyRestricted && updateMarketplaceView('sell')}
          className={`rounded-xl px-4 py-3 font-medium transition-all duration-200 ${
            activeTab === 'sell' ? 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg shadow-green-500/30' : 'text-gray-600 hover:bg-gray-50'
          } ${!isSeller || isCommerciallyRestricted ? 'cursor-not-allowed opacity-60' : ''}`}
        >
          My Listings
        </button>
        <button
          onClick={() => currentUser && updateMarketplaceView('orders')}
          className={`rounded-xl px-4 py-3 font-medium transition-all duration-200 ${
            activeTab === 'orders' ? 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg shadow-green-500/30' : 'text-gray-600 hover:bg-gray-50'
          } ${!currentUser ? 'cursor-not-allowed opacity-60' : ''}`}
        >
          My Orders
        </button>
      </div>

      {activeTab === 'buy' ? (
        <>
          <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
            <div className="flex flex-col gap-4 md:flex-row">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(event) => setSearchTerm(event.target.value)}
                  placeholder="Search products, brands, varieties, or sellers..."
                  className="w-full rounded-xl border border-gray-200 py-3 pl-12 pr-4 transition-all focus:border-transparent focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <button className="flex items-center space-x-2 rounded-xl border border-gray-200 px-6 py-3 transition-all hover:bg-gray-50">
                <Filter className="h-5 w-5 text-gray-600" />
                <span className="font-medium text-gray-700">Filters</span>
              </button>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition-all duration-200 ${
                    selectedCategory === category
                      ? 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-md shadow-green-500/30'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredProducts.map((product) => {
              const isOwnListing = String(product?.sellerUserId || '').trim() === String(currentUser?.id || '').trim();

              return (
                <button
                  key={product.id}
                  type="button"
                  onClick={() => handleOpenProductDetails(product)}
                  className="group flex h-full min-h-[27rem] flex-col overflow-hidden rounded-2xl border border-gray-100 bg-white text-left shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
                >
                  <div className="aspect-[4/3] overflow-hidden bg-gray-100">
                    {product.image ? (
                      <img
                        src={product.image}
                        alt={product.name}
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center text-sm text-gray-400">No image</div>
                    )}
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <div className="mb-3 flex items-start justify-between gap-2">
                      <h3 className="truncate whitespace-nowrap text-base font-semibold text-gray-900">{product.name}</h3>
                      <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-medium text-green-700">{product.category}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Store className="h-4 w-4 text-green-600" />
                      <p className="truncate">{product.seller}</p>
                    </div>
                    <div className="mt-3 flex items-center gap-4 text-xs text-gray-500">
                      <div className="flex items-center gap-1.5">
                        <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                        <span className="font-medium text-gray-700">{getProductRating(product) > 0 ? getProductRating(product).toFixed(1) : 'New'}</span>
                      </div>
                      <span>{getProductSoldCount(product)} sold</span>
                      <span>{getProductVarieties(product).length > 0 ? `${getProductVarieties(product).length} varieties` : 'Single item'}</span>
                    </div>
                    <div className="mt-3 flex items-center gap-3 text-xs text-gray-500">
                      <span className="rounded-full bg-emerald-50 px-2.5 py-1 font-medium text-emerald-700">{product.minimumOrder} min</span>
                      <span className="truncate">{getProductVarieties(product)[0]?.label || product.brand || product.condition || 'Farm goods'}</span>
                    </div>
                    <div className="mt-4 flex items-end justify-between gap-3">
                      <div>
                        <p className="bg-gradient-to-r from-green-600 to-green-700 bg-clip-text text-2xl font-bold text-transparent">
                          {formatPhpCurrency(product.price)}
                        </p>
                        <p className="text-xs text-gray-500">{getProductVarieties(product).length > 0 ? `starting price per ${product.unit}` : `per ${product.unit}`}</p>
                      </div>
                      <div className="text-right text-sm">
                        <p className="text-sm font-medium text-gray-700">{product.stock} {product.unit}</p>
                        <p className="text-xs text-gray-500">Total stock</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={(event) => {
                        event.stopPropagation();
                        handleOpenProductDetails(product);
                      }}
                      className={`mt-4 flex w-full items-center justify-center space-x-2 rounded-xl py-3 transition-all duration-200 ${
                        isOwnListing
                          ? 'border border-gray-200 bg-white text-gray-700 hover:bg-gray-50'
                          : 'bg-gradient-to-r from-green-500 to-green-600 text-white hover:shadow-lg hover:shadow-green-500/30'
                      }`}
                    >
                      {isOwnListing ? null : <ShoppingCart className="h-4 w-4" />}
                      <span>{isOwnListing ? 'View Details' : getProductVarieties(product).length > 0 ? 'Select Variety' : 'Add to Cart'}</span>
                    </button>
                  </div>
                </button>
              );
            })}
          </div>

        </>
      ) : activeTab === 'sell' ? (
        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
          {!isSeller && (
            <div className="mb-6 rounded-2xl border border-amber-200 bg-amber-50 px-5 py-4 text-sm text-amber-700">
              Buyer is the default account. Apply as a seller in your profile verification to unlock listing tools.
            </div>
          )}
          <div className="min-w-0">
            <div className="mb-6">
              <div className="grid gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => updateMarketplaceSellerSection('listings')}
                  className={`rounded-xl px-4 py-3 text-sm font-semibold transition ${
                    selectedSellerSection === 'listings'
                      ? 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg shadow-green-500/20'
                      : 'border border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  My Product Listings
                </button>
                <button
                  type="button"
                  onClick={() => updateMarketplaceSellerSection('orders')}
                  className={`rounded-xl px-4 py-3 text-sm font-semibold transition ${
                    selectedSellerSection === 'orders'
                      ? 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg shadow-green-500/20'
                      : 'border border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  Seller Orders
                </button>
              </div>
            </div>

            <div className="mb-6 flex items-center justify-between gap-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {selectedSellerSection === 'listings' ? 'My Product Listings' : 'Seller Orders'}
                  </h3>
                  <p className="mt-1 text-sm text-gray-500">
                    {selectedSellerSection === 'listings'
                      ? 'Manage your active product listings and update the details buyers can see.'
                      : 'Manage paid orders and update parcel progress from here.'}
                  </p>
                </div>
                {selectedSellerSection === 'listings' ? (
                  <button
                    onClick={handleOpenCreateListing}
                    disabled={!isSeller || isCommerciallyRestricted}
                    className="flex items-center space-x-2 rounded-xl bg-gradient-to-r from-green-500 to-green-600 px-6 py-3 font-medium text-white transition-all duration-200 hover:shadow-lg hover:shadow-green-500/30 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <Plus className="h-4 w-4" />
                    <span>New Listing</span>
                  </button>
                ) : (
                  <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                    {sellerOrders.length} order{sellerOrders.length !== 1 ? 's' : ''}
                  </span>
                )}
            </div>

            {selectedSellerSection === 'listings' ? (
              <div className="space-y-4">
                {isSeller && myListings.length === 0 && (
                  <div className="rounded-xl border border-dashed border-gray-200 p-8 text-center text-sm text-gray-500">
                    Seller verification is active. Add your first product listing with 1 to 3 photos and selectable varieties.
                  </div>
                )}
                {myListings.map((listing) => (
                  <button
                    key={listing.id}
                    type="button"
                    onClick={() => handleOpenProductDetails({ ...listing, canEdit: true })}
                    className="w-full rounded-xl border border-gray-100 p-4 text-left transition-all duration-200 hover:border-green-500 hover:shadow-md"
                  >
                    <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                      <div className="flex min-w-0 gap-4">
                        <div className="h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-gray-100">
                          {listing.image ? (
                            <img src={listing.image} alt={listing.name} className="h-full w-full object-cover" />
                          ) : (
                            <div className="flex h-full items-center justify-center text-xs text-gray-400">No image</div>
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="mb-2 flex flex-wrap items-center gap-3">
                            <h4 className="truncate text-lg font-semibold text-gray-900">{listing.name}</h4>
                            <span className={`rounded-full px-3 py-1 text-xs font-medium ${listing.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                              {listing.status}
                            </span>
                          </div>
                          <div className="flex flex-wrap items-center gap-3 text-sm text-gray-500">
                            <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-600">{listing.category}</span>
                            <span>{getProductVarieties(listing).length} varieties</span>
                            <span>{listing.stock} {listing.unit} stock</span>
                            <span>{listing.orders} sold</span>
                            <span>{listing.views} views</span>
                          </div>
                          <p className="mt-3 line-clamp-1 text-sm text-gray-600">
                            {listing.location}
                          </p>
                          <p className="mt-3 bg-gradient-to-r from-green-600 to-green-700 bg-clip-text text-xl font-bold text-transparent">
                            {formatPhpCurrency(listing.price)}
                            <span className="ml-2 text-xs font-medium text-gray-500">starting price</span>
                          </p>
                        </div>
                      </div>
                      <div className="flex shrink-0 items-center gap-2 md:flex-col md:items-end">
                        <div className="rounded-xl border border-gray-200 px-4 py-2 text-sm font-medium text-gray-700">
                          View Details
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              renderSellerOrdersContent()
            )}
          </div>
        </div>
      ) : (
        <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">My Orders</h3>
              <p className="mt-1 text-sm text-gray-500">Track your purchases in a Shopee-style order view with status tabs and parcel updates.</p>
            </div>
            <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">{selectedBuyerOrderTabCount} order{selectedBuyerOrderTabCount !== 1 ? 's' : ''}</span>
          </div>

          <div className="mt-5 overflow-x-auto rounded-2xl border border-gray-100 bg-white">
            <div className="grid min-w-[44rem] grid-cols-7 border-b border-gray-100 lg:min-w-[56rem]">
              {buyerOrderTabs.map((tab) => {
                const count = tab.key === 'all'
                  ? myOrders.length
                  : myOrders.filter((order) => tab.statuses.includes(String(order?.status || ''))).length;
                const isActive = selectedBuyerOrderTab === tab.key;
                const suffixCount = ['to_receive', 'to_ship', 'to_pay', 'cancelled', 'return_refund'].includes(tab.key) && count > 0
                  ? ` (${count})`
                  : '';

                return (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() => updateMarketplaceBuyerOrderTab(tab.key)}
                    className={`relative min-w-0 px-4 py-4 text-center text-sm font-semibold transition ${
                      isActive ? 'bg-green-50 text-green-700' : 'text-gray-700 hover:bg-green-50/70 hover:text-green-700'
                    }`}
                  >
                    {tab.label}{suffixCount}
                    <span className={`absolute inset-x-0 bottom-0 h-0.5 ${
                      isActive ? 'bg-green-600' : 'bg-transparent'
                    }`} />
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-4 rounded-2xl border border-amber-100 bg-amber-50 px-5 py-4">
            <p className="text-sm font-semibold uppercase tracking-[0.14em] text-amber-700">Shop Safe with AgriHub</p>
            <p className="mt-2 text-sm text-amber-900">
              Double-check the parcel details and confirm receipt only after you have inspected the items.
            </p>
          </div>

          <div className="mt-5 space-y-4">
            {filteredBuyerOrders.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-gray-200 px-5 py-8 text-center text-sm text-gray-500">
                No orders found in this tab yet.
              </div>
            ) : filteredBuyerOrders.map((order) => (
              <div
                key={order.orderId}
                onClick={() => openBuyerOrderDetails(order)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    openBuyerOrderDetails(order);
                  }
                }}
                role="button"
                tabIndex={0}
                className="w-full rounded-2xl border border-gray-100 p-5 text-left shadow-sm transition hover:border-green-200 hover:shadow-md"
              >
                <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 pb-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-gray-900">
                    <Store className="h-4 w-4 text-green-600" />
                    <span>{order.sellerName}</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-sm">
                    <span className="font-medium text-teal-600">{getOrderDisplayStatusLabel(order)}</span>
                    <span className="text-gray-300">|</span>
                    <span className="font-semibold uppercase tracking-[0.12em] text-green-700">
                      {String(order.status || '') === 'in_transit'
                        ? 'To Receive'
                        : String(order.status || '') === 'cancelled'
                          ? 'Cancelled'
                        : ['received', 'completed'].includes(String(order.status || ''))
                          ? 'Completed'
                          : 'To Ship'}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                  <div className="flex min-w-0 gap-4">
                    <div className="h-20 w-20 overflow-hidden rounded-2xl bg-gray-100">
                      {order.image ? (
                        <img src={order.image} alt={order.itemName} className="h-full w-full object-cover" />
                      ) : (
                        <div className="flex h-full items-center justify-center text-xs text-gray-400">No image</div>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-3">
                        <p className="text-lg font-semibold text-gray-900">{order.itemName}</p>
                      </div>
                      <p className="mt-1 text-sm text-gray-500">{order.sellerName}</p>
                      <div className="mt-3 flex flex-wrap gap-3 text-sm text-gray-600">
                        <span>{order.quantity} {order.unit}</span>
                        <span>{formatPhpCurrency(order.price)} each</span>
                        {order.selectedVarietyLabel ? <span>{order.selectedVarietyLabel}</span> : null}
                      </div>
                      <p className="mt-3 text-sm text-gray-500">{order.location}</p>
                      {hasMarketplaceTracking(order) ? (
                        <div className="mt-3 rounded-2xl border border-sky-100 bg-sky-50 px-3 py-2">
                          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-sky-700">
                            Tracking • {canShowTrackingNumber(order) ? order.logistics.trackingNumber : 'Pending release'}
                          </p>
                          <p className="mt-1 text-sm font-medium text-slate-800">
                            {getMarketplaceTrackingHeadline(order)}
                          </p>
                          <p className="mt-1 text-xs text-slate-600">
                            ETA {formatOrderDateTime(order.logistics.estimatedArrivalAt)}
                          </p>
                        </div>
                        ) : order?.logistics?.simulationLockedReason
                          && !['received', 'completed', 'cancelled'].includes(String(order?.status || '').trim())
                          && !isApprovedMarketplaceRefund(order) ? (
                          <div className="mt-3 rounded-2xl border border-amber-100 bg-amber-50 px-3 py-2">
                            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-amber-700">Tracking locked</p>
                            <p className="mt-1 text-xs text-amber-800">{order.logistics.simulationLockedReason}</p>
                          </div>
                        ) : null}
                      <p className="mt-3 text-xs font-semibold uppercase tracking-[0.18em] text-green-700">
                        Tap to view parcel timeline and order details
                      </p>
                    </div>
                  </div>
                    <div className="flex w-full flex-col gap-3 lg:w-auto lg:min-w-[16rem]">
                      <div className="rounded-2xl border border-gray-100 bg-gray-50 px-4 py-3 text-right">
                        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">Total Paid</p>
                        <p className="mt-1 text-2xl font-bold text-emerald-700">{formatPhpCurrency(order.totalPaid)}</p>
                      </div>
                      <button
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          handleContactSeller(order);
                        }}
                        className="rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition hover:bg-gray-50"
                      >
                        Contact
                      </button>
                      {order.status === 'paid' ? (
                        <button
                          type="button"
                          onClick={(event) => {
                            event.stopPropagation();
                            openCancelMarketplaceOrderModal(order);
                          }}
                          disabled={updatingOrderId === order.orderId}
                          className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700 transition hover:bg-red-100 disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          {updatingOrderId === order.orderId ? 'Cancelling...' : 'Cancel Order'}
                        </button>
                      ) : null}
                      {canConfirmMarketplaceOrderReceived(order) && (
                        <button
                          type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          handleConfirmOrderReceived(order);
                        }}
                        disabled={updatingOrderId === order.orderId}
                        className="rounded-2xl bg-gradient-to-r from-green-500 to-green-600 px-4 py-3 text-sm font-semibold text-white transition hover:shadow-lg hover:shadow-green-500/30 disabled:cursor-not-allowed disabled:bg-green-300"
                      >
                        {updatingOrderId === order.orderId ? 'Confirming...' : 'Order Received'}
                      </button>
                    )}
                      {order.status === 'received'
                        && !order.reviewed
                        && String(order.refundRequest?.status || 'none') === 'none' && (
                        <button
                          type="button"
                          onClick={(event) => {
                            event.stopPropagation();
                          openReviewModal(order);
                        }}
                        className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-700 transition hover:bg-amber-100"
                        >
                          Rate Product
                        </button>
                      )}
                      <div className="rounded-2xl border border-gray-100 bg-white px-4 py-3 text-center text-sm font-semibold text-gray-700">
                        View Details
                      </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {selectedBuyerOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 py-6 responsive-modal-shell">
          <button
            type="button"
            aria-label="Close order details"
            className="absolute inset-0 cursor-default"
            onClick={() => setSelectedBuyerOrderId('')}
          />
          <div className="responsive-modal-panel relative z-10 flex w-full max-w-5xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="responsive-modal-header rounded-t-3xl bg-gradient-to-r from-green-600 to-green-500 text-white">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-green-100">Order Details</p>
                  <h3 className="mt-2 text-2xl font-semibold">{selectedBuyerOrder.itemName}</h3>
                  <p className="mt-1 text-sm text-green-50">
                    Order ID {selectedBuyerOrder.orderId} • {getOrderDisplayStatusLabel(selectedBuyerOrder)}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedBuyerOrderId('')}
                  className="rounded-xl border border-white/30 p-2 text-white transition-colors hover:bg-white/10"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="responsive-modal-body space-y-6 overflow-y-auto">
              <div className="overflow-x-auto">
                <div className="responsive-modal-progress flex min-w-[30rem] items-start justify-between gap-4 md:min-w-[42rem]">
                  {getBuyerOrderProgressSteps(selectedBuyerOrder).map((step, index, steps) => {
                    const Icon = step.icon;
                    const stateClass = step.done
                      ? 'border-green-500 bg-green-500 text-white'
                      : step.active
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-200 bg-gray-50 text-gray-400';
                    const connectorClass = step.done && index < getOrderStatusRank(selectedBuyerOrder)
                      ? 'bg-green-500'
                      : 'bg-gray-200';

                    return (
                      <div key={step.key} className="flex min-w-0 flex-1 items-start">
                        <div className="min-w-0 flex-1 text-center">
                          <div className={`mx-auto flex h-14 w-14 items-center justify-center rounded-full border-2 ${stateClass}`}>
                            <Icon className="h-6 w-6" />
                          </div>
                          <p className="mt-3 text-sm font-semibold text-gray-900">{step.label}</p>
                          <p className="mt-1 text-xs text-gray-500">{formatOrderDateTime(step.timestamp)}</p>
                        </div>
                        {index < steps.length - 1 ? (
                          <div className={`mt-7 h-1 flex-1 rounded-full ${connectorClass}`} />
                        ) : null}
                      </div>
                    );
                  })}
                </div>
              </div>

              <LogisticsTrackerPanel order={selectedBuyerOrder} />

              <div className="responsive-modal-grid grid gap-6 lg:grid-cols-[1.3fr_0.9fr]">
                <div className="rounded-3xl border border-gray-100 bg-white p-5 shadow-sm">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gray-400">Parcel Timeline</p>
                      <h4 className="mt-2 text-xl font-semibold text-gray-900">What is happening to your parcel</h4>
                    </div>
                    <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                      {getOrderDisplayStatusLabel(selectedBuyerOrder)}
                    </span>
                  </div>

                  <div className="mt-6 space-y-4">
                    {getVisibleBuyerOrderTimeline(selectedBuyerOrder).map((event, index, visibleTimeline) => {
                      const isLatest = index === 0;
                      const markerClass = event.tone === 'success'
                        ? 'bg-emerald-500'
                        : event.tone === 'info'
                          ? 'bg-teal-500'
                          : 'bg-gray-300';
                      const { dateLabel, timeLabel } = getTimelineDateParts(event.timestamp);

                      return (
                        <div key={event.key} className="flex gap-3">
                          <div className="w-14 shrink-0 pt-0.5 text-right">
                            <p className={`text-[11px] leading-4 ${isLatest ? 'font-semibold text-slate-700' : 'text-gray-400'}`}>{dateLabel}</p>
                            <p className={`text-[11px] leading-4 ${isLatest ? 'font-semibold text-slate-700' : 'text-gray-400'}`}>{timeLabel}</p>
                          </div>
                          <div className="flex flex-col items-center">
                            <div className={`h-3 w-3 rounded-full ${markerClass}`} />
                            {index < visibleTimeline.length - 1 ? (
                              <div className="mt-1 h-full min-h-10 w-px bg-gray-200" />
                            ) : null}
                          </div>
                          <div className="min-w-0 pb-2 pt-[-1px]">
                            <p className={`text-[15px] leading-5 ${isLatest ? 'font-semibold text-teal-700' : 'font-medium text-gray-500'}`}>
                              {event.title}
                            </p>
                            {event.detail ? (
                              <p className="mt-1 text-sm leading-5 text-gray-500">{event.detail}</p>
                            ) : null}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="rounded-3xl border border-gray-100 bg-gray-50 p-5">
                    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gray-400">Delivery Summary</p>
                    <div className="mt-4 space-y-4">
                      <div>
                        <p className="text-sm font-semibold text-gray-900">Seller</p>
                        <p className="mt-1 text-sm text-gray-600">{selectedBuyerOrder.sellerName}</p>
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-gray-900">Seller Address</p>
                        <div className="mt-1 flex gap-2 text-sm text-gray-600">
                          <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                          <span>{selectedBuyerOrder.sellerAddress || selectedBuyerOrder.location || 'Waiting for seller address update'}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-gray-900">Buyer Delivery Address</p>
                        <div className="mt-1 flex gap-2 text-sm text-gray-600">
                          <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                          <span>{getVisibleBuyerAddress(selectedBuyerOrder)}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-gray-900">Payment Method</p>
                        <p className="mt-1 text-sm capitalize text-gray-600">{String(selectedBuyerOrder.paymentMethod || 'Online payment').replace(/_/g, ' ')}</p>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-3xl border border-gray-100 bg-white p-5 shadow-sm">
                    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gray-400">Order Breakdown</p>
                    <div className="mt-4 space-y-3 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Item subtotal</span>
                        <span className="font-medium text-gray-900">{formatPhpCurrency(selectedBuyerOrder.subtotal)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Tax</span>
                        <span className="font-medium text-gray-900">{formatPhpCurrency(selectedBuyerOrder.tax)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Shipping</span>
                        <span className="font-medium text-gray-900">{formatPhpCurrency(selectedBuyerOrder.shipping)}</span>
                      </div>
                      <div className="flex items-center justify-between border-t border-gray-100 pt-3">
                        <span className="font-semibold text-gray-900">Total paid</span>
                        <span className="text-xl font-bold text-green-700">{formatPhpCurrency(selectedBuyerOrder.totalPaid)}</span>
                      </div>
                    </div>
                  </div>

                  {selectedBuyerOrder.refundRequest?.status && selectedBuyerOrder.refundRequest.status !== 'none' ? (
                    <div className="space-y-3">
                      <button
                        type="button"
                        onClick={() => setSelectedBuyerRefundDetails(selectedBuyerOrder.refundRequest)}
                        className={`flex w-full items-center justify-between rounded-2xl border px-4 py-3 text-left text-sm font-semibold transition ${getRefundStatusButtonClassName(selectedBuyerOrder.refundRequest)}`}
                      >
                        <span>{getRefundStatusButtonLabel(selectedBuyerOrder.refundRequest)}</span>
                        <ChevronRight className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectedBuyerOrderId('')}
                        className="w-full rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition hover:bg-gray-50"
                      >
                        Close
                      </button>
                    </div>
                  ) : null}

                    {getMarketplaceRouteProgressPercent(selectedBuyerOrder) >= 100 ? (
                      <div className="space-y-3">
                        {selectedBuyerOrder.reviewed || selectedBuyerOrder.status === 'completed' ? (
                          <div className="rounded-3xl border border-emerald-100 bg-emerald-50 px-5 py-4 text-center text-sm font-semibold text-emerald-700">
                            Thank you for your purchase!
                          </div>
                        ) : selectedBuyerOrder.status !== 'received'
                          && String(selectedBuyerOrder.refundRequest?.status || 'none') === 'none' ? (
                          <button
                            type="button"
                            onClick={() => handleConfirmOrderReceived(selectedBuyerOrder)}
                            disabled={updatingOrderId === selectedBuyerOrder.orderId}
                            className="w-full rounded-2xl bg-gradient-to-r from-green-500 to-green-600 px-4 py-3 text-sm font-semibold text-white transition hover:shadow-lg hover:shadow-green-500/30 disabled:cursor-not-allowed disabled:bg-green-300"
                          >
                            {updatingOrderId === selectedBuyerOrder.orderId ? 'Confirming...' : 'Order Received'}
                          </button>
                        ) : String(selectedBuyerOrder.refundRequest?.status || 'none') === 'none' ? (
                          <button
                            type="button"
                            onClick={() => openReviewModal(selectedBuyerOrder)}
                            className="w-full rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-700 transition hover:bg-amber-100"
                          >
                            Rate Product
                          </button>
                        ) : null}
                        {!selectedBuyerOrder.reviewed
                          && selectedBuyerOrder.status !== 'received'
                          && selectedBuyerOrder.status !== 'completed'
                          && String(selectedBuyerOrder.refundRequest?.status || 'none') === 'none' ? (
                          <button
                            type="button"
                            onClick={() => handleRequestRefund(selectedBuyerOrder)}
                            className="w-full rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700 transition hover:bg-red-100"
                          >
                          Request Refund
                        </button>
                      ) : null}
                    </div>
                  ) : (
                    <div className="rounded-3xl border border-amber-100 bg-amber-50 px-5 py-4 text-sm text-amber-800">
                      {selectedBuyerOrder.status === 'paid'
                        ? 'Your payment is confirmed. The seller has not started preparing the parcel yet.'
                        : selectedBuyerOrder.status === 'preparing'
                          ? 'The seller is currently preparing your parcel.'
                          : selectedBuyerOrder.status === 'ready_for_pickup'
                            ? 'The parcel is packed and waiting for pickup.'
                              : selectedBuyerOrder.status === 'in_transit'
                                ? 'Your parcel is already on the way.'
                                : selectedBuyerOrder.status === 'cancelled'
                                  ? 'This order was cancelled before seller preparation and refunded to your wallet.'
                                  : selectedBuyerOrder.status === 'received'
                                    ? 'Order received.'
                                    : 'This order is complete and rated.'}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {selectedBuyerRefundDetails ? (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/45 px-4 py-6">
          <button
            type="button"
            aria-label="Close buyer refund details"
            className="absolute inset-0 cursor-default"
            onClick={() => setSelectedBuyerRefundDetails(null)}
          />
          <div className="relative z-10 w-full max-w-lg overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-gray-100 px-6 py-5">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gray-400">Refund Details</p>
                <h3 className="mt-2 text-xl font-semibold text-gray-900">{getRefundStatusButtonLabel(selectedBuyerRefundDetails).replace(/^View\s+/i, '')}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedBuyerRefundDetails(null)}
                className="rounded-xl border border-gray-200 p-2 text-gray-500 transition-colors hover:bg-gray-50"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-4 px-6 py-6">
              <p className="text-sm font-semibold text-gray-900">
                Status: {String(selectedBuyerRefundDetails.status || '').replace(/_/g, ' ')}
              </p>
              <p className="text-sm leading-6 text-gray-700">
                Buyer reason: {selectedBuyerRefundDetails.reason || 'No reason provided.'}
              </p>
              {selectedBuyerRefundDetails.adminDecisionReason ? (
                <p className="text-sm leading-6 text-gray-700">
                  Admin review: {selectedBuyerRefundDetails.adminDecisionReason}
                </p>
              ) : null}
              {getRefundImageList(selectedBuyerRefundDetails).length > 0 ? (
                <div className="space-y-3">
                  <p className="text-sm text-gray-700">
                    Uploaded {getRefundImageList(selectedBuyerRefundDetails).length} refund photo{getRefundImageList(selectedBuyerRefundDetails).length === 1 ? '' : 's'}.
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {getRefundImageList(selectedBuyerRefundDetails).map((image: string, imageIndex: number) => (
                      <div key={`buyer-refund-${imageIndex}`} className="overflow-hidden rounded-2xl border border-gray-200 bg-white">
                        <img src={image} alt={`Refund evidence ${imageIndex + 1}`} className="aspect-square w-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}

      {cancellingOrder ? (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/45 px-4 py-6">
          <button
            type="button"
            aria-label="Close cancel order dialog"
            className="absolute inset-0 cursor-default"
            onClick={closeCancelMarketplaceOrderModal}
          />
          <div className="relative z-10 w-full max-w-lg overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-gray-100 px-6 py-5">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gray-400">Cancel Order</p>
                <h3 className="mt-2 text-xl font-semibold text-gray-900">{cancellingOrder.itemName}</h3>
                <p className="mt-2 text-sm text-gray-500">
                  Tell us why you want to cancel this order. The amount will be returned to the buyer wallet after cancellation.
                </p>
              </div>
              <button
                type="button"
                onClick={closeCancelMarketplaceOrderModal}
                className="rounded-xl border border-gray-200 p-2 text-gray-500 transition-colors hover:bg-gray-50"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-4 px-6 py-6">
              <div>
                <label className="text-sm font-medium text-gray-700">Reason for cancellation</label>
                <textarea
                  value={cancelReason}
                  onChange={(event) => setCancelReason(event.target.value)}
                  rows={4}
                  className="mt-2 w-full rounded-2xl border border-gray-200 px-4 py-3 text-sm text-gray-900 focus:border-red-400 focus:outline-none focus:ring-2 focus:ring-red-200"
                  placeholder="Enter your reason for cancelling this order"
                />
              </div>
              {cancelModalError ? (
                <div className="rounded-2xl border border-red-100 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {cancelModalError}
                </div>
              ) : null}
              <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
                <button
                  type="button"
                  onClick={closeCancelMarketplaceOrderModal}
                  className="rounded-2xl border border-gray-200 px-5 py-3 text-sm font-medium text-gray-700 transition hover:bg-gray-50"
                >
                  Keep Order
                </button>
                <button
                  type="button"
                  onClick={() => void handleCancelMarketplaceOrder(cancellingOrder, cancelReason)}
                  disabled={updatingOrderId === cancellingOrder.orderId}
                  className="rounded-2xl bg-red-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {updatingOrderId === cancellingOrder.orderId ? 'Cancelling...' : 'Confirm Cancellation'}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {selectedSellerOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 py-6 responsive-modal-shell">
          <button
            type="button"
            aria-label="Close seller order details"
            className="absolute inset-0 cursor-default"
            onClick={() => setSelectedSellerOrderId('')}
          />
          <div className="responsive-modal-panel relative z-10 flex w-full max-w-5xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="responsive-modal-header rounded-t-3xl bg-gradient-to-r from-green-600 to-green-500 text-white">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-green-100">Seller Order Details</p>
                  <h3 className="mt-2 text-2xl font-semibold">{selectedSellerOrder.itemName}</h3>
                  <p className="mt-1 text-sm text-green-50">
                    Order ID {selectedSellerOrder.orderId} • {getOrderDisplayStatusLabel(selectedSellerOrder)}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedSellerOrderId('')}
                  className="rounded-xl border border-white/30 p-2 text-white transition-colors hover:bg-white/10"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="responsive-modal-body space-y-6 overflow-y-auto">
              <div className="overflow-x-auto">
                <div className="responsive-modal-progress flex min-w-[30rem] items-start justify-between gap-4 md:min-w-[42rem]">
                  {getBuyerOrderProgressSteps(selectedSellerOrder).map((step, index, steps) => {
                    const Icon = step.icon;
                    const stateClass = step.done
                      ? 'border-green-500 bg-green-500 text-white'
                      : step.active
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-200 bg-gray-50 text-gray-400';
                    const connectorClass = step.done && index < getOrderStatusRank(selectedSellerOrder)
                      ? 'bg-green-500'
                      : 'bg-gray-200';

                    return (
                      <div key={step.key} className="flex min-w-0 flex-1 items-start">
                        <div className="min-w-0 flex-1 text-center">
                          <div className={`mx-auto flex h-14 w-14 items-center justify-center rounded-full border-2 ${stateClass}`}>
                            <Icon className="h-6 w-6" />
                          </div>
                          <p className="mt-3 text-sm font-semibold text-gray-900">{step.label}</p>
                          <p className="mt-1 text-xs text-gray-500">{formatOrderDateTime(step.timestamp)}</p>
                        </div>
                        {index < steps.length - 1 ? (
                          <div className={`mt-7 h-1 flex-1 rounded-full ${connectorClass}`} />
                        ) : null}
                      </div>
                    );
                  })}
                </div>
              </div>

              <LogisticsTrackerPanel order={selectedSellerOrder} />

              <div className="responsive-modal-grid grid gap-6 lg:grid-cols-[1.3fr_0.9fr]">
                  <div className="rounded-3xl border border-gray-100 bg-white p-5 shadow-sm">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gray-400">Parcel Timeline</p>
                        <h4 className="mt-2 text-xl font-semibold text-gray-900">What is happening to your parcel</h4>
                      </div>
                      <span className="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                        {getOrderDisplayStatusLabel(selectedSellerOrder)}
                      </span>
                    </div>
  
                    <div className="mt-6 space-y-4">
                      {getVisibleBuyerOrderTimeline(selectedSellerOrder).map((event, index, visibleTimeline) => {
                        const isLatest = index === 0;
                        const markerClass = event.tone === 'success'
                          ? 'bg-emerald-500'
                          : event.tone === 'info'
                            ? 'bg-teal-500'
                            : 'bg-gray-300';
                        const { dateLabel, timeLabel } = getTimelineDateParts(event.timestamp);

                        return (
                          <div key={event.key} className="flex gap-3">
                            <div className="w-14 shrink-0 pt-0.5 text-right">
                              <p className={`text-[11px] leading-4 ${isLatest ? 'font-semibold text-slate-700' : 'text-gray-400'}`}>{dateLabel}</p>
                              <p className={`text-[11px] leading-4 ${isLatest ? 'font-semibold text-slate-700' : 'text-gray-400'}`}>{timeLabel}</p>
                            </div>
                            <div className="flex flex-col items-center">
                              <div className={`h-3 w-3 rounded-full ${markerClass}`} />
                              {index < visibleTimeline.length - 1 ? (
                                <div className="mt-1 h-full min-h-10 w-px bg-gray-200" />
                              ) : null}
                            </div>
                            <div className="min-w-0 pb-2 pt-[-1px]">
                              <p className={`text-[15px] leading-5 ${isLatest ? 'font-semibold text-teal-700' : 'font-medium text-gray-500'}`}>
                                {event.title}
                              </p>
                              {event.detail ? (
                                <p className="mt-1 text-sm leading-5 text-gray-500">{event.detail}</p>
                              ) : null}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="rounded-3xl border border-gray-100 bg-gray-50 p-5">
                    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gray-400">Order Summary</p>
                    <div className="mt-4 space-y-4">
                      <div>
                        <p className="text-sm font-semibold text-gray-900">Buyer</p>
                        <p className="mt-1 text-sm text-gray-600">{selectedSellerOrder.buyerName}</p>
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-gray-900">Delivery Location</p>
                        <div className="mt-1 flex gap-2 text-sm text-gray-600">
                          <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                          <span>{selectedSellerOrder.location || 'Waiting for seller address update'}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-gray-900">Payment Method</p>
                        <p className="mt-1 text-sm capitalize text-gray-600">{String(selectedSellerOrder.paymentMethod || 'Online payment').replace(/_/g, ' ')}</p>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-3xl border border-gray-100 bg-white p-5 shadow-sm">
                    <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gray-400">Order Breakdown</p>
                    <div className="mt-4 space-y-3 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Item subtotal</span>
                        <span className="font-medium text-gray-900">{formatPhpCurrency(selectedSellerOrder.subtotal)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Tax</span>
                        <span className="font-medium text-gray-900">{formatPhpCurrency(selectedSellerOrder.tax)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Shipping</span>
                        <span className="font-medium text-gray-900">{formatPhpCurrency(selectedSellerOrder.shipping)}</span>
                      </div>
                      <div className="flex items-center justify-between border-t border-gray-100 pt-3">
                        <span className="font-semibold text-gray-900">Total paid</span>
                        <span className="text-xl font-bold text-green-700">{formatPhpCurrency(selectedSellerOrder.totalPaid)}</span>
                      </div>
                    </div>
                  </div>

                  {selectedSellerOrder.refundRequest?.status && selectedSellerOrder.refundRequest.status !== 'none' ? (
                    <div className="space-y-3">
                      <button
                        type="button"
                        onClick={() => setSelectedSellerRefundDetails(selectedSellerOrder.refundRequest)}
                        className={`flex w-full items-center justify-between rounded-2xl border px-4 py-3 text-left text-sm font-semibold transition ${getRefundStatusButtonClassName(selectedSellerOrder.refundRequest)}`}
                      >
                        <span>{getRefundStatusButtonLabel(selectedSellerOrder.refundRequest)}</span>
                        <ChevronRight className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectedSellerOrderId('')}
                        className="w-full rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition hover:bg-gray-50"
                      >
                        Close
                      </button>
                    </div>
                  ) : null}

                  <div className="space-y-3">
                    {selectedSellerOrder?.waybill?.available && selectedSellerOrder?.status === 'preparing' ? (
                      <button
                        type="button"
                        onClick={() => void handleDownloadSellerWaybill(selectedSellerOrder)}
                        disabled={updatingOrderId === selectedSellerOrder.orderId}
                        className="w-full rounded-2xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm font-semibold text-sky-700 transition hover:bg-sky-100 disabled:cursor-not-allowed disabled:opacity-60"
                      >
                        {updatingOrderId === selectedSellerOrder.orderId ? 'Preparing PDF...' : 'Download Waybill PDF'}
                      </button>
                    ) : null}
                    {(() => {
                      const sellerAction = getSellerAction(selectedSellerOrder);
                      return sellerAction ? (
                        <button
                          type="button"
                          onClick={() => handleSellerOrderStatusUpdate(selectedSellerOrder, sellerAction.status)}
                          disabled={updatingOrderId === selectedSellerOrder.orderId}
                          className="w-full rounded-2xl bg-gradient-to-r from-green-500 to-green-600 px-4 py-3 text-sm font-semibold text-white transition hover:shadow-lg hover:shadow-green-500/30 disabled:cursor-not-allowed disabled:bg-green-300"
                        >
                          {updatingOrderId === selectedSellerOrder.orderId ? 'Updating...' : sellerAction.label}
                        </button>
                      ) : null;
                    })()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {selectedSellerRefundDetails ? (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/45 px-4 py-6">
          <button
            type="button"
            aria-label="Close seller refund details"
            className="absolute inset-0 cursor-default"
            onClick={() => setSelectedSellerRefundDetails(null)}
          />
          <div className="relative z-10 w-full max-w-lg overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-gray-100 px-6 py-5">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.24em] text-gray-400">Refund Details</p>
                <h3 className="mt-2 text-xl font-semibold text-gray-900">{getRefundStatusButtonLabel(selectedSellerRefundDetails).replace(/^View\s+/i, '')}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedSellerRefundDetails(null)}
                className="rounded-xl border border-gray-200 p-2 text-gray-500 transition-colors hover:bg-gray-50"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-4 px-6 py-6">
              <p className="text-sm font-semibold text-gray-900">
                Status: {String(selectedSellerRefundDetails.status || '').replace(/_/g, ' ')}
              </p>
              <p className="text-sm leading-6 text-gray-700">
                Buyer reason: {selectedSellerRefundDetails.reason || 'No reason provided.'}
              </p>
              {selectedSellerRefundDetails.adminDecisionReason ? (
                <p className="text-sm leading-6 text-gray-700">
                  Admin review: {selectedSellerRefundDetails.adminDecisionReason}
                </p>
              ) : null}
              {getRefundImageList(selectedSellerRefundDetails).length > 0 ? (
                <div className="space-y-3">
                  <p className="text-sm text-gray-700">
                    Buyer uploaded {getRefundImageList(selectedSellerRefundDetails).length} refund photo{getRefundImageList(selectedSellerRefundDetails).length === 1 ? '' : 's'}.
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {getRefundImageList(selectedSellerRefundDetails).map((image: string, imageIndex: number) => (
                      <div key={`seller-refund-modal-${imageIndex}`} className="overflow-hidden rounded-2xl border border-gray-200 bg-white">
                        <img src={image} alt={`Refund evidence ${imageIndex + 1}`} className="aspect-square w-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}

        {refundingOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 py-6 responsive-modal-shell">
            <button type="button" aria-label="Close refund request" className="absolute inset-0 cursor-default" onClick={resetRefundComposer} />
            <div className="responsive-modal-card relative z-10 w-full max-w-2xl overflow-hidden rounded-3xl bg-white shadow-2xl">
              <div className="rounded-t-3xl bg-gradient-to-r from-red-500 to-rose-500 px-6 py-5 text-white">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.24em] text-rose-100">Refund Request</p>
                    <h3 className="mt-2 text-2xl font-semibold">{refundingOrder.itemName}</h3>
                    <p className="mt-1 text-sm text-rose-50">
                      Order ID {refundingOrder.orderId} - Submit your reason and photo proof for admin review.
                    </p>
                  </div>
                  <button type="button" onClick={resetRefundComposer} className="rounded-xl border border-white/30 p-2 text-white transition-colors hover:bg-white/10">
                    <X className="h-5 w-5" />
                  </button>
                </div>
              </div>

              <form onSubmit={handleSubmitMarketplaceRefundRequest} className="space-y-5 px-6 py-6">
                {refundModalError ? (
                  <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                    {refundModalError}
                  </div>
                ) : null}

                <div>
                  <label className="mb-2 block text-sm font-medium text-gray-700">Reason for refund</label>
                  <textarea
                    value={refundReason}
                    onChange={(event) => setRefundReason(event.target.value)}
                    rows={5}
                    placeholder="Explain why you are requesting a refund."
                    className="w-full rounded-2xl border border-gray-300 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>

                <div>
                  <div className="mb-2 flex items-center justify-between gap-3">
                    <label className="text-sm font-medium text-gray-700">Photo evidence</label>
                    <span className="text-xs text-gray-500">Up to {MAX_REFUND_PHOTOS} refund photos</span>
                  </div>
                  <div className="space-y-3">
                    <label className="flex cursor-pointer items-center justify-center rounded-2xl border border-dashed border-gray-300 bg-gray-50 px-4 py-6 text-center hover:border-rose-300 hover:bg-rose-50/40">
                      <div>
                        <ImagePlus className="mx-auto h-7 w-7 text-gray-400" />
                        <p className="mt-2 text-sm font-medium text-gray-700">Upload photos that support your refund request</p>
                      </div>
                      <input type="file" accept="image/*" multiple className="hidden" onChange={handleRefundImageSelection} />
                    </label>

                    {refundImagePreviews.length > 0 ? (
                      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                        {refundImagePreviews.map((preview, index) => (
                          <div key={`refund-preview-${index}`} className="relative overflow-hidden rounded-2xl border border-gray-200 bg-gray-50">
                            <img src={preview} alt={`Refund preview ${index + 1}`} className="aspect-square w-full object-cover" />
                            <button
                              type="button"
                              onClick={() => handleRemoveRefundImage(index)}
                              className="absolute right-2 top-2 rounded-full bg-white/90 p-1 text-gray-600 shadow-sm hover:bg-white"
                              aria-label={`Remove refund photo ${index + 1}`}
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : null}
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <button
                    type="button"
                    onClick={resetRefundComposer}
                    className="rounded-2xl border border-gray-200 px-5 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
                  >
                    Keep Order
                  </button>
                  <button
                    type="submit"
                    disabled={updatingOrderId === refundingOrder.orderId}
                    className="rounded-2xl bg-red-500 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-red-600 disabled:cursor-not-allowed disabled:bg-red-300"
                  >
                    {updatingOrderId === refundingOrder.orderId ? 'Submitting...' : 'Submit Refund Request'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {reviewingOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 py-6">
            <button type="button" aria-label="Close marketplace review" className="absolute inset-0 cursor-default" onClick={resetReviewComposer} />
            <div className="relative z-10 w-full max-w-lg rounded-3xl bg-white shadow-2xl">
              <div className="rounded-t-3xl bg-gradient-to-r from-green-600 to-green-500 px-6 py-5 text-white">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.24em] text-green-100">Rate Product</p>
                    <h3 className="mt-2 text-2xl font-semibold">{reviewingOrder.itemName}</h3>
                    <p className="mt-1 text-sm text-green-50">Share your product experience after receiving the order.</p>
                  </div>
                  <button type="button" onClick={resetReviewComposer} className="rounded-xl border border-white/30 p-2 text-white transition-colors hover:bg-white/10">
                    <X className="h-5 w-5" />
                  </button>
                </div>
              </div>
              <form onSubmit={handleSubmitMarketplaceReview} className="space-y-5 px-6 py-6">
                {reviewModalError && (
                  <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                    {reviewModalError}
                  </div>
                )}
                <div>
                  <div className="mb-2 flex items-center justify-between gap-3">
                    <label className="block text-sm font-medium text-gray-700">Stars</label>
                    <span className="text-sm font-semibold text-amber-600">
                      {['', 'Very poor', 'Poor', 'Okay', 'Good', 'Excellent'][hoveredReviewRating || reviewRating]}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewRating(star)}
                        onMouseEnter={() => setHoveredReviewRating(star)}
                        onMouseLeave={() => setHoveredReviewRating(0)}
                        className="rounded-full p-1.5 transition duration-150 hover:scale-110"
                        aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
                      >
                        <Star
                          className={`h-9 w-9 ${
                            star <= (hoveredReviewRating || reviewRating)
                              ? 'fill-amber-400 text-amber-400 drop-shadow-[0_4px_10px_rgba(251,191,36,0.35)]'
                              : 'text-gray-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="mb-2 flex items-center justify-between gap-3">
                    <label className="block text-sm font-medium text-gray-700">Photos</label>
                    <span className="text-xs text-gray-500">Up to {MAX_REVIEW_PHOTOS} item photos</span>
                  </div>
                  <div className="space-y-3">
                    <label className="flex cursor-pointer items-center justify-center gap-3 rounded-2xl border border-dashed border-gray-300 bg-gray-50 px-4 py-4 text-center transition hover:border-green-400 hover:bg-green-50/60">
                      <ImagePlus className="h-5 w-5 text-green-600" />
                      <div>
                        <p className="text-sm font-medium text-gray-800">Add photos of the item you received</p>
                        <p className="text-xs text-gray-500">JPG, PNG, or WebP</p>
                      </div>
                      <input type="file" accept="image/*" multiple className="hidden" onChange={handleReviewImageSelection} />
                    </label>
                    {reviewImagePreviews.length > 0 && (
                      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                        {reviewImagePreviews.map((preview, index) => (
                          <div key={`review-preview-${index}`} className="relative overflow-hidden rounded-2xl border border-gray-200 bg-gray-50">
                            <img src={preview} alt={`Review preview ${index + 1}`} className="aspect-square w-full object-cover" />
                            <button
                              type="button"
                              onClick={() => handleRemoveReviewImage(index)}
                              className="absolute right-2 top-2 rounded-full bg-slate-900/70 p-1 text-white transition hover:bg-slate-900"
                              aria-label={`Remove review photo ${index + 1}`}
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <div>
                  <label className="mb-2 block text-sm font-medium text-gray-700">Comment</label>
                  <textarea
                    value={reviewComment}
                    onChange={(event) => setReviewComment(event.target.value)}
                  rows={4}
                  className="w-full rounded-2xl border border-gray-200 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="Tell buyers how the product quality and service went."
                />
              </div>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={resetReviewComposer}
                    className="flex-1 rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={updatingOrderId === reviewingOrder.orderId}
                    className="flex-1 rounded-2xl bg-green-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-green-700 disabled:cursor-not-allowed disabled:bg-green-300"
                  >
                    {updatingOrderId === reviewingOrder.orderId ? 'Submitting Review...' : 'Submit Review'}
                  </button>
                </div>
              </form>
            </div>
          </div>
      )}

      {selectedProduct && (
        (() => {
          const isOwnSelectedProduct = String(selectedProduct?.sellerUserId || '').trim() === String(currentUser?.id || '').trim();

          return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/55 px-4 py-6 responsive-modal-shell">
          <button type="button" aria-label="Close product details" className="absolute inset-0 cursor-default" onClick={() => setSelectedProduct(null)} />
          <div className="responsive-modal-panel relative z-10 flex w-full max-w-6xl flex-col overflow-hidden rounded-[2rem] bg-white shadow-2xl">
            <div className="responsive-modal-header flex items-center justify-between border-b border-gray-100">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-emerald-500">Marketplace Listing</p>
                <h3 className="mt-2 text-2xl font-semibold text-gray-900">{selectedProduct.name}</h3>
              </div>
              <button type="button" onClick={() => setSelectedProduct(null)} className="rounded-xl border border-gray-200 p-2 text-gray-600 transition-colors hover:bg-gray-50">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="responsive-modal-body overflow-y-auto">
              <div className="responsive-modal-grid grid gap-8 lg:grid-cols-[1.05fr_0.95fr]">
                <div className="flex h-full flex-col">
                  <div className="responsive-modal-media relative overflow-hidden rounded-[1.75rem] bg-gray-100">
                    {selectedProductImage ? (
                      <img src={selectedProductImage} alt={selectedProduct.name} className="aspect-square w-full object-cover" />
                    ) : (
                      <div className="flex aspect-square items-center justify-center text-sm text-gray-400">No image available</div>
                    )}
                    {selectedProductImages.length > 1 && (
                      <>
                        <button
                          type="button"
                          onClick={handleSelectPreviousProductImage}
                          className="absolute left-4 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-white/85 text-gray-700 shadow-lg transition hover:bg-white"
                        >
                          <ChevronLeft className="h-5 w-5" />
                        </button>
                        <button
                          type="button"
                          onClick={handleSelectNextProductImage}
                          className="absolute right-4 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full bg-white/85 text-gray-700 shadow-lg transition hover:bg-white"
                        >
                          <ChevronRight className="h-5 w-5" />
                        </button>
                        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-slate-900/65 px-3 py-1 text-xs font-medium text-white">
                          {selectedProductImages.findIndex((image) => image === selectedProductImage) + 1} / {selectedProductImages.length}
                        </div>
                      </>
                    )}
                  </div>
                  {selectedProductImages.length > 1 && (
                    <div className="mt-4 grid grid-cols-4 gap-3 sm:grid-cols-5">
                      {selectedProductImages.map((image: string, index: number) => (
                        <button
                          key={`${image}-${index}`}
                          type="button"
                          onClick={() => setSelectedProductImage(image)}
                          className={`overflow-hidden rounded-2xl border transition-all ${selectedProductImage === image ? 'border-green-500 ring-2 ring-green-200' : 'border-gray-200 hover:border-green-300'}`}
                        >
                          <img src={image} alt={`${selectedProduct.name} preview ${index + 1}`} className="aspect-square w-full object-cover" />
                        </button>
                      ))}
                    </div>
                  )}

                  <div className="mt-6 rounded-[1.75rem] border border-gray-100 bg-white p-6 shadow-sm">
                    <h4 className="text-lg font-semibold text-gray-900">Product Overview</h4>
                    <p className="mt-3 text-sm leading-7 text-gray-600">{selectedProduct.description || 'No product description provided.'}</p>
                  </div>

                  <div className="mt-6 rounded-[1.75rem] border border-gray-100 bg-white p-6 shadow-sm">
                    <h4 className="text-lg font-semibold text-gray-900">Product Details</h4>
                    <div className="mt-4">{renderProductSpecs(selectedProduct)}</div>
                  </div>
                </div>

                <div className="flex flex-col">
                  <div className="rounded-[1.75rem] border border-gray-100 bg-gradient-to-br from-emerald-50 via-white to-lime-50 p-6">
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="rounded-full bg-white px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-emerald-700 shadow-sm">{selectedProduct.category}</span>
                      <span className="rounded-full bg-white px-3 py-1 text-xs font-medium text-gray-600 shadow-sm">{selectedProduct.stock} {selectedProduct.unit} total stock</span>
                    </div>
                    <p className="mt-5 bg-gradient-to-r from-green-700 to-emerald-600 bg-clip-text text-4xl font-bold text-transparent">
                      {formatPhpCurrency(selectedVariety?.price || selectedProduct.price)}
                    </p>
                    <p className="mt-2 text-sm text-gray-500">Price per {selectedProduct.unit}</p>

                    {getProductVarieties(selectedProduct).length > 0 && (
                      <div className="mt-6">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-semibold uppercase tracking-[0.18em] text-gray-500">Choose Variety</h4>
                          <span className="text-xs text-gray-500">{getProductVarieties(selectedProduct).length} options</span>
                        </div>
                        <div className="mt-3 grid gap-3">
                          {getProductVarieties(selectedProduct).map((variety: any) => (
                            <button
                              key={variety.id}
                              type="button"
                              onClick={() => setSelectedProductVarietyId(String(variety.id || ''))}
                              className={`rounded-2xl border px-4 py-3 text-left transition-all ${String(variety.id || '') === String(selectedVariety?.id || '') ? 'border-green-500 bg-white shadow-sm ring-2 ring-green-200' : 'border-gray-200 bg-white/70 hover:border-green-300'}`}
                            >
                              <div className="flex items-center justify-between gap-4">
                                <div>
                                  <p className="font-semibold text-gray-900">{variety.label}</p>
                                  <p className="mt-1 text-sm text-gray-500">{variety.stock} {selectedProduct.unit} available</p>
                                </div>
                                <p className="text-sm font-semibold text-emerald-700">{formatPhpCurrency(variety.price)}</p>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                      <div className="rounded-2xl bg-white/90 px-4 py-3 shadow-sm">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-gray-400">Seller</p>
                        <p className="mt-1 flex items-center gap-2 text-sm font-medium text-gray-700">
                          <Store className="h-4 w-4 text-emerald-600" />
                          {selectedProduct.seller}
                        </p>
                      </div>
                      <div className="rounded-2xl bg-white/90 px-4 py-3 shadow-sm">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-gray-400">Minimum Order</p>
                        <p className="mt-1 flex items-center gap-2 text-sm font-medium text-gray-700">
                          <Package className="h-4 w-4 text-emerald-600" />
                          {selectedProduct.minimumOrder} {selectedProduct.unit}
                        </p>
                      </div>
                      <div className="rounded-2xl bg-white/90 px-4 py-3 shadow-sm">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-gray-400">Rating</p>
                        <p className="mt-1 flex items-center gap-2 text-sm font-medium text-gray-700">
                          <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                          {getProductRating(selectedProduct) > 0 ? getProductRating(selectedProduct).toFixed(1) : 'No ratings yet'}
                        </p>
                      </div>
                      <div className="rounded-2xl bg-white/90 px-4 py-3 shadow-sm">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-gray-400">Total Sold</p>
                        <p className="mt-1 text-sm font-medium text-gray-700">{getProductSoldCount(selectedProduct)} sold</p>
                      </div>
                    </div>

                    <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                      {selectedProduct?.canEdit ? (
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedProduct(null);
                            handleEditListing(selectedProduct);
                          }}
                          className="flex-1 rounded-2xl bg-gradient-to-r from-green-500 to-green-600 px-5 py-4 text-sm font-semibold text-white transition-all hover:shadow-lg hover:shadow-green-500/30"
                        >
                          Edit Listing
                        </button>
                      ) : isOwnSelectedProduct ? (
                        <button
                          type="button"
                          disabled
                          className="flex-1 cursor-not-allowed rounded-2xl border border-gray-200 bg-gray-100 px-5 py-4 text-sm font-semibold text-gray-500"
                        >
                          Your Listing
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleAddToCartFromProduct(selectedProduct)}
                          className="flex-1 rounded-2xl bg-gradient-to-r from-green-500 to-green-600 px-5 py-4 text-sm font-semibold text-white transition-all hover:shadow-lg hover:shadow-green-500/30"
                        >
                          Add to Cart
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setSelectedProduct(null)}
                        className="rounded-2xl border border-gray-200 px-5 py-4 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50"
                      >
                        Continue Browsing
                      </button>
                    </div>
                  </div>

                  <div className="mt-6 flex-1 rounded-[1.75rem] border border-gray-100 bg-white p-6 shadow-sm">
                    <div className="flex items-center justify-between gap-3">
                      <h4 className="text-lg font-semibold text-gray-900">Reviews</h4>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1.5">
                          <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                          {getProductRating(selectedProduct) > 0 ? getProductRating(selectedProduct).toFixed(1) : 'No ratings yet'}
                        </span>
                        <span>{getProductReviewCount(selectedProduct)} reviews</span>
                        <span>{getProductSoldCount(selectedProduct)} sold</span>
                      </div>
                    </div>
                    <div className="mt-4 max-h-[28rem] overflow-y-auto pr-1">{renderProductReviews(selectedProduct)}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
          );
        })()
      )}

      {selectedReviewImage && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/80 px-4 py-6">
          <button
            type="button"
            aria-label="Close review image preview"
            className="absolute inset-0 cursor-default"
            onClick={() => setSelectedReviewImage('')}
          />
          <div className="relative z-10 w-full max-w-4xl">
            <button
              type="button"
              onClick={() => setSelectedReviewImage('')}
              className="absolute right-4 top-4 rounded-full bg-white/90 p-2 text-gray-700 shadow-lg transition hover:bg-white"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="overflow-hidden rounded-[2rem] bg-white shadow-2xl">
              <img src={selectedReviewImage} alt="Review preview" className="max-h-[80vh] w-full object-contain bg-slate-50" />
            </div>
          </div>
        </div>
      )}

      {isListingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/45 px-4 py-6 responsive-modal-shell">
          <button type="button" aria-label="Close listing form" className="absolute inset-0 cursor-default" onClick={() => setIsListingModalOpen(false)} />
          <div className="responsive-modal-panel relative z-10 flex w-full max-w-5xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl">
            <div className="responsive-modal-header rounded-t-3xl bg-gradient-to-r from-green-600 to-green-500 text-white">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.24em] text-green-100">Seller Listing</p>
                  <h3 className="mt-2 text-2xl font-semibold">{listingForm.listingId ? 'Edit marketplace listing' : 'Create marketplace listing'}</h3>
                  <p className="mt-1 text-sm text-green-50">
                    Use one listing with multiple varieties. Photos must be 1 to 3 only, and pickup location must come from your farm or your saved address.
                  </p>
                </div>
                <button type="button" onClick={() => setIsListingModalOpen(false)} className="rounded-xl border border-white/30 p-2 text-white transition-colors hover:bg-white/10">
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            <form onSubmit={handleSaveListing} className="responsive-modal-body space-y-6 overflow-y-auto">
              <div className="responsive-modal-grid grid gap-6 lg:grid-cols-2">
                <div className="space-y-4">
                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700">Product Name</label>
                    <input
                      type="text"
                      value={listingForm.name}
                      onChange={(event) => setListingForm((current) => ({ ...current, name: event.target.value }))}
                      className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Category</label>
                      <select
                        value={listingForm.category}
                        onChange={(event) => {
                          const nextCategory = event.target.value;
                          setListingForm((current) => ({
                            ...current,
                            category: nextCategory,
                            unit: unitOptions[nextCategory]?.[0] || 'piece',
                            varieties: supportsVarieties(nextCategory) ? (current.varieties.length > 0 ? current.varieties : [buildVarietyDraft()]) : [buildVarietyDraft()],
                          }));
                        }}
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                      >
                        {categories.filter((category) => category !== 'all').map((category) => (
                          <option key={category} value={category}>{category.charAt(0).toUpperCase() + category.slice(1)}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Unit</label>
                      <select
                        value={listingForm.unit}
                        onChange={(event) => setListingForm((current) => ({ ...current, unit: event.target.value }))}
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                      >
                        {unitChoices.map((unit) => (
                          <option key={unit} value={unit}>{unit}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700">Description</label>
                    <textarea
                      value={listingForm.description}
                      onChange={(event) => setListingForm((current) => ({ ...current, description: event.target.value }))}
                      rows={5}
                      className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>

                  {showBrandField && (
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Brand</label>
                      <input
                        type="text"
                        value={listingForm.brand}
                        onChange={(event) => setListingForm((current) => ({ ...current, brand: event.target.value }))}
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                      />
                    </div>
                  )}

                  {showConditionField && (
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Condition</label>
                      <select
                        value={listingForm.condition}
                        onChange={(event) => setListingForm((current) => ({ ...current, condition: event.target.value }))}
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                      >
                        <option value="">Select condition</option>
                        <option value="Brand New">Brand New</option>
                        <option value="Like New">Like New</option>
                        <option value="Used - Good">Used - Good</option>
                        <option value="Used - Fair">Used - Fair</option>
                      </select>
                    </div>
                  )}

                  {showHarvestDateField && (
                    <div>
                      <label className="mb-2 block text-sm font-medium text-gray-700">Harvest Date</label>
                      <input
                        type="date"
                        value={listingForm.harvestDate}
                        onChange={(event) => setListingForm((current) => ({ ...current, harvestDate: event.target.value }))}
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700">Minimum Order</label>
                    <input
                      type="number"
                      min="1"
                      value={listingForm.minimumOrder}
                      onChange={(event) => setListingForm((current) => ({ ...current, minimumOrder: event.target.value }))}
                      className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>

                  <div>
                    <label className="mb-2 block text-sm font-medium text-gray-700">Pickup Location</label>
                    <input
                      type="text"
                      value={listingForm.location}
                      readOnly
                      className="w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-gray-600 focus:outline-none"
                    />
                    <p className="mt-2 text-xs text-gray-500">This uses the address saved in the user profile.</p>
                  </div>

                  {listingSupportsVarieties ? (
                    <div className="rounded-2xl border border-gray-200 bg-gray-50/70 p-4">
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <h4 className="text-sm font-semibold text-gray-900">Varieties</h4>
                          <p className="text-xs text-gray-500">Add multiple varieties with separate price and stock.</p>
                        </div>
                        <button
                          type="button"
                          onClick={handleAddVarietyRow}
                          className="rounded-xl border border-green-200 bg-white px-4 py-2 text-sm font-medium text-green-700 transition-colors hover:bg-green-50"
                        >
                          Add Variety
                        </button>
                      </div>
                      <div className="mt-4 space-y-3">
                        {listingForm.varieties.map((variety, index) => (
                          <div key={variety.id} className="rounded-2xl border border-gray-200 bg-white p-4">
                            <div className="mb-3 flex items-center justify-between">
                              <p className="text-sm font-semibold text-gray-800">Variety {index + 1}</p>
                              {listingForm.varieties.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveVarietyRow(variety.id)}
                                  className="text-xs font-medium text-red-600 hover:text-red-700"
                                >
                                  Remove
                                </button>
                              )}
                            </div>
                            <div className="grid gap-3 md:grid-cols-3">
                              <input
                                type="text"
                                placeholder="Variety name"
                                value={variety.label}
                                onChange={(event) => handleUpdateVarietyRow(variety.id, 'label', event.target.value)}
                                className="rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                              />
                              <input
                                type="text"
                                inputMode="decimal"
                                placeholder="Price"
                                value={variety.price}
                                onChange={(event) => handleUpdateVarietyRow(variety.id, 'price', event.target.value)}
                                className="rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                              />
                              <input
                                type="number"
                                min="1"
                                placeholder="Stock"
                                value={variety.stock}
                                onChange={(event) => handleUpdateVarietyRow(variety.id, 'stock', event.target.value)}
                                className="rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <label className="mb-2 block text-sm font-medium text-gray-700">Price</label>
                        <input
                          type="number"
                          min="0"
                          step="0.01"
                          value={listingForm.basePrice}
                          onChange={(event) => setListingForm((current) => ({ ...current, basePrice: event.target.value }))}
                          className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                        />
                      </div>
                      <div>
                        <label className="mb-2 block text-sm font-medium text-gray-700">Available Stock</label>
                        <input
                          type="number"
                          min="1"
                          value={listingForm.baseStock}
                          onChange={(event) => setListingForm((current) => ({ ...current, baseStock: event.target.value }))}
                          className="w-full rounded-xl border border-gray-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500"
                        />
                      </div>
                    </div>
                  )}

                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-gray-700">Product Photos</label>
                <div className="responsive-modal-grid grid items-start gap-4 lg:grid-cols-[1.15fr_0.85fr]">
                  <label className="flex min-h-[12rem] cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-gray-300 bg-gray-50 px-4 py-6 text-center hover:border-green-400 hover:bg-green-50/40">
                    <ImagePlus className="h-8 w-8 text-gray-400" />
                    <span className="mt-3 text-sm font-medium text-gray-700">Upload 1 to 3 photos</span>
                    <span className="mt-1 text-xs text-gray-500">JPG, PNG, or WebP. Maximum of 3 photos per listing.</span>
                    <input type="file" multiple accept="image/*" className="hidden" onChange={handleImageSelection} />
                  </label>

                  <div className="grid grid-cols-3 gap-3">
                    {Array.from({ length: 3 }).map((_, index) => {
                      const preview = listingImagePreviews[index];

                      return (
                        <div key={`listing-photo-slot-${index}`} className="aspect-square overflow-hidden rounded-xl border border-gray-200 bg-gray-100">
                          {preview ? (
                            <img src={preview} alt={`Listing preview ${index + 1}`} className="h-full w-full object-cover" />
                          ) : (
                            <div className="flex h-full items-center justify-center text-[11px] font-medium text-gray-400">
                              Photo {index + 1}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {listingError && (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {listingError}
                </div>
              )}

              <div className="responsive-modal-sticky-actions sticky bottom-0 flex flex-col gap-3 border-t border-gray-100 bg-white pt-4 sm:flex-row">
                <button
                  type="button"
                  onClick={() => setIsListingModalOpen(false)}
                  disabled={isSavingListing}
                  className="flex-1 rounded-2xl border border-gray-200 px-4 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingListing}
                  className="flex-1 rounded-2xl bg-green-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-green-700 disabled:cursor-not-allowed disabled:bg-green-300"
                >
                  {isSavingListing ? 'Saving Listing...' : listingForm.listingId ? 'Update Listing' : 'Publish Listing'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
