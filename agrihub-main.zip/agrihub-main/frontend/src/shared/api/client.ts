import { clearSession } from '../auth/session';

function getDefaultBaseUrl() {
  if (typeof window !== 'undefined' && window.location.hostname !== 'localhost') {
    return '/api/v1';
  }

  return 'http://localhost:5000/api/v1';
}

const defaultBaseUrl = getDefaultBaseUrl();

export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL?.trim() || defaultBaseUrl;

type ApiOptions = Omit<RequestInit, 'body'> & {
  body?: unknown;
};

function delay(ms: number) {
  return new Promise((resolve) => {
    window.setTimeout(resolve, ms);
  });
}

function isSafeRetryMethod(method?: string) {
  const normalized = String(method || 'GET').trim().toUpperCase();
  return normalized === 'GET' || normalized === 'HEAD';
}

function isLikelyNetworkError(error: unknown) {
  if (!(error instanceof Error)) {
    return false;
  }

  return error.name === 'TypeError' || /fetch|network|load failed|failed to fetch/i.test(error.message);
}

export async function apiRequest<T>(
  path: string,
  { headers, body, ...init }: ApiOptions = {},
): Promise<T> {
  const token =
    typeof window !== 'undefined' ? localStorage.getItem('agrihub_token') : null;

  const requestInit: RequestInit = {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  };

  const requestUrl = `${API_BASE_URL}${path}`;
  const shouldRetry = isSafeRetryMethod(requestInit.method);
  const maxAttempts = shouldRetry ? 2 : 1;
  let response: Response | null = null;
  let lastError: unknown = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      response = await fetch(requestUrl, requestInit);
      lastError = null;
      break;
    } catch (error) {
      lastError = error;

      if (!shouldRetry || !isLikelyNetworkError(error) || attempt >= maxAttempts) {
        break;
      }

      await delay(800 * attempt);
    }
  }

  if (!response) {
    if (isLikelyNetworkError(lastError)) {
      throw new Error('The server is waking up or temporarily unreachable. Please try again in a few seconds.');
    }

    throw lastError instanceof Error
      ? lastError
      : new Error('Something went wrong while contacting the server.');
  }

  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    const rawMessage =
      typeof payload?.message === 'string'
        ? payload.message
        : 'Something went wrong while contacting the server.';
    const message =
      rawMessage.startsWith('Route not found:')
        ? 'This feature is not available right now. Please try again in a moment.'
        : rawMessage;

    if (message === 'This account has been disabled. Please contact support.') {
      clearSession();

      if (typeof window !== 'undefined' && window.location.pathname !== '/login') {
        const loginUrl = new URL('/login', window.location.origin);
        loginUrl.searchParams.set(
          'message',
          'Your account has been disabled. Please contact support.',
        );
        window.location.assign(loginUrl.toString());
      }
    }

    throw new Error(message);
  }

  return payload as T;
}
