# AgriHub MongoDB Database Documentation

This document describes the MongoDB data model currently used by AgriHub and is aligned with the backend schema that is presently deployed in production from the current application codebase.

Primary schema sources for the deployed production model:

- [User.js](C:/Users/earlj/OneDrive/Desktop/SysArch/backend/src/models/User.js)
- [MarketplacePayment.js](C:/Users/earlj/OneDrive/Desktop/SysArch/backend/src/models/MarketplacePayment.js)
- [LaborPayment.js](C:/Users/earlj/OneDrive/Desktop/SysArch/backend/src/models/LaborPayment.js)
- [ServicePayment.js](C:/Users/earlj/OneDrive/Desktop/SysArch/backend/src/models/ServicePayment.js)
- [PendingRegistration.js](C:/Users/earlj/OneDrive/Desktop/SysArch/backend/src/models/PendingRegistration.js)
- [MarketplaceHub.js](C:/Users/earlj/OneDrive/Desktop/SysArch/backend/src/models/MarketplaceHub.js)
- [PlatformSetting.js](C:/Users/earlj/OneDrive/Desktop/SysArch/backend/src/models/PlatformSetting.js)

## Overview

AgriHub uses MongoDB as its primary operational database. The system stores:

- user accounts and roles
- marketplace listings and orders
- labor offers and labor bookings
- rental or service listings and bookings
- payment transaction records
- wallet transactions
- role verification records
- logistics routing and delivery simulation data
- temporary pending registration records
- platform-wide settings
- marketplace routing hub metadata

## Primary Schema

The currently deployed production schema is centered on the `users` collection and is supported by several transaction and configuration collections.

### Primary operational collection

- `users`

This is the main aggregate document for the live system and contains the majority of user-facing business data, including:

- identity and authentication state
- profile and verification state
- wallet balances and wallet transactions
- marketplace listings
- marketplace purchases and sales
- labor offers and labor bookings
- service or rental listings and bookings
- operations planning data

### Supporting production collections

- `marketplacepayments`
- `laborpayments`
- `servicepayments`
- `pendingregistrations`
- `marketplace_hubs`
- `platformsettings`

These supporting collections handle payment workflows, staged registration, logistics reference data, and global platform settings.

## Collections

The current deployed collections documented in this file are:

- `users`
- `marketplacepayments`
- `laborpayments`
- `servicepayments`
- `pendingregistrations`
- `marketplace_hubs`
- `platformsettings`

## 1. `users`

The `users` collection is the core collection in the system. It stores identity, profile, verification, wallet, marketplace, labor, service, and operations data in a large aggregate document.

### Top-level fields

| Field | Type | Description |
|---|---|---|
| `_id` | `ObjectId` | MongoDB primary key |
| `name` | `String` | Full display name |
| `email` | `String` | Unique normalized email address |
| `phone` | `String` | Primary contact number |
| `passwordHash` | `String \| null` | Hashed password for local-auth accounts |
| `googleId` | `String` | Google account id for Google-auth users |
| `emailVerified` | `Boolean` | Whether the primary email is verified |
| `role` | `String` | High-level role: `user` or `admin` |
| `roles` | `String[]` | Functional roles such as buyer, seller, laborer, service, operations, admin |
| `accountType` | `String` | Main account classification |
| `accountStatus` | `String` | `active` or `disabled` |
| `disabledAt` | `Date \| null` | Date of account disable |
| `disabledReason` | `String` | Disable reason |
| `pendingDisableAt` | `Date \| null` | Scheduled disable timestamp |
| `pendingDisableReason` | `String` | Scheduled disable reason |
| `pendingDeleteAt` | `Date \| null` | Scheduled delete timestamp |
| `pendingDeleteReason` | `String` | Scheduled delete reason |
| `verification` | `Object` | Seller and laborer verification state |
| `activityLog` | `Array` | User activity timeline |
| `passwordReset` | `Object` | Forgot-password state |
| `emailVerification` | `Object` | Email verification or email-change verification state |
| `phoneVerification` | `Object` | Phone verification and pending phone change state |
| `paymentMethods` | `Object` | Stored payment method display data |
| `wallet` | `Object` | Wallet balance and wallet transaction history |
| `penalty` | `Object` | Current penalty state |
| `penaltyHistory` | `Array` | Penalty history records |
| `profile` | `Object` | Personal, address, and profile metadata |
| `marketplaceListings` | `Array` | Seller marketplace listings |
| `marketplaceOrders` | `Object` | Buyer purchases and seller sales |
| `laborBookings` | `Object` | Labor bookings tied to the user as customer |
| `laborProfile` | `Object` | Laborer public profile and labor-side booking records |
| `serviceProfile` | `Object` | Service or rental listings and bookings |
| `operationsProfile` | `Object` | Operations dashboard data and field tasks |
| `createdAt` | `Date` | Document creation timestamp |
| `updatedAt` | `Date` | Document update timestamp |

### Role-related enums

#### `role`

- `user`
- `admin`

#### `roles`

- `buyer`
- `seller`
- `laborer`
- `service`
- `operations`
- `admin`

#### `accountType`

- `customer`
- `vendor`
- `laborer`
- `service`
- `operations`
- `admin`

#### `accountStatus`

- `active`
- `disabled`

### Embedded subdocuments in `users`

#### 1.1 `verification`

Contains verification state for:

- `seller`
- `laborer`

Each verification record contains:

| Field | Type | Description |
|---|---|---|
| `status` | `String` | `unverified`, `pending`, or `verified` |
| `submittedAt` | `Date \| null` | Submission date |
| `verifiedAt` | `Date \| null` | Approval date |
| `rejectedAt` | `Date \| null` | Rejection date |
| `reviewReason` | `String` | Admin review reason |
| `documents` | `Array` | Uploaded KYC / verification files |
| `details` | `Object` | Verification form details |

Verification document fields:

- `type`
- `bucket`
- `path`
- `originalName`
- `uploadedAt`

#### 1.2 `activityLog`

Activity log entries contain:

- `description`
- `status`: `completed`, `confirmed`, `pending`, `cancelled`
- `createdAt`

#### 1.3 `passwordReset`

Fields:

- `code`
- `expiresAt`
- `verifiedAt`
- `requestedAt`

#### 1.4 `emailVerification`

Fields:

- `code`
- `expiresAt`
- `requestedAt`
- `verifiedAt`
- `pendingEmail`

Used for:

- registration email verification
- email change verification

#### 1.5 `phoneVerification`

Fields:

- `status`: `unverified`, `verified`
- `source`
- `code`
- `expiresAt`
- `requestedAt`
- `verifiedAt`
- `pendingPhone`

#### 1.6 `paymentMethods`

Stored display information for:

- `gcash`
- `paymaya`
- `card`

Each payment method includes:

- `accountName`
- `mobileNumber`
- `cardholderName`
- `brand`
- `last4`

#### 1.7 `wallet`

Fields:

| Field | Type | Description |
|---|---|---|
| `balance` | `Number` | Current wallet balance |
| `totalEarned` | `Number` | Lifetime credited earnings |
| `totalWithdrawn` | `Number` | Lifetime withdrawn amount |
| `transactions` | `Array` | Wallet history |

Wallet transaction fields:

- `id`
- `type`: `credit`, `cashout`, `payment`
- `amount`
- `status`: `completed`, `pending`, `failed`
- `method`
- `description`
- `reference`
- `destinationLabel`
- `createdAt`

#### 1.8 `penalty`

Fields:

- `status`: `good`, `warned`, `restricted`, `suspended`
- `reason`
- `notes`
- `penalizedAt`
- `expiresAt`
- `penalizedBy`

#### 1.9 `penaltyHistory`

Historical records of prior penalty states with the same shape as `penalty`.

#### 1.10 `profile`

Personal and account profile fields include:

- `firstName`
- `middleName`
- `lastName`
- `age`
- `gender`
- `dateOfBirth`
- `civilStatus`
- `nationality`
- `emergencyContactName`
- `emergencyContactPhone`
- `address`
- `streetAddress`
- `city`
- `state`
- `postalCode`
- `country`
- `farmName`
- `location`
- `coordinates.lat`
- `coordinates.lng`
- `farmSize`
- `experience`
- `specialization`
- `avatarPath`
- `avatarUrl`

### Marketplace data inside `users`

#### 1.11 `marketplaceListings`

These are seller-owned listing documents embedded inside the user.

Listing fields:

- `listingId`
- `name`
- `category`
- `description`
- `brand`
- `variety`
- `condition`
- `harvestDate`
- `location`
- `price`
- `unit`
- `stock`
- `minimumOrder`
- `varieties`
- `image`
- `imagePaths`
- `reviews`
- `rating`
- `status`
- `views`
- `orders`

##### Listing varieties

Each variety contains:

- `id`
- `label`
- `price`
- `stock`

##### Listing reviews

Each review contains:

- `id`
- `author`
- `authorUserId`
- `rating`
- `comment`
- `imagePaths`
- `imageUrls`
- `createdAt`

#### 1.12 `marketplaceOrders`

This is split into:

- `purchases`
- `sales`

Both arrays use the same embedded marketplace-order schema.

Marketplace order core fields:

- `orderId`
- `paymentReference`
- `listingId`
- `sellerUserId`
- `buyerUserId`
- seller identity and address fields
- buyer identity and address fields
- `itemName`
- `category`
- `unit`
- `quantity`
- `price`
- `subtotal`
- `tax`
- `shipping`
- `totalPaid`
- `paymentMethod`
- `imagePath`
- `selectedVarietyId`
- `selectedVarietyLabel`
- `status`
- `reviewed`
- review fields
- payout fields
- status timestamps
- cancellation fields
- `refundRequest`
- `waybill`
- `createdAt`
- `logistics`

##### Marketplace order `status` enum

- `paid`
- `preparing`
- `ready_for_pickup`
- `in_transit`
- `received`
- `completed`
- `cancelled`
- `return_refund`

##### Seller payout fields

- `sellerPayoutStatus`: `pending`, `released`
- `sellerPayoutAmount`
- `sellerPayoutReleasedAt`
- `sellerPayoutTransactionId`

##### Lifecycle timestamps

- `paidAt`
- `preparingAt`
- `readyForPickupAt`
- `inTransitAt`
- `receivedAt`
- `completedAt`
- `cancelledAt`

##### Refund request subdocument

Fields:

- `status`: `none`, `pending`, `approved`, `rejected`
- `reason`
- `imagePaths`
- `imageUrls`
- `requestedAt`
- `reviewedAt`
- `reviewedByUserId`
- `reviewedByName`
- `adminDecisionReason`
- `refundedAt`

##### Waybill subdocument

Fields:

- `generatedAt`
- `generatedBy`

##### Logistics subdocument

Fields:

- `trackingNumber`
- `providerMeta.eta`
- `providerMeta.geometry`
- `providerMeta.optimization`
- `simulationEnabled`
- `simulationLockedReason`
- `currentStopIndex`
- `progressPercent`
- `currentLocation.lat`
- `currentLocation.lng`
- `distanceKm`
- `durationMinutes`
- `lastUpdatedAt`
- `estimatedArrivalAt`
- `routeGeometry[]`
- `routeStops[]`

Each `routeStop` contains:

- `id`
- `type`
- `label`
- `address`
- `coordinates.lat`
- `coordinates.lng`
- `estimatedAt`
- `arrivedAt`
- `departedAt`

### Labor data inside `users`

#### 1.13 `laborBookings`

Contains buyer-side labor bookings:

- `activeBookings`
- `bookingHistory`

Each labor booking includes:

- `bookingId`
- `worker`
- `workerId`
- `workerEmail`
- `workerPhone`
- `type`
- `date`
- `time`
- `duration`
- `location`
- `rate`
- `status`
- `cost`
- `rating`
- `reviewComment`
- `reviewedAt`
- booked-by identity fields
- `travelTracking`
- `completionConfirmation`
- `completedAt`
- `cancelledAt`
- `cancellationReason`
- `cancelledBy`

##### `travelTracking`

- `isOnTheWay`
- `startedAt`
- `updatedAt`
- `currentLocation.lat`
- `currentLocation.lng`

##### `completionConfirmation`

- `clientConfirmedAt`
- `workerConfirmedAt`

#### 1.14 `laborProfile`

Represents a user acting as a laborer.

Fields:

- `title`
- `description`
- `workerType`
- `rate`
- `availability`
- `skills`
- `distance`
- `serviceArea`
- `rating`
- `isPublished`
- `listings`
- `activeBookings`
- `bookingHistory`

##### `listings`

Each labor offer contains:

- `title`
- `description`
- `workerType`
- `rate`
- `availability`
- `skills`
- `distance`
- `serviceArea`
- `workingHoursStart`
- `workingHoursEnd`
- `isPublished`
- `reviews`
- `reviewCount`
- `rating`

##### Labor reviews

- `id`
- `author`
- `authorUserId`
- `rating`
- `comment`
- `bookingId`
- `createdAt`

### Service / rental data inside `users`

#### 1.15 `serviceProfile`

Fields:

- `category`
- `services`
- `bookings`
- `incomingBookings`

##### `services`

Each service or rental item contains:

- `listingId`
- `name`
- `category`
- `description`
- `condition`
- `identifier`
- `location`
- `rate`
- `unit`
- `minimumOrder`
- `quantity`
- `available`
- `ownerRole`
- `status`
- `image`
- `imagePaths`

##### `bookings` and `incomingBookings`

Each service booking contains:

- `service`
- `provider`
- `providerUserId`
- `customer`
- `customerUserId`
- `listingId`
- `date`
- `time`
- `duration`
- `location`
- `status`
- `description`
- `rate`
- `contact`
- `bookingRef`
- `pickupConfirmation`
- `completionConfirmation`
- `completedAt`
- `cancelledAt`
- `cancellationReason`
- `cancelledBy`

##### Confirmation subdocuments

- `pickupConfirmation.customerConfirmedAt`
- `pickupConfirmation.providerConfirmedAt`
- `completionConfirmation.customerConfirmedAt`
- `completionConfirmation.providerConfirmedAt`

### Operations data inside `users`

#### 1.16 `operationsProfile`

Fields:

- `fields[]`
- `activeOperations[]`
- `plannedOperations[]`
- `completedOperations[]`

Field entries contain:

- `id`
- `name`
- `area`
- `crop`
- `status`

Operation entries contain:

- `title`
- `field`
- `crop`
- `startDate`
- `completedDate`
- `duration`
- `progress`
- `workers`
- `equipment`
- `priority`
- `notes`
- `estimatedDuration`
- `status`
- `tasks[]`

Task entries contain:

- `id`
- `label`
- `icon`
- `completed`

### Indexes on `users`

Confirmed indexes from the schema:

- unique index on `email`
- partial unique index on `googleId`

The `googleId` index only applies when `googleId` is a string.

## 2. `marketplacepayments`

This collection stores checkout and payment state for marketplace purchases before and during fulfillment.

### Fields

| Field | Type | Description |
|---|---|---|
| `reference` | `String` | Unique payment reference |
| `status` | `String` | Payment lifecycle state |
| `paymentMethod` | `String` | Buyer-selected method |
| `paymentProvider` | `String` | Usually `xendit` |
| `buyerUserId` | `String` | Buyer id |
| `buyerName` | `String` | Buyer name |
| `buyerEmail` | `String` | Buyer email |
| `buyerPhone` | `String` | Buyer phone |
| `items` | `Array` | Purchased listing items |
| `subtotal` | `Number` | Subtotal |
| `tax` | `Number` | Tax |
| `shipping` | `Number` | Shipping |
| `total` | `Number` | Grand total |
| `checkoutUrl` | `String` | Xendit checkout URL |
| `xenditInvoiceId` | `String` | Xendit invoice id |
| `xenditInvoiceStatus` | `String` | Latest invoice status |
| `xenditWebhookPayload` | `Mixed` | Raw webhook payload |
| `paidAt` | `Date` | Payment confirmation date |
| `fulfillmentStatus` | `String` | Internal fulfillment state |
| `fulfilledAt` | `Date` | Fulfillment completion date |
| `releasedAt` | `Date` | Release date |
| `releasedOrderIds` | `String[]` | Order ids created or released |
| `fulfillmentFailureReason` | `String` | Failure details |
| `createdAt` | `Date` | Timestamp |
| `updatedAt` | `Date` | Timestamp |

### `status` enum

- `pending_checkout`
- `awaiting_payment`
- `paid`
- `expired`
- `failed`

### `fulfillmentStatus` enum

- `pending`
- `completed`
- `failed`

### Item subdocuments

Each marketplace payment item contains:

- `id`
- `name`
- `category`
- `seller`
- `sellerUserId`
- `listingId`
- `selectedVarietyId`
- `quantity`
- `unit`
- `price`
- `total`

### Indexes

- unique index on `reference`

## 3. `laborpayments`

Stores payment, booking-release, and refund data for labor transactions.

### Fields

- `reference`
- `status`
- `paymentMethod`
- `paymentProvider`
- buyer identity fields
- worker identity fields
- booking snapshot fields
- `bookingId`
- `rate`
- `subtotal`
- `tax`
- `total`
- `checkoutUrl`
- `xenditInvoiceId`
- `xenditInvoiceStatus`
- `xenditWebhookPayload`
- `paidAt`
- `bookingCreatedAt`
- `releasedAt`
- `releaseStatus`
- `releaseFailureReason`
- `refundStatus`
- `refundedAt`
- `metadata`
- `createdAt`
- `updatedAt`

### `status` enum

- `pending_checkout`
- `awaiting_payment`
- `paid`
- `booking_created`
- `expired`
- `failed`
- `ready_for_release`
- `released`
- `release_pending`
- `release_failed`
- `refunded`

### `releaseStatus` enum

- `not_ready`
- `ready`
- `pending`
- `released`
- `failed`

### `refundStatus` enum

- `not_requested`
- `refunded`

### Important indexes

- unique index on `reference`
- index on `buyerUserId`
- index on `workerUserId`
- index on `bookingId`
- index on `xenditInvoiceId`

## 4. `servicepayments`

Stores payment, booking-release, and refund data for rental or service transactions.

### Fields

- `reference`
- `status`
- `paymentMethod`
- `paymentProvider`
- buyer identity fields
- provider identity fields
- `listingId`
- `itemName`
- `itemUnit`
- booking snapshot fields
- `bookingRef`
- `rate`
- `subtotal`
- `tax`
- `total`
- `checkoutUrl`
- `xenditInvoiceId`
- `xenditInvoiceStatus`
- `xenditWebhookPayload`
- `paidAt`
- `bookingCreatedAt`
- `releasedAt`
- `releaseStatus`
- `releaseFailureReason`
- `refundStatus`
- `refundedAt`
- `metadata`
- `createdAt`
- `updatedAt`

### `status` enum

- `pending_checkout`
- `awaiting_payment`
- `paid`
- `booking_created`
- `expired`
- `failed`
- `ready_for_release`
- `released`
- `refunded`

### `releaseStatus` enum

- `not_ready`
- `ready`
- `pending`
- `released`
- `failed`

### `refundStatus` enum

- `not_requested`
- `refunded`

### Important indexes

- unique index on `reference`
- index on `buyerUserId`
- index on `providerUserId`
- index on `listingId`
- index on `bookingRef`
- index on `xenditInvoiceId`

## 5. `pendingregistrations`

This collection temporarily stores sign-up data before the user completes email verification.

The final `users` document is created only after registration verification succeeds.

### Fields

- `email` unique
- `name`
- `phone`
- `passwordHash`
- `role`
- `roles`
- `accountType`
- `profile.firstName`
- `profile.middleName`
- `profile.lastName`
- `emailVerification.code`
- `emailVerification.expiresAt`
- `emailVerification.requestedAt`
- `createdAt`
- `updatedAt`

### Purpose

This collection prevents unverified signups from being written directly into the main `users` collection.

## 6. `marketplace_hubs`

Stores logistics hub metadata used by marketplace routing logic.

### Fields

- `provider`
- `code`
- `name`
- `type`: `sorting` or `delivery`
- `address`
- `province`
- `city`
- `barangay`
- `serviceAreas[]`
- `coordinates.lat`
- `coordinates.lng`
- `metadata`
- `active`
- `createdAt`
- `updatedAt`

### Indexes

- unique sparse index on `{ provider, code }`
- compound index on `{ provider, type, city, province }`
- index on `{ active }`

## 7. `platformsettings`

Stores platform-wide configurable values.

### Fields

- `key` unique
- `value` mixed
- `updatedBy`
- `createdAt`
- `updatedAt`

### Current documented setting key

- `wallet_cashout_real_enabled`

This controls whether real wallet cash-out behavior is enabled.

## Relationships and Data Flow

## User-centered aggregate design

AgriHub stores many operational subdocuments directly under the `users` collection:

- seller listings
- buyer purchases
- seller sales
- labor profile and labor bookings
- service listings and service bookings
- wallet transactions

This means many user-facing views can be built from a single aggregate user document.

## Payment-to-order relationship

- `marketplacepayments.reference` links payment checkout to marketplace order creation
- marketplace orders also store `paymentReference`
- `laborpayments.bookingId` links payment records to embedded labor bookings
- `servicepayments.bookingRef` links payment records to embedded service bookings

## Verification and admin review relationship

- `users.verification.seller`
- `users.verification.laborer`

These are reviewed by admins and determine whether the user can operate in those roles.

## Logistics relationship

- logistics hub metadata comes from `marketplace_hubs`
- actual route snapshots and simulation state are embedded inside `users.marketplaceOrders.*[].logistics`

## Operational Notes

### 1. Mixed normalized and denormalized design

The database uses both:

- normalized collections for payments and shared settings
- denormalized embedded arrays in `users` for user-facing marketplace, labor, and service data

This improves read convenience for dashboards and detail modals, but requires synchronized updates across buyer and seller records in some flows.

### 2. Embedded order duplication

Marketplace orders are stored in two places:

- buyer side: `users.marketplaceOrders.purchases`
- seller side: `users.marketplaceOrders.sales`

Both records represent the same logical order and must remain synchronized.

### 3. Embedded booking duplication

Labor and service bookings can exist:

- in buyer/customer booking arrays
- in provider/worker booking arrays
- in separate payment collections

### 4. Temporary registration staging

Unverified registration data lives in `pendingregistrations` until verification completes.

### 5. Wallet is embedded

Wallet balance and wallet transaction history are embedded in `users.wallet`, not stored in a separate `wallets` collection.

## Suggested Documentation Use

This file can be used as the base for:

- thesis or capstone database documentation
- tester reference for field-level validation
- admin maintenance reference
- developer onboarding for backend and data model work

If you want, I can also turn this into:

- an ERD-style relationship document
- a collection-by-collection table in Word format
- a tester checklist for validating each collection with sample documents
